using ExitGames.Client.Photon;
using GameMessages;
using System.Collections.Generic;
using UnityEngine;

public class AntiAfkSystem : MonoBehaviour
{
	public enum AntiAFK
	{
		AFK,
		Dissconnect,
		Negative
	}

	public static AntiAfkSystem Inst;

	private Dictionary<string, double> m_DisconnectList = new Dictionary<string, double>();

	public int AFKTimer = 120;

	private bool Inited;

	private bool Recording;

	private bool m_Notified;

	private double LastInputTime;

	private double startTime;

	public GameObject NotifyUI;

	private GameObject m_CurrentNotifyUI;

	private bool IsSent;

	private int m_PlayerCount;

	private GameMode m_Mode;

	private void Awake()
	{
		if (Inst != null)
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
		else
		{
			Inst = this;
		}
	}

	public void OnStartup()
	{
		Init();
		CancelInvoke();
		InvokeRepeating("AFKChecker", 0f, 1f);
	}

	private void Init()
	{
		if (PhotonNetwork.inRoom)
		{
			PhotonNetwork.player.SetCustomProperties(new Hashtable
			{
				{
					"AFK",
					0
				}
			});
			m_PlayerCount = PhotonNetwork.room.PlayerCount;
			m_Mode = GameRuntime.GameMode;
		}
		m_DisconnectList.Clear();
		m_Notified = false;
		LastInputTime = 0.0;
		startTime = 0.0;
		Recording = false;
		Inited = false;
		IsSent = false;
		m_CurrentNotifyUI = null;
	}

	private void OnDestroy()
	{
		CancelInvoke();
		m_DisconnectList.Clear();
		m_DisconnectList = null;
		if (Inst == this)
		{
			Inst = null;
		}
	}

	private void Update()
	{
		if (Recording && Input.GetMouseButton(0))
		{
			SetLastInputTime();
		}
		if (Input.GetMouseButtonDown(0) && m_CurrentNotifyUI != null)
		{
			m_CurrentNotifyUI.SetActive(value: false);
		}
	}

	private void AFKChecker()
	{
		if (!PhotonNetwork.inRoom || m_PlayerCount <= 1)
		{
			CancelInvoke();
			return;
		}
		if (!m_Mode.Equals(GameMode.Match))
		{
			CancelInvoke();
			return;
		}
		if (GameRuntime.IsNormalGameOver)
		{
			CloseNotifyUI();
			CancelInvoke();
			return;
		}
		if (InGameWitness.Inst != null)
		{
			CancelInvoke();
			return;
		}
		if (!Inited)
		{
			if (PhotonNetwork.player.IsMasterClient)
			{
				double time = PhotonNetwork.time;
				PhotonNetwork.room.SetCustomProperties(new Hashtable
				{
					{
						"StartTime",
						time
					},
					{
						"DisconnectList",
						0
					}
				});
			}
			Inited = true;
			Recording = true;
			return;
		}
		if (startTime == 0.0)
		{
			if (!PhotonNetwork.room.CustomProperties.ContainsKey("StartTime"))
			{
				PhotonNetwork.room.SetCustomProperties(new Hashtable
				{
					{
						"StartTime",
						startTime
					}
				});
			}
			else
			{
				startTime = double.Parse(PhotonNetwork.room.CustomProperties["StartTime"].ToString());
				if (PhotonNetwork.time - startTime > 5.0)
				{
					LastInputTime = PhotonNetwork.time;
				}
			}
		}
		double num = PhotonNetwork.time - startTime;
		if (LastInputTime > 0.0)
		{
			if (!m_Notified)
			{
				if (PhotonNetwork.time - LastInputTime > (double)(0.5f * (float)AFKTimer))
				{
					PopNotified();
				}
			}
			else if (PhotonNetwork.time - LastInputTime > (double)(0.5f * (float)AFKTimer))
			{
				MarkAsAfkPlayer(AntiAFK.AFK, PhotonNetwork.player.UserId);
			}
		}
		else if (num > (double)AFKTimer)
		{
			MarkAsAfkPlayer(AntiAFK.AFK, PhotonNetwork.player.UserId);
		}
		else if (num > (double)(0.5f * (float)AFKTimer))
		{
			PopNotified();
		}
	}

	private void PopNotified()
	{
		m_Notified = true;
		if (LocalPlayerDatabase.Settings.idleSysOpen && m_Notified)
		{
			if (m_CurrentNotifyUI == null)
			{
				GameObject gameObject = GameObject.Find("UI");
				m_CurrentNotifyUI = UnityEngine.Object.Instantiate(NotifyUI, gameObject.transform);
				m_CurrentNotifyUI.SetActive(value: true);
			}
			else
			{
				m_CurrentNotifyUI.SetActive(value: true);
			}
		}
		LastInputTime = PhotonNetwork.time;
	}

	private void CloseNotifyUI()
	{
		if (m_CurrentNotifyUI != null)
		{
			m_CurrentNotifyUI.SetActive(value: false);
		}
	}

	private void MarkAsAfkPlayer(AntiAFK Result, string userID)
	{
		Recording = false;
		switch (Result)
		{
		case AntiAFK.AFK:
			UpdateResultToRoomProperties(2);
			SentReport(LocalPlayerDatabase.LoginInfo.roleID, 2);
			CancelInvoke();
			break;
		case AntiAFK.Negative:
			UpdateResultToRoomProperties(1);
			SentReport(LocalPlayerDatabase.LoginInfo.roleID, 1);
			CancelInvoke();
			break;
		case AntiAFK.Dissconnect:
			if (PhotonNetwork.isMasterClient)
			{
				int num = (int)PhotonNetwork.room.CustomProperties["DisconnectList"];
				num |= 1 << UserId2NumId.Get(userID);
				PhotonNetwork.room.SetCustomProperties(new Hashtable
				{
					{
						"DisconnectList",
						num
					}
				});
				SentDisconnectReport(GameRuntime.RoomPlayers[userID].RoleID, 1);
			}
			GameRuntime.PlayersState[userID].IsHangUp = true;
			break;
		}
	}

	public void SetLastInputTime()
	{
		LastInputTime = PhotonNetwork.time;
	}

	public void SetDisconnect(string userID, bool isInactive)
	{
		if (!m_DisconnectList.ContainsKey(userID) && !isInactive)
		{
			return;
		}
		if (isInactive)
		{
			if (!m_DisconnectList.ContainsKey(userID))
			{
				m_DisconnectList.Add(userID, PhotonNetwork.time);
			}
		}
		else if (m_DisconnectList.ContainsKey(userID))
		{
			if (PhotonNetwork.time - m_DisconnectList[userID] > (double)AFKTimer)
			{
				MarkAsAfkPlayer(AntiAFK.Dissconnect, userID);
			}
			else
			{
				m_DisconnectList.Remove(userID);
			}
			LastInputTime = PhotonNetwork.time;
		}
	}

	public void UpdateResultToRoomProperties(int type)
	{
		PhotonNetwork.player.SetCustomProperties(new Hashtable
		{
			{
				"AFK",
				type
			}
		});
	}

	public void SentReport(uint userId, int type)
	{
		if (!IsSent)
		{
			IsSent = true;
			HttpRequestIdle httpRequestIdle = new HttpRequestIdle();
			httpRequestIdle.reportRoleId = userId;
			httpRequestIdle.reportType = type;
			GameHttpManager.Inst.SendNoWait(httpRequestIdle);
		}
	}

	public void SentDisconnectReport(uint userId, int type)
	{
		HttpRequestIdle httpRequestIdle = new HttpRequestIdle();
		httpRequestIdle.reportRoleId = userId;
		httpRequestIdle.reportType = type;
		GameHttpManager.Inst.SendNoWait(httpRequestIdle);
	}

	public void GetResult()
	{
		if (!PhotonNetwork.inRoom || m_PlayerCount <= 1)
		{
			CancelInvoke();
			return;
		}
		CloseNotifyUI();
		if (PlayerController.Inst != null && PlayerController.Inst.Negtive && PhotonNetwork.time - startTime > (double)AFKTimer)
		{
			MarkAsAfkPlayer(AntiAFK.Negative, PhotonNetwork.player.UserId);
		}
		int num = 0;
		if (PhotonNetwork.room.CustomProperties.ContainsKey("DisconnectList"))
		{
			num = (int)PhotonNetwork.room.CustomProperties["DisconnectList"];
		}
		PhotonPlayer[] playerList = PhotonNetwork.playerList;
		foreach (PhotonPlayer photonPlayer in playerList)
		{
			if (photonPlayer.CustomProperties.ContainsKey("AFK") && (int)photonPlayer.CustomProperties["AFK"] > 0)
			{
				GameRuntime.PlayersState[photonPlayer.UserId].IsHangUp = true;
			}
			int num2 = UserId2NumId.Get(photonPlayer.UserId);
			if ((num & (1 << num2)) == 1 << num2)
			{
				GameRuntime.PlayersState[photonPlayer.UserId].IsOffline = true;
				GameRuntime.PlayersState[photonPlayer.UserId].IsHangUp = true;
			}
		}
		foreach (KeyValuePair<string, RuntimePlayerInfo> roomPlayer in GameRuntime.RoomPlayers)
		{
			if (m_DisconnectList.ContainsKey(roomPlayer.Key) && PhotonNetwork.time - m_DisconnectList[roomPlayer.Key] > (double)AFKTimer)
			{
				GameRuntime.PlayersState[roomPlayer.Key].IsOffline = true;
				GameRuntime.PlayersState[roomPlayer.Key].IsHangUp = true;
				if (PhotonNetwork.isMasterClient)
				{
					SentDisconnectReport(GameRuntime.RoomPlayers[roomPlayer.Key].RoleID, 3);
				}
			}
		}
		m_DisconnectList.Clear();
		m_PlayerCount = 0;
	}
}
