using LightUI;
using System;
using UnityEngine;
using UnityEngine.Events;

public class CharacterRootShareDisplay : MonoBehaviour
{
	private Canvas[] m_Canvas;

	private UIStateItem m_UIStatement;

	private void Start()
	{
		m_Canvas = base.gameObject.GetComponentsInChildren<Canvas>();
		m_UIStatement = base.gameObject.GetComponent<UIStateItem>();
	}

	private void Update()
	{
	}

	private void OnEnable()
	{
		UILobby current = UILobby.Current;
		current.OnPopup = (UnityAction<UIPopup>)Delegate.Combine(current.OnPopup, new UnityAction<UIPopup>(SetFalse));
		UILobby current2 = UILobby.Current;
		current2.OnGoBack = (UnityAction<UILobbyElement>)Delegate.Combine(current2.OnGoBack, new UnityAction<UILobbyElement>(SetTrue));
	}

	private void OnDisable()
	{
		UILobby current = UILobby.Current;
		current.OnPopup = (UnityAction<UIPopup>)Delegate.Remove(current.OnPopup, new UnityAction<UIPopup>(SetFalse));
		UILobby current2 = UILobby.Current;
		current2.OnGoBack = (UnityAction<UILobbyElement>)Delegate.Remove(current2.OnGoBack, new UnityAction<UILobbyElement>(SetTrue));
	}

	private void SetFalse(UIPopup m_UI)
	{
		Canvas[] canvas = m_Canvas;
		for (int i = 0; i < canvas.Length; i++)
		{
			canvas[i].enabled = false;
		}
		m_UIStatement.m_Items[m_UIStatement.State].gameObject.SetActive(value: false);
	}

	private void SetTrue(UILobbyElement m_UI)
	{
		Canvas[] canvas = m_Canvas;
		for (int i = 0; i < canvas.Length; i++)
		{
			canvas[i].enabled = true;
		}
		m_UIStatement.m_Items[m_UIStatement.State].gameObject.SetActive(value: true);
	}
}
