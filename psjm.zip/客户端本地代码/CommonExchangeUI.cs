using GameMessages;
using LightUI;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UI;

internal class CommonExchangeUI
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollViewTop;

	public Text m_Desc;

	public Text m_TimeText;

	private string m_TimeFormat;

	protected int m_activityId;

	private Dictionary<int, bool> m_tempTipsOpenData = new Dictionary<int, bool>();

	private static Dictionary<int, bool> m_RedPoint = new Dictionary<int, bool>();

	private HttpResponseExchangeActivityInfo m_HttpResponseExchangeActivityInfo;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_TimeText.text;
		}
		Activity activity = args["Activity"].val as Activity;
		m_Desc.text = LocalResources.ActivityLobbyInfos.Get(activity.activityId).Desc;
		m_TimeText.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		m_activityId = activity.activityId;
		HttpRequestExchangeActivityInfo httpRequestExchangeActivityInfo = new HttpRequestExchangeActivityInfo();
		httpRequestExchangeActivityInfo.activityId = activity.activityId;
		GameHttpManager.Inst.Send(httpRequestExchangeActivityInfo, delegate(HttpResponseExchangeActivityInfo OnHttpResponse)
		{
			m_HttpResponseExchangeActivityInfo = OnHttpResponse;
			SetItemsInfo(OnHttpResponse);
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	protected void OnDisable()
	{
		SaveTipsOpenDate();
	}

	private void SetItemsInfo(HttpResponseExchangeActivityInfo response)
	{
		bool redPoint = GetRedPoint(m_activityId);
		CommonDataCollection arg = new CommonDataCollection();
		Dictionary<int, ExchangeActivityInfo> dictionary = new Dictionary<int, ExchangeActivityInfo>();
		Dictionary<int, ExchangeActivityInfo> dictionary2 = new Dictionary<int, ExchangeActivityInfo>();
		Dictionary<int, ExchangeActivityInfo> dictionary3 = new Dictionary<int, ExchangeActivityInfo>();
		bool flag = false;
		for (int i = 0; i < response.ids.Length; i++)
		{
			ExchangeActivityInfo exchangeActivityInfo = LocalResources.ExchangeActivityInfo.Get(response.ids[i]);
			if (response.exchangeTimes[i] < exchangeActivityInfo.Limit)
			{
				if (exchangeActivityInfo.Rank == 0)
				{
					dictionary.Add(i, exchangeActivityInfo);
				}
				else
				{
					dictionary2.Add(i, exchangeActivityInfo);
				}
				bool state = false;
				if (!HaveLocalTipsOpenData(response.ids[i], out state))
				{
					state = response.tipsOpen[i];
				}
				if (!flag && state && CheckEnough(exchangeActivityInfo))
				{
					flag = true;
				}
			}
			else if (exchangeActivityInfo.Rank == 0)
			{
				dictionary.Add(i, exchangeActivityInfo);
			}
			else
			{
				dictionary3.Add(i, exchangeActivityInfo);
			}
		}
		WrapperData(dictionary, response, ref arg);
		WrapperData(dictionary2, response, ref arg);
		WrapperData(dictionary3, response, ref arg);
		m_DataScrollViewTop.SetItems(arg.Array);
		if (flag != redPoint)
		{
			RefreshRedPoint(m_activityId, flag);
		}
	}

	private void WrapperData(Dictionary<int, ExchangeActivityInfo> date, HttpResponseExchangeActivityInfo OnHttpResponse, ref CommonDataCollection arg)
	{
		date = (from k in date
			orderby k.Value.Rank
			select k).ToDictionary((KeyValuePair<int, ExchangeActivityInfo> k) => k.Key, (KeyValuePair<int, ExchangeActivityInfo> v) => v.Value);
		foreach (KeyValuePair<int, ExchangeActivityInfo> item in date)
		{
			int arraySize = arg.ArraySize;
			arg[arraySize]["info"].val = item.Value;
			arg[arraySize]["activityId"] = m_activityId;
			arg[arraySize]["exchangeTime"] = OnHttpResponse.exchangeTimes[item.Key];
			arg[arraySize]["tipsOpen"] = OnHttpResponse.tipsOpen[item.Key];
			arg[arraySize]["CommonExchangeUI"].val = this;
		}
	}

	private void SaveTipsOpenDate()
	{
		if (m_tempTipsOpenData.Count > 0)
		{
			List<int> list = new List<int>();
			List<bool> list2 = new List<bool>();
			foreach (KeyValuePair<int, bool> tempTipsOpenDatum in m_tempTipsOpenData)
			{
				list.Add(tempTipsOpenDatum.Key);
				list2.Add(tempTipsOpenDatum.Value);
			}
			m_tempTipsOpenData.Clear();
			HttpRequestExchangeActivityTipsState httpRequestExchangeActivityTipsState = new HttpRequestExchangeActivityTipsState();
			httpRequestExchangeActivityTipsState.ids = list.ToArray();
			httpRequestExchangeActivityTipsState.tipsOpen = list2.ToArray();
			httpRequestExchangeActivityTipsState.activityId = m_activityId;
			GameHttpManager.Inst.SendNoWait(httpRequestExchangeActivityTipsState);
		}
	}

	public void OnTipsOpenToggleChange(int id, bool state)
	{
		if (m_tempTipsOpenData.ContainsKey(id))
		{
			m_tempTipsOpenData[id] = state;
		}
		else
		{
			m_tempTipsOpenData.Add(id, state);
		}
		if (m_HttpResponseExchangeActivityInfo == null)
		{
			return;
		}
		bool redPoint = GetRedPoint(m_activityId);
		bool flag = false;
		for (int i = 0; i < m_HttpResponseExchangeActivityInfo.ids.Length; i++)
		{
			ExchangeActivityInfo exchangeActivityInfo = LocalResources.ExchangeActivityInfo.Get(m_HttpResponseExchangeActivityInfo.ids[i]);
			if (!flag && m_HttpResponseExchangeActivityInfo.exchangeTimes[i] < exchangeActivityInfo.Limit)
			{
				bool flag2 = m_HttpResponseExchangeActivityInfo.tipsOpen[i];
				if (m_tempTipsOpenData.ContainsKey(m_HttpResponseExchangeActivityInfo.ids[i]))
				{
					flag2 = m_tempTipsOpenData[m_HttpResponseExchangeActivityInfo.ids[i]];
				}
				if (flag2 && CheckEnough(exchangeActivityInfo))
				{
					flag = true;
				}
			}
		}
		if (redPoint != flag)
		{
			RefreshRedPoint(m_activityId, flag);
		}
	}

	public bool HaveLocalTipsOpenData(int id, out bool state)
	{
		state = false;
		if (m_tempTipsOpenData.ContainsKey(id))
		{
			state = m_tempTipsOpenData[id];
			return true;
		}
		return false;
	}

	public static void RefreshRedPoint(int activityId, bool state = true)
	{
		if (m_RedPoint.ContainsKey(activityId))
		{
			m_RedPoint[activityId] = state;
		}
		else
		{
			m_RedPoint.Add(activityId, state);
		}
		ActivityLobby.InvokeActivityLobbyRedPointChange();
	}

	public static bool CheckEnough(ExchangeActivityInfo info)
	{
		for (int i = 0; i < info.NeedIds.Length; i++)
		{
			if (ShopUtility.GetCurrencyAmount(info.NeedIds[i]) < info.NeedCounts[i])
			{
				return false;
			}
		}
		return true;
	}

	public static bool GetRedPoint(int activityId)
	{
		if (ActivityLobby.GetActivityById(activityId) == null)
		{
			return false;
		}
		if (m_RedPoint.ContainsKey(activityId))
		{
			return m_RedPoint[activityId];
		}
		return false;
	}
}
