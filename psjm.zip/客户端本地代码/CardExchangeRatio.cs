using LightUtility;
using System;

[Serializable]
public class CardExchangeRatio : IdBased
{
	public int ResolveCount;

	public int ExchangeCount;
}
