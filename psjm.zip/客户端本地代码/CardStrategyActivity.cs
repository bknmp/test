using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CardStrategyActivity
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Content;

	public Text m_Time;

	public RectTransform m_PreviewAnchor;

	public static List<CardStrategyInfo> m_CardStratrgyList = new List<CardStrategyInfo>();

	private string m_TimeFormat;

	private UIDataBinder m_PreviewUIInst;

	private ActivityLobbyInfo m_ActivityInfo;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		m_CardStratrgyList.Clear();
		Activity activity = args["Activity"].val as Activity;
		m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		m_ActivityInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
		m_CardStratrgyList = LocalResources.CardStrategyTable.FindAll((CardStrategyInfo x) => x.CardID == m_ActivityInfo.Index && LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade >= x.LimitGrade[0] && LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade <= x.LimitGrade[1]);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < m_CardStratrgyList.Count; i++)
		{
			commonDataCollection[i]["index"] = i;
		}
		m_Content.Args = commonDataCollection;
		SetPreviewItem();
	}

	public void SetPreviewItem()
	{
		if (m_PreviewUIInst == null)
		{
			m_PreviewUIInst = ResManager.Instantiate<UIDataBinder>("PreviewItem");
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["ShowCardId"] = m_ActivityInfo.Index;
			commonDataCollection["DiffState"] = 1;
			m_PreviewUIInst.Args = commonDataCollection;
		}
	}
}
