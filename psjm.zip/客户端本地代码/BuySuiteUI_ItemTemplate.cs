using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class BuySuiteUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Toggle m_CheckBox;

	public Image m_Frame;

	public Image m_Icon;

	public Text m_Owned;

	private int m_Index;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["idx"];
		DataItem item = args["id"];
		DropItem dropItem = LocalResources.DropItemTable.Get(item);
		m_Frame.sprite = SpriteSource.Inst.Find(dropItem.Frame);
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		if (m_CheckBox != null && m_Owned != null)
		{
			m_CheckBox.isOn = BuySuiteUI.ItemSelected[m_Index];
			if (LocalPlayerDatabase.OwnPermanentSkinPart(dropItem.TypeParam))
			{
				m_CheckBox.gameObject.SetActive(value: false);
				m_Owned.gameObject.SetActive(value: true);
			}
			else
			{
				m_CheckBox.gameObject.SetActive(value: true);
				m_Owned.gameObject.SetActive(value: false);
			}
			m_CheckBox.onValueChanged.RemoveAllListeners();
			m_CheckBox.onValueChanged.AddListener(OnToggle);
		}
	}

	private void OnToggle(bool selected)
	{
		BuySuiteUI.ItemSelected[m_Index] = selected;
		UIDataEvents.Inst.InvokeEvent("OnSkinSuiteCountChagned");
	}
}
