public enum ConnectionState
{
	Disconnected,
	Connecting,
	Connected,
	Disconnecting,
	InitializingApplication
}
