using GameMessages;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class BlueDiamondManager : MonoBehaviour
{
	private Dictionary<uint, BlueVipInfo> m_Cache = new Dictionary<uint, BlueVipInfo>();

	private Dictionary<uint, List<Delegates.ObjectCallback<BlueVipInfo>>> m_Pending = new Dictionary<uint, List<Delegates.ObjectCallback<BlueVipInfo>>>();

	private BlueVipInfo m_PlayerBlueVipInfo;

	private bool m_IsAcquiring;

	private bool m_SelfAcquired;

	private static BlueDiamondManager _inst;

	private float m_NextAcquireTime;

	private float m_AcquireInterval = 1f;

	public static BlueDiamondManager Inst
	{
		get
		{
			if (_inst == null)
			{
				GameObject gameObject = new GameObject("BlueDiamondManager");
				ResManager.DontDestroyOnLoad(gameObject);
				_inst = gameObject.AddComponent<BlueDiamondManager>();
			}
			return _inst;
		}
	}

	public BlueVipInfo PlayerBlueVipInfo => m_PlayerBlueVipInfo;

	private void Update()
	{
		if (QQgameToDll.m_Openid != null && QQgameToDll.m_Openkey != null && LocalPlayerDatabase.LoginInfo != null && Time.time >= m_NextAcquireTime)
		{
			m_NextAcquireTime = Time.time + m_AcquireInterval;
			AcquireBlueVipBatch();
		}
	}

	public void RequestMyBlueVipInfo()
	{
		int platformID = WindowsSDKAdapter.Adapter.PlatformID;
		if (platformID == 2)
		{
			HttpRequestBlueVip httpRequestBlueVip = new HttpRequestBlueVip();
			httpRequestBlueVip.openID = QQgameToDll.m_Openid;
			httpRequestBlueVip.openKey = QQgameToDll.m_Openkey;
			GameHttpManager.Inst.Send(httpRequestBlueVip, OnBlueVipSelf);
		}
	}

	private void AcquireBlueVipBatch()
	{
		if (!m_IsAcquiring && m_Pending.Count > 0)
		{
			if (!m_SelfAcquired)
			{
				m_SelfAcquired = true;
				m_IsAcquiring = true;
				HttpRequestBlueVip httpRequestBlueVip = new HttpRequestBlueVip();
				httpRequestBlueVip.openID = QQgameToDll.m_Openid;
				httpRequestBlueVip.openKey = QQgameToDll.m_Openkey;
				GameHttpManager.Inst.SendNoWait(httpRequestBlueVip, OnBlueVipSelf, delegate
				{
					m_IsAcquiring = false;
					m_Pending.Remove(LocalPlayerDatabase.LoginInfo.roleID);
				});
				UnityEngine.Debug.Log("AcquireBlueVipBatch:Self");
			}
			else
			{
				uint[] batchList = new uint[m_Pending.Count];
				m_Pending.Keys.CopyTo(batchList, 0);
				m_IsAcquiring = true;
				HttpRequestBlueVipBatch httpRequestBlueVipBatch = new HttpRequestBlueVipBatch();
				httpRequestBlueVipBatch.openID = QQgameToDll.m_Openid;
				httpRequestBlueVipBatch.openKey = QQgameToDll.m_Openkey;
				httpRequestBlueVipBatch.roleIDs = batchList;
				GameHttpManager.Inst.SendNoWait(httpRequestBlueVipBatch, OnBlueVipBatch, delegate
				{
					m_IsAcquiring = false;
					for (int i = 0; i < batchList.Length; i++)
					{
						m_Pending.Remove(batchList[i]);
						if (!m_Cache.ContainsKey(batchList[i]))
						{
							m_Cache.Add(batchList[i], null);
						}
					}
				});
				UnityEngine.Debug.Log("AcquireBlueVipBatch:" + batchList.Length);
			}
		}
	}

	private void OnBlueVipSelf(HttpResponseBlueVip msg)
	{
		UpdateCache(LocalPlayerDatabase.LoginInfo.roleID, msg.info);
	}

	private void OnBlueVipBatch(HttpResponseBlueVipBatch msg)
	{
		for (int i = 0; i < msg.roleIDs.Length; i++)
		{
			uint roleId = msg.roleIDs[i];
			BlueVipInfo info = msg.infos[i];
			UpdateCache(roleId, info);
		}
	}

	private void UpdateCache(uint roleId, BlueVipInfo info)
	{
		if (roleId == LocalPlayerDatabase.LoginInfo.roleID)
		{
			LocalPlayerDatabase.PlayerInfo.publicInfo.vipInfo = info;
			m_PlayerBlueVipInfo = info;
		}
		if (info.pfID != (int)LocalPlayerDatabase.LoginPlatformID)
		{
			return;
		}
		AddToCache(roleId, info);
		if (!m_Pending.ContainsKey(roleId))
		{
			return;
		}
		List<Delegates.ObjectCallback<BlueVipInfo>> list = m_Pending[roleId];
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != null)
			{
				list[i](info);
			}
		}
		list.Clear();
	}

	private BlueVipInfo GetBlueVipInfo(uint roleID)
	{
		if (!m_Cache.ContainsKey(roleID))
		{
			return null;
		}
		return m_Cache[roleID];
	}

	public void AddToCache(uint roleID, BlueVipInfo info)
	{
		if (info.pfID == (int)LocalPlayerDatabase.LoginPlatformID)
		{
			if (m_Cache.ContainsKey(roleID))
			{
				m_Cache[roleID] = info;
			}
			else
			{
				m_Cache.Add(roleID, info);
			}
		}
		else if (m_Cache.ContainsKey(roleID))
		{
			m_Cache[roleID] = null;
		}
		else
		{
			m_Cache.Add(roleID, null);
		}
	}

	public void Acquire(uint roleID, Delegates.ObjectCallback<BlueVipInfo> onComplete)
	{
		if (QQgameToDll.m_Openid == null || QQgameToDll.m_Openkey == null)
		{
			onComplete(null);
			return;
		}
		if (m_Cache.ContainsKey(roleID))
		{
			onComplete(m_Cache[roleID]);
			return;
		}
		if (m_Pending.ContainsKey(roleID))
		{
			m_Pending[roleID].Add(onComplete);
			return;
		}
		List<Delegates.ObjectCallback<BlueVipInfo>> list = new List<Delegates.ObjectCallback<BlueVipInfo>>();
		list.Add(onComplete);
		m_Pending.Add(roleID, list);
	}
}
