using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CommonTaskUI : TaskActivityUI
{
	public Text m_Desc;

	public Text m_TimeText;

	private string m_TimeFormat;

	public new void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_TimeText.text;
		}
		m_Desc.text = LocalResources.ActivityLobbyInfos.Get(activity.activityId).Desc;
		m_TimeText.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		base.Bind(args);
		m_claimAction = delegate
		{
			m_Host.UpdateBinding();
			ActivityLobby.InvokeActivityLobbyRedPointChange();
		};
	}

	public static bool GetRedPoint(int activityId)
	{
		ActivityLobbyInfo activityInfo = new ActivityLobbyInfo();
		Activity activityById = ActivityLobby.GetActivityById(activityId, out activityInfo);
		if (activityById != null && LocalPlayerDatabase.GetPrefValueInt("CommonTask_" + activityId) != activityById.startTime)
		{
			return true;
		}
		return TaskUtility.CanReceiveTaskReward(activityId);
	}
}
