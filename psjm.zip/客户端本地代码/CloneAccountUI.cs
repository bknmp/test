using LightUI;
using UnityEngine.UI;

internal class CloneAccountUI
{
	public UIDataBinder m_Host;

	public Text m_TokenText;

	public Button m_CloneBtn;

	public Text m_TitleText;

	public Button m_downloadBtn;

	public void Bind(CommonDataCollection args)
	{
		if (!string.IsNullOrEmpty(LocalPlayerDatabase.LoginInfo.cloneAccountToken))
		{
			m_TokenText.text = LocalPlayerDatabase.LoginInfo.cloneAccountToken;
			m_Host.EventProxy(m_CloneBtn, "Clone");
			m_Host.EventProxy(m_downloadBtn, "DownLoad");
		}
	}

	public void Clone()
	{
		ClipboardTool.CopyToSystemClipboard(LocalPlayerDatabase.LoginInfo.cloneAccountToken);
		UILobby.Current.ShowTips(Localization.TipsCopyOK);
	}

	public void DownLoad()
	{
		AndroidUpdater.DoUpdate(999999, "http://update.ss.igreatdream.com/hide/apk_list/com.bairimeng.dmmdzz.apk", "");
	}
}
