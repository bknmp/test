using GameMessages;

public class ChatInfo
{
	public uint senderID;

	public string sender;

	public string content;

	public ChatChannel channel;

	public GameMessages.MembershipInfo[] membershipInfos;
}
