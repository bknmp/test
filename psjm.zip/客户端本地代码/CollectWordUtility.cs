using GameMessages;
using System.Collections.Generic;

public class CollectWordUtility
{
	public static List<ItemInfo> m_IngameCollectedWords = new List<ItemInfo>();

	private static int m_LastRefreshTime;

	public static void CollectWordIngame(int dropId)
	{
		for (int i = 0; i < m_IngameCollectedWords.Count; i++)
		{
			if (m_IngameCollectedWords[i].itemID == dropId)
			{
				m_IngameCollectedWords[i].itemCount++;
				return;
			}
		}
		ItemInfo itemInfo = new ItemInfo();
		itemInfo.itemID = dropId;
		itemInfo.itemCount = 1;
		m_IngameCollectedWords.Add(itemInfo);
	}
}
