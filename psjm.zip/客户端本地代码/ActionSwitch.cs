using BehaviorDesigner.Runtime.Tasks;

[TaskName("节点开关")]
[TaskCategory("考驾照功能")]
public class ActionSwitch : Action
{
	public Action referencedAction;

	public bool enable;

	public override TaskStatus OnUpdate()
	{
		referencedAction.Disabled = !enable;
		return TaskStatus.Success;
	}
}
