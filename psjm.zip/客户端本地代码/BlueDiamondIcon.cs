using GameMessages;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BlueDiamondIcon : MonoBehaviour
{
	private Image m_BlueDiamondImg;

	private Image m_BlueDiamondYearImg;

	private uint m_RoleID;

	public bool m_ShowBlue;

	public bool m_AutoAdjustSize;

	private Image FindIcon(int index)
	{
		if (index >= base.transform.childCount)
		{
			return null;
		}
		return base.transform.GetChild(index).GetComponent<Image>();
	}

	private void ShowBlueDiamond(BlueVipInfo info)
	{
		m_BlueDiamondImg = FindIcon(0);
		m_BlueDiamondYearImg = FindIcon(1);
		if (info == null || info.vipLevel == 0 || m_BlueDiamondImg == null || m_BlueDiamondYearImg == null)
		{
			base.gameObject.SetActive(value: false);
			m_ShowBlue = false;
			return;
		}
		base.gameObject.SetActive(value: true);
		m_ShowBlue = true;
		if (LocalPlayerDatabase.LoginPlatformID == PlatformID.QQGame)
		{
			int num = (!info.isSuperVip) ? 1 : 19;
			int num2 = 27;
			string arg = "BuleDiamondIcon_";
			m_BlueDiamondYearImg.gameObject.SetActive(info.isYearVip);
			m_BlueDiamondYearImg.preserveAspect = true;
			if (info.isYearVip)
			{
				m_BlueDiamondYearImg.sprite = SpriteSource.Inst.Find(arg + num2);
			}
			string name = arg + (num + info.vipLevel - 1);
			m_BlueDiamondImg.sprite = SpriteSource.Inst.Find(name);
			m_BlueDiamondImg.preserveAspect = true;
		}
		else if (LocalPlayerDatabase.LoginPlatformID == PlatformID.QQZone)
		{
			string str = "YellowDiamond_" + (info.isSuperVip ? "a" : "b");
			string str2 = info.isYearVip ? "y" : "";
			m_BlueDiamondYearImg.gameObject.SetActive(value: false);
			string name2 = str + info.vipLevel.ToString() + str2;
			m_BlueDiamondImg.sprite = SpriteSource.Inst.Find(name2);
			m_BlueDiamondImg.preserveAspect = true;
		}
		if (m_AutoAdjustSize)
		{
			AdjustSize(info);
		}
	}

	private void AdjustSize(BlueVipInfo info)
	{
		Text componentInChildren = base.transform.parent.GetComponentInChildren<Text>();
		if (!(componentInChildren != null))
		{
			return;
		}
		if (LocalPlayerDatabase.LoginPlatformID == PlatformID.QQGame)
		{
			if (m_BlueDiamondImg.sprite != null)
			{
				LayoutElement layoutElement = m_BlueDiamondImg.GetComponent<LayoutElement>();
				if (layoutElement == null)
				{
					layoutElement = m_BlueDiamondImg.gameObject.AddComponent<LayoutElement>();
				}
				layoutElement.preferredWidth = Mathf.Min(componentInChildren.fontSize + 2, 40);
				layoutElement.preferredHeight = Mathf.Min(componentInChildren.fontSize + 2, 35);
			}
			if (m_BlueDiamondYearImg.sprite != null)
			{
				LayoutElement layoutElement2 = m_BlueDiamondYearImg.GetComponent<LayoutElement>();
				if (layoutElement2 == null)
				{
					layoutElement2 = m_BlueDiamondYearImg.gameObject.AddComponent<LayoutElement>();
				}
				layoutElement2.preferredWidth = Mathf.Min(componentInChildren.fontSize + 2, 40);
				layoutElement2.preferredHeight = Mathf.Min(componentInChildren.fontSize + 2, 35);
			}
		}
		else if (LocalPlayerDatabase.LoginPlatformID == PlatformID.QQZone && m_BlueDiamondImg.sprite != null)
		{
			LayoutElement layoutElement3 = m_BlueDiamondImg.GetComponent<LayoutElement>();
			if (layoutElement3 == null)
			{
				layoutElement3 = m_BlueDiamondImg.gameObject.AddComponent<LayoutElement>();
			}
			Vector2 size = m_BlueDiamondImg.sprite.rect.size;
			float num = size.x / size.y;
			layoutElement3.preferredHeight = Mathf.Clamp(componentInChildren.fontSize + 4, 26, 38);
			if (info.vipLevel == 8)
			{
				layoutElement3.preferredHeight *= 1.2f;
			}
			layoutElement3.preferredWidth = layoutElement3.preferredHeight * num;
		}
	}

	public void SetRoleID(uint roleID)
	{
		int platformID = WindowsSDKAdapter.Adapter.PlatformID;
		if (platformID == 2)
		{
			if (m_RoleID != roleID)
			{
				m_RoleID = roleID;
				base.gameObject.SetActive(value: false);
				m_ShowBlue = false;
				BlueDiamondManager.Inst.Acquire(roleID, ShowBlueDiamond);
			}
		}
		else
		{
			base.gameObject.SetActive(value: false);
		}
	}
}
