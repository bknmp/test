using GameMessages;
using LightUtility;
using System;
using System.Collections;
using UnityEngine;

public class CustomNotificationManager : MonoBehaviour
{
	public int m_NextDayTime = 12;

	public int m_LimitSeconds = 1800;

	public int m_NextTime1 = 13;

	public int m_NextTime2 = 19;

	private static CustomNotificationManager Ins;

	private void Awake()
	{
		if (Ins != null)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			return;
		}
		ResManager.DontDestroyOnLoad(base.gameObject);
		Ins = this;
	}

	private void OnApplicationPause(bool pause)
	{
		if (LocalPlayerDatabase.IsLogined)
		{
			if (pause)
			{
				RegisterBoxNotification();
			}
			else
			{
				StartCoroutine(DoForeground());
			}
		}
	}

	private IEnumerator DoForeground()
	{
		UnityLocalNotification.Instance.CleanAllNotification();
		yield return new WaitForEndOfFrame();
		LocalPlayerDatabase.RegisterNotifications();
	}

	private void RegisterBoxNotification()
	{
		DateTime nowDateTime = UtcTimeStamp.NowDateTime;
		DateTime d = new DateTime(nowDateTime.Year, nowDateTime.Month, nowDateTime.Day, m_NextDayTime, 0, 0).AddDays(1.0);
		int num = BoxUtility.HaveBoxUnlocking();
		if (BoxUtility.HaveBoxCanOpen())
		{
			NotificationLocalInfo notificationLocalInfo = LocalResources.NotificationLocalInfo.Get(100);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo.Id, m_LimitSeconds, notificationLocalInfo.Title, notificationLocalInfo.Desc, notificationLocalInfo.RepeatInterval);
			notificationLocalInfo = LocalResources.NotificationLocalInfo.Get(101);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo.Id, (int)(d - nowDateTime).TotalSeconds, notificationLocalInfo.Title, notificationLocalInfo.Desc, notificationLocalInfo.RepeatInterval);
		}
		else if (num > m_LimitSeconds)
		{
			NotificationLocalInfo notificationLocalInfo2 = LocalResources.NotificationLocalInfo.Get(100);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo2.Id, num, notificationLocalInfo2.Title, notificationLocalInfo2.Desc, notificationLocalInfo2.RepeatInterval);
			notificationLocalInfo2 = LocalResources.NotificationLocalInfo.Get(101);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo2.Id, (int)(d - nowDateTime).TotalSeconds, notificationLocalInfo2.Title, notificationLocalInfo2.Desc, notificationLocalInfo2.RepeatInterval);
		}
		else if (BoxUtility.HaveBoxCanBeUnlocked())
		{
			NotificationLocalInfo notificationLocalInfo3 = LocalResources.NotificationLocalInfo.Get(102);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo3.Id, m_LimitSeconds, notificationLocalInfo3.Title, notificationLocalInfo3.Desc, notificationLocalInfo3.RepeatInterval);
			notificationLocalInfo3 = LocalResources.NotificationLocalInfo.Get(103);
			UnityLocalNotification.Instance.SendNotification(notificationLocalInfo3.Id, (int)(d - nowDateTime).TotalSeconds, notificationLocalInfo3.Title, notificationLocalInfo3.Desc, notificationLocalInfo3.RepeatInterval);
		}
		CardLotteryInfo lotteryInfo = CardLotteryUtility.GetLotteryInfo(8);
		if (lotteryInfo != null)
		{
			if (lotteryInfo.IsFree())
			{
				NotificationLocalInfo notificationLocalInfo4 = LocalResources.NotificationLocalInfo.Get(106);
				UnityLocalNotification.Instance.SendNotification(notificationLocalInfo4.Id, m_LimitSeconds, notificationLocalInfo4.Title, notificationLocalInfo4.Desc, notificationLocalInfo4.RepeatInterval);
				notificationLocalInfo4 = LocalResources.NotificationLocalInfo.Get(107);
				UnityLocalNotification.Instance.SendNotification(notificationLocalInfo4.Id, (int)(d - nowDateTime).TotalSeconds, notificationLocalInfo4.Title, notificationLocalInfo4.Desc, notificationLocalInfo4.RepeatInterval);
			}
			else
			{
				NotificationLocalInfo notificationLocalInfo5 = LocalResources.NotificationLocalInfo.Get(107);
				UnityLocalNotification.Instance.SendNotification(notificationLocalInfo5.Id, Mathf.Max(lotteryInfo.nextFreeTime - UtcTimeStamp.Now, m_LimitSeconds), notificationLocalInfo5.Title, notificationLocalInfo5.Desc, notificationLocalInfo5.RepeatInterval);
			}
		}
	}

	public static void TryRegisterBoxNotification()
	{
		if (Ins != null && LocalPlayerDatabase.IsLogined)
		{
			Ins.RegisterBoxNotification();
		}
	}
}
