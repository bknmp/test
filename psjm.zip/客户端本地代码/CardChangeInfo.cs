using LightUtility;
using System;

[Serializable]
public class CardChangeInfo : IdBased
{
	public int CardID;

	public string Title;

	public string[] CardNames;

	public string[] CardIcons;

	public string[] CardDescs;

	public string[] Questions;

	public string[] Answers;
}
