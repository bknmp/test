using LightUtility;
using SimpleJson;
using UnityEngine;

public class Bubble : BouncingSkill
{
	[HideInInspector]
	public int Sleepiness;

	public GameObject m_NightmareFX;

	private GameObject m_NightmareFXInst;

	private float m_TalentCostCoin;

	public override bool ShowRingProgress
	{
		get
		{
			if (!m_Info.ShowRingProgress)
			{
				return m_State == 1;
			}
			return true;
		}
	}

	public bool IsStarting
	{
		get
		{
			if (InGameScene.Inst.GameTime - m_LastSkillTime < m_Info.Cooldown - 0.5f)
			{
				return m_LastSkillTime > 0f;
			}
			return false;
		}
	}

	public override void Initialize(PlayerController player, SkillInfo skillInfo)
	{
		base.Initialize(player, skillInfo);
		m_PlayerController.BuffManager.OnBuffRemoved += OnBuffRemoved;
		TalentManager.Talent talent = m_PlayerController.TalentManager.GetTalent(131);
		if (talent != null)
		{
			m_TalentCostCoin = talent.Param;
			if (m_TalentCostCoin > 0f)
			{
				ChangeCoinCost((int)m_TalentCostCoin);
			}
		}
	}

	public override bool CanClickSkill(bool active, object[] parameters = null)
	{
		if (!base.Activating && !active && parameters != null && !IsStarting)
		{
			return true;
		}
		if (base.Activating && m_State == 1)
		{
			return true;
		}
		return false;
	}

	public override void LocalSkill(bool active, object[] parameters = null)
	{
		base.LocalSkill(active, parameters);
		if (!base.Activating && !active && parameters != null && !IsStarting)
		{
			if (!m_PlayerController.BuffManager.ContainsBuff(522))
			{
				Sleepiness++;
				if (Sleepiness < 3)
				{
					CreateBubble();
					StartSkill(0f);
					EndSkill();
				}
				else
				{
					m_State = 1;
					ChangeCoinCost(0);
					CreateBubble();
					StartSkill(m_Info.Cooldown);
					m_PreCooldownTime = InGameScene.Inst.GameTime - m_Info.Cooldown;
				}
			}
			else
			{
				CreateBubble();
				StartSkill(0f);
				EndSkill();
			}
		}
		else if (base.Activating && m_State == 1)
		{
			m_PlayerController.BuffManager.RemoveCorrelatedBuff(521);
			Sleepiness = 0;
			m_PlayerController.BuffManager.CreateCorrelatedBuff(m_PlayerController, 522, BuffCorrelation.Talent, 133, overrideDuration: true);
			EndSkill();
			SpawnNightmareFX();
			m_LastSkillTime = 0f;
		}
	}

	protected new void Update()
	{
		base.Update();
		UpdateVisible();
		if (!m_PlayerController.BuffManager.ContainsBuff(522))
		{
			OnBuffRemoved(522);
		}
	}

	private void UpdateVisible()
	{
		bool isVisible = m_PlayerController.IsVisible;
		if (m_NightmareFXInst != null && m_NightmareFXInst.activeSelf != isVisible)
		{
			m_NightmareFXInst.SetActive(isVisible);
		}
	}

	private void OnBuffRemoved(int id)
	{
		if (id == 522 && m_NightmareFXInst != null)
		{
			PoolSpawner.DeSpawn(m_NightmareFXInst);
			m_NightmareFXInst = null;
		}
	}

	private void CreateBubble()
	{
		if (PhotonNetwork.isMasterClient)
		{
			object[] data = new object[5]
			{
				m_PlayerController.UserId,
				m_PreviewPos,
				0,
				m_PreviewDir,
				0
			};
			PhotonNetwork.InstantiateSceneObject(m_PreviewPrefab.name, m_PreviewPos, Quaternion.identity, 0, data);
		}
		m_PlayerController.m_Animator.SetTrigger((m_PlayerController.SpeedForAnimator > 0.1f) ? "skill" : "skill_all");
	}

	private void SpawnNightmareFX()
	{
		m_NightmareFXInst = PoolSpawner.Spawn(m_NightmareFX, m_PlayerController.transform);
		m_NightmareFXInst.transform.localPosition = Vector3.zero;
	}

	public override void StartSkill(float duration, float delay = 0f)
	{
		m_StartTime = InGameScene.Inst.GameTime;
		m_Duration = duration;
		m_Delay = delay;
		m_SkillEndTime = 0f;
		m_PreCooldownTime = 0f;
		m_LastSkillTime = base.StartTime;
	}

	public override void EndSkill()
	{
		base.EndSkill();
		ChangeCoinCost((int)m_TalentCostCoin);
	}

	public override void OnReSyncWrite(object data)
	{
		base.OnReSyncWrite(data);
		(data as JsonObject)["sleepiness"] = Sleepiness;
	}

	public override void OnReSyncRead(object data)
	{
		base.OnReSyncRead(data);
		JsonObject jsonObject = data as JsonObject;
		Sleepiness = jsonObject.AsInt("sleepiness");
		if (m_PlayerController.BuffManager.ContainsBuff(522))
		{
			SpawnNightmareFX();
		}
	}
}
