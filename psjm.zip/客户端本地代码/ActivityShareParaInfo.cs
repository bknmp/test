using LightUtility;
using System;

[Serializable]
public class ActivityShareParaInfo : IdBased
{
	public int ActivityId;

	public int Grade;

	public int[] Param;

	public string Type;

	public string ItemId;

	public string ItemNum;

	public string Url;

	public string LocalFile;

	public string TextColor;
}
