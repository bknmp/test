using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CommonLoginActivityRewardUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Image m_RewardPreview;

	public Text m_ItemName;

	public Text m_ItemCount;

	public UITipsDialogController m_Tips;

	public GameObject m_AvailabFX;

	public Button m_DetailBtn;

	public UIPage m_PreviewDetailUI;

	public UIStateImage m_FrameBG;

	public GameObject m_Hot;

	public Text m_HotPoint;

	public UIStateImage m_BG;

	private CommonDataCollection m_args;

	private int m_ActivityId;

	private int m_Index;

	private int m_RewardIndex;

	private string m_CountText;

	private string m_CustomItemName;

	private DropItem m_RewardInfo;

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		m_ActivityId = m_args["activityId"];
		m_Index = m_args["index"];
		m_RewardIndex = m_args["rewardIndex"];
		CommonLoginActivityRewardInfo commonLoginActivityRewardInfo = LocalResources.CommonLoginActivityRewardTable.Find((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(m_ActivityId) && x.Days.Equals(m_Index));
		m_RewardInfo = LocalResources.DropItemTable.Get(commonLoginActivityRewardInfo.ItemId[m_RewardIndex]);
		m_CountText = commonLoginActivityRewardInfo.CountForUI[m_RewardIndex].ToString();
		m_CustomItemName = commonLoginActivityRewardInfo.Tips;
		if ((bool)m_BG)
		{
			m_BG.State = m_args["canClaim"];
		}
		InitIcon();
		TextHandle();
		AvailableHandle();
		ClaimHandle();
		QualityHandle();
		TipsHandle();
		GiftHandle();
		m_Host.EventProxy(m_DetailBtn, "OnClickDetailBtn");
	}

	private void InitIcon()
	{
		m_RewardPreview.sprite = SpriteSource.Inst.Find(m_RewardInfo.Icon);
	}

	private void TextHandle()
	{
		if (string.IsNullOrEmpty(m_CustomItemName))
		{
			if ((bool)m_ItemName)
			{
				m_ItemName.text = m_RewardInfo.Name;
			}
		}
		else if ((bool)m_ItemName)
		{
			m_ItemName.text = m_CustomItemName;
		}
		if ((bool)m_ItemCount)
		{
			m_ItemCount.text = "x" + m_CountText;
		}
	}

	private void QualityHandle()
	{
		if (m_FrameBG != null)
		{
			m_FrameBG.State = m_RewardInfo.Quality;
		}
	}

	private void TipsHandle()
	{
		if (LocalResources.ShopSuiteTable.Get(m_RewardInfo.Id).Name != null)
		{
			ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(m_RewardInfo.Id);
			m_Tips.SetTips(shopSuiteInfo.BubbleTips);
			m_DetailBtn.gameObject.SetActive(value: true);
		}
		else
		{
			m_Tips.SetDropItemTips(m_RewardInfo.Id);
			m_DetailBtn.gameObject.SetActive(m_RewardInfo.Type == DropItemType.SkinPart || m_RewardInfo.Type == DropItemType.CardSkin || m_RewardInfo.Type == DropItemType.IngameEmotion);
		}
	}

	private void GiftHandle()
	{
		if (m_Hot != null)
		{
			if (m_RewardInfo.Type == DropItemType.Gift)
			{
				m_Hot.SetActive(value: true);
				GiftInfo giftInfo = LocalResources.GiftInfo.Get(m_RewardInfo.TypeParam);
				m_HotPoint.text = giftInfo.HotPoint.ToString();
			}
			else
			{
				m_Hot.SetActive(value: false);
			}
		}
	}

	private void AvailableHandle()
	{
		m_AvailabFX.gameObject.SetActive(CommonLoginActivityUtility.isRewardAvailable(m_ActivityId, m_Index));
	}

	private void ClaimHandle()
	{
		if (CommonLoginActivityUtility.isRewardReceive(m_ActivityId, m_Index))
		{
			m_AvailabFX.SetActive(value: false);
		}
	}

	public void OnClickDetailBtn()
	{
		CommonDataCollection argWarpper = PreviewDetailUI.GetArgWarpper(m_RewardInfo.Id, string.Empty, string.Empty, 0, 0, string.Empty, null);
		UILobby.Current.ShowUI(m_PreviewDetailUI, argWarpper);
	}
}
