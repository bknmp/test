public class BouncingSkill : PlaceableSkill
{
}
