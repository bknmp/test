using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChatPageFriends
{
	public UIDataBinder m_Host;

	public GameObject m_ChatViewPort;

	public GameObject m_Tips;

	public UIDataScrollView m_DataScrollView;

	public GameObject m_FriendEmpty;

	public GameObject m_ChatPageFriends;

	public InputField m_InputField;

	public Button m_EmojiBuntton;

	private ChatPanel m_ChatPanel;

	public void Bind(CommonDataCollection args)
	{
		EmojiItem.SetChatInput(m_InputField);
		m_Host.EventProxy(m_EmojiBuntton, "OnEmojiButtonClicked");
		m_ChatPanel = m_ChatPageFriends.GetComponentInParent<ChatPanel>();
		m_ChatViewPort.SetActive(ChatPanel.m_ChatUIInst != null);
		m_Tips.SetActive(value: false);
		m_FriendEmpty.SetActive(value: false);
		OnRefreshView();
	}

	private void OnRefreshView()
	{
		SocialUtility.GetFriendIDs(onlyOnline: false, delegate(List<SocialUtility.FollowingInfo> v)
		{
			v.Sort(SocialUtility.FollowingComparer_UnreadTime);
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < v.Count; i++)
			{
				commonDataCollection[i]["roleID"] = v[i].roleID;
				commonDataCollection[i]["online"] = v[i].onlineStatus;
			}
			if (commonDataCollection.ArraySize > 0)
			{
				m_Tips.SetActive(ChatPanel.m_ChatUIInst == null);
				m_DataScrollView.SetItems(commonDataCollection.Array);
				m_DataScrollView.m_TemplateInitiator.UpdateImmediately(withChildren: true);
				if (ChatPageFriends_ItemTemplate.Selected == 0)
				{
					m_DataScrollView.m_ScrollRect.ScrollToStart(immediately: true);
				}
				else
				{
					int num = -1;
					for (int j = 0; j < v.Count; j++)
					{
						if (ChatPageFriends_ItemTemplate.Selected == v[j].roleID)
						{
							num = j;
							break;
						}
					}
					if (num != -1)
					{
						m_DataScrollView.m_ScrollRect.ScrollToItem(num);
					}
				}
			}
			else
			{
				m_DataScrollView.ClearItems();
				m_FriendEmpty.SetActive(value: true);
				m_Tips.SetActive(value: false);
				m_ChatViewPort.SetActive(value: false);
			}
		});
	}

	public void OnEmojiButtonClicked()
	{
		if (m_ChatPanel != null)
		{
			m_ChatPanel.ToggleEmojiPanel();
		}
	}
}
