using DG.Tweening;
using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using UnityEngine;

internal class CommonProgressActivity_FlyEffect : CommonProgressActivity
{
	public GameObject m_OldCardFlyEffect;

	public GameObject m_PointerEffect;

	public GameObject m_MaskPart;

	private GameObject m_FlyEffectStartGo;

	private Coroutine m_flyEffectCoroutine;

	private Delegates.IntCallback m_OnEffectComplete;

	private Tween m_Tween;

	public new void Bind(CommonDataCollection args)
	{
		m_FlyEffectStartGo = (args["FlyEffectStartGo"].val as GameObject);
		args.Remove("FlyEffectStartGo");
		m_updateAction = (args["ProgressUpdateAction"].val as Action);
		m_activity = (args["Activity"].val as Activity);
		m_PointNumGrow = m_PointerText.GetComponent<UINumberGrow>();
		int addScoresCount = args["addScoresCount"];
		if (args.ContainsKey("OnPreviewCallBack"))
		{
			m_OnPreviewCallBack = (args["OnPreviewCallBack"].val as Action<int>);
		}
		if (m_FlyEffectStartGo == null)
		{
			UpdateInfo();
		}
		else
		{
			m_flyEffectCoroutine = m_Host.StartCoroutine(ShowFlyEffect(addScoresCount, m_FlyEffectStartGo.transform.position, m_PointerText.transform, null, OnFlyEffectComplete));
		}
	}

	private IEnumerator ShowFlyEffect(int addScoresCount, Vector3 startPosition, Transform endTrans, Delegates.VoidCallback OnEachComplete = null, Delegates.IntCallback OnAllComplete = null)
	{
		if (m_OnEffectComplete == null)
		{
			m_OnEffectComplete = OnFlyEffectComplete;
		}
		m_MaskPart.SetActive(value: true);
		AssetFlyEffect component = PoolSpawner.Spawn(m_OldCardFlyEffect).GetComponent<AssetFlyEffect>();
		yield return component.Show(1, startPosition, endTrans, null, delegate
		{
			if (m_OnEffectComplete != null)
			{
				m_OnEffectComplete(addScoresCount);
			}
		});
	}

	private void OnFlyEffectComplete(int count)
	{
		int num = m_HttpResponseCache.point + count;
		m_PointerEffect.SetActive(value: false);
		m_PointerEffect.SetActive(value: true);
		if (m_Tween != null)
		{
			m_Tween.Kill();
		}
		m_Tween = DOTween.To(() => int.Parse(m_PointerText.text), delegate(int x)
		{
			SetPointNum(x);
		}, num, 0.5f).OnComplete(delegate
		{
			m_MaskPart.SetActive(value: false);
		});
		if (m_ProgressBar != null)
		{
			m_ProgressBar.DOKill();
			m_ProgressBar.DOValue(GetProgressPos(num), 0.5f);
		}
	}

	private void SetPointNum(int point)
	{
		if (m_HttpResponseCache.point != point)
		{
			m_HttpResponseCache.point = point;
			m_PointNumGrow.SetNumber(m_HttpResponseCache.point);
			OnPointValueChanged(point);
		}
	}

	private void UpdateInfo()
	{
		if (m_TemplateInitiatorHorizontal != null)
		{
			m_TemplateInitiatorHorizontal.OnItemsChanged.RemoveListener(UpdateProgressPos);
			m_TemplateInitiatorHorizontal.OnItemsChanged.AddListener(UpdateProgressPos);
		}
		HttpRequestCommonProgressActivity httpRequestCommonProgressActivity = new HttpRequestCommonProgressActivity();
		m_Type = (int)CommonProgressActivity.GetCommonProgressActivityType(m_activity.activityId);
		httpRequestCommonProgressActivity.type = m_Type;
		GameHttpManager.Inst.Send(httpRequestCommonProgressActivity, delegate(HttpResponseCommonProgressActivity OnHttpResponse)
		{
			m_HttpResponseCache = OnHttpResponse;
			SetInfo();
			m_PointerText.text = m_HttpResponseCache.point.ToString();
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	private void OnPointValueChanged(int value)
	{
		foreach (UIDataBinder item in m_TemplateInitiatorHorizontal.Items)
		{
			CommonDataCollection args = item.Args;
			args["point"] = value;
			item.Args = args;
		}
	}

	private void OnDisable()
	{
		if (m_flyEffectCoroutine != null)
		{
			m_Host.StopCoroutine(m_flyEffectCoroutine);
		}
		m_PointerEffect.SetActive(value: false);
		m_MaskPart.SetActive(value: false);
		m_OnEffectComplete = null;
	}
}
