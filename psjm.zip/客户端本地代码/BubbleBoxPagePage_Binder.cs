using LightUI;
using System.Collections.Generic;

public class BubbleBoxPagePage_Binder
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollViewTop;

	public void Bind(CommonDataCollection args)
	{
		if (HeadBubbleBoxUtility.m_Category[args["category"]] != null)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			List<int> list = new List<int>(HeadBubbleBoxUtility.m_Category[args["category"]]);
			list.RemoveAll((int bubbleBoxID) => (LocalResources.DropItemTable.Get(LocalResources.HeadBubbleBoxInfos.Get(bubbleBoxID).TypeParam).Type == DropItemType.BubbleBox) ? (!HeadBubbleBoxUtility.IsOpen(bubbleBoxID)) : true);
			list.Sort(delegate(int x, int y)
			{
				HeadBubbleBoxInfo headBubbleBoxInfo = LocalResources.HeadBubbleBoxInfos.Get(x);
				HeadBubbleBoxInfo headBubbleBoxInfo2 = LocalResources.HeadBubbleBoxInfos.Get(y);
				return -HeadBubbleBoxUtility.hasHeadOrBubble(headBubbleBoxInfo.Id).CompareTo(HeadBubbleBoxUtility.hasHeadOrBubble(headBubbleBoxInfo2.Id)) * 2 + headBubbleBoxInfo.Rank.CompareTo(headBubbleBoxInfo2.Rank);
			});
			for (int i = 0; i < list.Count; i++)
			{
				commonDataCollection[i]["bubbleBoxID"] = list[i];
			}
			m_DataScrollViewTop.SetItems(commonDataCollection.Array);
		}
	}
}
