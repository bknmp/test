using UnityEngine;

public class ActivityTypeScript : MonoBehaviour
{
	public ActivityType m_ActivityType;
}
