using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterUI : UIEventListener
{
	[Serializable]
	public class CharacterAudio
	{
		public int characterID;

		public AudioItem audioItem;
	}

	public Vector3 m_ProjectionOffset;

	public float m_TweenDuration = 0.3f;

	public UITabPage m_TabPage;

	public GameObject m_Mask;

	public UITweenElement m_MovieEffect;

	public GameObject m_SetActiveEffect;

	public List<CharacterAudio> m_CharacterAudio;

	private List<int> skinPartIds;

	public static bool IsShowing;

	public static int SelectedTabIndex;

	private new void Awake()
	{
		base.Awake();
		UIDataEvents.Inst.AddEventListener("OnCharacterSelectedChange", this, OnCharacterSelectedChange);
		GetComponent<UIPage>().SetTag(LobbyScene.Mode.Normal.ToString());
	}

	private void OnDestroy()
	{
		CharacterUI_ColorTemplate.SelectedItem = null;
		IsShowing = false;
	}

	private CameraOffCenterProjection GetOffCenterProjection()
	{
		CameraOffCenterProjection cameraOffCenterProjection = LobbyScene.Inst.NormalCamera.GetComponent<CameraOffCenterProjection>();
		if (cameraOffCenterProjection == null)
		{
			cameraOffCenterProjection = LobbyScene.Inst.NormalCamera.gameObject.AddComponent<CameraOffCenterProjection>();
		}
		return cameraOffCenterProjection;
	}

	public override void OnEnterUI()
	{
		IsShowing = true;
		UpdateCurSkinPartID();
		NewSkinPartTips.Inst.CheckOutOfDate();
		NewIngameEmotionTips.Inst.CheckOutOfDate();
		NewLightnessTips.Inst.CheckOutOfDate();
		m_TabPage.m_ResetOnEnable = false;
	}

	public override void OnExitUI()
	{
		IsShowing = false;
		SoundManager.StopNarrator();
		m_TabPage.m_ResetOnEnable = true;
	}

	private void OnEnable()
	{
		AutoHideLobbyCharacter.ReleaseHiding(force: true);
		if (CharacterUI_SelectCharacterItemTemplate.globalSelected <= 0)
		{
			CharacterUI_SelectCharacterItemTemplate.globalSelected = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
		}
		PreviewUtility.PreviewCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		m_MovieEffect.gameObject.SetActive(value: false);
		if (!IsShowing && !CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			StartCoroutine(TryShowEntrance());
		}
		else
		{
			HideMask();
			SetCameraOffCenter();
		}
		LobbyScene.Inst.ResetView();
	}

	private void OnDisable()
	{
		TrySaveSkinPart();
		CharacterUtility.RevertCurrentColors();
		PreviewUtility.RevertAllPreview();
	}

	private void SetCameraOffCenter()
	{
		if (LobbyScene.Inst != null)
		{
			CameraOffCenterProjection offCenterProjection = GetOffCenterProjection();
			offCenterProjection.enabled = true;
			offCenterProjection.TweenOffset(m_ProjectionOffset, m_TweenDuration);
		}
	}

	public void TrySaveSkinPart()
	{
		if (!CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			return;
		}
		PlayerCharacterInfo ownedCharacterInfo = CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		int num = 0;
		while (true)
		{
			if (num < ownedCharacterInfo.currentSkinInfo.skinPartIDs.Length)
			{
				if (ownedCharacterInfo.currentSkinInfo.skinPartIDs[num] != skinPartIds[num])
				{
					break;
				}
				num++;
				continue;
			}
			return;
		}
		CharacterUtility.SetSkinPart(new List<int>(ownedCharacterInfo.currentSkinInfo.skinPartIDs));
	}

	public void UpdateCurSkinPartID()
	{
		skinPartIds = new List<int>(CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected).currentSkinInfo.skinPartIDs);
	}

	private void OnCharacterSelectedChange()
	{
		if (!base.gameObject.activeSelf)
		{
			return;
		}
		if (SelectedTabIndex == 4 && !CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			PreviewUtility.PreviewCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected, force: true);
			m_MovieEffect.gameObject.SetActive(value: false);
			StartCoroutine(TryShowEntrance(fromInside: true));
			LobbyScene.Inst.ResetView();
		}
		else
		{
			CharacterAudio characterAudio = m_CharacterAudio.Find((CharacterAudio x) => x.characterID == CharacterUI_SelectCharacterItemTemplate.globalSelected);
			if (characterAudio != null)
			{
				SoundManager.PlayNarrator(characterAudio.audioItem);
			}
		}
	}

	public void JumpStoreUI()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.Store);
	}

	public void GoBack()
	{
		if (TeamRoomUI.IsShowing || !CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			GetComponent<UIPage>().GoBack();
		}
		else if (!CharacterUtility.IsActiveCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			UILobby.Current.ShowMessageBoxYesNo(Localization.MsgBoxSetActiveCharacter, Localization.TipsSetActive, Localization.No, Localization.MsgBoxTitle, delegate
			{
				CharacterUtility.SetActiveCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
				PoolSpawner.Spawn(m_SetActiveEffect, LobbyScene.Inst.CurrentCharacter.transform);
				UILobby.Current.GoBack();
			}, delegate
			{
				UILobby.Current.GoBack();
			});
		}
		else
		{
			UILobby.Current.GoBack();
		}
	}

	private IEnumerator TryShowEntrance(bool fromInside = false)
	{
		CameraOffCenterProjection offCenterProjection = GetOffCenterProjection();
		offCenterProjection.enabled = true;
		offCenterProjection.offset = Vector3.zero;
		LobbyScene.Inst.LockCamera = true;
		if (fromInside)
		{
			List<UITweenElement> group = GetComponent<UITweenElement>().m_Group;
			for (int i = 0; i < group.Count; i++)
			{
				group[i].DeActiveUI(UITweenManager.Default);
			}
		}
		m_MovieEffect.ActiveUI(UITweenManager.Default);
		ShowMask();
		LobbyScene.Inst.CurrentCharacter.StartLobbyEntrance();
		yield return new WaitForSeconds(2.2f);
		SetCameraOffCenter();
		HideMask();
		LobbyScene.Inst.LockCamera = false;
		m_MovieEffect.DeActiveUI(UITweenManager.Default);
		if (fromInside)
		{
			List<UITweenElement> group2 = GetComponent<UITweenElement>().m_Group;
			for (int j = 0; j < group2.Count; j++)
			{
				group2[j].ActiveUI(UITweenManager.Default);
			}
			m_TabPage.SetSelectedTabIndex(3);
		}
		yield return new WaitForSeconds(0.2f);
		m_MovieEffect.gameObject.SetActive(value: false);
		CharacterAudio audio = m_CharacterAudio.Find((CharacterAudio x) => x.characterID == CharacterUI_SelectCharacterItemTemplate.globalSelected);
		yield return new WaitForSeconds(0.1f);
		if (audio != null)
		{
			SoundManager.PlayNarrator(audio.audioItem);
		}
	}

	private void ShowMask()
	{
		m_Mask.SetActive(value: true);
		UILobby.Current.GetComponent<GraphicRaycaster>().enabled = false;
		GetComponent<UITweenElement>().m_DelayTime = 2.2f;
	}

	private void HideMask()
	{
		m_Mask.SetActive(value: false);
		UILobby.Current.GetComponent<GraphicRaycaster>().enabled = true;
		GetComponent<UITweenElement>().m_DelayTime = 0f;
	}
}
