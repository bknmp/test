using LightUtility;

public class ActivityLobbyInfo : IdBased
{
	public string TabName;

	public ActivityType Type;

	public string Prefab;

	public string TitleName;

	public int Rank;

	public string Desc;

	public ActivityCollectionType CollectionType;

	public int[] PreviewActivityIDs;

	public string TimeDesc;

	public int version;

	public int gradeLimit;

	public int Index;

	public int startTime;

	public int endTime;

	public int exchangeEndTime;

	public int MobileTimeOffset;

	public int EndTime => endTime + MobileTimeOffset;
}
