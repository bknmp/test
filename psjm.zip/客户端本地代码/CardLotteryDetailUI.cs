using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CardLotteryDetailUI
{
	public UIDataBinder m_Host;

	public Text m_NewCardActivityTips;

	private string m_NewCardActivityTipsFormat;

	public void Bind(CommonDataCollection args)
	{
		ActivityLobbyInfo activityInfo = new ActivityLobbyInfo();
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.BUY_NEW_CARD_DIRECT, ActivityCollectionType.NEW_CARD_ACTIVITY, out activityInfo);
		m_NewCardActivityTips.gameObject.SetActive(activityByActivityTypeAndCollectionType != null);
		if (m_NewCardActivityTips.gameObject.activeSelf)
		{
			if (string.IsNullOrEmpty(m_NewCardActivityTipsFormat))
			{
				m_NewCardActivityTipsFormat = m_NewCardActivityTips.text;
			}
			m_NewCardActivityTips.text = string.Format(m_NewCardActivityTipsFormat, LocalResources.InGameStoreTable.Get(activityInfo.Index).FullName);
		}
	}
}
