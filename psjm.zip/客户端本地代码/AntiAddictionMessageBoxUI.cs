using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class AntiAddictionMessageBoxUI
{
	public UIDataBinder m_Host;

	public Text m_Message;

	public MultiTargetGraphicButton m_ChangeButton;

	public Button m_Logout;

	public Button m_OK;

	public Button m_GoCertify;

	public Button m_CloseButton;

	public Button m_TipsBg;

	public Button m_CountDown;

	public UIStateItem m_State;

	private Text m_CountDownText;

	private string m_CountDownFormat;

	private int m_DelayTime = 15;

	private Coroutine m_CountDownQuit;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_GoCertify, "OnChangeCertification");
		m_Host.EventProxy(m_Logout, "OnLogOut");
		m_Host.EventProxy(m_ChangeButton, "OnChangeCertification");
		m_Host.EventProxy(m_CloseButton, "OnShowTips");
		m_Host.EventProxy(m_TipsBg, "OnTipsClicked");
		m_Host.EventProxy(m_CountDown, "QuitGame");
		m_Message.text = (args["message"].val as string);
		DataItem item = args["IsGobackOrQuit"];
		m_Logout.gameObject.SetActive(!item && CanLogOut());
		m_OK.gameObject.SetActive(item);
		m_CloseButton.gameObject.SetActive(value: false);
		m_CountDown.gameObject.SetActive(!item);
		m_CountDownText = m_CountDown.GetComponentInChildren<Text>();
		m_TipsBg.gameObject.SetActive(value: false);
		m_State.State = 0;
		m_GoCertify.gameObject.SetActive(!AntiAddictionUtility.Verified);
		m_ChangeButton.gameObject.SetActive(AntiAddictionUtility.Verified && AntiAddictionUtility.CanReVerify());
		TryStartCountDown();
	}

	private void OnDestroy()
	{
		if (AntiAddictionSystem.Inst != null)
		{
			AntiAddictionSystem.Inst.SetShowingPopup(val: false);
		}
	}

	public void OnShowTips()
	{
		m_State.State = 1;
	}

	private void TryStartCountDown()
	{
		if (m_CountDown.gameObject.activeSelf)
		{
			if (m_CountDownFormat == null)
			{
				m_CountDownFormat = m_CountDownText.text;
			}
			m_CountDownQuit = m_Host.StartCoroutine(ButtonCountDown(m_DelayTime));
		}
	}

	private IEnumerator ButtonCountDown(int time)
	{
		while (time > 0)
		{
			m_CountDownText.text = string.Format(m_CountDownFormat, time);
			yield return Yielders.GetWaitForSeconds(1f);
			time--;
		}
		QuitGame();
	}

	public void QuitGame()
	{
		Application.Quit();
	}

	public void OnLogOut()
	{
		UILobby.Current.ShowMessageBoxYesNo(Localization.TipsLogoutConfirm, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, LoadingUI.DoLogout, null);
	}

	public void OnTipsClicked()
	{
		if (LocalPlayerDatabase.Settings.RNSUseSelfSystem == 1)
		{
			OnChangeCertification();
		}
		else
		{
			m_State.State = 0;
		}
	}

	public void OnChangeCertification()
	{
		if (AndroidSDKAdapter.AndroidChannel == AndroidChannel.HUAWEI)
		{
			UILobby.Current.ShowTips(string.Format(Localization.TipsVerifyByChannel));
			return;
		}
		bool force = !AntiAddictionUtility.Verified;
		if (m_CountDownQuit != null)
		{
			m_Host.StopCoroutine(m_CountDownQuit);
		}
		AntiAddictionUtility.TryShowVerify(delegate
		{
			TryGoBack(force);
		}, delegate
		{
			TryStartCountDown();
		});
	}

	private void TryGoBack(bool force)
	{
		if ((m_OK.gameObject.activeSelf || AntiAddictionUtility.IsAudlt) | force)
		{
			m_Host.GetComponent<UIPopup>().GoBack();
		}
		else
		{
			TryStartCountDown();
		}
	}

	private bool CanLogOut()
	{
		if (!(AndroidSDKAdapter.ChannelName == "TMGP"))
		{
			return AndroidSDKAdapter.OfficialLogin;
		}
		return true;
	}
}
