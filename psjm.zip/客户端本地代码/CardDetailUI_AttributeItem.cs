using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardDetailUI_AttributeItem
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public Text m_AttributeDesc;

	public Text m_AttributeValue;

	public Text m_ChangeValue;

	public GameObject m_UIFX;

	public UIStateItem m_BG;

	private bool m_IsPreview;

	private Color m_OriginalColor = new Color(1f, 1f, 1f, 1f);

	private Color m_assetEnoughColor = new Color(98f / 255f, 76f / 85f, 0.470588237f, 1f);

	private Color m_assetNotEnoughColor = new Color(191f / 255f, 191f / 255f, 191f / 255f, 191f / 255f);

	private Color m_assetPreviewColor = new Color(13f / 255f, 46f / 51f, 83f / 85f, 1f);

	public void Bind(CommonDataCollection args)
	{
		m_IsPreview = args["IsPreview"];
		if (m_IsPreview)
		{
			m_AttributeValue.text = args["PreviewValue"];
			m_AttributeValue.color = (args["IsHighlight"] ? m_assetPreviewColor : m_OriginalColor);
			m_ChangeValue.gameObject.SetActive(value: false);
			m_UIFX.gameObject.SetActive(value: false);
		}
		else
		{
			m_AttributeValue.text = args["AttrValue"];
			m_AttributeValue.color = m_OriginalColor;
			m_ChangeValue.text = args["AttrChange"];
			m_ChangeValue.color = (args["AssetEnough"] ? m_assetEnoughColor : m_assetNotEnoughColor);
			m_ChangeValue.gameObject.SetActive(!string.IsNullOrEmpty(m_ChangeValue.text));
			m_UIFX.gameObject.SetActive(args["AssetEnough"]);
		}
		m_AttributeDesc.text = args["AttrDesc"];
		m_Icon.sprite = SpriteSource.Inst.Find(args["AttrIcon"]);
		m_BG.State = ((!string.IsNullOrEmpty(m_ChangeValue.text) && (bool)args["AssetEnough"]) ? 1 : 0);
	}
}
