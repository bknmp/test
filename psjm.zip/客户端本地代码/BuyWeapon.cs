using BehaviorDesigner.Runtime.Tasks;

[TaskName("购买武器")]
[TaskCategory("躲猫猫AI/普通行为")]
[TaskDescription("购买武器，如果没带武器卡或者金币不足，返回failure")]
public class BuyWeapon : Action
{
	public SharedAIController ai;

	public override TaskStatus OnUpdate()
	{
		int num = ai.Value.PlayerController.FindWeaponID();
		if (num > 0 && ai.Value.BuyWeapon(num))
		{
			return TaskStatus.Success;
		}
		return TaskStatus.Failure;
	}
}
