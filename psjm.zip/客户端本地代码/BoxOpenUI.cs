using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class BoxOpenUI
{
	public UIDataBinder m_Host;

	public ChangeBoxSprite m_Box;

	public Animator m_BoxAnimator;

	public Animator m_ItemAnimator;

	public Button m_ClickButton;

	public UIDataBinder m_BoxItem;

	public AudioItemData m_OpenAudio;

	public UITemplateInitiator m_SummaryItems;

	public GameObject m_Tips;

	public Text m_Num;

	public Text m_SummaryTitle;

	public GameObject m_ClickEffect;

	public GameObject m_Bg;

	public Text m_CardLotteryRemainText;

	public UIPopup m_AdCardButton;

	public UIToggleButton m_Skip;

	private const float SCROLLVIEW_HEIGHT_LONG = 681f;

	private const float SCROLLVIEW_HEIGHT_SHORT = 450f;

	private const float SCROLLVIEW_WIDTH_LONG = 1780f;

	private Queue<ItemInfo> m_ShowSequences = new Queue<ItemInfo>();

	private GameObject m_LastCard;

	private BoxInfo m_BoxItemInfo;

	private bool m_Summary;

	private bool m_IsPlaying;

	private const int ONE_LINE_NUM = 7;

	private int m_TotalCount;

	private float m_SummaryTime;

	public static bool IsShowing;

	private static bool m_IsCardLottery
	{
		get
		{
			if (!(LobbyScene.Inst != null))
			{
				return false;
			}
			return LobbyScene.Inst.m_CardLotteryPanel.Root.activeInHierarchy;
		}
	}

	public static bool Skip
	{
		get
		{
			if (m_IsCardLottery)
			{
				return LocalPlayerDatabase.GetPrefValue("CardLotterySkip");
			}
			return LocalPlayerDatabase.GetPrefValue("BoxSkip");
		}
		set
		{
			if (m_IsCardLottery)
			{
				LocalPlayerDatabase.SetPrefValue("CardLotterySkip", value);
			}
			else
			{
				LocalPlayerDatabase.SetPrefValue("BoxSkip", value);
			}
		}
	}

	public void Bind(CommonDataCollection args)
	{
		IsShowing = true;
		DataItem item = args["boxID"];
		ItemInfo[] array = (ItemInfo[])args["items"].val;
		m_TotalCount = array.Length;
		m_Box.gameObject.SetActive(!m_IsCardLottery);
		m_Box.m_Icon.color = Color.white;
		m_Bg.SetActive(!m_IsCardLottery);
		m_Skip.onButtonClicked.RemoveAllListeners();
		m_Skip.onButtonClicked.AddListener(OnSkipValueChanged);
		m_Skip.Toggle(Skip);
		m_BoxItemInfo = LocalResources.BoxTable.Find(item);
		m_ShowSequences.Clear();
		args.Clear();
		for (int i = 0; i < array.Length; i++)
		{
			m_ShowSequences.Enqueue(array[i]);
			args[i]["itemID"] = array[i].itemID;
			args[i]["itemCount"] = array[i].itemCount;
		}
		m_SummaryItems.Args = args;
		m_SummaryItems.UpdateImmediately();
		m_Summary = false;
		m_SummaryItems.transform.parent.transform.parent.transform.parent.gameObject.SetActive(value: false);
		GameObject gameObject = m_SummaryItems.transform.parent.transform.parent.gameObject;
		float x = 1780f;
		float y = 681f;
		gameObject.GetComponent<Image>().raycastTarget = false;
		if (m_IsCardLottery)
		{
			gameObject.GetComponent<Image>().raycastTarget = true;
			if (array.Length < 7)
			{
				x = 1780f * (float)array.Length / 7f;
				y = 450f;
			}
		}
		gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(x, y);
		m_Tips.SetActive(value: false);
		m_ClickEffect.SetActive(value: false);
		m_BoxItem.gameObject.SetActive(value: false);
		ShowCardNum(show: false);
		SetBoxInfo();
		m_Host.EventProxy(m_ClickButton, "OnContinueClicked");
	}

	public void OnContinueClicked()
	{
		if (!m_IsPlaying)
		{
			m_Host.StartCoroutine(Playing());
		}
	}

	private void SetBoxInfo()
	{
		m_Box.SetBoxId(m_BoxItemInfo.Id);
		if (Skip)
		{
			m_BoxAnimator.SetTrigger("BoxClick");
			ShowSummaryImmediately();
		}
		else
		{
			m_Host.StartCoroutine(DelayShowItem(m_IsCardLottery ? 0f : 0.8f));
		}
	}

	private void ShowCardNum(bool show)
	{
		m_Num.transform.parent.gameObject.SetActive(show);
		m_CardLotteryRemainText.transform.parent.gameObject.SetActive(m_IsCardLottery && show);
	}

	private void SetCardNum()
	{
		if (m_ShowSequences.Count > 0)
		{
			ShowCardNum(show: true);
			m_Num.text = m_ShowSequences.Count.ToString();
			m_CardLotteryRemainText.text = m_Num.text;
		}
		else
		{
			ShowCardNum(show: false);
		}
	}

	private IEnumerator DelayShowItem(float delay)
	{
		yield return new WaitForSeconds(delay);
		OnContinueClicked();
	}

	private void ShowItem(ItemInfo item)
	{
		SoundManager.PlayOnce(m_OpenAudio.Item);
		UIDataBinder uIDataBinder = Object.Instantiate(m_BoxItem, m_Host.transform, worldPositionStays: false);
		uIDataBinder.gameObject.SetActive(value: true);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["ItemInfo"].val = item;
		commonDataCollection["playAnim"] = true;
		uIDataBinder.Args = commonDataCollection;
		m_LastCard = uIDataBinder.gameObject;
	}

	private void DestroyLastCard()
	{
		if (m_LastCard != null)
		{
			UnityEngine.Object.Destroy(m_LastCard);
		}
	}

	private void ShowSummaryImmediately()
	{
		bool flag = false;
		while (m_ShowSequences.Count > 0)
		{
			m_ShowSequences.Dequeue();
			SetCardNum();
			flag = true;
		}
		if (flag)
		{
			SoundManager.PlayOnce(m_OpenAudio.Item);
		}
		DestroyLastCard();
		m_Host.StartCoroutine(ShowSummary(show: true));
	}

	private IEnumerator Playing()
	{
		m_IsPlaying = true;
		DestroyLastCard();
		if (m_ShowSequences.Count > 0)
		{
			m_ClickEffect.SetActive(value: false);
			m_ClickEffect.SetActive(value: true);
			ShowItem(m_ShowSequences.Dequeue());
			SetCardNum();
			if (m_IsCardLottery)
			{
				if (m_TotalCount > m_ShowSequences.Count)
				{
					CardLotteryUI.Inst.PlayAgain();
				}
			}
			else
			{
				m_BoxAnimator.SetTrigger("BoxClick");
			}
			yield return new WaitForSeconds(0.8f);
		}
		else if (!m_Summary)
		{
			yield return ShowSummary(show: true);
		}
		else if (Time.realtimeSinceStartup - m_SummaryTime > 1f)
		{
			GoBack();
		}
		m_IsPlaying = false;
	}

	private void GoBack()
	{
		IsShowing = false;
		BoxUtility.RefreshBoxList();
		LocalPlayerDatabase.RefreshAssetsInfo();
		m_Host.GetComponent<UILobbyElement>().GoBack();
		bool isCardLottery = m_IsCardLottery;
	}

	private IEnumerator ShowSummary(bool show)
	{
		m_Summary = show;
		m_SummaryItems.transform.parent.transform.parent.transform.parent.gameObject.SetActive(show);
		m_SummaryItems.gameObject.SetActive(show);
		m_SummaryTime = Time.realtimeSinceStartup;
		if (show)
		{
			m_SummaryTitle.gameObject.SetActive(value: false);
			yield return null;
			m_SummaryTitle.gameObject.SetActive(value: true);
			yield return new WaitForSeconds(0.3f);
			m_Tips.SetActive(value: true);
			yield return new WaitForSeconds(0.3f);
		}
		else
		{
			m_Tips.SetActive(value: false);
		}
	}

	public void TryShowAd()
	{
		if (m_BoxItemInfo.Type != 7 || !AdUtility.IsAdEnable(AdScene.CARD_DRAW))
		{
			return;
		}
		if (UtcTimeStamp.IsCrossDay(LocalPlayerDatabase.GetPrefValueInt("lastAdTime"), UtcTimeStamp.Now))
		{
			LocalPlayerDatabase.SetPrefValue("lastAdTime", UtcTimeStamp.Now);
			LocalPlayerDatabase.SetPrefValue("todayCardAd", 1);
		}
		else
		{
			if (LocalPlayerDatabase.GetPrefValueInt("todayCardAd") >= 3)
			{
				return;
			}
			LocalPlayerDatabase.SetPrefValue("todayCardAd", LocalPlayerDatabase.GetPrefValueInt("todayCardAd") + 1);
		}
		AdSDKManager.TryReportEvent(AdScene.CARD_DRAW, AdStatistics.Show);
		UILobby.Current.Popup(m_AdCardButton);
	}

	public void OnSkipValueChanged()
	{
		Skip = !Skip;
		m_Skip.Toggle(Skip);
		if (Skip)
		{
			ShowSummaryImmediately();
		}
	}
}
