using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using BehaviorDesigner.Runtime.Tasks.Basic.Math;
using UnityEngine;

public class CustomFloatComparison : Conditional
{
	public FloatComparison.Operation operation;

	public SharedFloat value;

	protected float CompareValue;

	public override TaskStatus OnUpdate()
	{
		switch (operation)
		{
		case FloatComparison.Operation.LessThan:
			if (!(CompareValue < value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case FloatComparison.Operation.LessThanOrEqualTo:
			if (!(CompareValue <= value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case FloatComparison.Operation.EqualTo:
			if (!Mathf.Approximately(CompareValue, value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case FloatComparison.Operation.NotEqualTo:
			if (Mathf.Approximately(CompareValue, value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case FloatComparison.Operation.GreaterThanOrEqualTo:
			if (!(CompareValue >= value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case FloatComparison.Operation.GreaterThan:
			if (!(CompareValue > value.Value))
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		default:
			return TaskStatus.Failure;
		}
	}
}
