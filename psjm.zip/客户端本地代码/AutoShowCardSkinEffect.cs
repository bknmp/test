using UnityEngine;

public class AutoShowCardSkinEffect : MonoBehaviour
{
	public GameObject m_Effect;

	private void OnEnable()
	{
		if (m_Effect != null && GetComponentInParent<CardDetailUI>() == null)
		{
			m_Effect.SetActive(value: true);
		}
	}
}
