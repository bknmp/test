using GameMessages;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CardSkinEditUI : MonoBehaviour
{
	private class LoadSkinPrefabPending
	{
		public string PrefabName;

		public Delegates.ObjectCallback<GameObject> OnFinishLoad;

		public int sort;
	}

	private class skinData
	{
		public int cardID;

		public int skinID;
	}

	private class styleData
	{
		public int skinID;

		public int styleID;
	}

	private List<skinData> m_oldSkinData;

	private List<styleData> m_oldStyleData;

	private static List<skinData> m_newSkinData;

	private List<styleData> m_newStyleData;

	private List<int> m_newCurSkinID = new List<int>();

	private Dictionary<int, int> m_newCurStylePair = new Dictionary<int, int>();

	private List<LoadSkinPrefabPending> m_LoadSkinPrefabPending = new List<LoadSkinPrefabPending>();

	private bool m_loading;

	private bool m_sorted;

	private float m_LastLoadTime;

	private void OnEnable()
	{
		m_newSkinData = new List<skinData>();
		m_oldSkinData = new List<skinData>();
		m_newStyleData = new List<styleData>();
		m_oldStyleData = new List<styleData>();
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardIDs.Length; i++)
		{
			skinData skinData = new skinData();
			skinData.cardID = LocalPlayerDatabase.PlayerInfo.cardIDs[i];
			skinData.skinID = LocalPlayerDatabase.PlayerInfo.cardCurSkin[i];
			m_oldSkinData.Add(skinData);
		}
		for (int j = 0; j < LocalPlayerDatabase.PlayerInfo.cardCurStyle.Length; j++)
		{
			styleData styleData = new styleData();
			styleData.skinID = LocalPlayerDatabase.PlayerInfo.cardOwnSkin[j];
			styleData.styleID = LocalPlayerDatabase.PlayerInfo.cardCurStyle[j];
			m_oldStyleData.Add(styleData);
		}
	}

	private void OnDisable()
	{
		ClearPending();
		bool num = CheckNewSkin();
		bool flag = CheckNewStyle();
		if (num || flag)
		{
			HttpRequestSetCardSkin httpRequestSetCardSkin = new HttpRequestSetCardSkin();
			httpRequestSetCardSkin.cardSkinID = m_newCurSkinID.ToArray();
			List<int> list = new List<int>();
			List<int> list2 = new List<int>();
			foreach (KeyValuePair<int, int> item in m_newCurStylePair)
			{
				list2.Add(item.Key);
				list.Add(item.Value);
			}
			httpRequestSetCardSkin.cardStyleID = list.ToArray();
			httpRequestSetCardSkin.styleRelatedSkinID = list2.ToArray();
			GameHttpManager.Inst.Send(httpRequestSetCardSkin, null);
		}
	}

	public void ClearPending()
	{
		m_LoadSkinPrefabPending.Clear();
	}

	private bool CheckNewSkin()
	{
		m_newCurSkinID.Clear();
		foreach (skinData newSkinDatum in m_newSkinData)
		{
			for (int i = 0; i < m_oldSkinData.Count; i++)
			{
				if (m_oldSkinData[i].cardID == newSkinDatum.cardID)
				{
					if (m_oldSkinData[i].skinID != newSkinDatum.skinID)
					{
						m_newCurSkinID.Add(newSkinDatum.skinID);
					}
					break;
				}
			}
		}
		return m_newCurSkinID.Count > 0;
	}

	private bool CheckNewStyle()
	{
		m_newCurStylePair.Clear();
		foreach (styleData newStyleDatum in m_newStyleData)
		{
			for (int i = 0; i < m_oldStyleData.Count; i++)
			{
				if (m_oldStyleData[i].skinID == newStyleDatum.skinID)
				{
					if (m_oldStyleData[i].styleID != newStyleDatum.styleID)
					{
						m_newCurStylePair.Add(newStyleDatum.skinID, newStyleDatum.styleID);
					}
					break;
				}
			}
		}
		return m_newCurStylePair.Count > 0;
	}

	public void LocalSetCardSkin(int cardID, int skinID)
	{
		CardUtility.SetCardSkin(cardID, skinID);
		foreach (skinData newSkinDatum in m_newSkinData)
		{
			if (newSkinDatum.cardID == cardID)
			{
				newSkinDatum.skinID = skinID;
				return;
			}
		}
		skinData skinData = new skinData();
		skinData.cardID = cardID;
		skinData.skinID = skinID;
		m_newSkinData.Add(skinData);
	}

	public void LocalSetCardStyle(int skinID, int styleID)
	{
		CardUtility.SetCardStyle(skinID, styleID);
		foreach (styleData newStyleDatum in m_newStyleData)
		{
			if (newStyleDatum.skinID == skinID)
			{
				newStyleDatum.styleID = styleID;
				return;
			}
		}
		styleData styleData = new styleData();
		styleData.skinID = skinID;
		styleData.styleID = styleID;
		m_newStyleData.Add(styleData);
	}

	public void Acquire(string prefabsName, Delegates.ObjectCallback<GameObject> onComplete, int sort)
	{
		if (m_LoadSkinPrefabPending.Find((LoadSkinPrefabPending x) => x.PrefabName == prefabsName) == null)
		{
			m_sorted = false;
			m_LoadSkinPrefabPending.Add(new LoadSkinPrefabPending
			{
				PrefabName = prefabsName,
				OnFinishLoad = onComplete,
				sort = sort
			});
			m_LastLoadTime = 0f;
		}
	}

	private void Update()
	{
		if (!m_sorted)
		{
			m_LoadSkinPrefabPending = (from x in m_LoadSkinPrefabPending
				orderby x.sort
				select x).ToList();
		}
		if (!m_loading && m_LoadSkinPrefabPending.Count > 0 && Time.realtimeSinceStartup - m_LastLoadTime > 0.25f)
		{
			StartLoadingSkinPrefab(m_LoadSkinPrefabPending[0]);
		}
	}

	private void StartLoadingSkinPrefab(LoadSkinPrefabPending pending)
	{
		m_loading = true;
		GameObject gameObject = ResourceSource.Load(pending.PrefabName);
		GameObject v = null;
		if (gameObject != null)
		{
			v = GameObjectUtility.Instantiate(gameObject, base.transform);
		}
		pending.OnFinishLoad(v);
		m_LoadSkinPrefabPending.RemoveAt(0);
		m_LastLoadTime = Time.realtimeSinceStartup;
		m_loading = false;
	}
}
