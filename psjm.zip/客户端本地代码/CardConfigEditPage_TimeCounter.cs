using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_TimeCounter
{
	public UIDataBinder m_Host;

	public Text m_TimeCounter;

	public void Bind(CommonDataCollection args)
	{
		int num = (int)args["expiredTime"].val;
		if (num < 0)
		{
			m_TimeCounter.text = Localization.NotOwn;
			return;
		}
		if (num == 0)
		{
			m_TimeCounter.text = Localization.Forever;
			return;
		}
		int num2 = num - UtcTimeStamp.Now;
		if (num2 > 0)
		{
			m_TimeCounter.text = GetTimeLeftText(num2);
			return;
		}
		m_TimeCounter.text = Localization.OutOfDate;
		args["expiredTime"] = -1;
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	private string GetTimeLeftText(int seconds)
	{
		seconds = Mathf.Max(seconds, 60);
		return string.Format(Localization.TimeLeft, UITimeText.GetFormatTimeShort(seconds, withAgo: false));
	}
}
