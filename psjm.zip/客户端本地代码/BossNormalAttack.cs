using UnityEngine;

public class BossNormalAttack : PlaceableObject
{
	public float m_MinDistance;

	private new void Awake()
	{
		base.Awake();
	}

	public override void StartPreview()
	{
		base.StartPreview();
		m_Root.SetActive(value: false);
		base.transform.localPosition = Vector3.zero;
		m_PreviewArea.transform.localPosition = base.transform.position + m_MinDistance * base.transform.forward;
		UpdatePreviewArea();
		if (m_PreviewColor != null)
		{
			m_PreviewColor.ForceUpdate();
		}
	}

	protected override void UpdatePreviewArea()
	{
		if (PlayerController.Inst != null)
		{
			Vector3 lhs = GetPreviewTouchWorldOffset(m_PlaceMaxDistanceMobile);
			if (lhs == Vector3.zero)
			{
				lhs = base.transform.forward;
			}
			base.PreviewPosition = base.transform.position + lhs.normalized * m_MinDistance;
		}
	}
}
