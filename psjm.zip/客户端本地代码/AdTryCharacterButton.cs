using LightUI;
using LightUtility;
using UnityEngine.UI;

public class AdTryCharacterButton : AdTryCharacterSuiteButton
{
	public Text m_CharacterName;

	public UIDataBinder[] m_TalentItems;

	public override void SetInfo(Delegates.VoidCallback onFinish, AdScene adScene)
	{
		base.SetInfo(onFinish, adScene);
		if (m_CharacterID > 0)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_CharacterID);
			int[] talentIDs = characterInfo.TalentIDs;
			m_CharacterName.text = characterInfo.Name;
			for (int i = 0; i < talentIDs.Length; i++)
			{
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				commonDataCollection["talentID"] = talentIDs[i];
				commonDataCollection["talentLevel"] = m_PlayerCharacterInfo.TalentLevels[i];
				m_TalentItems[i].Args = commonDataCollection;
			}
		}
	}
}
