using CustomRoom;
using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CreatePerfTestUI : MonoBehaviour
{
	public InputField m_RoomNameInputField;

	public ToggleGroup m_ModeLayout;

	public ToggleGroup m_MapLayout;

	public Slider m_ThiefSlider;

	public Slider m_PoliceSlider;

	public Button m_CreateButton;

	public Text m_ThiefCount;

	public Text m_PoliceCount;

	public GameObject m_ThiefSliderObj;

	public GameObject m_PoliceSliderObj;

	public GameObject m_BattleRoyaleMapToggle;

	public GameObject m_SkillModePanel;

	public InputField m_PropOrWeaponIDInputField;

	public InputField m_UseIntervalInputField;

	public GameObject m_RealSimulatePanel;

	public InputField m_PlayTimeInputField;

	[SerializeField]
	private bool m_IsOffline;

	private CreatePerfData m_CacheData;

	private IPerfTestUI m_UILogic;

	private const string m_CreatePerfDataKey = "CREATE_PERF_DATA_KEY";

	private void OnEnable()
	{
		string prefValueString = LocalPlayerDatabase.GetPrefValueString("CREATE_PERF_DATA_KEY");
		if (!string.IsNullOrEmpty(prefValueString))
		{
			m_CacheData = JsonUtility.FromJson<CreatePerfData>(prefValueString);
		}
		else
		{
			m_CacheData = new CreatePerfData();
		}
		if (null != m_CreateButton)
		{
			m_CreateButton.onClick.AddListener(OnCreateClick);
		}
		if (null != m_ThiefSlider)
		{
			m_ThiefSlider.onValueChanged.AddListener(OnThiefSliderChanged);
		}
		if (null != m_PoliceSlider)
		{
			m_PoliceSlider.onValueChanged.AddListener(OnPoliceSliderChanged);
		}
		if (null != m_ModeLayout)
		{
			ToggleGroupUtility.SetListener(m_ModeLayout, OnModeChanged);
		}
		if (null != m_MapLayout)
		{
			ToggleGroupUtility.SetListener(m_MapLayout, OnMapChanged);
		}
		if (null != m_RoomNameInputField)
		{
			m_RoomNameInputField.onValueChanged.AddListener(OnRoomNameChanged);
		}
		if (null != m_BattleRoyaleMapToggle)
		{
			m_BattleRoyaleMapToggle.SetActive(value: false);
		}
		SetUILogic();
	}

	private void OnDisable()
	{
		if (null != m_CreateButton)
		{
			m_CreateButton.onClick.RemoveListener(OnCreateClick);
		}
		if (null != m_ThiefSlider)
		{
			m_ThiefSlider.onValueChanged.RemoveListener(OnThiefSliderChanged);
		}
		if (null != m_PoliceSlider)
		{
			m_PoliceSlider.onValueChanged.RemoveListener(OnPoliceSliderChanged);
		}
		if (null != m_RoomNameInputField)
		{
			m_RoomNameInputField.onValueChanged.RemoveListener(OnRoomNameChanged);
		}
	}

	public void SetSliderValue(Slider slider, int minValue, int maxValue, int value)
	{
		if (!(null == slider))
		{
			slider.minValue = minValue;
			slider.maxValue = maxValue;
			slider.value = Mathf.Clamp(value, minValue, maxValue);
			slider.onValueChanged?.Invoke(slider.value);
		}
	}

	public void SetToggleGroupValue(ToggleGroup toggleGroup, int value)
	{
		if (!(null == toggleGroup))
		{
			Toggle[] componentsInChildren = toggleGroup.transform.GetComponentsInChildren<Toggle>(includeInactive: false);
			value = Mathf.Clamp(value, 0, componentsInChildren.Length - 1);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].isOn = (i == value);
			}
		}
	}

	private void SetUILogic()
	{
		m_UILogic?.ExitUI(this);
		switch (m_CacheData.mode)
		{
		case 0:
			m_UILogic = new ExtremeMode();
			break;
		case 2:
			m_UILogic = new SkillMode();
			break;
		case 1:
			m_UILogic = new SceneMode();
			break;
		case 3:
			m_UILogic = new RealSimulateMode();
			break;
		}
		m_UILogic?.SetUI(this, m_CacheData);
	}

	private void OnThiefSliderChanged(float value)
	{
		m_CacheData.thiefCount = (int)value;
		if (null != m_ThiefCount)
		{
			m_ThiefCount.text = ((int)value).ToString();
		}
	}

	private void OnPoliceSliderChanged(float value)
	{
		m_CacheData.policeCount = (int)value;
		if (null != m_PoliceCount)
		{
			m_PoliceCount.text = ((int)value).ToString();
		}
	}

	private void OnModeChanged(bool isOn)
	{
		if (isOn)
		{
			m_CacheData.mode = m_ModeLayout.GetToggleGroupValue();
			SetUILogic();
		}
	}

	private void OnMapChanged(bool isOn)
	{
		if (isOn)
		{
			m_CacheData.map = ToggleNumToMapTypeNum(m_MapLayout.GetToggleGroupValue());
		}
	}

	private void OnRoomNameChanged(string value)
	{
		m_CacheData.roomName = value;
	}

	private void OnCreateClick()
	{
		LocalPlayerDatabase.SetPrefValue("CREATE_PERF_DATA_KEY", JsonUtility.ToJson(m_CacheData));
		m_UILogic.SaveData();
		GameRuntimePerformanceTest.Data = m_CacheData;
		if (m_IsOffline)
		{
			m_CreateButton.StartCoroutine(GameUtility.EnterPerformanceTestLevel(GameRuntime.PlayingRole, (MapType)m_CacheData.map));
			return;
		}
		RoomConfig roomConfig = CreateRoomConfig();
		UILobby.Current.ShowWait(immediately: true);
		CustomRoomUtility.CreatCustomRoom(roomConfig, delegate(HttpResponseCreateRoom response)
		{
			UILobby.Current.GoBack();
			CustomRoomUtility.CachedRoomConfig = roomConfig;
			GameRuntime.SetRoomMapAndConfig(roomConfig.Map(), GameMode.CustomRoom, roomConfig);
			EnterRoom(response);
		});
	}

	private RoomConfig CreateRoomConfig()
	{
		RoomConfig defaultRoomConfig = CustomRoomUtility.DefaultRoomConfig;
		defaultRoomConfig.name = m_CacheData.roomName;
		defaultRoomConfig.mode = 99;
		defaultRoomConfig.map = m_CacheData.map;
		defaultRoomConfig.thiefCnt = m_CacheData.thiefCount;
		defaultRoomConfig.policeCnt = m_CacheData.policeCount;
		return defaultRoomConfig;
	}

	private void EnterRoom(HttpResponseCreateRoom createRoom)
	{
		TeamRoomManager.Inst.CustomConnectToTeamServer(createRoom, delegate
		{
			TeamRoomManager.Inst.ActiveOpenRoomUI();
		});
	}

	public static int ToggleNumToMapTypeNum(int toggleNum)
	{
		if (toggleNum == 3)
		{
			return 5;
		}
		return toggleNum;
	}
}
