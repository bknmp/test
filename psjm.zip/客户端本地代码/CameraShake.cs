using UnityEngine;

public class CameraShake : MonoBehaviour
{
	public float m_ShakeCameraDuration = 1f;

	public float m_ShakeCameraIntensity = 0.08f;

	public float m_ShakeCameraDistanceDecay = 0.01f;

	public float m_ShakeDelay;

	private void Start()
	{
		if (m_ShakeDelay > 0f)
		{
			Invoke("Shake", m_ShakeDelay);
		}
		else
		{
			Shake();
		}
	}

	private void Shake()
	{
		if (SceneCamera.Inst != null)
		{
			Vector3 followPosition = SceneCamera.Inst.FollowPosition;
			float num = m_ShakeCameraIntensity - Vector3.Distance(followPosition, base.transform.position) * m_ShakeCameraDistanceDecay;
			if (num > 0f)
			{
				SceneCamera.Inst.Shake(m_ShakeCameraDuration, num);
			}
		}
	}
}
