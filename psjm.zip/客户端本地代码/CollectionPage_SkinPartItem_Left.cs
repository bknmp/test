using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CollectionPage_SkinPartItem_Left
{
	public static int Selected;

	public UIDataBinder m_Host;

	public Text m_Personality;

	public Text m_NameText;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_NotCollected;

	public GameObject m_NotOwnedText;

	public Button m_Button;

	public Button m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public GameObject m_Selected;

	public GameObject m_NotHaveTips;

	public UIDataBinder m_SkinPartPanel;

	public Text m_SuiteText;

	public RawImage m_Preview;

	public UIPointerBehaviour m_Input;

	public Text m_PassSeason;

	private string m_PersonalityFormat;

	private int m_ItemID;

	private DropItem m_DropItemInfo;

	private bool m_IsOwn;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_Button, "OnSelectButtonClick");
		m_ItemID = args["itemID"];
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		if (m_PersonalityFormat == null)
		{
			m_PersonalityFormat = m_Personality.text;
		}
		DropItem dropItem = LocalResources.DropItemTable.Find(m_ItemID);
		m_IsOwn = CollectionUtility.OwnedForever(dropItem, m_PlayerInfo);
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Find(dropItem.TypeParam);
		int limitedEdition = skinPartInfo.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		m_NameText.text = skinPartInfo.Name;
		m_NotCollected.SetActive(!m_IsOwn);
		m_NotOwnedText.SetActive(!m_IsOwn);
		m_Personality.text = (m_IsOwn ? string.Format(m_PersonalityFormat, dropItem.Personality) : "");
		m_Personality.gameObject.SetActive(m_IsOwn);
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_QualityBG.State = dropItem.Quality;
		m_Effect.State = dropItem.Quality;
		m_Effect.gameObject.SetActive(m_IsOwn);
		if (Selected == 0)
		{
			Selected = m_ItemID;
			ShowCharacter();
		}
		UpdateSelectState();
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_ItemID)
		{
			Selected = m_ItemID;
			ShowCharacter();
			UIDataEvents.Inst.InvokeEvent("OnSelectSuiteItemChanged");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_ItemID == Selected;
			m_Selected.SetActive(active);
		}
	}

	private void ShowCharacter()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int[] val = new int[1]
		{
			m_ItemID
		};
		commonDataCollection["itemIDs"].val = val;
		commonDataCollection["playerInfo"].val = m_PlayerInfo;
		m_SkinPartPanel.Args = commonDataCollection;
		m_DropItemInfo = LocalResources.DropItemTable.Get(m_ItemID);
		m_SuiteText.text = m_DropItemInfo.Name;
		m_SuiteText.color = m_DropItemInfo.QualityColor;
		m_NotHaveTips.SetActive(!m_IsOwn);
		m_ButtonGain.gameObject.SetActive(!m_IsOwn && m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID);
		int characterID = LocalResources.SkinPartTable.Get(m_DropItemInfo.TypeParam).CharacterID;
		RoleType role = LocalResources.CharacterTable.Find(characterID).Role;
		PlayerCharacterInfo skinPartCharacterInfo = CollectionUtility.GetSkinPartCharacterInfo(characterID, m_PlayerInfo, m_DropItemInfo);
		MatchPlayerData matchPlayerData = null;
		matchPlayerData = ((m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID) ? CharacterUtility.GetPlayerData(m_PlayerID, skinPartCharacterInfo.characterID, m_PlayerInfo, m_PlayerCardConfigs) : CharacterUtility.GetPlayerData(characterID));
		if (matchPlayerData != null)
		{
			LobbyScene.Inst.UpdateCampPanel(role, m_PlayerInfo.publicInfo.name, skinPartCharacterInfo, matchPlayerData, m_Preview, notRTMethod: false, m_Input, closeOppositeRole: true);
		}
	}
}
