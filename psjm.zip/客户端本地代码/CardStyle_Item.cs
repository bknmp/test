using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CardStyle_Item
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public GameObject m_Select;

	public Button m_SelectButton;

	public UIDataBinder m_Show;

	private int index;

	private DropItem m_DropItem;

	public static int selectIndex;

	public static bool changeStyle;

	public static Quaternion rotation;

	public void Bind(CommonDataCollection args)
	{
		index = args["styleIndex"];
		m_DropItem = (args["dropItem"].val as DropItem);
		m_Icon.sprite = SpriteSource.Inst.Find(m_DropItem.Icon);
		UpdateSelect();
		m_Host.EventProxy(m_SelectButton, "SelectThis");
	}

	private void UpdateSelect()
	{
		m_Select.SetActive(index == selectIndex);
	}

	public void SelectThis()
	{
		PassRewardsPage_Preview.hasClickStyle = true;
		SelectIndex(index);
	}

	public static void SelectIndex(int i)
	{
		rotation = LobbyScene.Inst.m_CardSkinPanel.PrefabRoot.rotation;
		selectIndex = i;
		changeStyle = true;
		UIDataEvents.Inst.InvokeEvent("OnPassRewardStyleChange");
	}
}
