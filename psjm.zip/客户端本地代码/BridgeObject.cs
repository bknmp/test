using DG.Tweening;
using SimpleJson;
using System.Collections.Generic;
using UnityEngine;

public class BridgeObject : MonoBehaviour
{
	private bool m_IsOpened;

	private Vector2 m_MapPos;

	private AudioSource m_AudioSource;

	public static List<BridgeObject> AllBridges = new List<BridgeObject>();

	public bool IsOpened => m_IsOpened;

	public Vector2 MapPos => m_MapPos;

	private void Awake()
	{
		AllBridges.Add(this);
		m_IsOpened = true;
		if (InGameScene.Inst != null)
		{
			InGameScene.Inst.Map.WorldPositionToIndices(base.transform.position, out int x, out int y);
			m_MapPos.x = x;
			m_MapPos.y = y;
		}
		m_AudioSource = GetComponentInChildren<AudioSource>();
	}

	private void OnDestroy()
	{
		AllBridges.Remove(this);
	}

	public void Switch(bool isOn)
	{
		m_IsOpened = isOn;
		int end = (!m_IsOpened) ? (-2) : 0;
		base.gameObject.SetActive(value: true);
		base.transform.DOLocalMoveY(end, 0.5f).OnComplete(delegate
		{
			base.gameObject.SetActive(end >= 0);
		});
	}

	public void ToggleState()
	{
		m_IsOpened = !m_IsOpened;
		int end = (!m_IsOpened) ? (-2) : 0;
		base.gameObject.SetActive(value: true);
		base.transform.DOLocalMoveY(end, 0.5f).OnComplete(delegate
		{
			base.gameObject.SetActive(end >= 0);
		});
		if (m_AudioSource != null)
		{
			m_AudioSource.volume = 1f;
			m_AudioSource.Play();
			m_AudioSource.DOFade(0f, 0.2f).SetDelay(0.3f).OnComplete(m_AudioSource.Stop);
		}
	}

	public void OnReSyncWrite(object data)
	{
		(data as JsonObject)["opened"] = m_IsOpened;
	}

	public void OnReSyncRead(object data)
	{
		if ((data as JsonObject).AsBool("opened") != m_IsOpened)
		{
			ToggleState();
		}
	}

	public static void ReSyncReadByMapPos(int x, int y, object data)
	{
		foreach (BridgeObject allBridge in AllBridges)
		{
			Vector2 mapPos = allBridge.MapPos;
			if ((int)mapPos.x == x && (int)mapPos.y == y)
			{
				allBridge.OnReSyncRead(data);
				break;
			}
		}
	}
}
