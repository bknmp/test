using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;

public class ChatEntryManager : MonoBehaviour
{
	private List<ChatInfo> m_CacheMessages = new List<ChatInfo>();

	public static ChatEntryManager Inst;

	private void Awake()
	{
		Inst = this;
	}

	private void OnDestroy()
	{
		if (Inst == this)
		{
			Inst = null;
		}
	}

	private void InvokeChatEvent()
	{
		UIDataEvents.Inst.InvokeEvent("OnChatEntryEvent");
	}

	public void AddCacheMessages(uint senderID, string sender, string content, ChatChannel channel, GameMessages.MembershipInfo[] membershipInfos = null)
	{
		ChatInfo chatInfo = new ChatInfo();
		chatInfo.senderID = senderID;
		chatInfo.sender = sender;
		chatInfo.content = content;
		chatInfo.channel = channel;
		chatInfo.membershipInfos = membershipInfos;
		m_CacheMessages.Add(chatInfo);
		InvokeChatEvent();
	}

	public void ExtractCacheMessages(List<ChatInfo> outMsgs)
	{
		outMsgs.AddRange(m_CacheMessages);
		m_CacheMessages.Clear();
	}
}
