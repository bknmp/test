using LightUtility;
using System.Collections;
using UnityEngine;

public class BouncingObject : DirectionalObject
{
	public RectTransform m_FirstStage;

	public RectTransform m_SecondStage;

	public float m_PreviewLength = 10f;

	public float m_PerMeterLength = 100f;

	public AudioSource m_BounceAudio;

	private float m_LastDist;

	private Vector3 m_LastSpeed;

	protected Vector3 m_TargetPos;

	protected Vector3 m_NextTargetPos;

	protected Vector3 m_CurrentPos;

	protected float m_Radius = 0.5f;

	protected float m_MaxLength;

	private float m_LastUpdateTime;

	private float m_LastSyncPosTime;

	public bool IsMine
	{
		get
		{
			if (m_PlayerController != null)
			{
				return m_PlayerController.IsMine;
			}
			return false;
		}
	}

	protected virtual bool IsArbiter
	{
		get
		{
			if (!IsMine)
			{
				if (PhotonNetwork.isMasterClient)
				{
					return InGameScene.Inst.GameTime - m_LastSyncPosTime > 0.2f;
				}
				return false;
			}
			return true;
		}
	}

	protected bool IsReconnect => InGameReconnect.Inst.IsReConnecting;

	protected new void Start()
	{
		base.Start();
		if (!string.IsNullOrEmpty(base.UserId))
		{
			m_MaxLength = m_Timeout * m_SpeedScale;
			m_TargetPos = base.PreviewPosition + m_StartDir * m_MaxLength;
			m_LastSyncPosTime = InGameScene.Inst.GameTime;
		}
	}

	public override IEnumerator DelayShow()
	{
		if (IsForwardBarrier())
		{
			base.transform.position = m_PlayerController.transform.position;
			UpdateTargetPos();
		}
		yield return null;
	}

	protected override void UpdatePreviewArea()
	{
		base.UpdatePreviewArea();
		UpdateStage();
	}

	public override void BatchUpdate()
	{
		if (!string.IsNullOrEmpty(base.UserId) && !m_Hit && m_Launched && !m_IsTimeOut && !IsReconnect)
		{
			CheckBounce();
			if (IsArbiter)
			{
				UpdateTargetPos();
				RpcSetTargetPos(m_TargetPos, m_NextTargetPos, base.transform.position);
			}
			if (!base.WaitRpcTrigger)
			{
				UpdateMoving(m_TargetPos);
				UpdateFall();
			}
			UpdateTime();
		}
	}

	private void CheckBounce()
	{
		if (Vector3.Distance(m_TargetPos, base.transform.position) < m_Radius && !m_TargetPos.IsEquals(m_NextTargetPos))
		{
			m_TargetPos = m_NextTargetPos;
			Vector3 normalized = (m_TargetPos - base.transform.position).FlattenY().normalized;
			base.transform.rotation = Quaternion.LookRotation(normalized);
			m_LastUpdateTime = 0f;
			if (m_BounceAudio != null && m_BounceAudio.isActiveAndEnabled)
			{
				m_BounceAudio.Play();
			}
		}
	}

	private void UpdateStage()
	{
		if (BarrierRaycast(base.transform.position, base.PreviewDirection, m_PreviewLength, out Vector3 hitPos, out Vector3 normal, out float hitDistance))
		{
			SetStageLength(m_FirstStage, hitDistance - m_Radius);
			m_SecondStage.gameObject.SetActive(value: true);
			m_PreviewArea.transform.position = m_PreviewArea.transform.position.FlattenY(base.transform.position.y + 0.1f);
			Vector3 vector = Vector3.Reflect(base.PreviewDirection, normal);
			m_SecondStage.rotation = Quaternion.LookRotation(vector);
			m_SecondStage.eulerAngles = m_SecondStage.eulerAngles.FlattenX(90f);
			m_SecondStage.position = (hitPos + m_Radius * -base.PreviewDirection + -vector * 0.3f).FlattenY(m_FirstStage.position.y);
			if (BarrierRaycast(hitPos, vector, m_PreviewLength, out hitPos, out normal, out float hitDistance2))
			{
				SetStageLength(m_SecondStage, Mathf.Clamp(hitDistance2, 0f, Mathf.Min(m_PreviewLength - hitDistance, hitDistance2)));
			}
			else
			{
				SetStageLength(m_SecondStage, m_PreviewLength - hitDistance);
			}
		}
		else
		{
			SetStageLength(m_FirstStage, m_PreviewLength);
			m_SecondStage.gameObject.SetActive(value: false);
		}
	}

	private void SetStageLength(RectTransform rect, float length)
	{
		Vector2 sizeDelta = rect.sizeDelta;
		sizeDelta.y = m_PerMeterLength * length;
		rect.sizeDelta = sizeDelta;
	}

	protected void UpdateTargetPos()
	{
		if (!(Time.time - m_LastUpdateTime < 0.1f))
		{
			m_LastUpdateTime = Time.time;
			float hitDistance = 0f;
			Vector3 vector = m_TargetPos;
			Vector3 nextTargetPos = m_NextTargetPos;
			Vector3 position = base.transform.position;
			Vector3 normalized = (m_TargetPos - position).FlattenY().normalized;
			if (BarrierRaycast(position, normalized, 3f, out Vector3 hitPos, out Vector3 normal, out hitDistance))
			{
				vector = hitPos + m_Radius * 0.5f * -normalized;
				Vector3 lhs = Vector3.Reflect(normalized, normal);
				nextTargetPos = vector + m_MaxLength * lhs.FlattenY();
			}
			if (!m_TargetPos.IsEquals(vector))
			{
				LocalSetTargetPos(vector, nextTargetPos, base.transform.position);
			}
		}
	}

	protected override void UpdateMoving(Vector3 targetPos)
	{
		Vector3 position = base.transform.position;
		Vector3 lhs = (targetPos - position).FlattenY();
		Vector3 vector = lhs.normalized * Mathf.Clamp01(m_LastDist);
		Vector3 vector2 = (m_SpeedScale * vector - m_LastSpeed) * Mathf.Min(Time.deltaTime * 20f, 1f);
		m_LastSpeed += vector2;
		m_LastDist = lhs.FlattenY().magnitude;
		position = Vector3.Lerp(position, position + m_LastSpeed, Time.deltaTime);
		if (vector != Vector3.zero)
		{
			base.transform.rotation = Quaternion.Slerp(base.transform.rotation, Quaternion.LookRotation(vector), 900f * Time.deltaTime);
		}
		base.transform.position = position;
	}

	private bool BarrierRaycast(Vector3 startPos, Vector3 dir, float rayDistance, out Vector3 hitPos, out Vector3 normal, out float hitDistance)
	{
		bool result = false;
		hitPos = Vector3.zero;
		normal = Vector3.zero;
		hitDistance = 0f;
		LayerMask mask = 1 << LayerMask.NameToLayer("Default");
		int num = Physics.RaycastNonAlloc(startPos + new Vector3(0f, 0.1f, 0f), dir, GameObjectUtility.CacheRaycastHits, rayDistance, mask);
		float num2 = 99f;
		for (int i = 0; i < num; i++)
		{
			RaycastHit hit = GameObjectUtility.CacheRaycastHits[i];
			if (CheckBarrier(hit))
			{
				float distance = hit.distance;
				if (num2 > distance)
				{
					hitDistance = distance;
					num2 = hitDistance;
					hitPos = hit.point.FlattenY(startPos.y);
					normal = hit.normal;
					result = true;
				}
			}
		}
		return result;
	}

	private bool CheckBarrier(RaycastHit hit)
	{
		if (hit.collider == null)
		{
			return false;
		}
		if (GameUtility.IsPlayer(hit.collider))
		{
			return false;
		}
		if (hit.collider.CompareTag("InGame/IgnoreTrigger"))
		{
			return false;
		}
		DamagableTarget component = hit.collider.GetComponent<DamagableTarget>();
		if (component != null)
		{
			if (component.m_TargetType == DamagableTarget.TargetType.MagicWall)
			{
				MagicWallObject magicWallObject = (MagicWallObject)component.Target;
				if (!magicWallObject.Effective || magicWallObject.UserPlayer.InSameTeam(m_PlayerController))
				{
					return false;
				}
			}
			else if (component.m_TargetType != DamagableTarget.TargetType.BlockBar && component.m_TargetType != DamagableTarget.TargetType.IceWall && component.m_TargetType != DamagableTarget.TargetType.TrampolineObject && component.m_TargetType != DamagableTarget.TargetType.Imprison)
			{
				return false;
			}
		}
		string tag = hit.collider.tag;
		if (hit.collider.name.Contains("灯") || tag.Contains("Tree") || tag.Contains("RoadSign"))
		{
			return false;
		}
		return true;
	}

	protected override void GetCheckFallPos(Vector3 pos)
	{
		base.GetCheckFallPos(pos);
		m_CheckFallPos.Add(pos + base.transform.forward * 0.8f);
	}

	protected void RpcSetTargetPos(Vector3 targetPos, Vector3 nextTargetPos, Vector3 currentPos)
	{
		m_PhotonView.RPC("LocalSetTargetPos", PhotonTargets.All, targetPos, nextTargetPos, currentPos);
	}

	protected virtual void LocalSetTargetPos(Vector3 targetPos, Vector3 nextTargetPos, Vector3 currentPos)
	{
		if (!string.IsNullOrEmpty(PhotonNetwork.CurrentRpcCaller) && m_PlayerController != null && PhotonNetwork.CurrentRpcCaller == m_PlayerController.UserId)
		{
			m_LastSyncPosTime = InGameScene.Inst.GameTime;
		}
		else if (!string.IsNullOrEmpty(PhotonNetwork.CurrentRpcCaller) && m_PlayerController != null && PhotonNetwork.CurrentRpcCaller != m_PlayerController.UserId && IsMine && Time.realtimeSinceStartup - m_StartTime > 2f)
		{
			base.transform.position = currentPos;
		}
		m_TargetPos = targetPos;
		m_NextTargetPos = nextTargetPos;
		m_CurrentPos = currentPos;
	}

	private void OnTriggerEnter(Collider other)
	{
		if (!m_Launched || m_Hit || m_Trigger || !IsMine || m_IsTimeOut)
		{
			return;
		}
		DamagableTarget component = other.GetComponent<DamagableTarget>();
		bool flag = false;
		int numID = 0;
		int viewID = 0;
		int localNum = 0;
		Vector3 position = base.transform.position;
		if (component != null)
		{
			if (IsThroughBarrier(other.transform.position))
			{
				return;
			}
			if (CanTriggerTarget(component, ref numID, ref viewID, ref localNum))
			{
				position = component.Target.transform.position;
				flag = true;
			}
		}
		if (flag)
		{
			m_Trigger = true;
			m_TriggerTime = Time.realtimeSinceStartup;
			OnTrigger(position, numID, viewID, localNum);
		}
	}

	public bool IsThroughBarrier(Vector3 endPos)
	{
		Vector3 normalized = (endPos - base.transform.position).FlattenY().normalized;
		Vector3 vector = base.transform.position - normalized;
		vector.y += 0.1f;
		endPos.y = vector.y;
		return BulletObject.IsThroughBarrier(vector, endPos);
	}

	protected virtual void OnTrigger(Vector3 hitPos = default(Vector3), int numID = 0, int viewID = 0, int localNum = 0)
	{
	}

	protected override void RpcFinishHit(Vector3 hitPos = default(Vector3), int numID = 0, int viewID = 0, int localNum = 0)
	{
		m_PhotonView.RPC("OnFinishHit", PhotonTargets.AllViaServer, hitPos, numID, viewID, localNum);
	}

	protected override void OnTimeOut()
	{
		base.OnTimeOut();
		SafeDestroy();
	}
}
