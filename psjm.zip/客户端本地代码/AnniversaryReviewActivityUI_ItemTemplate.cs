using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class AnniversaryReviewActivityUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Text;

	public RawImage m_UIRawImage;

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["id"];
		AnniversaryReviewTitle anniversaryReviewTitle = LocalResources.AnniversaryReviewTitleTable.Get(item);
		m_Text.text = anniversaryReviewTitle.Title;
		Color color3 = m_Text.color = (m_UIRawImage.color = anniversaryReviewTitle.Color);
	}
}
