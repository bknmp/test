using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChatPageTeam
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	public InputField m_InputField;

	public UIShortcutSelectable m_Send;

	public GameObject m_ChatPageTeam;

	public Button m_EmojiBuntton;

	private ChatPanel m_ChatPanel;

	private const int MaxInputCount = 30;

	private List<RoomChatInfo> m_Messages = new List<RoomChatInfo>();

	public void Bind(CommonDataCollection args)
	{
		EmojiItem.SetChatInput(m_InputField);
		m_ChatPanel = m_ChatPageTeam.GetComponentInParent<ChatPanel>();
		m_Messages.Clear();
		if (!TeamRoomManager.InTeam)
		{
			RoomChatManager.Inst.ExtractUnReadMessages(m_Messages);
		}
		else
		{
			TeamRoomManager.Inst.ExtractUnReadMessages(m_Messages);
		}
		m_InputField.GetComponent<SensitiveWordFilter>().SetMaxInputCount(30);
		m_InputField.placeholder.GetComponent<Text>().text = Localization.TipsAntiFraud;
		if (m_Messages.Count == 0)
		{
			m_DataScrollView.ClearItems();
			m_DataScrollView.m_TemplateInitiator.UpdateImmediately();
		}
		else
		{
			args.Clear();
			string icon = LocalPlayerDatabase.PlayerInfo.publicInfo.icon;
			for (int i = 0; i < m_Messages.Count; i++)
			{
				args[i]["roleID"] = m_Messages[i].senderID;
				if (m_Messages[i].senderID == LocalPlayerDatabase.LoginInfo.roleID)
				{
					args[i]["sender"] = Localization.Me;
				}
				else
				{
					args[i]["sender"] = m_Messages[i].sender;
				}
				args[i]["content"] = m_Messages[i].content;
				args[i]["icon"] = ((m_Messages[i].senderID == LocalPlayerDatabase.LoginInfo.roleID) ? icon : m_Messages[i].icon);
				args[i]["sex"] = m_Messages[i].sex;
				args[i]["activeHeadBoxID"] = ((m_Messages[i].senderID == LocalPlayerDatabase.LoginInfo.roleID) ? LocalPlayerDatabase.PlayerInfo.activeHeadBoxID : m_Messages[i].activeHeadBoxID);
				args[i]["activeBubbleBoxID"] = ((m_Messages[i].senderID == LocalPlayerDatabase.LoginInfo.roleID) ? LocalPlayerDatabase.PlayerInfo.activeBubbleBoxID : m_Messages[i].activeBubbleBoxID);
				args[i]["membership"] = MembershipUtility.IsInTime(0, m_Messages[i].membershipInfos);
			}
			m_DataScrollView.AddItems(args.Array);
			m_DataScrollView.m_TemplateInitiator.UpdateImmediately();
		}
		UIScrollRect scrollRect = m_DataScrollView.m_ScrollRect;
		if (scrollRect.ContentPos - scrollRect.ContentSize > 0f - scrollRect.ViewSize - 100f)
		{
			m_DataScrollView.m_ScrollRect.ScrollToEnd();
		}
		m_Send.OnButtonDown = OnSendClicked;
		m_Host.EventProxy(m_EmojiBuntton, "OnEmojiButtonClicked");
	}

	private void OnSendMsg(string msg)
	{
		SoundManager.PlayOnce(PublicChatManager.Inst.m_SendSound);
		msg = msg.Trim().Replace(" ", "\u00a0").Replace("\r", "")
			.Replace("\n", "");
		if (!string.IsNullOrEmpty(msg))
		{
			if (!TeamRoomManager.InTeam)
			{
				RoomChatManager.Inst.SendRoomChatMessgae(msg);
			}
			else
			{
				TeamRoomManager.Inst.SendTeamChat(msg);
			}
			m_InputField.text = "";
			m_DataScrollView.m_ScrollRect.ScrollToEnd(immediately: true);
		}
	}

	public void OnSendClicked(UIShortcutSelectable.OperationType opType)
	{
		if (HeadBubbleBoxUtility.CheckExpiredTime(HeadBubbleBox.BubbleBox))
		{
			UILobby.Current.ShowTips(Localization.BubbleBoxExpiredTips);
		}
		else
		{
			OnSendMsg(m_InputField.text);
		}
	}

	public void OnEmojiButtonClicked()
	{
		if (m_ChatPanel != null)
		{
			m_ChatPanel.ToggleEmojiPanel();
		}
	}
}
