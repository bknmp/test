using UnityEngine;
using UnityEngine.UI;

[ExecuteInEditMode]
[RequireComponent(typeof(CanvasScaler))]
public class AspectRatioAdapter : MonoBehaviour
{
	private CanvasScaler m_CanvasScaler;

	private int m_LastScreenWidth;

	private int m_LastScreenHeight;

	private void Awake()
	{
		m_CanvasScaler = GetComponent<CanvasScaler>();
		AdaptRatio();
	}

	private void Update()
	{
		if (Screen.width != m_LastScreenWidth || Screen.height != m_LastScreenHeight)
		{
			AdaptRatio();
		}
	}

	private void AdaptRatio()
	{
		m_LastScreenWidth = Screen.width;
		m_LastScreenHeight = Screen.height;
		float num = (float)m_LastScreenWidth / (float)m_LastScreenHeight;
		float num2 = m_CanvasScaler.referenceResolution.x / m_CanvasScaler.referenceResolution.y;
		if (num - num2 > 0.001f)
		{
			m_CanvasScaler.matchWidthOrHeight = 1f;
		}
		else
		{
			m_CanvasScaler.matchWidthOrHeight = 0f;
		}
	}
}
