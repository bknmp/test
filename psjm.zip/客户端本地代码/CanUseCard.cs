using BehaviorDesigner.Runtime.Tasks;

[TaskName("能否用道具卡")]
[TaskCategory("躲猫猫AI/条件")]
[TaskDescription("Ids为Card的TypeParam")]
public class CanUseCard : Conditional
{
	public SharedAIController ai;

	public int[] Ids;

	public override TaskStatus OnUpdate()
	{
		for (int i = 0; i < Ids.Length; i++)
		{
			if (!ai.Value.CanUseProp(Ids[i]))
			{
				return TaskStatus.Failure;
			}
		}
		return TaskStatus.Success;
	}
}
