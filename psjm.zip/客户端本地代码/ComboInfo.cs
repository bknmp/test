using System.Collections;

public class ComboInfo
{
	public int comboTimes;

	public IEnumerator comboCancel;

	public float comboInterval;
}
