using BehaviorDesigner.Runtime.Tasks;
using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[TaskName("摄像机跟随玩家")]
[TaskCategory("考驾照功能")]
public class CameraFollowPlayer : BehaviorDesigner.Runtime.Tasks.Action
{
	[Serializable]
	public class MoveData
	{
		public RoleType roleType;

		public int index;

		public float moveDuration = 1f;

		public float waitDuration = 2f;

		public float followDuration = 3f;
	}

	public List<MoveData> moveDatas;

	private bool moveEnd;

	public override void OnStart()
	{
		moveEnd = false;
		StartCoroutine(StartFollowPlayer());
	}

	public override TaskStatus OnUpdate()
	{
		if (!moveEnd)
		{
			return TaskStatus.Running;
		}
		return TaskStatus.Success;
	}

	private IEnumerator StartFollowPlayer()
	{
		for (int i = 0; i < moveDatas.Count; i++)
		{
			PlayerController player = ConfigPlayerAI.GetPlayer(moveDatas[i].roleType, moveDatas[i].index);
			DOTween.To(() => SceneCamera.Inst.FollowPosition, delegate(Vector3 x)
			{
				SceneCamera.Inst.SetFollowPosition(x);
			}, player.transform.localPosition, moveDatas[i].moveDuration).SetEase(Ease.InOutSine);
			yield return new WaitForSeconds(moveDatas[i].moveDuration);
			yield return new WaitForSeconds(moveDatas[i].waitDuration);
			SceneCamera.Inst.SetFollowTarget(player);
			yield return new WaitForSeconds(moveDatas[i].followDuration);
		}
		InGameStartup.Inst.m_Black.gameObject.SetActive(value: true);
		InGameStartup.Inst.m_Black.alpha = 0f;
		InGameStartup.Inst.m_Black.DOFade(1f, 0.5f);
		yield return new WaitForSeconds(0.5f);
		SceneCamera.Inst.SetFollowTarget(PlayerController.Inst);
		DOTween.To(GetMinLight, SetMinLight, 0.2f, 5f);
		InGameStartup.Inst.m_Black.DOFade(0f, 1f);
		yield return new WaitForSeconds(2f);
		moveEnd = true;
	}

	private void SetMinLight(float x)
	{
		Shader.SetGlobalFloat("_MinLight", x);
	}

	private float GetMinLight()
	{
		return Shader.GetGlobalFloat("_MinLight");
	}
}
