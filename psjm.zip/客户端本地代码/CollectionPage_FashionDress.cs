using LightUI;

internal class CollectionPage_FashionDress
{
	public UIDataBinder m_Host;

	public UITabPage m_TabPage;

	private CommonDataCollection m_Args;

	public void Bind(CommonDataCollection args)
	{
		m_Args = args;
		OnTabChange();
		m_Host.EventProxy(m_TabPage, "OnTabChange");
	}

	public void OnTabChange()
	{
		m_TabPage.m_Buttons[m_TabPage.GetSelectedTabIndex()].m_TabContent.GetComponent<UIDataBinder>().Args = m_Args;
	}
}
