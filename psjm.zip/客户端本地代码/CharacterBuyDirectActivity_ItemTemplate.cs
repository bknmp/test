using GameMessages;
using LightUI;
using UnityEngine;

internal class CharacterBuyDirectActivity_ItemTemplate : ActivityGiftUI_ItemTemplate
{
	public GameObject m_OwnTips;

	public new void Bind(CommonDataCollection args)
	{
		base.Bind(args);
		DropItem dropItem = LocalResources.DropItemTable.Get(m_ActivityGiftInfo.items[0].itemID);
		m_OwnTips.gameObject.SetActive(CharacterUtility.IsOwnForeverCharacter(dropItem.TypeParam));
	}

	public new void OnClickBuy()
	{
		if (m_OwnTips.gameObject.activeSelf)
		{
			UILobby.Current.ShowTips(Localization.OwnForeverCharacterCantBuyAgain);
		}
		else
		{
			base.OnClickBuy();
		}
	}

	protected override void SetDropItems(ItemInfo[] items)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int arraySize = commonDataCollection.ArraySize;
		commonDataCollection[arraySize]["dropItemInfo"].val = items[1];
		m_TemplateInitiatorHorizontal.Args = commonDataCollection;
	}
}
