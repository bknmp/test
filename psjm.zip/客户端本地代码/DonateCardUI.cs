using LightUI;
using System.Linq;
using UnityEngine.UI;

internal class DonateCardUI
{
	public UIDataBinder m_Host;

	public Text m_Tips;

	public UITemplateInitiator m_Content;

	private string m_TipsFormat;

	public void Bind(CommonDataCollection args)
	{
		if (m_TipsFormat == null)
		{
			m_TipsFormat = m_Tips.text;
		}
		m_Tips.text = string.Format(m_TipsFormat, UnionUtility.Settings.askWhiteCardMax, UnionUtility.Settings.askBlueCardMax, UnionUtility.Settings.askPurpleCardMax);
		InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
		allCardInfos = (from x in allCardInfos
			orderby x.Quality
			select x).ToArray();
		args.Clear();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			if (CardUtility.IsOwned(inGameStoreInfo.Id) && !CardUtility.IsNewCard(inGameStoreInfo.Id))
			{
				int arraySize = args.ArraySize;
				args[arraySize]["id"].val = inGameStoreInfo.Id;
			}
		}
		m_Content.Args = args;
	}
}
