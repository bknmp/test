using BehaviorDesigner.Runtime.Tasks;

[TaskName("比较剩余子弹数量")]
[TaskCategory("躲猫猫AI/条件")]
public class BulletRemainedComparison : CustomIntComparison
{
	public SharedAIController ai;

	public override TaskStatus OnUpdate()
	{
		CompareValue = ai.Value.PlayerController.ProjectileLauncher.BulletRemained;
		return base.OnUpdate();
	}
}
