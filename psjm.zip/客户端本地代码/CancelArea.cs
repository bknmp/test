using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class CancelArea : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	public bool m_PointerEnter;

	private int m_PointerID;

	private void OnEnable()
	{
		Reset();
	}

	public void Reset()
	{
		m_PointerEnter = false;
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		m_PointerEnter = true;
		m_PointerID = eventData.pointerId;
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		if (m_PointerID == eventData.pointerId)
		{
			StartCoroutine(DelayReset());
		}
	}

	private IEnumerator DelayReset()
	{
		yield return null;
		Reset();
	}
}
