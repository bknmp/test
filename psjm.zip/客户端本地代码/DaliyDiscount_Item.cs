using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class DaliyDiscount_Item
{
	public UIDataBinder m_Host;

	public UIStateRawImage m_QualityBG;

	public Image m_Icon;

	public Text m_Name;

	public Text m_Price;

	public Text m_Cost;

	public Image m_Currency;

	public UIStateItem m_IsFree;

	public UIStateItem m_IsCardPiece;

	public Text m_Amount;

	public Text m_Count;

	public CardPieceProcessBar m_CardProcessUI;

	public Button m_BuyBtn;

	public GameObject m_HadBuy;

	private int m_Id;

	private int m_Index;

	private Action m_BuyCallBack;

	private int m_Timestamp;

	public void Bind(CommonDataCollection args)
	{
		m_Id = args["id"];
		m_Index = args["index"];
		m_BuyCallBack = (args["callback"].val as Action);
		SetInfo();
		m_Host.EventProxy(m_BuyBtn, "ClickBuyItem");
	}

	private void SetInfo()
	{
		DropItem dropItem = LocalResources.DropItemTable.Get(StoreRecommendUIBinder.ShopRommendInfo.dailyItems[m_Index].itemID);
		bool flag = dropItem.Type == DropItemType.CardPiece;
		bool flag2 = StoreRecommendUIBinder.ShopRommendInfo.cost[m_Index] == 0;
		bool flag3 = StoreRecommendUIBinder.ShopRommendInfo.hasBuy[m_Index];
		m_QualityBG.State = dropItem.Quality;
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_Name.text = dropItem.Name;
		m_IsCardPiece.State = (flag ? 1 : 0);
		int itemCount = StoreRecommendUIBinder.ShopRommendInfo.dailyItems[m_Index].itemCount;
		if (flag)
		{
			m_Count.text = "+" + itemCount;
			m_CardProcessUI.SetInfo(dropItem.TypeParam);
		}
		else
		{
			m_Amount.text = "x" + itemCount;
			m_Amount.gameObject.SetActive(itemCount > 1);
		}
		m_HadBuy.SetActive(flag3);
		m_HadBuy.GetComponentInChildren<Text>().text = (flag2 ? Localization.hadClaim : Localization.HasBuy);
		m_IsFree.gameObject.SetActive(!flag3);
		if (m_IsFree.gameObject.activeSelf)
		{
			m_IsFree.State = ((!flag2) ? 1 : 0);
			if (!flag2)
			{
				m_Price.text = StoreRecommendUIBinder.ShopRommendInfo.prices[m_Index].ToString();
				m_Cost.text = StoreRecommendUIBinder.ShopRommendInfo.cost[m_Index].ToString();
				m_Currency.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(StoreRecommendUIBinder.ShopRommendInfo.currency[m_Index]).Icon);
			}
		}
	}

	public void ClickBuyItem()
	{
		m_Timestamp = StoreRecommendUIBinder.ShopRommendInfo.timestamp;
		if (m_IsFree.State == 0)
		{
			BuyItem();
		}
		else
		{
			EnsureBuyPopUp.EnsureBuyItems(new ItemInfo[1]
			{
				StoreRecommendUIBinder.ShopRommendInfo.dailyItems[m_Index]
			}, StoreRecommendUIBinder.ShopRommendInfo.currency[m_Index], StoreRecommendUIBinder.ShopRommendInfo.prices[m_Index], StoreRecommendUIBinder.ShopRommendInfo.cost[m_Index], BuyItem);
		}
	}

	private void BuyItem()
	{
		HttpRequestBuyDailyItem httpRequestBuyDailyItem = new HttpRequestBuyDailyItem();
		httpRequestBuyDailyItem.id = m_Id;
		httpRequestBuyDailyItem.timestamp = m_Timestamp;
		GameHttpManager.Inst.Send(httpRequestBuyDailyItem, delegate(HttpResponseBuyDailyItem res)
		{
			DaliyDiscount_Item daliyDiscount_Item = this;
			CommonRewardPopupUI result = null;
			using (ResManager.Load("CommonRewardPopupUI", out result))
			{
				CommonRewardPopupUI.Show(result, delegate
				{
					if (res.itemInfo[0].itemID == 18)
					{
						UIDataEvents.Inst.InvokeEvent("OnPassInfoChanged");
					}
					if (daliyDiscount_Item.m_BuyCallBack != null)
					{
						daliyDiscount_Item.m_BuyCallBack();
					}
				}).AddItems(res.itemInfo);
			}
		});
	}
}
