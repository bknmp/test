using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CardLotteryConfirmPage_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Unit;

	public Text m_Price;

	public Text m_PriceType;

	public Text m_OriginalPrice;

	public Image m_Selected;

	public Button m_SelectBtn;

	private BoxInfo m_BoxInfo;

	private int m_UnitNum;

	private CardLotteryConfirmPage m_ParentUI;

	private float m_Discount;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SelectBtn, "OnClickSelect");
		m_BoxInfo = (args["boxInfo"].val as BoxInfo);
		m_UnitNum = args["unit"];
		m_Discount = args["discount"];
		m_ParentUI = (args["m_ParentUI"].val as CardLotteryConfirmPage);
		m_OriginalPrice.transform.parent.gameObject.SetActive(m_Discount < 1f);
		if (m_Discount < 1f)
		{
			int num = m_BoxInfo.LotteryMoneyCost * m_UnitNum;
			m_OriginalPrice.text = num.ToString();
		}
		float num2 = (float)(m_BoxInfo.LotteryMoneyCost * m_UnitNum) * m_Discount;
		m_Price.text = num2.ToString();
		m_Price.color = (((float)ShopUtility.GetCurrencyAmount(m_BoxInfo.LotteryMoneyType) < num2) ? Color.red : Color.white);
		m_Unit.text = "x" + m_UnitNum.ToString();
		m_PriceType.text = LocalResources.DropItemTable.Get(m_BoxInfo.LotteryMoneyType).Name;
		UpdateSelectState();
	}

	private void UpdateSelectState()
	{
		m_Selected.gameObject.SetActive(m_ParentUI.m_ChoosedUnit == m_UnitNum);
	}

	public void OnClickSelect()
	{
		m_ParentUI.m_IsMoneyEnough = true;
		m_ParentUI.m_ChoosedUnit = m_UnitNum;
		if (m_Price.color == Color.red)
		{
			m_ParentUI.m_IsMoneyEnough = false;
		}
		UIDataEvents.Inst.InvokeEvent("OnChooseCardLotteryUnitChanged");
		UpdateSelectState();
	}
}
