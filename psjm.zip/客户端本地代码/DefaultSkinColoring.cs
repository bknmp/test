using UnityEngine;

public class DefaultSkinColoring : MonoBehaviour
{
	public int[] ColorIds;

	private SkinColorationController m_colorationController;

	private void Awake()
	{
		m_colorationController = GetComponent<SkinColorationController>();
		for (int i = 0; i < ColorIds.Length; i++)
		{
			m_colorationController.ColorizeSkin((SkinPartType)i, ColorIds[i]);
		}
	}
}
