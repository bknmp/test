using GameMessages;
using LightUI;

public class BoxUpgradePreviewUI : BoxPreview
{
	public UIDataBinder m_Container;

	public new void Bind(CommonDataCollection args)
	{
		base.Bind(args);
		m_Container.Args = args;
		ShowStateButtonDetail();
		AdScene adScene = AdScene.UPGRADE_BOX;
		if (AdUtility.IsAdEnable(adScene))
		{
			m_AdButton.onClick.RemoveAllListeners();
			m_Ad.gameObject.SetActive(value: true);
			m_AdButton.onClick.AddListener(delegate
			{
				OnAdClicked(boxPos, unlock: false, adScene);
			});
		}
		else
		{
			m_Ad.gameObject.SetActive(value: false);
		}
		if (m_Ad.activeSelf)
		{
			AdSDKManager.TryReportEvent(AdScene.UPGRADE_BOX, AdStatistics.Show);
		}
	}
}
