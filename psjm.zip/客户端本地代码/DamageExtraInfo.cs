using UnityEngine;

public struct DamageExtraInfo
{
	public Vector3 explosionPos;

	public float explosionRadius;

	public Vector3 playerPos;

	public int rrt;

	public int cardID;

	public short critical;

	public float time;
}
