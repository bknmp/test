using LightUtility;

public class CharacterInfo : IdBased
{
	public RoleType Role;

	public string Name;

	public string AniPreName;

	public string Icon;

	public string ExpIcon;

	public string IngameHeadIcon;

	public string LobbyPrefab;

	public string InGamePrefab;

	public int[] DefaultParts;

	public string[] PartNames;

	public int[] TalentIDs;

	public string Story;

	public int Rank;

	public bool IsVisibleInUI;

	public int DefaultEmotionDoodle;

	public int DefaultEmotionMotion;

	public int SkillID;

	public string[] Label;

	public string[] AttrDesc;

	public string[] AttrValue;
}
