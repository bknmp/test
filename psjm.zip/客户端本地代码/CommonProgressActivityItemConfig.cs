using UnityEngine;

public class CommonProgressActivityItemConfig : MonoBehaviour
{
	public Vector3 m_ListItemSize;

	public bool m_ShowFirstProgress;

	public GameObject m_LastEffect;
}
