using LightUI;

public class CardUpgradeRewardActivityUI : UIEventListener
{
	private bool isFirstEnterUI;

	public bool FirstEnterUI
	{
		get
		{
			return isFirstEnterUI;
		}
		set
		{
			isFirstEnterUI = value;
		}
	}

	private void Start()
	{
		isFirstEnterUI = true;
	}

	public override void OnEnterUI()
	{
		isFirstEnterUI = true;
	}
}
