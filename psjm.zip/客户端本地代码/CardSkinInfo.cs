public class CardSkinInfo : BaseCardSkinInfo
{
	public int UnlockLevel;

	public int Rank;

	public int GainType;

	public int[] Styles;
}
