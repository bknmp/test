using GameMessages;
using LightUI;
using LightUtility;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_SelectCharacterItemTemplate
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public MultiTargetGraphicButton m_Button;

	public GameObject m_RedPoint;

	public Text m_Name;

	public Text m_Level;

	public GameObject m_Mask;

	public GameObject m_IsActive;

	public UIProgressBar m_ExpBar;

	public UIStateItem m_State;

	public GameObject m_IsFree;

	public static int globalSelected = -1;

	private int m_Id;

	private bool m_Own;

	private bool m_CanUse;

	private string m_LevelFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_LevelFormat))
		{
			m_LevelFormat = m_Level.text;
		}
		CharacterInfo characterInfo = args["characterInfo"].val as CharacterInfo;
		m_Id = characterInfo.Id;
		if (m_Id == 0)
		{
			m_State.State = 1;
		}
		else
		{
			m_State.State = 0;
			m_Icon.sprite = SpriteSource.Inst.Find(characterInfo.Icon);
			m_Name.text = characterInfo.Name;
			m_Own = CharacterUtility.IsOwnCharacter(characterInfo.Id);
			m_CanUse = (m_Own || CharacterFreeUtility.IsCharacterFree);
			m_Mask.gameObject.SetActive(!m_CanUse);
			m_RedPoint.SetActive(TalentUtility.HasTalentCanUpgrade(CharacterUtility.GetOwnedCharacterInfo(m_Id), characterInfo));
			if (!m_CanUse)
			{
				m_Level.gameObject.SetActive(value: false);
				m_IsActive.gameObject.SetActive(value: false);
				m_ExpBar.gameObject.SetActive(value: false);
			}
			else
			{
				m_IsActive.gameObject.SetActive(CharacterUtility.IsActiveCharacter(m_Id));
				m_Level.gameObject.SetActive(value: true);
				PlayerCharacterInfo playerCharacter = CharacterUtility.GetOwnedCharacterInfo(m_Id);
				m_Level.text = string.Format(m_LevelFormat, playerCharacter.ExpLevel);
				m_ExpBar.gameObject.SetActive(value: true);
				if (playerCharacter.ExpLevel < LocalResources.ExpLevelTable.Last().Level)
				{
					m_ExpBar.SetProgress(playerCharacter.ExpPoint, LocalResources.ExpLevelTable.Find((ExpLevelInfo a) => a.Level == playerCharacter.ExpLevel).ExpNeed);
				}
				else
				{
					m_ExpBar.SetProgress(1f, 1f, Localization.MaxLevel);
				}
			}
			m_IsFree.SetActive(CharacterFreeUtility.IsCharacterFree && !m_Own);
		}
		m_Host.EventProxy(m_Button, "OnClickSelect");
	}

	public void OnClickSelect()
	{
		if (m_Id == 0)
		{
			UILobby.Current.ShowTips(Localization.CharacterComingSoon);
			return;
		}
		globalSelected = m_Id;
		UIDataEvents.Inst.InvokeEvent("OnCharacterSelectedChange");
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["arg"] = (LobbyNewbieDirector.IsGuiding ? 1 : 0);
		JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI, commonDataCollection);
	}
}
