using System;

[Serializable]
public enum CustomParamID
{
	CoinGain = 1,
	MoveSpeed,
	MoveInertia,
	Blood,
	ViewRange,
	TalentEffect,
	BodyScale,
	HeadBodyScale
}
