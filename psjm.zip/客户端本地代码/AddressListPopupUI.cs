using GameMessages;
using LightUI;
using UnityEngine.UI;

public class AddressListPopupUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Content;

	public Button m_ConfiromBtn;

	public UIPopup m_AddressEditorPopupUI;

	public Button m_AddAddressBtn;

	public Button m_CloseButton;

	public UIPopup m_PopupUI;

	public UIScrollRect m_ScrollView;

	private int m_Type = -1;

	public void Bind(CommonDataCollection args)
	{
		m_Type = args["type"];
		ExchangeAddressUtility.TryRefreshAddress(delegate
		{
			ExchangeAddressUtility.LastSelectedId = ExchangeAddressUtility.CurrentSelectedId;
			m_Content.Args = WrapData(ExchangeAddressUtility.CacheAddress);
		});
		m_ConfiromBtn.gameObject.SetActive(m_Type != 0);
		m_Host.EventProxy(m_ConfiromBtn, "OnClickConfirmBtn");
		m_Host.EventProxy(m_AddAddressBtn, "OnClickAddAddressBtn");
		m_Host.EventProxy(m_CloseButton, "OnClickCloseBtn");
	}

	protected CommonDataCollection WrapData(HttpResponseRewardAddress onResponse)
	{
		CommonDataCollection goodsArg = new CommonDataCollection();
		int num = 0;
		AddressInfo[] addressInfo = onResponse.addressInfo;
		foreach (AddressInfo item in addressInfo)
		{
			SetArgs(ref goodsArg, item, num);
			num++;
		}
		return goodsArg;
	}

	private void SetArgs(ref CommonDataCollection goodsArg, AddressInfo item, int count)
	{
		goodsArg[count]["id"] = item.id;
		goodsArg[count]["playerName"] = item.playerName;
		goodsArg[count]["phone"] = item.phone;
		goodsArg[count]["address1"] = item.address1;
		goodsArg[count]["address2"] = item.address2;
		goodsArg[count]["address3"] = item.address3;
		goodsArg[count]["address4"] = item.address4;
		goodsArg[count]["type"] = m_Type;
	}

	public void OnClickConfirmBtn()
	{
		ExchangeAddressUtility.LastSelectedId = ExchangeAddressUtility.CurrentSelectedId;
		if (ExchangeAddressUtility.CurrentSelectedId < 0)
		{
			UILobby.Current.ShowTips(Localization.ExchangeAddressSelectedEmpty);
		}
		else
		{
			UILobby.Current.GoBack();
		}
	}

	public void OnClickAddAddressBtn()
	{
		CommonDataCollection obj = new CommonDataCollection
		{
			["type"] = 0,
			["playerName"] = "",
			["phone"] = "",
			["address1"] = "",
			["address2"] = "",
			["address3"] = "",
			["address4"] = ""
		};
		UILobby.Current.ShowUI(m_AddressEditorPopupUI, null);
	}

	public void OnClickCloseBtn()
	{
		ExchangeAddressUtility.CurrentSelectedId = ExchangeAddressUtility.LastSelectedId;
		m_PopupUI.GoBack();
	}
}
