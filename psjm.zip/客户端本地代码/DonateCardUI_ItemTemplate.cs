using DG.Tweening;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class DonateCardUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public GameObject m_Selected;

	public Image m_Frame;

	public Button m_ButtonAsk;

	public RectTransform m_Root;

	public Text m_Level;

	public CardPieceProcessBar m_Process;

	public MultiTargetGraphicButton m_SelectButton;

	public UIMaskItem m_MaskItem;

	public UIPopup m_DonateCardUI;

	public UIScrollRect m_ScrollView;

	private bool m_InitalSelection;

	private bool m_Init;

	private string m_LevelFormat;

	private int m_CardID;

	public static int SelectedID = -1;

	public static int ScrollItemID = -1;

	public void Bind(CommonDataCollection args)
	{
		if (!m_Init)
		{
			m_LevelFormat = m_Level.text;
			m_Init = true;
		}
		m_CardID = args["id"];
		int cardLevel = CardUtility.GetCardLevel(m_CardID);
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_CardID);
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Find(inGameStoreInfo.DefaultSkinID);
		m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_Level.text = string.Format(m_LevelFormat, cardLevel);
		m_Process.SetInfo(m_CardID);
		UpdateSelection();
		TryShowScrollToItemAnimation();
		m_Host.EventProxy(m_SelectButton, "OnButtonClicked");
	}

	private void UpdateSelection()
	{
		bool flag = SelectedID == m_CardID;
		m_Process.GetComponent<CanvasGroup>().alpha = ((!flag) ? 1 : 0);
		if (flag != m_Selected.activeSelf || !m_InitalSelection)
		{
			if (flag)
			{
				m_Root.transform.DOScale(1.1f, 0.2f).SetEase(Ease.OutBack);
				m_Root.anchoredPosition = new Vector2(0f, 13f);
				m_Host.EventProxy(m_ButtonAsk, "OnButtonAskClicked");
				ScrollToItemAnimation();
			}
			else
			{
				m_Root.transform.DOKill();
				m_Root.transform.localScale = Vector3.one;
				m_Root.anchoredPosition = new Vector2(0f, -20f);
			}
			m_Selected.SetActive(flag);
			m_InitalSelection = true;
		}
	}

	public void OnButtonClicked()
	{
		SelectedID = m_CardID;
		UIDataEvents.Inst.InvokeEvent("OnDonateCardSelectedChanged");
	}

	public void OnButtonAskClicked()
	{
		UnionUtility.AskCard(m_CardID);
		NewsPage_ChatPage.m_GotoBottom = true;
		GoBack();
	}

	private void GoBack()
	{
		m_DonateCardUI.GoBack();
	}

	private void TryShowScrollToItemAnimation()
	{
		if (ScrollItemID == m_CardID)
		{
			ScrollItemID = -1;
			ScrollToItemAnimation();
		}
	}

	private void ScrollToItemAnimation()
	{
		m_ScrollView.content.DOMoveY(m_ScrollView.content.transform.position.y + m_MaskItem.IsTotalVisible(2), 0.2f);
	}
}
