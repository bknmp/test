using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BoxPreviewUI_BoxInfo
{
	public UIDataBinder m_Host;

	public Text m_BoxName;

	public Text m_CardText1;

	public Text m_CardText2;

	public Text m_CardText3;

	public Text m_GoldText;

	public Text m_ColoringAgentText;

	public Text m_TicketText;

	public Image m_TimeBoxIcon;

	public GameObject m_Reward;

	public GameObject m_Cards;

	public UIStateRawImage m_Mirror;

	private BoxItemInfo m_BoxInfo;

	public void Bind(CommonDataCollection args)
	{
		int id = args["boxID"];
		BoxInfo boxInfo = LocalResources.BoxTable.Find(id);
		m_BoxName.text = boxInfo.Name;
		string icon = boxInfo.Icon;
		m_TimeBoxIcon.sprite = SpriteSource.Inst.Find(icon);
		m_TimeBoxIcon.transform.parent.gameObject.SetActive(value: true);
		m_Mirror.gameObject.SetActive(value: true);
		m_Mirror.State = boxInfo.Quality;
		SetBoxAward(boxInfo);
	}

	private void SetBoxAward(BoxInfo boxItemInfo)
	{
		bool flag = SetCardText(m_CardText1, boxItemInfo.AwardCardCountArray, 3);
		bool flag2 = SetCardText(m_CardText2, boxItemInfo.AwardCardCountArray, 2);
		bool flag3 = SetCardText(m_CardText3, boxItemInfo.AwardCardCountArray, 1);
		m_Cards.SetActive(flag | flag2 | flag3);
		int num = 0;
		if (boxItemInfo.AwardCoinRange.Length > 1)
		{
			num++;
			m_GoldText.transform.parent.gameObject.SetActive(value: true);
			m_GoldText.text = $"{boxItemInfo.AwardCoinRange[0]} ~ {boxItemInfo.AwardCoinRange[1]}";
		}
		else
		{
			m_GoldText.transform.parent.gameObject.SetActive(value: false);
		}
		if (boxItemInfo.AwardColoringAgent > 0)
		{
			num++;
			m_ColoringAgentText.transform.parent.gameObject.SetActive(value: true);
			m_ColoringAgentText.text = boxItemInfo.AwardColoringAgent.FormatAmount();
		}
		else
		{
			m_ColoringAgentText.transform.parent.gameObject.SetActive(value: false);
		}
		if (boxItemInfo.AwardTicketRange.Length > 1)
		{
			num++;
			m_TicketText.transform.parent.gameObject.SetActive(value: true);
			m_TicketText.text = $"{boxItemInfo.AwardTicketRange[0]} ~ {boxItemInfo.AwardTicketRange[1]}";
		}
		else
		{
			m_TicketText.transform.parent.gameObject.SetActive(value: false);
		}
		m_Reward.SetActive(num > 0);
	}

	private bool SetCardText(Text text, int[] cardArray, int index)
	{
		if (cardArray.Length > index && cardArray[index] > 0)
		{
			text.transform.parent.gameObject.SetActive(value: true);
			text.text = cardArray[index].FormatAmountX();
			return true;
		}
		text.transform.parent.gameObject.SetActive(value: false);
		return false;
	}
}
