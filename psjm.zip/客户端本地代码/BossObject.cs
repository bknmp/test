public class BossObject : PoliceObject
{
}
