using LightUtility;
using System;
using UnityEngine;

[Serializable]
public class AnniversaryReviewTitle : IdBased
{
	public string Title;

	public Color Color;
}
