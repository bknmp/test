using DG.Tweening;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class AssetFlyEffect : MonoBehaviour
{
	public GameObject m_Prefab;

	public float m_StartInterval = 0.2f;

	public float m_Phase1Scale = 1.2f;

	public float m_Phase1OffsetMin = 1f;

	public float m_Phase1OffsetMax = 2f;

	public float m_Phase1AngleMin;

	public float m_Phase1AngleMax = 360f;

	public float m_Phase1Duration = 0.5f;

	public float m_Phase2Duration = 0.5f;

	public float m_Phase2Curveness = 1f;

	public float m_Phase2MaxSpeed = 15f;

	public AudioItem m_MoneySound;

	public AudioItem m_GetSound;

	private void Awake()
	{
		if (m_Prefab != null)
		{
			m_Prefab.SetActive(value: false);
		}
	}

	public IEnumerator Show(int count, Vector3 start, Transform end, UnityAction onSingleComplete, UnityAction onAllComplete)
	{
		SoundManager.PlayOnce(m_MoneySound);
		base.transform.position = start;
		int num;
		for (int i = 0; i < count; i = num)
		{
			GameObject inst = (m_Prefab == null) ? base.gameObject : PoolSpawner.Spawn(m_Prefab, base.transform);
			inst.SetActive(value: true);
			inst.transform.position = start;
			Vector3 a = Quaternion.AngleAxis(UnityEngine.Random.Range(m_Phase1AngleMin, m_Phase1AngleMax), Vector3.forward) * Vector3.up;
			bool isLast = i == count - 1;
			Vector3 phase1Pos = start + a * UnityEngine.Random.Range(m_Phase1OffsetMin, m_Phase1OffsetMax);
			CanvasGroup canvasGroup = inst.GetComponent<CanvasGroup>();
			canvasGroup.DOFade(0f, 0f);
			canvasGroup.DOFade(0f, m_StartInterval * (float)i).OnComplete(delegate
			{
				canvasGroup.DOFade(1f, 0.25f);
				inst.transform.DOScale(m_Phase1Scale, m_Phase1Duration);
				inst.transform.DOMove(phase1Pos, m_Phase1Duration).OnComplete(delegate
				{
					Vector3 position = end.position;
					Vector3 v = position - phase1Pos;
					Vector2 v2 = MathUtility.Right(v).normalized * UnityEngine.Random.Range(0f - m_Phase2Curveness, m_Phase2Curveness);
					float num2 = Mathf.Max(m_Phase2Duration, v.magnitude / m_Phase2MaxSpeed);
					inst.transform.DOScale(1f, num2);
					inst.transform.DOBlendableMoveBy(v2, num2 * 0.5f).SetLoops(2, LoopType.Yoyo);
					inst.transform.DOBlendableMoveBy(position - phase1Pos, num2).SetEase(Ease.InSine).OnComplete(delegate
					{
						PoolSpawner.DeSpawn(inst);
						if (isLast)
						{
							if (onAllComplete != null)
							{
								SoundManager.PlayOnce(m_GetSound);
								onAllComplete();
							}
							PoolSpawner.DeSpawn(base.gameObject);
						}
						else if (onSingleComplete != null)
						{
							SoundManager.PlayOnce(m_GetSound);
							onSingleComplete();
						}
					});
				});
			});
			yield return null;
			num = i + 1;
		}
	}
}
