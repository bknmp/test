using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public class BasicDecal : MonoBehaviour
{
	[SerializeField]
	private bool previewInEditMode = true;

	[SerializeField]
	private bool resetOnPlay;

	[SerializeField]
	private Vector3 scale = Vector3.one;

	[SerializeField]
	private float decalOffset = 0.005f;

	private Bounds boxBounds;

	[SerializeField]
	private MeshFilter mesh;

	public Vector3 rotation;

	private Vector3 prevPosition;

	private float prevDecalScale;

	private Vector3 prevScale;

	private Vector3 prevRotation;

	private List<Vector3> newVertices = new List<Vector3>();

	private List<int> newTriangles = new List<int>();

	private List<CombineInstance> combinedMesh = new List<CombineInstance>();

	private Dictionary<Mesh, Vector3[]> meshVertices = new Dictionary<Mesh, Vector3[]>();

	private Dictionary<Mesh, int[]> meshTriangles = new Dictionary<Mesh, int[]>();

	public void Awake()
	{
		mesh = GetComponentInChildren<MeshFilter>();
		boxBounds = default(Bounds);
		boxBounds.size = scale;
		boxBounds.center = base.transform.position;
	}

	private void Start()
	{
		if (resetOnPlay)
		{
			ResetDecal();
		}
	}

	public void ResetDecal()
	{
		Collider[] array = Physics.OverlapBox(base.transform.position, Vector3.one * boxBounds.extents.x / 2f, base.transform.rotation, -5);
		List<MeshFilter> list = new List<MeshFilter>();
		for (int i = 0; i < array.Length; i++)
		{
			if ((bool)array[i].GetComponent<MeshFilter>())
			{
				list.Add(array[i].GetComponent<MeshFilter>());
			}
		}
		ResetDecal(list);
	}

	public void ResetDecal(List<MeshFilter> renderers)
	{
		if (mesh.sharedMesh != null)
		{
			mesh.sharedMesh.Clear();
		}
		if (renderers.Count <= 0)
		{
			return;
		}
		combinedMesh.Clear();
		for (int i = 0; i < renderers.Count; i++)
		{
			for (int j = 0; j < renderers[i].sharedMesh.subMeshCount; j++)
			{
				CombineInstance item = default(CombineInstance);
				item.mesh = renderers[i].sharedMesh;
				item.transform = renderers[i].transform.localToWorldMatrix;
				item.subMeshIndex = j;
				combinedMesh.Add(item);
			}
		}
		mesh.sharedMesh = new Mesh();
		mesh.sharedMesh.CombineMeshes(combinedMesh.ToArray(), mergeSubMeshes: true);
		RemoveDoubles(mesh.sharedMesh, 1f);
		newVertices.Clear();
		newTriangles.Clear();
		int num = 0;
		float num2 = float.NegativeInfinity;
		float num3 = float.PositiveInfinity;
		Bounds bounds = default(Bounds);
		int[] triangles = mesh.sharedMesh.triangles;
		Vector3[] vertices = mesh.sharedMesh.vertices;
		Vector3[] normals = mesh.sharedMesh.normals;
		for (int k = 0; k < triangles.Length; k += 3)
		{
			bounds.size = Vector3.zero;
			bounds.center = (vertices[triangles[k]] + vertices[triangles[k + 1]] + vertices[triangles[k + 2]]) / 3f;
			bounds.Encapsulate(vertices[triangles[k]]);
			bounds.Encapsulate(vertices[triangles[k + 1]]);
			bounds.Encapsulate(vertices[triangles[k + 2]]);
			if (boxBounds.Intersects(bounds))
			{
				Vector3 point = (normals[triangles[k]] + normals[triangles[k + 1]] + normals[triangles[k + 2]]) / 3f;
				float z = (Quaternion.Inverse(Quaternion.Euler(rotation)) * point).z;
				if (z < num3)
				{
					num3 = z;
				}
				if (z > num2)
				{
					num2 = z;
				}
				if (z < 0f)
				{
					newVertices.Add(base.transform.InverseTransformPoint(vertices[triangles[k]] + normals[triangles[k]] * decalOffset));
					newVertices.Add(base.transform.InverseTransformPoint(vertices[triangles[k + 1]] + normals[triangles[k + 1]] * decalOffset));
					newVertices.Add(base.transform.InverseTransformPoint(vertices[triangles[k + 2]] + normals[triangles[k + 2]] * decalOffset));
					newTriangles.Add(num);
					newTriangles.Add(num + 1);
					newTriangles.Add(num + 2);
					num += 3;
				}
			}
		}
		mesh.sharedMesh = new Mesh();
		mesh.sharedMesh.vertices = newVertices.ToArray();
		mesh.sharedMesh.triangles = newTriangles.ToArray();
		Vector3[] vertices2 = mesh.sharedMesh.vertices;
		Vector2[] array = new Vector2[vertices2.Length];
		for (int l = 0; l < vertices2.Length; l++)
		{
			Vector3 vector = Quaternion.Inverse(Quaternion.Euler(rotation)) * vertices2[l] + new Vector3(scale.x / 2f, scale.y / 2f, scale.z / 2f);
			array[l].x = vector.x / scale.x;
			array[l].y = vector.y / scale.y;
		}
		mesh.sharedMesh.uv = array;
		Mesh sharedMesh = mesh.sharedMesh;
		mesh.sharedMesh.RecalculateBounds();
	}

	private void RemoveDoubles(Mesh mesh, float bucketStep, float threshold = 0.0001f)
	{
		Vector3[] vertexList = GetVertexList(mesh);
		Vector3[] array = new Vector3[vertexList.Length];
		int[] array2 = new int[vertexList.Length];
		int num = 0;
		Vector3 vector = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
		Vector3 vector2 = new Vector3(float.MinValue, float.MinValue, float.MinValue);
		for (int i = 0; i < vertexList.Length; i++)
		{
			if (vertexList[i].x < vector.x)
			{
				vector.x = vertexList[i].x;
			}
			if (vertexList[i].y < vector.y)
			{
				vector.y = vertexList[i].y;
			}
			if (vertexList[i].z < vector.z)
			{
				vector.z = vertexList[i].z;
			}
			if (vertexList[i].x > vector2.x)
			{
				vector2.x = vertexList[i].x;
			}
			if (vertexList[i].y > vector2.y)
			{
				vector2.y = vertexList[i].y;
			}
			if (vertexList[i].z > vector2.z)
			{
				vector2.z = vertexList[i].z;
			}
		}
		int num2 = (int)((vector2.x - vector.x) / bucketStep) + 1;
		int num3 = (int)((vector2.y - vector.y) / bucketStep) + 1;
		int num4 = (int)((vector2.z - vector.z) / bucketStep) + 1;
		List<int>[,,] array3 = new List<int>[num2, num3, num4];
		for (int j = 0; j < vertexList.Length; j++)
		{
			int num5 = (int)((vertexList[j].x - vector.x) / bucketStep);
			int num6 = (int)((vertexList[j].y - vector.y) / bucketStep);
			int num7 = (int)((vertexList[j].z - vector.z) / bucketStep);
			if (array3[num5, num6, num7] == null)
			{
				array3[num5, num6, num7] = new List<int>();
			}
			int num8 = 0;
			while (true)
			{
				if (num8 < array3[num5, num6, num7].Count)
				{
					if (Vector3.SqrMagnitude(array[array3[num5, num6, num7][num8]] - vertexList[j]) < threshold)
					{
						array2[j] = array3[num5, num6, num7][num8];
						break;
					}
					num8++;
					continue;
				}
				array[num] = vertexList[j];
				array3[num5, num6, num7].Add(num);
				array2[j] = num;
				num++;
				break;
			}
		}
		int[] triangleList = GetTriangleList(mesh);
		int[] array4 = new int[triangleList.Length];
		for (int k = 0; k < triangleList.Length; k++)
		{
			array4[k] = array2[triangleList[k]];
		}
		Vector3[] array5 = new Vector3[num];
		for (int l = 0; l < num; l++)
		{
			array5[l] = array[l];
		}
		mesh.Clear();
		mesh.vertices = array5;
		mesh.triangles = array4;
		mesh.RecalculateNormals();
	}

	private Vector3[] GetVertexList(Mesh mesh)
	{
		if (meshVertices.ContainsKey(mesh))
		{
			return meshVertices[mesh];
		}
		Vector3[] vertices = mesh.vertices;
		meshVertices.Add(mesh, vertices);
		return vertices;
	}

	private int[] GetTriangleList(Mesh mesh)
	{
		if (meshTriangles.ContainsKey(mesh))
		{
			return meshTriangles[mesh];
		}
		int[] triangles = mesh.triangles;
		meshTriangles.Add(mesh, triangles);
		return triangles;
	}

	private void OnDrawGizmosSelected()
	{
		if (previewInEditMode && !Application.isPlaying && (base.transform.position != prevPosition || prevScale != scale || prevRotation != rotation))
		{
			Awake();
			ResetDecal();
			prevPosition = base.transform.position;
			prevScale = scale;
			prevRotation = rotation;
		}
		Gizmos.color = Color.black;
		Gizmos.matrix = Matrix4x4.TRS(base.transform.position, Quaternion.Euler(rotation), scale);
		Gizmos.DrawLine(Vector3.back / 2f, Vector3.forward);
		Gizmos.DrawWireCube(Vector3.forward / 2f, new Vector3(0.9f, 0.9f, 0f));
		Gizmos.matrix = Matrix4x4.TRS(base.transform.position, Quaternion.identity, scale);
		Gizmos.color = Color.green;
		Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
	}
}
