using UnityEngine;

public class CanvasGroupHandler : MonoBehaviour
{
	private CanvasGroup m_CG;

	public static CanvasGroupHandler Inst;

	private void Awake()
	{
		Inst = this;
	}

	public void ForceHidePage()
	{
		if (m_CG == null)
		{
			m_CG = base.transform.parent.parent.parent.parent.GetComponent<CanvasGroup>();
		}
		m_CG.alpha = 0f;
		m_CG.interactable = false;
	}

	public void ResumeHidePage()
	{
		if (m_CG == null)
		{
			m_CG = base.transform.parent.parent.parent.parent.GetComponent<CanvasGroup>();
		}
		m_CG.alpha = 1f;
		m_CG.interactable = true;
	}
}
