using GameMessages;
using LightUtility;
using System.Collections.Generic;
using System.Linq;

public static class CollectionUtility
{
	private static int m_AllSkinPartCount = 0;

	private static int m_AllCardSkinCount = 0;

	private static int m_AllCharacterCount = 0;

	private static int m_AllCardStyleCount = 0;

	private static List<int> TmpGroupIDs = new List<int>();

	public static int GetAllCharacterCount()
	{
		if (m_AllCharacterCount == 0)
		{
			m_AllCharacterCount = LocalResources.CharacterTable.Count((CharacterInfo a) => (a.Role != RoleType.Thief) ? (a.Role == RoleType.Police) : true);
		}
		return m_AllCharacterCount;
	}

	public static int GetAllSkinPartCount()
	{
		if (m_AllSkinPartCount == 0)
		{
			int num = LocalResources.DropItemTable.Count((DropItem a) => a.Type == DropItemType.SkinPart && a.expiredTime == 0);
			int num2 = LocalResources.DropItemTable.Count((DropItem a) => a.Type == DropItemType.SkinGroup && a.expiredTime == 0);
			m_AllSkinPartCount = num + num2;
		}
		return m_AllSkinPartCount;
	}

	public static int GetAllCardSkinAndStyleCount()
	{
		if (m_AllCardSkinCount == 0)
		{
			IEnumerable<int> defaultIDs = from b in LocalResources.InGameStoreTable
				select b.DefaultSkinID into id
				where id > 0
				select id;
			m_AllCardSkinCount = LocalResources.DropItemTable.Count((DropItem a) => a.Type == DropItemType.CardSkin && a.expiredTime == 0 && !defaultIDs.Contains(a.TypeParam));
		}
		if (m_AllCardStyleCount == 0)
		{
			m_AllCardStyleCount = LocalResources.DropItemTable.Count((DropItem a) => a.Type == DropItemType.CardStyle && a.expiredTime == 0);
		}
		return m_AllCardSkinCount + m_AllCardStyleCount;
	}

	public static int GetAllHeadBubbleBoxCount(HttpResponsePlayerAssets assets = null)
	{
		return HeadBubbleBoxUtility.GetHeadOrBubbleBoxIDs(HeadBubbleBox.All, open: true, assets).Count;
	}

	public static bool IsDefaultPart(int skinPartID)
	{
		foreach (CharacterInfo item in LocalResources.CharacterTable)
		{
			if (item.IsVisibleInUI && item.DefaultParts.Contains(skinPartID))
			{
				return true;
			}
		}
		return false;
	}

	public static int GetForeverCharacterCount(HttpResponsePlayerAssets assets)
	{
		int num = 0;
		for (int i = 0; i < assets.ownedCharacters.Length; i++)
		{
			if (assets.ownedCharacters[i].expiredTime == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static int GetForeverSkinPartCount(HttpResponsePlayerAssets assets)
	{
		int num = 0;
		TmpGroupIDs.Clear();
		for (int i = 0; i < assets.ownedSkins.skinPartIDs.Length; i++)
		{
			int num2 = assets.ownedSkins.skinPartIDs[i];
			int groupID = ShopUtility.GetGroupID(num2);
			if (groupID > 0)
			{
				if (TmpGroupIDs.Contains(groupID))
				{
					continue;
				}
				TmpGroupIDs.Add(groupID);
			}
			if (assets.ownedSkins.expiredTime[i] == 0)
			{
				if (!IsDefaultPart(num2))
				{
					num++;
				}
				else if (CharacterUtility.IsOwnCharacter(LocalResources.SkinPartTable.Find(num2).CharacterID, assets))
				{
					num++;
				}
			}
		}
		return num;
	}

	public static int GetForeverCardSkinCount(HttpResponsePlayerAssets assets)
	{
		int num = 0;
		int[] target = (from a in LocalResources.InGameStoreTable
			select a.DefaultSkinID into a
			where a > 0
			select a).ToArray();
		for (int i = 0; i < assets.cardOwnSkin.Length; i++)
		{
			if (!target.Contains(assets.cardOwnSkin[i]) && assets.cardSkinExpiredTime[i] == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static int GetForeverCardStyleCount(HttpResponsePlayerAssets assets)
	{
		int num = 0;
		for (int i = 0; i < assets.cardOwnStyle.Length; i++)
		{
			if (assets.cardStyleExpiredTime[i] == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static int GetForeverCardSkinAndStyleCount(HttpResponsePlayerAssets assets)
	{
		int num = 0;
		int[] target = (from a in LocalResources.InGameStoreTable
			select a.DefaultSkinID into a
			where a > 0
			select a).ToArray();
		for (int i = 0; i < assets.cardOwnSkin.Length; i++)
		{
			if (!target.Contains(assets.cardOwnSkin[i]) && assets.cardSkinExpiredTime[i] == 0)
			{
				num++;
			}
		}
		for (int j = 0; j < assets.cardOwnStyle.Length; j++)
		{
			if (assets.cardStyleExpiredTime[j] == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static int GetForeverSuiteCount(HttpResponsePlayerAssets assets, out List<ShopSuiteInfo> shopSuiteInfos)
	{
		shopSuiteInfos = new List<ShopSuiteInfo>();
		int num = 0;
		for (int i = 0; i < LocalResources.ShopSuiteTable.Count; i++)
		{
			ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable[i];
			int[] shopItemIDs = shopSuiteInfo.ShopItemIDs;
			if (LocalResources.DropItemTable.Find(shopItemIDs[0]).expiredTime == 0 && shopItemIDs.All((int id) => OwnedForever(LocalResources.DropItemTable.Find(id), assets)))
			{
				num++;
				shopSuiteInfos.Add(shopSuiteInfo);
			}
		}
		return num;
	}

	public static int GetForeverSkinPartCount(HttpResponsePlayerAssets assets, out List<ShopInfo> shopSkinpartInfos)
	{
		shopSkinpartInfos = new List<ShopInfo>();
		int num = 0;
		for (int i = 0; i < LocalResources.ShopTable.Count; i++)
		{
			ShopInfo shopInfo = LocalResources.ShopTable[i];
			DropItemType type = LocalResources.DropItemTable.Get(shopInfo.DropItemID).Type;
			if ((type == DropItemType.SkinPart || type == DropItemType.SkinGroup) && IsForeverSkinPart(shopInfo) && !GetIsInSuite(shopInfo.Id) && OwnedForever(LocalResources.DropItemTable.Find(shopInfo.DropItemID), assets))
			{
				num++;
				shopSkinpartInfos.Add(shopInfo);
			}
		}
		return num;
	}

	private static bool GetIsInSuite(int skinPartId)
	{
		bool result = false;
		foreach (ShopSuiteInfo item in LocalResources.ShopSuiteTable)
		{
			if (item.ShopItemIDs.Contains(skinPartId))
			{
				return true;
			}
		}
		return result;
	}

	public static int GetForeverHeadBubbleBoxCount(HttpResponsePlayerAssets assets)
	{
		return HeadBubbleBoxUtility.GetOwnedHeadOrBubbleBoxIDs(assets, HeadBubbleBox.All, permanent: true).Count;
	}

	public static bool OwnedForever(DropItem item, HttpResponsePlayerAssets assets)
	{
		if (item.Type == DropItemType.SkinPart)
		{
			int idxInAssets = ArrayUtility.IndexOf(assets.ownedSkins.skinPartIDs, item.TypeParam);
			return OwnedSkinPartForever(assets, idxInAssets);
		}
		if (item.Type == DropItemType.SkinGroup)
		{
			SkinGroupInfo skinGroupInfo = LocalResources.SkinGroupTable.Get(item.TypeParam);
			int idxInAssets2 = ArrayUtility.IndexOf(assets.ownedSkins.skinPartIDs, skinGroupInfo.SkinPartIds[0]);
			return OwnedSkinPartForever(assets, idxInAssets2);
		}
		if (item.Type == DropItemType.CardSkin)
		{
			int num = ArrayUtility.IndexOf(assets.cardOwnSkin, item.TypeParam);
			if (num != -1)
			{
				return assets.cardSkinExpiredTime[num] == 0;
			}
			return false;
		}
		if (item.Type == DropItemType.CardStyle)
		{
			int num2 = ArrayUtility.IndexOf(assets.cardOwnStyle, item.TypeParam);
			if (num2 != -1)
			{
				return assets.cardStyleExpiredTime[num2] == 0;
			}
			return false;
		}
		return true;
	}

	private static bool OwnedSkinPartForever(HttpResponsePlayerAssets assets, int idxInAssets)
	{
		if (idxInAssets != -1)
		{
			int num = assets.ownedSkins.skinPartIDs[idxInAssets];
			if (assets.ownedSkins.expiredTime[idxInAssets] == 0)
			{
				if (!IsDefaultPart(num))
				{
					return true;
				}
				if (CharacterUtility.IsOwnCharacter(LocalResources.SkinPartTable.Find(num).CharacterID, assets))
				{
					return true;
				}
				return false;
			}
			return false;
		}
		return false;
	}

	public static DropItem[] GetSuiteCollectProgress(int suiteID, HttpResponsePlayerAssets assets)
	{
		return (from t in LocalResources.ShopSuiteTable.Find(suiteID).ShopItemIDs
			select LocalResources.DropItemTable.Find(t) into t
			where OwnedForever(t, assets)
			select t).ToArray();
	}

	public static int CalculateItemsPersonality(int[] itemIDs)
	{
		return (from itemID in itemIDs
			select LocalResources.DropItemTable.Get(itemID) into dropInfo
			select dropInfo.Personality).Sum();
	}

	public static int GetSkinPartColor(int skinPartID, PlayerSkinInfo playerSkinInfo)
	{
		int num = ArrayUtility.IndexOf(playerSkinInfo.skinPartIDs, skinPartID);
		if (num != -1)
		{
			return playerSkinInfo.skinPartColors[num];
		}
		return LocalResources.SkinPartTable.Get(skinPartID).DefaultColorID;
	}

	public static PlayerCharacterInfo GetSuiteCharacterInfo(int characterID, HttpResponsePlayerAssets assets, ShopSuiteInfo suiteInfo)
	{
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo();
		playerSkinInfo.expiredTime = new int[characterID.PartCount()];
		DropItem[] suiteCollectProgress = GetSuiteCollectProgress(suiteInfo.Id, assets);
		int num = suiteCollectProgress.Length;
		int num2 = suiteInfo.ShopItemIDs.Length;
		if (num == num2)
		{
			int[] suiteParts = CharacterUtility.GetSuiteParts(suiteInfo);
			int[] array = new int[suiteParts.Length];
			for (int i = 0; i < suiteParts.Length; i++)
			{
				array[i] = GetSkinPartColor(suiteParts[i], assets.ownedSkins);
			}
			playerSkinInfo.skinPartIDs = suiteParts;
			playerSkinInfo.skinPartColors = array;
		}
		else if (num < num2 && num > 0)
		{
			int[] array2 = MathUtility.Clone(LocalResources.CharacterTable.Get(characterID).DefaultParts);
			int[] array3 = new int[array2.Length];
			for (int j = 0; j < array2.Length; j++)
			{
				array3[j] = LocalResources.SkinPartTable.Get(array2[j]).DefaultColorID;
			}
			DropItem[] array4 = suiteCollectProgress;
			foreach (DropItem dropItem in array4)
			{
				int typeParam = dropItem.TypeParam;
				int id = ShopUtility.IsGroup(typeParam) ? LocalResources.SkinGroupTable.Get(typeParam).SkinPartIds[0] : typeParam;
				SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Find(id);
				int partType = (int)skinPartInfo.PartType;
				array2[partType] = dropItem.TypeParam;
				array3[partType] = GetSkinPartColor(skinPartInfo.Id, assets.ownedSkins);
			}
			playerSkinInfo.skinPartIDs = array2;
			playerSkinInfo.skinPartColors = array3;
		}
		else if (num == 0)
		{
			int[] suiteParts2 = CharacterUtility.GetSuiteParts(suiteInfo);
			int[] array5 = new int[suiteParts2.Length];
			for (int l = 0; l < suiteParts2.Length; l++)
			{
				array5[l] = LocalResources.SkinPartTable.Get(suiteParts2[l]).DefaultColorID;
			}
			playerSkinInfo.skinPartIDs = suiteParts2;
			playerSkinInfo.skinPartColors = array5;
		}
		PlayerCharacterInfo playerCharacterInfo = new PlayerCharacterInfo();
		playerCharacterInfo.characterID = characterID;
		playerCharacterInfo.currentSkinInfo = playerSkinInfo;
		playerCharacterInfo.expiredTime = 0u;
		playerCharacterInfo.ExpLevel = 1;
		playerCharacterInfo.ExpPoint = 0;
		playerCharacterInfo.TalentLevels = new int[3];
		playerCharacterInfo.TalentPointRemained = 0;
		return playerCharacterInfo;
	}

	public static PlayerCharacterInfo GetSkinPartCharacterInfo(int characterID, HttpResponsePlayerAssets assets, DropItem skinPartItemInfo)
	{
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo();
		playerSkinInfo.expiredTime = new int[characterID.PartCount()];
		List<int> list = LocalResources.CharacterTable.Get(characterID).DefaultParts.ToList();
		List<int> list2 = new List<int>();
		for (int i = 0; i < list.Count; i++)
		{
			list2.Add(LocalResources.SkinPartTable.Get(list[i]).DefaultColorID);
		}
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Find(skinPartItemInfo.TypeParam);
		int partType = (int)skinPartInfo.PartType;
		list[partType] = skinPartItemInfo.TypeParam;
		list2[partType] = GetSkinPartColor(skinPartInfo.Id, assets.ownedSkins);
		playerSkinInfo.skinPartIDs = list.ToArray();
		playerSkinInfo.skinPartColors = list2.ToArray();
		PlayerCharacterInfo playerCharacterInfo = new PlayerCharacterInfo();
		playerCharacterInfo.characterID = characterID;
		playerCharacterInfo.currentSkinInfo = playerSkinInfo;
		playerCharacterInfo.expiredTime = 0u;
		playerCharacterInfo.ExpLevel = 1;
		playerCharacterInfo.ExpPoint = 0;
		playerCharacterInfo.TalentLevels = new int[3];
		playerCharacterInfo.TalentPointRemained = 0;
		return playerCharacterInfo;
	}

	public static DropItem[] GetForeverSkinPartItems(HttpResponsePlayerAssets assets)
	{
		List<DropItem> list = new List<DropItem>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < assets.ownedSkins.skinPartIDs.Length; i++)
		{
			if (assets.ownedSkins.expiredTime[i] != 0)
			{
				continue;
			}
			int num = assets.ownedSkins.skinPartIDs[i];
			int groupID = ShopUtility.GetGroupID(num);
			if (groupID > 0)
			{
				if (list2.Contains(groupID))
				{
					continue;
				}
				list2.Add(groupID);
			}
			if (groupID > 0)
			{
				DropItem foreverItem = GetForeverItem(groupID);
				if (foreverItem != null)
				{
					list.Add(foreverItem);
				}
			}
			else if (!IsDefaultPart(num))
			{
				DropItem foreverItem2 = GetForeverItem(num);
				if (foreverItem2 != null)
				{
					list.Add(foreverItem2);
				}
			}
			else if (CharacterUtility.IsOwnCharacter(LocalResources.SkinPartTable.Find(num).CharacterID, assets))
			{
				DropItem foreverItem3 = GetForeverItem(num);
				if (foreverItem3 != null)
				{
					list.Add(foreverItem3);
				}
			}
		}
		return list.ToArray();
	}

	public static DropItem[] GetForeverSkinPartItems_NotInSuite(HttpResponsePlayerAssets assets)
	{
		List<DropItem> list = new List<DropItem>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < assets.ownedSkins.skinPartIDs.Length; i++)
		{
			int skinPartID = assets.ownedSkins.skinPartIDs[i];
			int groupID = ShopUtility.GetGroupID(skinPartID);
			if (groupID > 0)
			{
				if (list2.Contains(groupID))
				{
					continue;
				}
				list2.Add(groupID);
			}
			if (assets.ownedSkins.expiredTime[i] != 0)
			{
				continue;
			}
			int dropID = (groupID > 0) ? LocalResources.DropItemTable.Find((DropItem a) => a.TypeParam == groupID && a.expiredTime == 0).Id : LocalResources.DropItemTable.Find((DropItem a) => a.TypeParam == skinPartID && a.expiredTime == 0).Id;
			ShopInfo shopInfo = LocalResources.ShopTable.Find((ShopInfo a) => a.DropItemID == dropID);
			if (shopInfo == null || GetIsInSuite(shopInfo.Id))
			{
				continue;
			}
			if (!IsDefaultPart(skinPartID))
			{
				DropItem foreverItem = GetForeverItem(skinPartID);
				if (foreverItem != null)
				{
					list.Add(foreverItem);
				}
			}
			else if (CharacterUtility.IsOwnCharacter(LocalResources.SkinPartTable.Find(skinPartID).CharacterID, assets))
			{
				DropItem foreverItem2 = GetForeverItem(skinPartID);
				if (foreverItem2 != null)
				{
					list.Add(foreverItem2);
				}
			}
		}
		return list.ToArray();
	}

	public static DropItem[] GetForeverCardSkinItems(HttpResponsePlayerAssets assets)
	{
		List<DropItem> list = new List<DropItem>();
		for (int i = 0; i < assets.cardOwnSkin.Length; i++)
		{
			if (assets.cardSkinExpiredTime[i] == 0)
			{
				DropItem foreverItem = GetForeverItem(assets.cardOwnSkin[i]);
				if (foreverItem != null)
				{
					list.Add(foreverItem);
				}
			}
		}
		return list.ToArray();
	}

	public static DropItem[] GetForeverCardStyleItems(HttpResponsePlayerAssets assets)
	{
		List<DropItem> list = new List<DropItem>();
		for (int i = 0; i < assets.cardOwnStyle.Length; i++)
		{
			if (assets.cardStyleExpiredTime[i] == 0)
			{
				DropItem foreverItem = GetForeverItem(assets.cardOwnStyle[i]);
				if (foreverItem != null)
				{
					list.Add(foreverItem);
				}
			}
		}
		return list.ToArray();
	}

	private static DropItem GetForeverItem(int typeID)
	{
		return (from a in LocalResources.DropItemTable
			where a.TypeParam == typeID
			select a).FirstOrDefault((DropItem a) => a.expiredTime == 0);
	}

	public static bool IsForeverSuite(ShopSuiteInfo suiteInfo)
	{
		if (suiteInfo.ShopItemIDs == null || suiteInfo.ShopItemIDs.Length == 0 || LocalResources.DropItemTable.Find(suiteInfo.ShopItemIDs[0]).expiredTime == 0)
		{
			return true;
		}
		return false;
	}

	public static bool IsForeverSkinPart(ShopInfo skinPartInfo)
	{
		if (LocalResources.DropItemTable.Find(skinPartInfo.DropItemID).expiredTime == 0)
		{
			return true;
		}
		return false;
	}

	public static int GetForeverIngameEmotionCount(HttpResponsePlayerInfo assets)
	{
		int num = 0;
		for (int i = 0; i < assets.ownedIngameEmotion.id.Length; i++)
		{
			if (assets.ownedIngameEmotion.expiredTime[i] == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static int GetForeverLightnessCount(HttpResponsePlayerInfo assets)
	{
		int num = 0;
		for (int i = 0; i < assets.lightness.id.Length; i++)
		{
			if (assets.lightness.id[i] != 0 && assets.lightness.expiredTime[i] == 0)
			{
				num++;
			}
		}
		return num;
	}

	public static bool IsOwnForeverIngameEmotion(int ingameEmotionId, HttpResponsePlayerInfo assets)
	{
		for (int i = 0; i < assets.ownedIngameEmotion.id.Length; i++)
		{
			if (assets.ownedIngameEmotion.id[i] == ingameEmotionId)
			{
				if (assets.ownedIngameEmotion.expiredTime[i] == 0)
				{
					return true;
				}
				return false;
			}
		}
		return false;
	}
}
