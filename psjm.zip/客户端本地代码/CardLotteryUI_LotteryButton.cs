using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardLotteryUI_LotteryButton
{
	public UIDataBinder m_Host;

	public UIStateRawImage m_BtnState;

	public UICooldownBar m_FreeTimeCooldown;

	public Image m_PriceIcon;

	public Text m_PriceText;

	public GameObject m_DiscountContainer;

	public UICooldownBar m_DiscountCooldown;

	public Text m_DiscountText;

	public GameObject m_RedPoint;

	public Button m_Button;

	public UIPopup m_CardLotteryConfirmUI;

	public UIPage m_CardLotteryOpenUI;

	public Text m_FreeTimesText;

	public GameObject m_NewbieTips;

	private BoxInfo m_BoxInfo;

	private CardLotteryInfo m_LotteryInfo;

	private int m_CostCurrency;

	private int m_CostAmount;

	private float m_Discount;

	private int m_DiamondCost;

	public void Bind(CommonDataCollection args)
	{
		int id = args["boxID"];
		m_BoxInfo = LocalResources.BoxTable.Get(id);
		m_LotteryInfo = CardLotteryUtility.GetLotteryInfo(m_BoxInfo.Type);
		m_BtnState.State = ((m_BoxInfo.Type == 9) ? 1 : 0);
		if (m_BoxInfo.Type == 9 || m_BoxInfo.Type == 19)
		{
			m_BtnState.State = 1;
		}
		else
		{
			m_BtnState.State = 0;
		}
		LobbyScene.Inst.AddCardLotteryItem((CardLotteryType)m_BoxInfo.Type);
		m_Host.EventProxy(m_Button, "OnLottery");
		UpdateContent();
	}

	private void UpdateContent()
	{
		int num = m_LotteryInfo.nextFreeTime - UtcTimeStamp.Now;
		bool flag = m_LotteryInfo.IsFree();
		bool flag2 = m_LotteryInfo.IsDiscount();
		bool flag3 = m_LotteryInfo.discount != 100 && m_LotteryInfo.discountTime == 0;
		float num2 = flag2 ? ((float)m_LotteryInfo.discount / 100f) : 1f;
		int num3 = (int)((float)m_BoxInfo.LotteryMoneyCost * num2);
		int type = m_BoxInfo.Type;
		bool flag4 = ShopUtility.GetCurrencyAmount(type) > 0;
		bool flag5 = ShopUtility.GetCurrencyAmount(m_BoxInfo.LotteryMoneyType) >= num3;
		m_CostCurrency = (flag4 ? type : m_BoxInfo.LotteryMoneyType);
		m_CostAmount = (flag4 ? 1 : num3);
		m_Discount = num2;
		m_DiamondCost = m_BoxInfo.LotteryMoneyCost;
		m_RedPoint.SetActive(flag | flag4);
		bool flag6 = m_LotteryInfo.nextFreeTime > 0 && num > 0 && m_LotteryInfo.freeTimesRemained >= 0 && (!flag2 | flag3);
		m_FreeTimeCooldown.gameObject.SetActive(flag6 && (m_LotteryInfo.type != CardLotteryType.Normal || m_LotteryInfo.freeTimesRemained > 0));
		m_FreeTimesText.gameObject.SetActive(m_LotteryInfo.type == CardLotteryType.Normal && (flag || m_LotteryInfo.freeTimesRemained == 0));
		if (m_FreeTimeCooldown.gameObject.activeSelf)
		{
			m_FreeTimeCooldown.SetTime(num, num, UpdateContent);
		}
		if (m_FreeTimesText.gameObject.activeSelf)
		{
			m_FreeTimesText.text = (flag ? string.Format(Localization.FreeTimesFormat, m_LotteryInfo.freeTimesRemained) : Localization.TipsNoFreeTimes);
		}
		DropItem dropItem = LocalResources.DropItemTable.Get((m_LotteryInfo.type == CardLotteryType.Normal) ? m_CostCurrency : type);
		m_PriceIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon.Replace("_drop", ""));
		if (m_LotteryInfo.type == CardLotteryType.Normal)
		{
			m_PriceText.text = (flag ? Localization.Free : m_CostAmount.ToString());
			m_PriceText.color = ((!flag && !flag4 && !flag5) ? Color.red : Color.white);
		}
		else
		{
			if (flag4)
			{
				m_PriceText.text = "1";
				m_PriceIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon.Replace("_drop", ""));
			}
			else
			{
				m_PriceText.text = m_DiamondCost.ToString();
				m_PriceIcon.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(m_BoxInfo.LotteryMoneyType).Icon);
			}
			m_PriceText.color = Color.white;
		}
		m_BtnState.GetComponent<UIStateItem>().State = (flag ? 1 : 0);
		m_PriceIcon.transform.parent.gameObject.SetActive(!flag);
		m_DiscountContainer.SetActive((!flag && !flag4) & flag2);
		if (m_DiscountContainer.activeSelf)
		{
			int num4 = (m_LotteryInfo.discountTime > 0) ? Mathf.Max(0, m_LotteryInfo.discountTime - UtcTimeStamp.Now) : 0;
			m_DiscountCooldown.gameObject.SetActive(num4 > 0);
			if (m_DiscountCooldown.gameObject.activeSelf)
			{
				m_DiscountCooldown.SetTime(num4, num4, UpdateContent);
			}
			m_DiscountText.text = (int)(num2 * 10f) + Localization.Discount;
			if (m_LotteryInfo.type == CardLotteryType.Normal)
			{
				m_PriceText.text = m_BoxInfo.LotteryMoneyCost.ToString();
				m_PriceText.color = Color.white;
			}
		}
		int prefValueInt = LocalPlayerDatabase.GetPrefValueInt(GetNewbieFlag());
		m_NewbieTips.SetActive(flag && prefValueInt != 2);
	}

	private string GetNewbieFlag()
	{
		if (m_LotteryInfo.type != CardLotteryType.Normal)
		{
			return "CardLotteryFirstFree_Purple";
		}
		return "CardLotteryFirstFree_Blue";
	}

	public void OnLottery()
	{
		if (m_LotteryInfo.drawCountTdy >= m_LotteryInfo.drawCountLimit)
		{
			UILobby.Current.ShowTips(Localization.TipsCardLotteryLimit);
			return;
		}
		if (m_NewbieTips.activeSelf)
		{
			m_NewbieTips.SetActive(value: false);
			LocalPlayerDatabase.SetPrefValue(GetNewbieFlag(), 2);
		}
		if (m_LotteryInfo.IsFree())
		{
			OpenBoxImmediately();
		}
		else if (ShopUtility.GetCurrencyAmount(m_BoxInfo.Type) > 0)
		{
			OpenBoxUseTicket();
		}
		else if (ShopUtility.GetCurrencyAmount(m_CostCurrency) < m_CostAmount)
		{
			if (m_CostCurrency == 1)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.TipsNoEnoughGold, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, LobbyScene_Money.BuyGold, null);
			}
			else if (m_CostCurrency == 2)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.NotEnoughDiamonds, Localization.Yes, Localization.NextTime, "", LobbyScene_Money.Recharge, null);
			}
			else if (m_CostCurrency == 4)
			{
				string msg = string.Format(Localization.NotEnoughAndBuy, Localization.Ticket);
				UILobby.Current.ShowMessageBoxYesNo(msg, Localization.Yes, Localization.NextTime, "", LobbyScene_Money.BuyTicket, null);
			}
			else
			{
				UILobby.Current.ShowTips(LocalResources.DropItemTable.Get(m_CostCurrency).Name + " not enough!");
			}
		}
		else
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["boxInfo"].val = m_BoxInfo;
			commonDataCollection["goodsID"] = m_BoxInfo.Type;
			commonDataCollection["discount"] = m_Discount;
			UILobby.Current.ShowUI(m_CardLotteryConfirmUI, commonDataCollection);
		}
	}

	private void OpenBoxImmediately()
	{
		BoxUtility.RequestOpenBoxByID(m_BoxInfo.Id, delegate(ItemInfo[] items)
		{
			CardLotteryItem cardLotteryItem = LobbyScene.Inst.GetCardLotteryItem((CardLotteryType)m_BoxInfo.Type);
			CardLotteryUI.Inst.OnOpenBox(m_BoxInfo.Id, m_CardLotteryOpenUI, cardLotteryItem, items);
			LocalPlayerDatabase.RefreshCardLotteryInfo();
		});
	}

	private void OpenBoxUseTicket()
	{
		BoxUtility.RequestOpenBoxByID(m_BoxInfo.Id, delegate(ItemInfo[] items)
		{
			CardLotteryItem cardLotteryItem = LobbyScene.Inst.GetCardLotteryItem((CardLotteryType)m_BoxInfo.Type);
			CardLotteryUI.Inst.OnOpenBox(m_BoxInfo.Id, m_CardLotteryOpenUI, cardLotteryItem, items);
			LocalPlayerDatabase.RefreshCardLotteryInfo();
		}, null, 1);
	}
}
