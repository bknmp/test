using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class BuyMembershipItem
{
	public UIDataBinder m_Host;

	public Text m_Unit;

	public Text m_Price;

	public Text m_SelectedTime;

	public Button m_SelectBtn;

	public GameObject m_Selected;

	private int m_GoodsID;

	public static int globalSelected;

	public void Bind(CommonDataCollection args)
	{
		m_GoodsID = args["goodsID"];
		GoodsInfo goodsInfo = LocalResources.GoodsTable.Get(m_GoodsID);
		MembershipInfo membershipInfo = LocalResources.MembershipInfos.Get(goodsInfo.SpecialParam[0]);
		m_Price.text = (goodsInfo.Price / 10).ToString();
		if (membershipInfo.Id == 1)
		{
			m_Unit.text = goodsInfo.SpecialParam[1] + Localization.Week;
		}
		else if (membershipInfo.Id == 2)
		{
			m_Unit.text = goodsInfo.SpecialParam[1] + Localization.Month;
		}
		m_Selected.SetActive(globalSelected == m_GoodsID);
		if (globalSelected == m_GoodsID)
		{
			m_SelectedTime.text = (goodsInfo.SpecialParam[1] * membershipInfo.Duration).ToString() + Localization.Day;
		}
		m_Host.EventProxy(m_SelectBtn, "OnSelectButtonClicked");
	}

	public void OnSelectButtonClicked()
	{
		globalSelected = m_GoodsID;
		UIDataEvents.Inst.InvokeEvent("OnStoreGoodsBuyTimeChanged");
	}
}
