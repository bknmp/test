using GameMessages;
using LightUI;

internal class AccountPage_ChangeNameRedPoint
{
	public UIDataBinder m_Host;

	public void Bind(CommonDataCollection args)
	{
		m_Host.gameObject.SetActive(!LocalPlayerDatabase.ChangeAccountNameInfo.HasChangedName() && !LocalPlayerDatabase.Settings.disableChangeName);
	}
}
