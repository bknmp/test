using BehaviorDesigner.Runtime.Tasks;

public class DoPatrolCommand : Action
{
	private AIController ai;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
		ai.UpdatePatrolling();
	}

	public override TaskStatus OnUpdate()
	{
		if (!ai.InMode(AIMode.Patrol))
		{
			return TaskStatus.Failure;
		}
		if (!ai.IsMoving)
		{
			ai.UpdatePatrolling();
		}
		ai.MoveToTarget();
		return TaskStatus.Running;
	}
}
