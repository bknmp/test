using GameMessages;
using LightUtility;
using System.Collections.Generic;

public static class CardLotteryUtility
{
	public class ExpectAmount
	{
		public int totalCount;

		public int minItemID;

		public int minItemCount;
	}

	public enum OneTimeEvent
	{
		AdvanceTicketOwned,
		SuperTicketOwned,
		SupperDiscount,
		RainbowTicketOwned
	}

	public enum OneTimeEventStatus
	{
		Uninitialized,
		Happened,
		Read
	}

	public class OneTimeEventRecord
	{
		public OneTimeEvent type;

		public OneTimeEventStatus status;
	}

	private static Dictionary<OneTimeEvent, OneTimeEventRecord> OneTimeEventRecords = new Dictionary<OneTimeEvent, OneTimeEventRecord>();

	public static bool CheckStatus(OneTimeEvent type, OneTimeEventStatus status)
	{
		OneTimeEventRecord value = null;
		if (OneTimeEventRecords.TryGetValue(type, out value))
		{
			return value.status == status;
		}
		return false;
	}

	public static void UpdateOneTimeEvents()
	{
		if (OneTimeEventRecords.Count == 0)
		{
			OneTimeEventRecords.Add(OneTimeEvent.AdvanceTicketOwned, new OneTimeEventRecord
			{
				type = OneTimeEvent.AdvanceTicketOwned,
				status = OneTimeEventStatus.Uninitialized
			});
			OneTimeEventRecords.Add(OneTimeEvent.SuperTicketOwned, new OneTimeEventRecord
			{
				type = OneTimeEvent.SuperTicketOwned,
				status = OneTimeEventStatus.Uninitialized
			});
			OneTimeEventRecords.Add(OneTimeEvent.SupperDiscount, new OneTimeEventRecord
			{
				type = OneTimeEvent.SupperDiscount,
				status = OneTimeEventStatus.Uninitialized
			});
			OneTimeEventRecords.Add(OneTimeEvent.RainbowTicketOwned, new OneTimeEventRecord
			{
				type = OneTimeEvent.RainbowTicketOwned,
				status = OneTimeEventStatus.Uninitialized
			});
		}
		foreach (KeyValuePair<OneTimeEvent, OneTimeEventRecord> oneTimeEventRecord in OneTimeEventRecords)
		{
			if (oneTimeEventRecord.Value.status == OneTimeEventStatus.Uninitialized)
			{
				bool flag = false;
				switch (oneTimeEventRecord.Value.type)
				{
				case OneTimeEvent.AdvanceTicketOwned:
					flag = (ShopUtility.GetCurrencyAmount(8) > 0);
					break;
				case OneTimeEvent.SuperTicketOwned:
					flag = (ShopUtility.GetCurrencyAmount(9) > 0);
					break;
				case OneTimeEvent.SupperDiscount:
				{
					CardLotteryInfo lotteryInfo = GetLotteryInfo(9);
					flag = (lotteryInfo.IsDiscount() && lotteryInfo.discountTime > 0);
					break;
				}
				case OneTimeEvent.RainbowTicketOwned:
					flag = (ShopUtility.GetCurrencyAmount(19) > 0);
					break;
				}
				if (flag)
				{
					oneTimeEventRecord.Value.status = OneTimeEventStatus.Happened;
				}
			}
		}
	}

	public static void ReadAllOneTimeEvents()
	{
		foreach (KeyValuePair<OneTimeEvent, OneTimeEventRecord> oneTimeEventRecord in OneTimeEventRecords)
		{
			if (oneTimeEventRecord.Value.status == OneTimeEventStatus.Happened)
			{
				oneTimeEventRecord.Value.status = OneTimeEventStatus.Read;
			}
		}
	}

	public static ExpectAmount GetExpectAmount(BoxInfo boxInfo)
	{
		int num = 0;
		int num2 = 0;
		int minItemID = 0;
		for (int i = 0; i < boxInfo.AwardCardCountArray.Length; i++)
		{
			int num3 = boxInfo.AwardCardCountArray[i];
			num += num3;
			if (i > 0 && num3 > 0 && num2 == 0)
			{
				num2 = num3;
				int num4;
				switch (i)
				{
				default:
					num4 = 20003;
					break;
				case 2:
					num4 = 20002;
					break;
				case 1:
					num4 = 20001;
					break;
				}
				minItemID = num4;
			}
		}
		return new ExpectAmount
		{
			totalCount = num,
			minItemID = minItemID,
			minItemCount = num2
		};
	}

	public static BoxInfo GetLotteryBox(CardLotteryType type, int grade)
	{
		for (int i = 0; i < LocalResources.BoxTable.Count; i++)
		{
			BoxInfo boxInfo = LocalResources.BoxTable[i];
			if (boxInfo.Type == (int)type)
			{
				GradeMappingInfo gradeMapping = LocalResources.GetGradeMapping(grade);
				if (gradeMapping.Id >= boxInfo.GradesRange[0] && gradeMapping.Id <= boxInfo.GradesRange[1])
				{
					return boxInfo;
				}
			}
		}
		return null;
	}

	public static CardLotteryInfo GetLotteryInfo(int type)
	{
		if (LocalPlayerDatabase.CardLotteryInfo == null)
		{
			return null;
		}
		CardLotteryInfo[] infos = LocalPlayerDatabase.CardLotteryInfo.infos;
		foreach (CardLotteryInfo cardLotteryInfo in infos)
		{
			if (cardLotteryInfo.type == (CardLotteryType)type)
			{
				return cardLotteryInfo;
			}
		}
		return null;
	}

	public static bool HasUnlockedNewCard()
	{
		InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			if (CardUtility.CanDropCardPiece(inGameStoreInfo.Id) && !CardUtility.IsOwned(inGameStoreInfo.Id) && !CardUtility.CanComposeCard(inGameStoreInfo.Id))
			{
				return true;
			}
		}
		return false;
	}

	public static string GetLotteryName(BoxInfo info)
	{
		return info.Name.Substring(2);
	}

	public static bool IsFree(this CardLotteryInfo info)
	{
		if (info.freeTimesRemained > 0 && info.nextFreeTime > 0)
		{
			return info.nextFreeTime <= UtcTimeStamp.Now;
		}
		return false;
	}

	public static bool IsDiscount(this CardLotteryInfo info)
	{
		if (info.discount != 100)
		{
			if (info.discountTime != 0)
			{
				return info.discountTime > UtcTimeStamp.Now;
			}
			return true;
		}
		return false;
	}
}
