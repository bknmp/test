public enum BindFriendTaskType
{
	bind,
	friendLogin,
	gameWithFriend,
	friendRecharge
}
