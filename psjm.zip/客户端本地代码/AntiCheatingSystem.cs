using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;

public class AntiCheatingSystem : GameSocialNetBehaviour
{
	private struct UsingTime
	{
		public float startTime;

		public int addCount;

		public int QTECount;
	}

	private class Ghost
	{
		public string user;

		public Transform transform;

		public Vector3 lastPosition;

		public float lastTime;

		public bool IsValid => GameTime - lastTime < 3f;
	}

	private class GhostList
	{
		internal List<Ghost> list = new List<Ghost>();

		public void Add(Transform t, string userId)
		{
			list.Add(new Ghost
			{
				user = userId,
				transform = t,
				lastTime = GameTime,
				lastPosition = t.position
			});
		}

		public bool FindNearby(Vector3 pos, float radius, string user)
		{
			if (list == null || list.Count == 0)
			{
				return false;
			}
			float num = radius * radius;
			foreach (Ghost item in list)
			{
				if (!(item.user != user) && item.IsValid && (pos - item.lastPosition).FlattenY().sqrMagnitude < num)
				{
					return true;
				}
			}
			return false;
		}

		public void Update()
		{
			if (list == null)
			{
				return;
			}
			int num = 0;
			while (num < list.Count)
			{
				Ghost ghost = list[num];
				if (ghost.transform != null)
				{
					if (ghost.transform.gameObject.activeInHierarchy)
					{
						ghost.lastPosition = ghost.transform.position;
						ghost.lastTime = GameTime;
					}
					else
					{
						ghost.transform = null;
					}
				}
				if (!ghost.IsValid)
				{
					list.RemoveAt(num);
				}
				else
				{
					num++;
				}
			}
		}
	}

	public float m_CheckInterval;

	public float m_TimeDiffThreshold;

	public float m_OverSpeedTimeThreshold;

	public float m_OverSpeedFactorThreshold;

	public float m_PlaceableDistanceThreshold;

	public float m_CooldownTimeThreshold;

	public float m_UseDistanceThreshold;

	public float m_ProjectileDistance;

	public float m_GrenadeDistance;

	public float m_MedkitDistance;

	public float m_SaberDistance;

	public float m_TrapMinDamage;

	public float m_SpawnProjectileDistance;

	public int m_SuspectCountThreshold;

	public float m_MinTrapInterval;

	private int m_MaxSupplementBoxCount;

	private float m_StartLocalTime;

	private uint m_StartServerTime;

	private float m_CullDistance2;

	private float m_LastUpdateTime;

	private float m_AllThiefsShowInMiniMapDuration;

	private float m_NotAllThiefsShowInMiniMapDuration;

	public static AntiCheatingSystem Inst;

	public static float ElapsedLocal;

	public static float ElapsedServer;

	private SafeGameDictionary<string, List<AntiCheatingResult>> PlayerReported = new SafeGameDictionary<string, List<AntiCheatingResult>>();

	private SafeGameDictionary<string, bool> PlayerNotified = new SafeGameDictionary<string, bool>();

	private SafeGameDictionary<string, float> PlayerOverSpeedTime = new SafeGameDictionary<string, float>();

	private SafeGameDictionary<string, float> PlayerOverAnimatorSpeedTime = new SafeGameDictionary<string, float>();

	private SafeGameDictionary<string, float> PlayerExpectedSpeed = new SafeGameDictionary<string, float>();

	private SafeGameDictionary<string, UsingTime> PlayerUsingTime = new SafeGameDictionary<string, UsingTime>();

	private SafeGameDictionary<string, SafeGameDictionary<AntiCheatingResult, int>> SuspectCounter = new SafeGameDictionary<string, SafeGameDictionary<AntiCheatingResult, int>>();

	private SafeGameDictionary<string, SafeGameDictionary<AntiCheatingResult, StringBuilder>> SuspectDetails = new SafeGameDictionary<string, SafeGameDictionary<AntiCheatingResult, StringBuilder>>();

	private SafeGameDictionary<AntiCheatingGhost, GhostList> Ghosts = new SafeGameDictionary<AntiCheatingGhost, GhostList>();

	private SafeGameDictionary<string, float> PlayerLastAddTrapTime = new SafeGameDictionary<string, float>();

	private static StringBuilder StringBuff = new StringBuilder();

	private static readonly List<RpcBehaviourType> m_SupportedCheckList_BR = new List<RpcBehaviourType>
	{
		RpcBehaviourType.Move,
		RpcBehaviourType.ApplyDamage,
		RpcBehaviourType.SpawnProjectile,
		RpcBehaviourType.UsePropcard,
		RpcBehaviourType.CreateBuff
	};

	private static readonly List<RpcBehaviourType> m_SupportedCheckList_RedEnvelope = new List<RpcBehaviourType>
	{
		RpcBehaviourType.Move,
		RpcBehaviourType.ApplyDamage,
		RpcBehaviourType.SpawnProjectile,
		RpcBehaviourType.CreateBuff
	};

	private static float GameTime
	{
		get
		{
			if (!(InGameScene.Inst != null))
			{
				return Time.realtimeSinceStartup;
			}
			return InGameScene.Inst.GameTime;
		}
	}

	public bool AlarmOn
	{
		get;
		set;
	}

	private new void Awake()
	{
		base.Awake();
		Inst = this;
		foreach (AntiCheatingGhost value in Enum.GetValues(typeof(AntiCheatingGhost)))
		{
			Ghosts[value] = new GhostList();
		}
		ElapsedLocal = 0f;
		ElapsedServer = 0f;
		m_AllThiefsShowInMiniMapDuration = (m_NotAllThiefsShowInMiniMapDuration = 0f);
		Initialize();
		if (GameRuntime.ResumeGame)
		{
			DelayEnableAntiCheat();
		}
	}

	public void DelayEnableAntiCheat(float delay = 10f)
	{
		base.enabled = false;
		Invoke("DoDelayEnableAntiCheat", delay);
	}

	private void DoDelayEnableAntiCheat()
	{
		m_LastUpdateTime = 0f;
		base.enabled = true;
	}

	private new void OnDestroy()
	{
		base.OnDestroy();
		if (Inst == this)
		{
			Inst = null;
		}
	}

	private void Start()
	{
		CullArea cullArea = UnityEngine.Object.FindObjectOfType<CullArea>();
		if (cullArea != null)
		{
			m_CullDistance2 = cullArea.Size.Div(cullArea.Subdivisions[0]).sqrMagnitude;
		}
		else
		{
			m_CullDistance2 = float.MaxValue;
		}
		InvokeRepeating("LocalCheck", m_CheckInterval, m_CheckInterval);
	}

	private void LateUpdate()
	{
		foreach (KeyValuePair<AntiCheatingGhost, GhostList> ghost in Ghosts)
		{
			ghost.Value.Update();
		}
		float num = Time.realtimeSinceStartup - m_LastUpdateTime;
		if (base.enabled && m_LastUpdateTime > 0f && num > 3f)
		{
			PlayerController inst = PlayerController.Inst;
			if (!GameRuntime.WitnessMode && !GameRuntime.IsNormalGameOver && PhotonNetwork.connected && inst != null)
			{
				if (inst.PlayingRole == RoleType.Thief && inst.IsDying)
				{
					HandleFroze("1", num);
					return;
				}
				if (num > 5f)
				{
					HandleFroze("2", num);
					return;
				}
			}
		}
		m_LastUpdateTime = Time.realtimeSinceStartup;
		if (!base.enabled || GameRuntime.ResumeGame || GameRuntime.IsOfflineMode || GameRuntime.WitnessMode || !(InGameStartup.Inst != null) || !InGameStartup.Inst.CountDownStartFinished || GameRuntime.PlayingRole == RoleType.Thief)
		{
			return;
		}
		bool flag = true;
		int num2 = 0;
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer.PlayingRole == RoleType.Thief && !allPlayer.FinalDeadOrEscaped)
			{
				num2++;
				if (!InGameMinimap.Inst.IsEnemyVisibleInMinimap(allPlayer))
				{
					flag = false;
				}
			}
		}
		if (num2 > 0)
		{
			if (flag)
			{
				m_AllThiefsShowInMiniMapDuration += Time.deltaTime;
			}
			else
			{
				m_NotAllThiefsShowInMiniMapDuration += Time.deltaTime;
			}
			if (PlayerController.Inst != null && m_AllThiefsShowInMiniMapDuration > 5f && m_NotAllThiefsShowInMiniMapDuration < 1f)
			{
				string detail = AddDetails($"map:{GameRuntime.MapType} role:{GameRuntime.PlayingRole} allShow:{m_AllThiefsShowInMiniMapDuration} notAllShow:{m_NotAllThiefsShowInMiniMapDuration}");
				UpdateSuspectDetail(PlayerController.Inst.UserId, AntiCheatingResult.MiniMapOpen, detail);
				SendReport(PlayerController.Inst.UserId, AntiCheatingResult.MiniMapOpen);
			}
		}
	}

	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.red;
		foreach (KeyValuePair<AntiCheatingGhost, GhostList> ghost in Ghosts)
		{
			foreach (Ghost item in ghost.Value.list)
			{
				if (item.IsValid)
				{
					Gizmos.DrawWireCube(item.lastPosition, Vector3.one);
				}
			}
		}
	}

	private void OnApplicationPause(bool pause)
	{
		m_StartLocalTime = 0f;
		m_StartServerTime = 0u;
	}

	private void HandleFroze(string param1, float frozeDeltaTime)
	{
		m_LastUpdateTime = 0f;
		LocalPlayerDatabase.ReportEvent(GameMessages.Event.USE_BUG, param1, ((int)frozeDeltaTime).ToString());
		PhotonNetwork.networkingPeer.Disconnect();
	}

	private void Initialize()
	{
		if (m_MaxSupplementBoxCount != 0)
		{
			return;
		}
		GameObject gameObject = GameObject.Find("SupplementArea");
		if (gameObject != null)
		{
			SceneObjectSpawner[] componentsInChildren = gameObject.GetComponentsInChildren<SceneObjectSpawner>(includeInactive: true);
			foreach (SceneObjectSpawner sceneObjectSpawner in componentsInChildren)
			{
				m_MaxSupplementBoxCount += sceneObjectSpawner.GetMaxCount;
			}
		}
	}

	private void LocalCheck()
	{
		if (PhotonNetwork.connected && PhotonNetwork.inRoom && !GameRuntime.IsNormalGameOver)
		{
			InGameCheck();
			return;
		}
		m_StartLocalTime = 0f;
		m_StartServerTime = 0u;
	}

	private void InGameCheck()
	{
		if (!(InGameScene.Inst == null) && !(UdpPingPeer.Inst == null) && UdpPingPeer.Inst.IsServerTimeValid)
		{
			if (m_StartLocalTime == 0f)
			{
				m_StartLocalTime = Time.realtimeSinceStartup;
			}
			if (m_StartServerTime == 0)
			{
				m_StartServerTime = UdpPingPeer.ServerTimeInSecs;
			}
			ElapsedLocal = Mathf.Abs(Time.realtimeSinceStartup - m_StartLocalTime);
			ElapsedServer = (float)(double)(UdpPingPeer.ServerTimeInSecs - m_StartServerTime);
			if (ElapsedLocal > 3f && Mathf.Abs(ElapsedLocal - ElapsedServer) > m_TimeDiffThreshold)
			{
				Quit();
			}
		}
	}

	private void SendReport(string userID, AntiCheatingResult result)
	{
		if (result == AntiCheatingResult.Normal)
		{
			return;
		}
		List<AntiCheatingResult> value = null;
		if (!PlayerReported.TryGetValue(userID, out value))
		{
			value = new List<AntiCheatingResult>();
			PlayerReported.Add(userID, value);
		}
		string text = "";
		try
		{
			if (SuspectDetails.ContainsKey(userID) && SuspectDetails[userID].TryGetValue(result, out StringBuilder value2))
			{
				text = value2.ToString();
			}
		}
		catch (Exception)
		{
		}
		if (!value.Contains(result))
		{
			value.Add(result);
			uint roleID = GameRuntime.RoomPlayers[userID].RoleID;
			string text2 = result.ToString();
			if (GameRuntime.IsCustomRoom)
			{
				text2 += "_custom";
			}
			else if (GameRuntime.IsMapBattleRoyale)
			{
				text2 += "_battle";
			}
			LocalPlayerDatabase.ReportEvent(GameMessages.Event.AUTO_REPORT, roleID.ToString(), text2, text, GameRuntime.CurrentRoom.name);
			if (PhotonNetwork.isMasterClient)
			{
				Inst.StartCoroutine(Inst.StartQueryCheatingPlayer());
			}
			UnityEngine.Debug.LogWarningFormat("Report Cheating {0}: {1}, {2}", userID, text2, text);
			ShowTipsWarning(userID, text2, "上报了!");
		}
	}

	private void Quit()
	{
		SendReport(PhotonNetwork.player.UserId, AntiCheatingResult.TimeMismatched);
		UnityEngine.Debug.LogWarningFormat("Cheating");
		UILobby.Current.ShowTips(Localization.TipsCheating);
		Invoke("QuitApplication", 1f);
	}

	private void QuitApplication()
	{
		GameRuntime.PhotonDisonnectOnPurpose = true;
		PhotonNetwork.Disconnect();
		Application.Quit();
	}

	private IEnumerator StartQueryCheatingPlayer()
	{
		int maxTime = 3;
		float interval = 2f;
		yield return new WaitForSeconds(interval);
		HttpRequestQueryCheating msg = new HttpRequestQueryCheating
		{
			roleIDs = GetReportedRoleIDs()
		};
		while (true)
		{
			int num = maxTime;
			maxTime = num - 1;
			if (num > 0)
			{
				GameHttpManager.Inst.SendNoWait(msg, delegate(HttpResponseQueryCheating response)
				{
					OnQueryCheatingResult(response.roleIDs, response.reasons);
				});
				yield return new WaitForSeconds(interval);
				continue;
			}
			break;
		}
	}

	private uint[] GetReportedRoleIDs()
	{
		List<uint> list = new List<uint>();
		foreach (string key in PlayerReported.Keys)
		{
			list.Add(GameRuntime.RoomPlayers[key].RoleID);
		}
		return list.ToArray();
	}

	private void OnQueryCheatingResult(uint[] roleIDs, string[] reasons)
	{
		for (int i = 0; i < roleIDs.Length; i++)
		{
			string text = GameRuntime.RoleID2UserID(roleIDs[i]);
			if (!string.IsNullOrEmpty(text) && !PlayerNotified[text])
			{
				PlayerNotified[text] = true;
				int num = UserId2NumId.Get(text);
				InGameScene.Inst.m_PhotonView.RPC("NotifyCheating", PhotonTargets.AllViaServer, num, reasons[i]);
				ShowTipsWarning(text, reasons[i]);
				PhotonPlayer photonPlayer = PhotonPlayer.Find(text);
				if (photonPlayer != null && PhotonNetwork.isMasterClient)
				{
					PhotonNetwork.CloseConnection(photonPlayer);
				}
			}
		}
	}

	public override void OnNotifyCheating(RpcNotifyCheating msg)
	{
		OnQueryCheatingResult(msg.roleIDs, msg.reasons);
	}

	public static void AddGhost(AntiCheatingGhost g, Transform t, string userId)
	{
		if (Inst != null)
		{
			Inst.Ghosts[g].Add(t, userId);
		}
	}

	public static void BehaviourCheck(RpcBehaviourType type, MonoBehaviour target, object param1 = null, object param2 = null, object param3 = null, object param4 = null)
	{
		if (GameRuntime.ResumeGame || Inst == null || !Inst.enabled || (GameRuntime.IsMapBattleRoyale && !m_SupportedCheckList_BR.Contains(type)) || (GameRuntime.IsMapRedEnvelopeFight && !m_SupportedCheckList_RedEnvelope.Contains(type)) || (GameRuntime.IsMapCoinFight && !m_SupportedCheckList_BR.Contains(type)))
		{
			return;
		}
		if (InGameScene.Inst != null && PhotonNetwork.inRoom && target != null && !GameRuntime.IsOfflineMode && !GameRuntime.IsNormalGameOver && !GameRuntime.WitnessMode && PlayerController.Inst != null && PlayerController.Inst.PerformanceQuality > 10)
		{
			string cheater;
			AntiCheatingResult antiCheatingResult = DoCheck(out cheater, type, target, param1, param2, param3, param4);
			if (antiCheatingResult != 0 && !string.IsNullOrEmpty(cheater))
			{
				try
				{
					Inst.SendReport(cheater, antiCheatingResult);
				}
				catch (Exception message)
				{
					UnityEngine.Debug.LogError(message);
				}
			}
		}
		else
		{
			Inst.PlayerOverSpeedTime.Clear();
			Inst.PlayerOverAnimatorSpeedTime.Clear();
		}
	}

	private void ShowTipsWarning(string userID, string result, string detail = "")
	{
		if (AlarmOn)
		{
			string text = (!string.IsNullOrEmpty(detail)) ? $"Cheating Warning {userID} : {result} ({detail})" : $"Cheating Warning {userID} : {result} ";
			UILobby.Current.ShowTips(text);
			UnityEngine.Debug.LogWarning(text);
		}
	}

	private static AntiCheatingResult DoCheck(out string cheater, RpcBehaviourType type, MonoBehaviour target, object param1, object param2, object param3, object param4)
	{
		try
		{
			PlayerController playerController = target as PlayerController;
			if (!(playerController != null) || (!playerController.IsAI && (!playerController.IsMine || !(playerController.UserId != PhotonNetwork.player.UserId))))
			{
				switch (type)
				{
				case RpcBehaviourType.Move:
					return CheckMove(out cheater, playerController);
				case RpcBehaviourType.PlacePlaceable:
					return CheckPlacePlaceable(out cheater, playerController, param1 as PlaceableInfo, (Vector3)param2, (Vector3)param3);
				case RpcBehaviourType.TeleportOut:
					return CheckTeleport(out cheater, teleportOut: true, playerController);
				case RpcBehaviourType.TeleportIn:
					return CheckTeleport(out cheater, teleportOut: false, playerController);
				case RpcBehaviourType.AddCoin:
					return CheckAddCoin(out cheater, playerController, (InGameCoinRewardReason)param1, (int)param2);
				case RpcBehaviourType.GiveCoin:
					return CheckGiveCoin(out cheater, playerController, (int)param1, (int[])param2);
				case RpcBehaviourType.CreateBuff:
					return CheckCreateBuff(out cheater, playerController, (int)param1, (BuffCorrelation)param2, (int)param3, param4 as PlayerController);
				case RpcBehaviourType.ShapeShift:
					return CheckShapeShift(out cheater, playerController, (int)param1);
				case RpcBehaviourType.SetWeapon:
					return CheckWeapon(out cheater, playerController, param1 as ProjectileLauncher, (int)param2);
				case RpcBehaviourType.SetMagazine:
					return CheckMagazine(out cheater, playerController, param1 as ProjectileLauncher, (int)param2, (bool)param3, (int)param4);
				case RpcBehaviourType.RadarScan:
					return CheckRadarScan(out cheater, playerController);
				case RpcBehaviourType.AddProp:
					return CheckAddProp(out cheater, playerController, (int)param1);
				case RpcBehaviourType.StartUsing:
					return CheckStartUsing(out cheater, playerController, (UsableObject)param1);
				case RpcBehaviourType.AddUsing:
					return CheckAddUsing(out cheater, playerController, (UsableObject)param1, (float)param2, (int)param3);
				case RpcBehaviourType.ApplyDamage:
					return CheckApplyDamage(out cheater, playerController, (float)param1, (int)param2, (DamageSourceType)param3, (DamageExtraInfo)param4);
				case RpcBehaviourType.SpawnProjectile:
					return CheckSpawnProjectile(out cheater, playerController, param1 as ProjectileLauncher, (ProjectileExtraInfo)param2);
				case RpcBehaviourType.GiveTalent:
					return CheckGiveTalent(out cheater, playerController, (float)param1, (float)param2, (int[])param3);
				case RpcBehaviourType.NotifyQTEResult:
					return CheckQTEResult(out cheater, playerController, (UsableObject)param1, (InGameQTE.Result)param2, (Vector3)param3);
				case RpcBehaviourType.FinalEscaped:
					return CheckFinalEscaped(out cheater, playerController);
				case RpcBehaviourType.TalentEffect:
					return CheckTalentEffect(out cheater, playerController, (int)param1, (int)param2, (float[])param3);
				case RpcBehaviourType.AddTrap:
					return CheckAddTrap(out cheater, playerController, (string)param1, (int)param2);
				case RpcBehaviourType.AddSupplementBox:
					return CheckAddSupplementBox(out cheater, playerController, (int)param1);
				case RpcBehaviourType.ChangeCardSkin:
					return CheckChangeCardSkin(out cheater);
				case RpcBehaviourType.UsePropcard:
					return CheckUsePropcard(out cheater, playerController, (int)param1);
				case RpcBehaviourType.ModifyMemory:
					return CheckModifyMemory(out cheater, playerController, (string)param1, (string)param2, (MonoBehaviour)param3);
				case RpcBehaviourType.SummaryTime:
					return CheckSummaryTime(out cheater, playerController, (int)param1);
				default:
					cheater = null;
					return LogAndReturn(cheater, AntiCheatingResult.Normal);
				}
			}
			cheater = string.Empty;
			return AntiCheatingResult.Normal;
		}
		catch (Exception ex)
		{
			UnityEngine.Debug.LogError($"DoCheck:{type} error:{ex.Message}");
			cheater = null;
			return LogAndReturn(cheater, AntiCheatingResult.Normal);
		}
	}

	private static AntiCheatingResult CheckAddSupplementBox(out string cheater, PlayerController player, int allCount)
	{
		if (Inst.m_MaxSupplementBoxCount > 0 && allCount > Inst.m_MaxSupplementBoxCount)
		{
			cheater = PhotonNetwork.CurrentInstantiationCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.AddSupplementBox);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckAddTrap(out string cheater, PlayerController creater, string carrier, int maxCount)
	{
		PlayerController playerController = PlayerController.FindPlayer(carrier);
		if (playerController != null)
		{
			if (playerController.TalentManager.GetTalent(110) == null)
			{
				cheater = carrier;
				string detail = AddDetails("talent == null");
				return CheckSuspectCounter(cheater, AntiCheatingResult.AddTrap, detail);
			}
			if (InGameScene.Inst.GameTime > 15f)
			{
				float num = Inst.PlayerLastAddTrapTime[carrier];
				Inst.PlayerLastAddTrapTime[carrier] = GameTime;
				float minTrapInterval = Inst.m_MinTrapInterval;
				if (num > 0f && GameTime - num < minTrapInterval)
				{
					cheater = carrier;
					string detail2 = AddDetails($"time:{GameTime} lastTime:{num} interval:{GameTime - num} threshold:{minTrapInterval}");
					return CheckSuspectCounter(cheater, AntiCheatingResult.AddTrap, detail2);
				}
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckTeleport(out string cheater, bool teleportOut, PlayerController player)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		Teleporter teleporter = player.Teleporter;
		if (teleporter == null)
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.Teleport);
		}
		if (teleportOut)
		{
			if (InGameScene.Inst.GameTime < InGameStartup.Inst.m_TeleportCooldownTime * (1f - Inst.m_CooldownTimeThreshold))
			{
				cheater = currentRpcCaller;
				return LogAndReturn(cheater, AntiCheatingResult.Teleport);
			}
			if (teleporter.TeleportCooldownTimeRatio > Inst.m_CooldownTimeThreshold)
			{
				cheater = currentRpcCaller;
				return CheckSuspectCounter(cheater, AntiCheatingResult.Teleport);
			}
		}
		else if (!teleporter.IsTeleporting)
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.Teleport);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckPlacePlaceable(out string cheater, PlayerController player, PlaceableInfo info, Vector3 previewPos, Vector3 playerPos)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (info == null)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy);
		}
		if (info.InGameStoreItemID != 0 && !player.Cards.Contains(info.InGameStoreItemID))
		{
			cheater = currentRpcCaller;
			string cards = GetCards(player.Cards);
			string detail = AddDetails($"misCard:{info.InGameStoreItemID} cards:{cards} whose:{player.UserId}");
			return LogAndReturn(cheater, AntiCheatingResult.CardMismatched, detail);
		}
		BaseCardSkinInfo baseCardSkinInfo = player.GetBaseCardSkinInfo(info.InGameStoreItemID);
		PlaceableObject placeableObject = PrefabSource.Inst.Load<PlaceableObject>(baseCardSkinInfo.Prefabs);
		float num = Vector3.Distance(playerPos.FlattenY(), previewPos.FlattenY());
		float num2 = placeableObject.MaxPlaceDistance * Inst.m_PlaceableDistanceThreshold;
		if (num > num2)
		{
			cheater = currentRpcCaller;
			string detail2 = AddDetails($"name:{placeableObject.name} dis:{num} threshold:{num2}");
			return CheckSuspectCounter(cheater, AntiCheatingResult.PlaceTooFar, detail2);
		}
		if (info.InGameStoreItemID != 0)
		{
			int num3 = DoBuyItem(player, info.InGameStoreItemID);
			if (num3 > 0)
			{
				cheater = currentRpcCaller;
				SetUseCardDetailTips(StringBuff, player, info.InGameStoreItemID, num3);
				return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckAddCoin(out string cheater, PlayerController player, InGameCoinRewardReason reason, int overrideCoin)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (!string.IsNullOrEmpty(currentRpcCaller))
		{
			if (reason == InGameCoinRewardReason.ExamLevel && GameRuntime.GameMode != GameMode.Exam)
			{
				cheater = currentRpcCaller;
				string detail = AddDetails($"reason:{reason} overrideCoin:{overrideCoin} mode:{GameRuntime.GameMode}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.AddCoin, detail);
			}
			if (reason == InGameCoinRewardReason.Newbie && GameRuntime.GameMode != GameMode.Newbie)
			{
				cheater = currentRpcCaller;
				string detail2 = AddDetails($"reason:{reason} overrideCoin:{overrideCoin} mode:{GameRuntime.GameMode}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.AddCoin, detail2);
			}
			int maxInGameCoinReward = GameRuntime.GetMaxInGameCoinReward(reason);
			if (overrideCoin > maxInGameCoinReward && maxInGameCoinReward > 0)
			{
				cheater = currentRpcCaller;
				string detail3 = AddDetails($"reason:{reason} overrideCoin:{overrideCoin} maxCoin:{maxInGameCoinReward}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.AddCoin, detail3);
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckGiveCoin(out string cheater, PlayerController player, int coin, int[] playerIDs)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (ArrayUtility.Contains(playerIDs, UserId2NumId.Get(player.UserId)))
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.GiveCoinSelf);
		}
		if (!string.IsNullOrEmpty(currentRpcCaller) && GetCoin(player) < coin * playerIDs.Length)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.GiveCoinTooMuch);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckGiveTalent(out string cheater, PlayerController player, float lockSpeedAmount, float trapSpeedAmount, int[] playerIDs)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (ArrayUtility.Contains(playerIDs, UserId2NumId.Get(player.UserId)))
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.GiveTalent);
		}
		float num = 0.1f;
		float num2 = player.m_TalentProperties.lockSpeedUp + 1f;
		num2 += num;
		if (lockSpeedAmount < 1E-06f || num2 < lockSpeedAmount * (float)playerIDs.Length)
		{
			cheater = currentRpcCaller;
			string detail = AddDetails($"total:{num2} give:{lockSpeedAmount * (float)playerIDs.Length}");
			return CheckSuspectCounter(cheater, AntiCheatingResult.GiveTalentTooMuch, detail);
		}
		float num3 = player.m_TalentProperties.trapSpeedUp + 1f;
		num3 += num;
		if (trapSpeedAmount < 1E-06f || num3 < trapSpeedAmount * (float)playerIDs.Length)
		{
			cheater = currentRpcCaller;
			string detail2 = AddDetails($"total:{num3} give:{trapSpeedAmount * (float)playerIDs.Length}");
			return CheckSuspectCounter(cheater, AntiCheatingResult.GiveTalentTooMuch, detail2);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckCreateBuff(out string cheater, PlayerController player, int buffID, BuffCorrelation correlation, int talentId, PlayerController user)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (buffID > 0)
		{
			if (!string.IsNullOrEmpty(currentRpcCaller) && user != null && (user.IsAI || (user.m_PhotonView.owner.UserId == currentRpcCaller && user.UserId != currentRpcCaller)))
			{
				cheater = null;
				return LogAndReturn(cheater, AntiCheatingResult.Normal);
			}
			BuffInfo buffInfo = LocalResources.BuffTable.Find(buffID);
			switch (correlation)
			{
			case BuffCorrelation.Talent:
				if (talentId <= 0)
				{
					cheater = currentRpcCaller;
					string detail10 = AddDetails($"buffID:{buffID} talentID == 0");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail10);
				}
				if (!buffInfo.DeBuff && player.TalentManager.GetTalentLevel(talentId) == 0)
				{
					cheater = currentRpcCaller;
					string detail11 = AddDetails($"buffID:{buffID} talentID:{talentId} buff:{player.UserId}");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail11);
				}
				if (buffInfo.DeBuff && user != null && user.TalentManager.GetTalentLevel(talentId) == 0)
				{
					cheater = currentRpcCaller;
					string detail12 = AddDetails($"buffID:{buffID} talentID:{talentId} debuff:{user.UserId}");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail12);
				}
				break;
			case BuffCorrelation.Connect:
				if (user.SkillManager.RoleSkill == null || !(user != null) || !(user.SkillManager.RoleSkill is Connect))
				{
					cheater = currentRpcCaller;
					string detail9 = AddDetails($"buffID:{buffID} connect:{user.CharacterID}");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail9);
				}
				break;
			default:
				if (buffInfo == null)
				{
					cheater = currentRpcCaller;
					string detail = AddDetails($"buffID:{buffID} correlation:{correlation} info == null");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail);
				}
				if (buffInfo.Correlation != correlation)
				{
					cheater = currentRpcCaller;
					string detail2 = AddDetails($"buffID:{buffID} correlation:{correlation} info:{buffInfo.Correlation}");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail2);
				}
				if (GameRuntime.IsMapBattleRoyale || GameRuntime.IsMapCoinFight)
				{
					if (buffInfo.CorrelationCardID != 0 && user != null)
					{
						return CheckUsePropcard(out cheater, user, buffInfo.CorrelationCardID);
					}
				}
				else if (!GameRuntime.IsMapRedEnvelopeFight && buffInfo.CorrelationCardID != 0 && user != null && user.Cards.Length != 0 && !user.Cards.Contains(buffInfo.CorrelationCardID))
				{
					cheater = currentRpcCaller;
					string cards = GetCards(user.Cards);
					string detail3 = AddDetails($"buffID:{buffID} correlation:{correlation} misCard:{buffInfo.CorrelationCardID} cards:{cards} whose:{user.UserId} => player:{player.UserId}");
					return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail3);
				}
				switch (correlation)
				{
				case BuffCorrelation.Buy:
					if (!GameRuntime.IsMapBattleRoyale)
					{
						if (currentRpcCaller != player.UserId)
						{
							cheater = currentRpcCaller;
							string detail5 = AddDetails($"buffID:{buffID} caller:{currentRpcCaller} player:{player.UserId}");
							return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail5);
						}
						if (buffInfo.InGameStoreItemID != 0 && !player.Cards.Contains(buffInfo.InGameStoreItemID))
						{
							cheater = currentRpcCaller;
							string cards2 = GetCards(player.Cards);
							string detail6 = AddDetails($"misCard:{buffInfo.InGameStoreItemID} cards:{cards2} whose:{player.UserId}");
							return LogAndReturn(cheater, AntiCheatingResult.CardMismatched, detail6);
						}
						int num = DoBuyItem(player, buffInfo.InGameStoreItemID);
						if (num > 0)
						{
							cheater = currentRpcCaller;
							SetUseCardDetailTips(StringBuff, player, buffInfo.InGameStoreItemID, num);
							return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
						}
					}
					break;
				case BuffCorrelation.PoliceRevive:
				case BuffCorrelation.PoliceRage:
					if (player.PlayingRole != 0)
					{
						cheater = currentRpcCaller;
						string detail7 = AddDetails($"buffID:{buffID} role:{player.PlayingRole}");
						return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail7);
					}
					break;
				case BuffCorrelation.Water:
					if (GameRuntime.MapType != MapType.TypeAmusementPark && GameRuntime.MapType != MapType.TypeBattleRoyale && GameRuntime.MapType != MapType.TypeBattleRoyaleTeam)
					{
						cheater = currentRpcCaller;
						string detail8 = AddDetails($"buffID:{buffID} mapType:{GameRuntime.MapType}");
						return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail8);
					}
					break;
				case BuffCorrelation.Boss:
					if (GameRuntime.MapType != MapType.TypeBoss || (user != null && user.PlayingRole != RoleType.Boss))
					{
						cheater = currentRpcCaller;
						string detail4 = AddDetails($"buffID:{buffID} mapType:{GameRuntime.MapType} user:{user.UserId} role:{user.PlayingRole}");
						return LogAndReturn(cheater, AntiCheatingResult.CreateBuff, detail4);
					}
					break;
				}
				break;
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckShapeShift(out string cheater, PlayerController player, int id)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		ShapeShiftInfo shapeShiftInfo = LocalResources.ShapeShiftTable.Get(id);
		if (shapeShiftInfo.Type == ShapeShiftType.Vehicle)
		{
			int num = DoBuyItem(player, shapeShiftInfo.InGameStoreItemID);
			if (num > 0)
			{
				cheater = currentRpcCaller;
				SetUseCardDetailTips(StringBuff, player, shapeShiftInfo.InGameStoreItemID, num);
				return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
			}
			if (shapeShiftInfo.InGameStoreItemID != 0 && !player.Cards.Contains(shapeShiftInfo.InGameStoreItemID))
			{
				cheater = currentRpcCaller;
				string cards = GetCards(player.Cards);
				string detail = AddDetails($"misCard:{shapeShiftInfo.InGameStoreItemID} cards:{cards} whose:{player.UserId}");
				return LogAndReturn(cheater, AntiCheatingResult.CardMismatched, detail);
			}
		}
		else if (shapeShiftInfo.Type == ShapeShiftType.Default && !player.IsLocalPlayer && player.CurrentPropID(0) == 0)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.ShapeShift);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckWeapon(out string cheater, PlayerController player, ProjectileLauncher launcher, int id)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		WeaponInfo weaponInfo = LocalResources.WeaponTable.Find(id);
		if (weaponInfo == null)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy);
		}
		if (launcher.CurrentWeapont != null && launcher.CurrentWeapont.Id + 1 != id)
		{
			cheater = currentRpcCaller;
			SetUseCardDetailTips(StringBuff, player, weaponInfo.InGameStoreItemID, 0);
			StringBuff.Append(" ,curWeaponID:").Append(launcher.CurrentWeapont.InGameStoreItemID).Append(";");
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
		}
		int num = DoBuyItem(player, weaponInfo.InGameStoreItemID);
		if (num > 0)
		{
			cheater = currentRpcCaller;
			SetUseCardDetailTips(StringBuff, player, weaponInfo.InGameStoreItemID, num);
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckMagazine(out string cheater, PlayerController player, ProjectileLauncher launcher, int newMagazineRemained, bool manual, int oldMagazineRemained)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (launcher.CurrentWeapont != null)
		{
			float threshold = GetThreshold(4f, LocalPlayerDatabase.Settings.antiCheatingSettings.magazineAddThreshold);
			if ((float)launcher.MagazineRemained + threshold < (float)newMagazineRemained || oldMagazineRemained + 1 < newMagazineRemained)
			{
				cheater = currentRpcCaller;
				string detail = AddDetails($"map:{GameRuntime.MapType} localMagazine:{launcher.MagazineRemained} newMagazineRemained:{newMagazineRemained} threshold:{threshold} oldMagazineRemained:{oldMagazineRemained}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.BuyMagazine, detail);
			}
			InGameStoreInfo inGameStoreInfo = FindMagazineForWeaponID(player, launcher.CurrentWeapont.Id);
			if (inGameStoreInfo == null)
			{
				cheater = currentRpcCaller;
				StringBuff.Length = 0;
				SetPlayerTips(StringBuff, player);
				StringBuff.Append(" ,newRemained:").Append(newMagazineRemained).Append(";");
				return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
			}
			if (!manual)
			{
				int num = DoBuyItem(player, inGameStoreInfo.Id);
				if (num > 0)
				{
					cheater = currentRpcCaller;
					SetUseCardDetailTips(StringBuff, player, inGameStoreInfo.Id, num);
					return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
				}
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckRadarScan(out string cheater, PlayerController player)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		InGameStoreInfo inGameStoreInfo = FindRadarID();
		if (inGameStoreInfo == null)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy);
		}
		int num = DoBuyItem(player, inGameStoreInfo.Id);
		if (num > 0)
		{
			cheater = currentRpcCaller;
			SetUseCardDetailTips(StringBuff, player, inGameStoreInfo.Id, num);
			return CheckSuspectCounter(cheater, AntiCheatingResult.Buy, StringBuff.ToString());
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckAddProp(out string cheater, PlayerController player, int propID)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		PropInfo propInfo = LocalResources.PropTable.Find(propID);
		if (propInfo == null || propInfo.InGameStoreItemID != 0 || player.CarriedPropCount(0) > 1)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.AddProp);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckStartUsing(out string cheater, PlayerController player, UsableObject usable)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (usable is EscapeDoor && VaultObject.StolenCount < InGameScene.Inst.m_TargetVaultCount)
		{
			cheater = currentRpcCaller;
			string detail = AddDetails($"stolenCount:{VaultObject.StolenCount} targetVaultCount:{InGameScene.Inst.m_TargetVaultCount}");
			return LogAndReturn(cheater, AntiCheatingResult.EscapeDoor, detail);
		}
		if (player.PlayingRole == RoleType.Thief && player.IsDying)
		{
			cheater = currentRpcCaller;
			return CheckSuspectCounter(cheater, AntiCheatingResult.StartUsingDying);
		}
		if (usable is VaultObject || usable is EscapeDoor)
		{
			float num = Vector3.Distance(player.transform.position.FlattenY(), usable.transform.position.FlattenY());
			if (!IsLagOrOutsideCullArea(player) && num > Inst.m_UseDistanceThreshold)
			{
				cheater = currentRpcCaller;
				string detail2 = AddDetails($"type:{usable.name} dis:{num} threshold:{Inst.m_UseDistanceThreshold}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.StartUsing, detail2);
			}
		}
		if (!string.IsNullOrEmpty(currentRpcCaller))
		{
			Inst.PlayerUsingTime[currentRpcCaller] = new UsingTime
			{
				startTime = InGameScene.Inst.GameTime,
				addCount = 0,
				QTECount = 0
			};
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckAddUsing(out string cheater, PlayerController player, UsableObject usable, float deltaTime, int userCount)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (usable.Block != null && (usable is VaultObject || usable is EscapeDoor))
		{
			float progress = usable.Progress;
			float b = 1f + usable.GetSpeedUpRatio(player.UserId);
			b = Mathf.Max(1f, b);
			b = usable.GetSpeedLimit(b, userCount);
			b *= Mathf.Max(0.2f, usable.m_RpcInterval);
			float num = Mathf.Max(0.3f, b * 3.5f);
			if (deltaTime > num)
			{
				if (progress <= 0f)
				{
					cheater = currentRpcCaller;
					string detail = AddDetails($"type:{usable.name} delta:{deltaTime} threshold:{num} userCount:{userCount}");
					return CheckSuspectCounter(cheater, AntiCheatingResult.AddUsingNotStart, detail);
				}
				if (progress <= usable.m_TimeComsuption * 0.95f)
				{
					cheater = currentRpcCaller;
					string detail2 = AddDetails($"type:{usable.name} delta:{deltaTime} threshold:{num} progress:{progress} userCount:{userCount}");
					return CheckSuspectCounter(cheater, AntiCheatingResult.AddUsingTooFast, detail2);
				}
			}
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckApplyDamage(out string cheater, PlayerController player, float damage, int numID, DamageSourceType source, DamageExtraInfo extraInfo)
	{
		string text = NumId2UserId.Get(numID);
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (source == DamageSourceType.Dog || source == DamageSourceType.Adrenaline || source == DamageSourceType.Boss || source == DamageSourceType.Connect)
		{
			cheater = null;
			return LogAndReturn(cheater, AntiCheatingResult.Normal);
		}
		PlayerController playerController = PlayerController.FindPlayer(text);
		if (playerController == null || player == null)
		{
			cheater = null;
			return LogAndReturn(cheater, AntiCheatingResult.Normal);
		}
		if (!string.IsNullOrEmpty(currentRpcCaller) && (playerController.IsAI || (playerController.m_PhotonView.owner.UserId == currentRpcCaller && playerController.UserId != currentRpcCaller)))
		{
			cheater = null;
			return LogAndReturn(cheater, AntiCheatingResult.Normal);
		}
		bool flag = source == DamageSourceType.Projectile || source == DamageSourceType.ProjectileCritical;
		bool flag2 = playerController.PlayingRole == RoleType.Boss;
		if ((source == DamageSourceType.Boss && damage > 200f) || (flag && damage > (float)(flag2 ? 200 : 100)) || (source == DamageSourceType.Grenade && damage > (float)(flag2 ? 200 : 100)) || (source == DamageSourceType.Saber && damage > 100f) || damage > 200f)
		{
			cheater = currentRpcCaller;
			string detail = AddDetails($"damage:{damage}, source:{source}");
			return CheckSuspectCounter(currentRpcCaller, AntiCheatingResult.OverDamage, detail);
		}
		if ((damage > 0f && player != playerController && player.InSameTeam(playerController)) || (damage < 0f && !player.InSameTeam(playerController)))
		{
			cheater = currentRpcCaller;
			return LogAndReturn(detail: (!GameRuntime.IsMapBattleRoyale) ? AddDetails(string.Format("map:{0} damage:{1}, inSameTeam:{2} source:{3} player:{4} user:{5}", GameRuntime.MapType, damage, player.InSameTeam(playerController), source, player.PlayingRole + "-" + player.UserId, playerController.PlayingRole + "-" + playerController.UserId)) : AddDetails(string.Format("map:{0} damage:{1}, inSameTeam:{2} source:{3} player:{4} user:{5}", GameRuntime.MapType, damage, player.InSameTeam(playerController), source, IngameGroupUtility.GetGroupID(player.UserId) + "-" + player.UserId, IngameGroupUtility.GetGroupID(playerController.UserId) + "-" + playerController.UserId)), cheater: cheater, result: AntiCheatingResult.ApplyDamageRole);
		}
		if (IsLagOrOutsideCullArea(player))
		{
			cheater = null;
			return LogAndReturn(cheater, AntiCheatingResult.Normal);
		}
		switch (source)
		{
		case DamageSourceType.Projectile:
		case DamageSourceType.ProjectileCritical:
		{
			float threshold4 = GetThreshold(Inst.m_ProjectileDistance, LocalPlayerDatabase.Settings.antiCheatingSettings.projectileDistance);
			return CheckApplyDamageDistance(out cheater, currentRpcCaller, AntiCheatingGhost.Projectile, threshold4, player.UserId, extraInfo, text);
		}
		case DamageSourceType.Grenade:
		{
			float threshold3 = GetThreshold(Inst.m_GrenadeDistance, LocalPlayerDatabase.Settings.antiCheatingSettings.grenadeDistance);
			return CheckApplyDamageDistance(out cheater, currentRpcCaller, AntiCheatingGhost.Grenade, threshold3, player.UserId, extraInfo, text);
		}
		case DamageSourceType.Medkit:
		{
			float threshold2 = GetThreshold(Inst.m_MedkitDistance, LocalPlayerDatabase.Settings.antiCheatingSettings.medkitDistance);
			return CheckApplyDamageDistance(out cheater, currentRpcCaller, AntiCheatingGhost.Medkit, threshold2, player.UserId, extraInfo, text);
		}
		case DamageSourceType.Saber:
		{
			float threshold = GetThreshold(Inst.m_SaberDistance, LocalPlayerDatabase.Settings.antiCheatingSettings.saberDistance);
			return CheckApplyDamageDistance(out cheater, currentRpcCaller, AntiCheatingGhost.Saber, threshold, player.UserId, extraInfo, text);
		}
		case DamageSourceType.AutoRecover:
		{
			AutoRecoverable component = player.GetComponent<AutoRecoverable>();
			if (component == null)
			{
				cheater = currentRpcCaller;
				string detail4 = AddDetails("autoRecoverable is null");
				return LogAndReturn(cheater, AntiCheatingResult.ApplyDamage, detail4);
			}
			if (Mathf.Abs(Mathf.Abs(damage) - component.m_Amount) > 0.01f)
			{
				cheater = currentRpcCaller;
				string detail5 = AddDetails($"damage:{Mathf.Abs(damage)} > amount:{component.m_Amount}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.ApplyDamage, detail5);
			}
			break;
		}
		case DamageSourceType.Trap:
			if (damage <= Inst.m_TrapMinDamage)
			{
				cheater = currentRpcCaller;
				string detail3 = AddDetails($"Damage {damage} <= TrapMinDamage {Inst.m_TrapMinDamage}");
				return LogAndReturn(cheater, AntiCheatingResult.ApplyDamage, detail3);
			}
			break;
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckApplyDamageDistance(out string cheater, string caller, AntiCheatingGhost ghostType, float maxDistance, string apply, DamageExtraInfo extraInfo, string user)
	{
		Vector3 playerPos = extraInfo.playerPos;
		Vector3 explosionPos = extraInfo.explosionPos;
		float explosionRadius = extraInfo.explosionRadius;
		float time = extraInfo.time;
		float num = Vector3.Distance(playerPos.FlattenY(), explosionPos.FlattenY());
		string text = $"type:{ghostType} playerPos:{playerPos} explosionPos:{explosionPos} radius:{explosionRadius} time:{time} dis:{num}";
		if (playerPos == Vector3.zero || explosionPos == Vector3.zero || Math.Abs(explosionRadius) < 1E-08f || Math.Abs(time) < 1E-08f)
		{
			cheater = caller;
			string detail = AddDetails(text);
			return CheckSuspectCounter(caller, AntiCheatingResult.ApplyDamageExtraInfo, detail);
		}
		if (explosionRadius > maxDistance)
		{
			cheater = caller;
			string detail2 = AddDetails($"radius:{explosionRadius} > threshold:{maxDistance}");
			return CheckSuspectCounter(caller, AntiCheatingResult.ApplyDamageExtraInfo, detail2);
		}
		if (num > maxDistance)
		{
			cheater = caller;
			string detail3 = AddDetails($"dis:{num} > threshold:{maxDistance} " + text);
			return CheckSuspectCounter(caller, AntiCheatingResult.ApplyDamageExtraInfo, detail3);
		}
		if (time > 0.1f)
		{
			GhostList ghostList = Inst.Ghosts[ghostType];
			int num2 = 0;
			if (ghostList.list != null)
			{
				num2 = ghostList.list.Count((Ghost a) => a.user == user);
			}
			if (num2 == 0)
			{
				cheater = caller;
				string detail4 = AddDetails($"type:{ghostType} " + text);
				return CheckSuspectCounter(caller, AntiCheatingResult.ApplyDamageEmpty, detail4);
			}
			if ((ghostType == AntiCheatingGhost.Grenade || ghostType == AntiCheatingGhost.Medkit) && !ghostList.FindNearby(playerPos, maxDistance, user))
			{
				cheater = caller;
				SetGhostsTips(StringBuff, apply, playerPos, ghostType, maxDistance, caller, user);
				return CheckSuspectCounter(caller, AntiCheatingResult.ApplyDamageTooFar, StringBuff + text);
			}
		}
		cheater = null;
		return LogAndReturn(null, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckSpawnProjectile(out string cheater, PlayerController player, ProjectileLauncher launcher, ProjectileExtraInfo extraInfo)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		int id = launcher.CurrentWeapont.Id;
		float reloadTime = launcher.ReloadTime;
		float maxCooldownTime = launcher.MaxCooldownTime;
		int magazineRemained = launcher.MagazineRemained;
		int weaponID = extraInfo.weaponID;
		float reloadTime2 = extraInfo.reloadTime;
		float fireTime = extraInfo.fireTime;
		int magazineRemained2 = extraInfo.magazineRemained;
		if (id == weaponID)
		{
			float threshold = GetThreshold(0f, LocalPlayerDatabase.Settings.antiCheatingSettings.fireCooldownTime);
			if ((reloadTime2 <= threshold && reloadTime > 0.05f) || (fireTime <= threshold && maxCooldownTime > 0.05f))
			{
				cheater = currentRpcCaller;
				string str = $"map:{GameRuntime.MapType} type:{weaponID} rpc rt:{reloadTime2} ft:{fireTime}";
				string str2 = $" => local rt:{reloadTime} ft:{maxCooldownTime} threshold:{threshold}";
				string detail = AddDetails(str + str2);
				return CheckSuspectCounter(currentRpcCaller, AntiCheatingResult.SpawnProjectileTooFast, detail);
			}
			if (((double)reloadTime > 0.05 && reloadTime2 < reloadTime - 0.05f) || (maxCooldownTime > 0.05f && fireTime < maxCooldownTime - 0.05f))
			{
				cheater = currentRpcCaller;
				string str3 = $"map:{GameRuntime.MapType} type:{weaponID} rpc rt:{reloadTime2} ft:{fireTime}";
				string str4 = $" => local rt:{reloadTime} ft:{maxCooldownTime}";
				string detail2 = AddDetails(str3 + str4);
				return CheckSuspectCounter(currentRpcCaller, AntiCheatingResult.SpawnProjectileMismatched, detail2);
			}
			if (player.PlayingRole == RoleType.Thief && !GameRuntime.IsMapRedEnvelopeFight)
			{
				float threshold2 = GetThreshold(200f, LocalPlayerDatabase.Settings.antiCheatingSettings.magazineRemainedMax);
				if ((float)magazineRemained2 > threshold2)
				{
					cheater = currentRpcCaller;
					string str5 = $"map:{GameRuntime.MapType} type:{weaponID} rpc mr:{magazineRemained2}";
					string str6 = $" => local mr:{magazineRemained} threshold:{threshold2}";
					string detail3 = AddDetails(str5 + str6);
					return CheckSuspectCounter(currentRpcCaller, AntiCheatingResult.SpawnProjectileTooMuch, detail3);
				}
				float threshold3 = GetThreshold(3f, LocalPlayerDatabase.Settings.antiCheatingSettings.magazineRemainedThreshold);
				if (magazineRemained <= 0 && !GameRuntime.ResumeGame && (float)magazineRemained2 > (float)magazineRemained + threshold3)
				{
					cheater = currentRpcCaller;
					string str7 = $"map:{GameRuntime.MapType} type:{weaponID} rpc mr:{magazineRemained2}";
					string str8 = $" => local mr:{magazineRemained} threshold:{threshold3}";
					string detail4 = AddDetails(str7 + str8);
					return CheckSuspectCounter(cheater, AntiCheatingResult.SpawnProjectile, detail4);
				}
			}
		}
		else
		{
			UnityEngine.Debug.Log("武器类型不一致，不检查 " + id + " " + weaponID);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckQTEResult(out string cheater, PlayerController player, UsableObject usable, InGameQTE.Result result, Vector3 playerPos)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		float num = Vector3.Distance(playerPos.FlattenY(), usable.transform.position.FlattenY());
		if ((result == InGameQTE.Result.Perfect || result == InGameQTE.Result.Good) && !player.OnHookJoint && !player.IsHookForwarding && !player.PortalAdapter.IsPortaling)
		{
			float threshold = GetThreshold(Inst.m_UseDistanceThreshold, LocalPlayerDatabase.Settings.antiCheatingSettings.useDistanceThreshold);
			if (!IsLagOrOutsideCullArea(player) && num > threshold)
			{
				cheater = currentRpcCaller;
				string detail = AddDetails($"dis:{num} threshold:{threshold} result:{result}");
				return CheckSuspectCounter(cheater, AntiCheatingResult.NotifyQTEResultTooFar, detail);
			}
		}
		if (!string.IsNullOrEmpty(currentRpcCaller))
		{
			UsingTime usingTime = Inst.PlayerUsingTime[currentRpcCaller];
			if (usingTime.startTime < 1E-06f)
			{
				usingTime.startTime = InGameScene.Inst.GameTime;
			}
			float num2 = InGameScene.Inst.GameTime - usingTime.startTime;
			int num3 = Mathf.CeilToInt(2f * num2 / InGameSkillUI.Inst.QTE.m_MinTriggerInterval);
			if (num2 > InGameSkillUI.Inst.QTE.m_MinTriggerInterval && usingTime.QTECount++ > num3)
			{
				cheater = currentRpcCaller;
				return CheckSuspectCounter(cheater, AntiCheatingResult.NotifyQTEResult);
			}
			Inst.PlayerUsingTime[currentRpcCaller] = usingTime;
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckFinalEscaped(out string cheater, PlayerController player)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		if (EscapeDoor.OpenedCount == 0)
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.FinalEscaped);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckMove(out string cheater, PlayerController player)
	{
		float expectedSpeed = GetExpectedSpeed(player);
		if (!IsLagOrOutsideCullArea(player) && IsOverAnimatorSpeed(player, expectedSpeed) && !IsFiring(player))
		{
			if (Inst.PlayerOverAnimatorSpeedTime[player.UserId] < 1E-06f)
			{
				Inst.PlayerOverAnimatorSpeedTime[player.UserId] = InGameScene.Inst.GameTime;
			}
			else if (InGameScene.Inst.GameTime - Inst.PlayerOverAnimatorSpeedTime[player.UserId] > Inst.m_OverSpeedTimeThreshold && IsOverSpeed(player, expectedSpeed))
			{
				Inst.PlayerOverAnimatorSpeedTime[player.UserId] = 0f;
				cheater = player.UserId;
				return LogAndReturn(cheater, AntiCheatingResult.OverAnimatorSpeed);
			}
		}
		else
		{
			Inst.PlayerOverAnimatorSpeedTime[player.UserId] = 0f;
		}
		if (!IsLagOrOutsideCullArea(player) && IsOverSpeed(player, expectedSpeed) && !IsFiring(player))
		{
			if (Inst.PlayerOverSpeedTime[player.UserId] < 1E-06f)
			{
				Inst.PlayerOverSpeedTime[player.UserId] = InGameScene.Inst.GameTime;
			}
			else if (InGameScene.Inst.GameTime - Inst.PlayerOverSpeedTime[player.UserId] > Inst.m_OverSpeedTimeThreshold)
			{
				Inst.PlayerOverSpeedTime[player.UserId] = 0f;
				cheater = player.UserId;
				return LogAndReturn(cheater, AntiCheatingResult.OverSpeed);
			}
		}
		else
		{
			Inst.PlayerOverSpeedTime[player.UserId] = 0f;
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckTalentEffect(out string cheater, PlayerController player, int talentID, int talentLevel, float[] others)
	{
		string currentRpcCaller = PhotonNetwork.CurrentRpcCaller;
		TalentManager.Talent talent = player.TalentManager.GetTalent(talentID);
		if (talent == null)
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.TalentMismatched);
		}
		if (talent.Level != talentLevel)
		{
			cheater = currentRpcCaller;
			return LogAndReturn(cheater, AntiCheatingResult.TalentMismatched);
		}
		int num = (int)others[0];
		float num2 = others[1];
		if (!talent.RandomTriggerByIndex(num, num2) && !GameRuntime.ResumeGame)
		{
			cheater = currentRpcCaller;
			float probability = talent.Probability;
			float randomValue = talent.GetRandomValue(num);
			string detail = AddDetails($"talentID:{talent.ID} randomIndex:{num} factor:{num2} probability:{probability} result:{randomValue}");
			return CheckSuspectCounter(cheater, AntiCheatingResult.TalentTrigger, detail);
		}
		cheater = null;
		return LogAndReturn(cheater, AntiCheatingResult.Normal);
	}

	private static AntiCheatingResult CheckChangeCardSkin(out string cheater)
	{
		cheater = PhotonNetwork.masterClient.UserId;
		return LogAndReturn(cheater, AntiCheatingResult.ChangeCardSkin);
	}

	private static AntiCheatingResult CheckUsePropcard(out string cheater, PlayerController player, int cardID)
	{
		if ((!GameRuntime.IsMapBattleRoyale && !GameRuntime.IsMapCoinFight) || cardID == 0)
		{
			cheater = null;
			return AntiCheatingResult.Normal;
		}
		int num = player.PropcardKnapsack.CarriedCardCount(cardID);
		if (num < 0)
		{
			string text = cheater = PhotonNetwork.CurrentRpcCaller;
			string detail = AddDetails($"card:{cardID} cardCount:{num} player:{player.UserId}");
			return CheckSuspectCounter(cheater, AntiCheatingResult.UsePropcard, detail);
		}
		cheater = null;
		return AntiCheatingResult.Normal;
	}

	private static bool IsFiring(PlayerController player)
	{
		if (player.ProjectileLauncher != null)
		{
			return player.ProjectileLauncher.IsFiring;
		}
		return false;
	}

	private static bool IsLag(PlayerController player)
	{
		return player.PerformanceQuality < 100;
	}

	private static bool IsPause()
	{
		float num = (Inst != null) ? Inst.m_LastUpdateTime : 0f;
		float num2 = Time.realtimeSinceStartup - num;
		if (num > 0f)
		{
			return num2 > 1f;
		}
		return false;
	}

	private static bool IsLagOrOutsideCullArea(PlayerController player)
	{
		if (PlayerController.Inst == null)
		{
			return true;
		}
		if (!IsLag(player) && !((PlayerController.Inst.transform.position - player.transform.position).sqrMagnitude > Inst.m_CullDistance2))
		{
			return IsPause();
		}
		return true;
	}

	private static bool IsBeingDragged(PlayerController player)
	{
		if (player.PlayingRole == RoleType.Thief)
		{
			return ((ThiefController)player).IsBeingDragged;
		}
		return false;
	}

	private static bool IsOverSpeed(PlayerController player, float expectedSpeed)
	{
		if (player.OnVehichle != null || Connect.CheckConnectState(player))
		{
			return false;
		}
		if (IsBeingDragged(player))
		{
			return false;
		}
		if (player.OnHookJoint)
		{
			return false;
		}
		float magnitude = player.LinearVelocity.FlattenY().magnitude;
		if (FindPusher(player) != null)
		{
			return false;
		}
		return magnitude > expectedSpeed;
	}

	private static bool IsOverAnimatorSpeed(PlayerController player, float expectedSpeed)
	{
		if (player.OnVehichle != null || Connect.CheckConnectState(player))
		{
			return false;
		}
		if (IsBeingDragged(player))
		{
			return false;
		}
		return player.SpeedForAnimator > expectedSpeed;
	}

	private static float GetExpectedSpeed(PlayerController player)
	{
		float speed = player.m_MovementProperties.speed;
		speed *= player.GetTargetSpeedRatio();
		speed *= Mathf.Max(1f, 1f + player.BuffManager.SpeedGain);
		speed *= Inst.m_OverSpeedFactorThreshold;
		Inst.PlayerExpectedSpeed[player.UserId] = Mathf.Lerp(Inst.PlayerExpectedSpeed[player.UserId], speed, 0.01f);
		return Mathf.Max(speed, Inst.PlayerExpectedSpeed[player.UserId]);
	}

	private static PlayerController FindPusher(PlayerController player)
	{
		if (player.m_PhotonViewForTransform.owner != null && player.m_PhotonViewForTransform.owner != player.m_PhotonView.owner)
		{
			return PlayerController.FindPlayer(player.m_PhotonViewForTransform.owner.UserId);
		}
		return null;
	}

	private static AntiCheatingResult CheckSuspectCounter(string player, AntiCheatingResult result, string detail = "")
	{
		if (string.IsNullOrEmpty(player))
		{
			return AntiCheatingResult.Normal;
		}
		if (!Inst.SuspectCounter.TryGetValue(player, out SafeGameDictionary<AntiCheatingResult, int> value))
		{
			value = new SafeGameDictionary<AntiCheatingResult, int>();
			Inst.SuspectCounter.Add(player, value);
		}
		UnityEngine.Debug.LogWarningFormat("CheckSuspectCounter {0}: {1} {2}", player, result.ToString(), detail);
		SafeGameDictionary<AntiCheatingResult, int> safeGameDictionary = value;
		AntiCheatingResult key = result;
		if (++safeGameDictionary[key] >= Inst.m_SuspectCountThreshold)
		{
			return LogAndReturn(player, result, detail);
		}
		UpdateSuspectDetail(player, result, detail);
		Inst.ShowTipsWarning(player, result.ToString(), detail);
		return LogAndReturn(player, AntiCheatingResult.Normal);
	}

	private static void UpdateSuspectDetail(string player, AntiCheatingResult result, string detail)
	{
		try
		{
			if (!string.IsNullOrEmpty(detail) && !string.IsNullOrEmpty(player) && (!Inst.PlayerReported.ContainsKey(player) || !Inst.PlayerReported[player].Contains(result)))
			{
				if (!Inst.SuspectDetails.ContainsKey(player))
				{
					Inst.SuspectDetails.Add(player, new SafeGameDictionary<AntiCheatingResult, StringBuilder>());
				}
				if (!Inst.SuspectDetails[player].ContainsKey(result))
				{
					Inst.SuspectDetails[player].Add(result, new StringBuilder());
				}
				else
				{
					Inst.SuspectDetails[player][result].Append(";");
				}
				Inst.SuspectDetails[player][result].Append(detail);
			}
		}
		catch (Exception message)
		{
			UnityEngine.Debug.LogError(message);
		}
	}

	private static int GetCoin(PlayerController player)
	{
		if (player.m_PhotonView.isMine)
		{
			return int.MaxValue;
		}
		return player.CurCoin + 50;
	}

	private static bool BuyItem(PlayerController player, int itemID)
	{
		return DoBuyItem(player, itemID) == 0;
	}

	private static int DoBuyItem(PlayerController player, int itemID)
	{
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(itemID);
		if (inGameStoreInfo == null || (inGameStoreInfo.RoleType != -1 && inGameStoreInfo.RoleType != (int)player.PlayingRole))
		{
			return 1;
		}
		if (inGameStoreInfo.Type != InGameStoreType.WeaponUpgrade && inGameStoreInfo.Type != InGameStoreType.Magazine && !player.Cards.Contains(itemID))
		{
			return 2;
		}
		int cardPrice = player.GetCardPrice(itemID);
		if (!player.CanBuyFree && GetCoin(player) < cardPrice)
		{
			return 3;
		}
		return 0;
	}

	private static InGameStoreInfo FindRadarID()
	{
		foreach (PropInfo item in LocalResources.PropTable)
		{
			if (item.Type == PropType.Radar)
			{
				return LocalResources.InGameStoreTable.Get(item.InGameStoreItemID);
			}
		}
		return null;
	}

	private static InGameStoreInfo FindMagazineForWeaponID(PlayerController player, int weaponID)
	{
		foreach (InGameStoreInfo item in LocalResources.InGameStoreTable)
		{
			if (item.Type == InGameStoreType.Magazine)
			{
				int typeParam = LocalResources.InGameStoreTable.Get(item.TypeParam).TypeParam;
				if (weaponID >= typeParam && weaponID - typeParam < 10)
				{
					return item;
				}
			}
		}
		return null;
	}

	private static AntiCheatingResult LogAndReturn(string cheater, AntiCheatingResult result, string detail = "")
	{
		if (Inst != null && result != 0 && !string.IsNullOrEmpty(cheater))
		{
			Inst.ShowTipsWarning(cheater, result.ToString(), detail);
			UpdateSuspectDetail(cheater, result, detail);
		}
		return result;
	}

	private static PhotonPlayer FindPhotonPlayer(string userID)
	{
		PhotonPlayer[] playerList = PhotonNetwork.playerList;
		foreach (PhotonPlayer photonPlayer in playerList)
		{
			if (photonPlayer.UserId == userID)
			{
				return photonPlayer;
			}
		}
		return null;
	}

	private static void SetUseCardDetailTips(StringBuilder sb, PlayerController player, int useCard, int buyResult)
	{
		sb.Length = 0;
		SetPlayerTips(sb, player);
		sb.Append(" ,useCard:").Append(useCard);
		sb.Append(" ,buy:").Append(buyResult);
		if (buyResult > 0)
		{
			sb.Append(";");
		}
	}

	private static void SetPlayerTips(StringBuilder sb, PlayerController player)
	{
		sb.Append("[");
		int[] cards = player.Cards;
		foreach (int value in cards)
		{
			sb.Append(value).Append(",");
		}
		sb.Append("] coin:");
		sb.Append(player.CurCoin);
	}

	private static void SetGhostsTips(StringBuilder sb, string apply, Vector3 playerPos, AntiCheatingGhost ghostType, float maxDistance, string caller, string user)
	{
		GhostList ghostList = Inst.Ghosts[ghostType];
		sb.Length = 0;
		sb.Append("type:").Append(ghostType.ToString()).Append(", ");
		sb.Append("caller:").Append(caller).Append(", ");
		sb.Append("user:").Append(user).Append(", ");
		sb.Append("apply:").Append(apply).Append(", ");
		sb.Append("threshold:").Append(maxDistance).Append(", ");
		sb.Append("pos:").Append(playerPos).Append(", ");
		sb.Append("time:").Append(GameTime).Append(", ");
		sb.Append("ghosts:[");
		if (ghostList.list != null)
		{
			foreach (Ghost item in ghostList.list)
			{
				if (!(item.user != user))
				{
					sb.Append("{");
					sb.Append("isValid:").Append(item.IsValid).Append(", ");
					sb.Append("delay:").Append(GameTime - item.lastTime).Append(", ");
					sb.Append("dis:").Append((playerPos - item.lastPosition).FlattenY().magnitude).Append(", ");
					sb.Append("lp:").Append(item.lastPosition);
					sb.Append("}");
				}
			}
		}
		sb.Append("]");
	}

	private static string AddDetails(string details)
	{
		StringBuff.Length = 0;
		StringBuff.Append(details);
		return StringBuff.ToString();
	}

	private static float GetThreshold(float defaultThreshold, float serverThreshold)
	{
		float result = defaultThreshold;
		if (serverThreshold > 0f)
		{
			result = serverThreshold;
		}
		return result;
	}

	private static string GetCards(int[] cardArray)
	{
		string text = "";
		for (int i = 0; i < cardArray.Length; i++)
		{
			text = ((i >= cardArray.Length - 1) ? (text + cardArray[i]) : (text + cardArray[i] + ","));
		}
		return text;
	}

	public static AntiCheatingResult CheckSummaryTime(out string cheater, PlayerController player, int senderID)
	{
		PhotonPlayer photonPlayer = PhotonPlayer.Find(senderID);
		if (photonPlayer != null)
		{
			if (GameRuntime.ResumeGame || InGameScene.Inst.GameTime <= 0f || (player != null && player.UserId == photonPlayer.UserId))
			{
				cheater = null;
				return LogAndReturn(cheater, AntiCheatingResult.Normal);
			}
			float num = (float)(GameRuntime.MapInfo.RageStartTime + GameRuntime.MapInfo.RageLastingTime) - InGameScene.Inst.GameTime;
			float num2 = 30f;
			if (LocalPlayerDatabase.Settings.antiCheatingSettings.summaryRemainTimeThreshold > 0f)
			{
				num2 = LocalPlayerDatabase.Settings.antiCheatingSettings.summaryRemainTimeThreshold;
			}
			if (num > num2)
			{
				string detail = $"map:{GameRuntime.MapType} remainTime:{num} threshold:{num2}";
				cheater = photonPlayer.UserId;
				return LogAndReturn(cheater, AntiCheatingResult.SummaryTooFast, detail);
			}
		}
		cheater = null;
		return AntiCheatingResult.Normal;
	}

	public static AntiCheatingResult CheckModifyMemory(out string cheater, PlayerController player, string sign, string key, MonoBehaviour target)
	{
		cheater = PhotonNetwork.CurrentRpcCaller;
		if (!string.IsNullOrEmpty(cheater) && ComputeSign(key, target) != sign)
		{
			string arg = Decrypt(sign, key);
			string detail = AddDetails($"type:{target.name} parameters:{arg} sign:{sign}");
			return LogAndReturn(cheater, AntiCheatingResult.ModifyMemory, detail);
		}
		cheater = null;
		return AntiCheatingResult.Normal;
	}

	public static string GetParameterSign(string key, MonoBehaviour target)
	{
		return ComputeSign(key, target);
	}

	public static string ComputeSign(string key, MonoBehaviour target)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (FieldInfo signField in GetSignFields(target.GetType()))
		{
			stringBuilder.Append($"{signField.GetValue(target):0.##}").Append("_");
		}
		stringBuilder.Append(key);
		return Encrypt(stringBuilder.ToString().ToLower(), key);
	}

	private static string Encrypt(string input, string key)
	{
		return Convert.ToBase64String(EncryptDecrypt(Encoding.UTF8.GetBytes(input), key));
	}

	public static string Decrypt(string sign, string key)
	{
		byte[] bys = Convert.FromBase64String(sign);
		bys = EncryptDecrypt(bys, key);
		return Encoding.UTF8.GetString(bys);
	}

	public static byte[] EncryptDecrypt(byte[] bys, string key)
	{
		int length = key.Length;
		int num = bys.Length;
		byte[] array = new byte[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = (byte)(bys[i] ^ key[i % length]);
		}
		return array;
	}

	private static List<FieldInfo> GetSignFields(Type type)
	{
		return new List<FieldInfo>(from field in type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
			where (CheckField)Attribute.GetCustomAttribute(field, typeof(CheckField), inherit: true) != null
			orderby field.Name.ToLower()
			select field);
	}
}
