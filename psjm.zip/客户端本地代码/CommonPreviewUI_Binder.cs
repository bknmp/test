using LightUI;
using LightUtility;
using UnityEngine;

public class CommonPreviewUI_Binder : CommonPreviewBinder
{
	public new void Bind(CommonDataCollection args)
	{
		if (!m_Preview.isActiveAndEnabled || !(m_Preview.texture != null))
		{
			base.Bind(args);
		}
	}

	protected override void PreviewCardSkin(int cardSkinID)
	{
		string prefabs = LocalResources.CardSkinTable.Get(cardSkinID).Prefabs;
		string text = prefabs + "_UI";
		string text2 = prefabs + "_Lobby";
		GameObject x = ResourceSource.Load(text, enableErrorLog: false);
		prefabs = text;
		if (x == null)
		{
			x = ResourceSource.Load(text2);
			prefabs = text2;
		}
		bool flag = LobbyScene.Inst.m_CardSkinPanel.PrefabRoot.childCount > 0 && LobbyScene.Inst.m_CardSkinPanel.PrefabRoot.GetChild(0).name.Contains(prefabs);
		if (x != null)
		{
			if (!flag)
			{
				LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
				LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, prefabs, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>());
				ClampCardSkinCameraAxis(50f, 0f, forbidAutoRotate: false);
				LobbyScene.Inst.m_CardSkinPanel.Camera.transform.localPosition = new Vector3(0f, 0.1f, -3f);
			}
			else
			{
				LobbyScene.Inst.ChangePreviewTarget(LobbyScene.Inst.m_CardSkinPanel, notRTMethod: false, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>());
			}
		}
	}

	protected override void PreviewCardStyle(int cardStyleID)
	{
		string prefabs = LocalResources.CardStyleTable.Get(cardStyleID).Prefabs;
		string text = prefabs + "_UI";
		string text2 = prefabs + "_Lobby";
		GameObject x = ResourceSource.Load(text, enableErrorLog: false);
		prefabs = text;
		if (x == null)
		{
			x = ResourceSource.Load(text2);
			prefabs = text2;
		}
		if (x != null)
		{
			LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, prefabs, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>());
			ClampCardSkinCameraAxis(50f, 0f, forbidAutoRotate: false);
			LobbyScene.Inst.m_CardSkinPanel.Camera.transform.localPosition = new Vector3(0f, 0.1f, -3f);
		}
	}

	private void OnDisable()
	{
		m_Preview.gameObject.SetActive(value: false);
	}
}
