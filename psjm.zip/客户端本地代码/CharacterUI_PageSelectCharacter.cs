using LightUI;
using System.Collections.Generic;
using System.Linq;

internal class CharacterUI_PageSelectCharacter
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_ThiefContent;

	public UITemplateInitiator m_PoliceContent;

	private bool m_IsShowMisteryPolice;

	private bool m_IsShowMisteryThief;

	private static List<int> m_CharacterList;

	public static List<int> CharacterList
	{
		get
		{
			if (m_CharacterList == null)
			{
				UpdateOwnCharacterList();
			}
			return m_CharacterList;
		}
	}

	public void Bind(CommonDataCollection args)
	{
		m_IsShowMisteryPolice = false;
		m_IsShowMisteryThief = false;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		foreach (int character in CharacterList)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(character);
			if (characterInfo.Role == RoleType.Thief)
			{
				commonDataCollection[commonDataCollection.ArraySize]["characterInfo"].val = characterInfo;
			}
			else
			{
				commonDataCollection2[commonDataCollection2.ArraySize]["characterInfo"].val = characterInfo;
			}
		}
		if (m_IsShowMisteryPolice)
		{
			CharacterInfo val = LocalResources.CharacterTable.Get(0);
			commonDataCollection2[commonDataCollection2.ArraySize]["characterInfo"].val = val;
		}
		if (m_IsShowMisteryThief)
		{
			CharacterInfo val2 = LocalResources.CharacterTable.Get(0);
			commonDataCollection[commonDataCollection.ArraySize]["characterInfo"].val = val2;
		}
		m_PoliceContent.Args = commonDataCollection2;
		m_ThiefContent.Args = commonDataCollection;
	}

	private static void UpdateOwnCharacterList()
	{
		m_CharacterList = (from a in LocalResources.CharacterTable
			where a.IsVisibleInUI
			orderby a.Role descending, a.Rank
			select a.Id).ToList();
	}
}
