using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CreateTipsUI
{
	public UIDataBinder m_Host;

	public Button m_Yes;

	public Image m_PriceIcon;

	public Text m_PriceText;

	public UnionBadgeItem m_Badge;

	public Text m_UnionNameText;

	private string m_UnionNameFormat;

	private string m_PriceFormat;

	private string m_UnionName;

	private string m_Notice;

	private int m_IconID;

	private int m_FrameID;

	private int m_FlagID;

	private int m_Review;

	private int m_Grade;

	private int m_Type;

	public void Bind(CommonDataCollection args)
	{
		m_UnionName = args["unionName"];
		m_Notice = args["notice"];
		m_IconID = args["iconID"];
		m_FrameID = args["frameID"];
		m_FlagID = args["flagID"];
		m_Review = args["review"];
		m_Grade = args["grade"];
		m_Type = args["type"];
		if (m_UnionNameFormat == null)
		{
			m_UnionNameFormat = m_UnionNameText.text;
		}
		if (m_PriceFormat == null)
		{
			m_PriceFormat = m_PriceText.text;
		}
		m_Badge.SetBadge(m_IconID, m_FrameID, m_FlagID);
		m_UnionNameText.text = string.Format(m_UnionNameFormat, m_UnionName);
		if (m_Type == 1)
		{
			m_PriceText.text = string.Format(m_PriceFormat, UnionUtility.Settings.createCostDiamond);
			m_PriceIcon.sprite = SpriteSource.Inst.Find("icon钻石");
		}
		else if (m_Type == 2)
		{
			m_PriceText.text = string.Format(m_PriceFormat, UnionUtility.Settings.createCostTicket);
			m_PriceIcon.sprite = SpriteSource.Inst.Find("icon点券");
		}
		m_Host.EventProxy(m_Yes, "OnCreateClicked");
	}

	public void OnCreateClicked()
	{
		UnionBadge badge = new UnionBadge
		{
			iconID = m_IconID,
			frameID = m_FrameID,
			flagID = m_FlagID
		};
		UnionUtility.CreateUnion(m_UnionName, badge, m_Notice, m_Review, m_Grade, m_Type, OnCreateUnionFinish);
	}

	private void OnCreateUnionFinish()
	{
		UILobby.Current.ShowTips(Localization.TipsUnionCreated);
		m_Host.GetComponent<UIPopup>().GoBack();
	}
}
