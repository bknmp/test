using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_CardSkinPage
{
	public UIDataBinder m_Host;

	public Text m_CollectProgress;

	public Text m_Personality;

	public UITemplateInitiator m_Content;

	public GameObject m_Empty;

	public GameObject m_CardSkinsPanel;

	public GameObject m_PreviewPort;

	public UIScrollRect m_ScrollView;

	public GameObject m_NotHaveTips;

	public Button m_ButtonGain;

	public UIPage m_CardDetailUI;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private string m_CollectFormat;

	private int m_AllCardSkinNum;

	public void Bind(CommonDataCollection args)
	{
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_ButtonGain.gameObject.SetActive(value: false);
		if (m_CollectFormat == null)
		{
			m_CollectFormat = m_CollectProgress.text;
		}
		CollectionPage_CardSkinItem.Selected = 0;
		LoadCardSkinData();
		m_CollectProgress.text = string.Format(m_CollectFormat, CollectionUtility.GetForeverCardSkinCount(m_PlayerInfo), m_AllCardSkinNum);
		DropItem[] foreverCardSkinItems = CollectionUtility.GetForeverCardSkinItems(m_PlayerInfo);
		m_Personality.text = foreverCardSkinItems.Sum((DropItem a) => a.Personality).ToString();
		m_ScrollView.ScrollToStart(immediately: true);
		m_NotHaveTips.SetActive(value: false);
		m_Host.EventProxy(m_ButtonGain, "OnGainButtonClick");
	}

	private void LoadCardSkinData()
	{
		m_AllCardSkinNum = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		DropItem[] array = (from a in LocalResources.DropItemTable
			where a.Type == DropItemType.CardSkin && a.expiredTime == 0
			orderby a.Quality descending, LocalResources.CardSkinTable.Get(a.TypeParam).CardID, LocalResources.CardSkinTable.Get(a.TypeParam).Rank
			select a).ToArray();
		int[] target = (from a in LocalResources.InGameStoreTable
			select a.DefaultSkinID into a
			where a > 0
			select a).ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			if (target.Contains(array[i].Id))
			{
				continue;
			}
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(LocalResources.DropItemTable.Get(array[i].Id).TypeParam);
			bool flag = CollectionUtility.OwnedForever(array[i], m_PlayerInfo);
			if (flag)
			{
				list.Add(array[i].Id);
			}
			else
			{
				if (!flag && cardSkinInfo.SellStartTime != 0 && cardSkinInfo.SellStartTime > UtcTimeStamp.Now)
				{
					continue;
				}
				list2.Add(array[i].Id);
			}
			m_AllCardSkinNum++;
		}
		int num = 0;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (list.Count > 0)
		{
			commonDataCollection[num]["state"] = 0;
			commonDataCollection[num]["items"].val = list.ToList();
			commonDataCollection[num]["roleID"].val = m_PlayerID;
			commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			num++;
		}
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
		{
			if (list2.Count > 0)
			{
				commonDataCollection[num]["state"] = 2;
				commonDataCollection[num]["items"].val = list2.ToList();
				commonDataCollection[num]["roleID"].val = m_PlayerID;
				commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			}
			m_CardSkinsPanel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
			m_Empty.SetActive(value: false);
		}
		else if (list.Count > 0)
		{
			m_Empty.SetActive(value: false);
			m_CardSkinsPanel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
		}
		else
		{
			m_CardSkinsPanel.SetActive(value: false);
			m_PreviewPort.SetActive(value: false);
			m_Empty.SetActive(value: true);
		}
		m_Content.Args = commonDataCollection;
		m_Content.UpdateImmediately(withChildren: true);
	}

	public void OnGainButtonClick()
	{
		int selected = CollectionPage_CardSkinItem.Selected;
		DropItem dropItem = LocalResources.DropItemTable.Get(selected);
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(dropItem.TypeParam);
		UILobby.Current.ShowUI(m_CardDetailUI, CardUtility.CardDetailUIArgsWraper(cardSkinInfo.CardID, CardUtility.GetCardLevel(cardSkinInfo.CardID)));
		CardConfigEditPage_CardSkinItemTemplate.globalSelected = cardSkinInfo.Id;
		StyleItemTemplate.GlobleSelectedStyleId = 0;
		CardConfigEditPage_PageCardSkin.HadSetCardSkinDefaultSelect = true;
		UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
	}
}
