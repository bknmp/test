using BehaviorDesigner.Runtime;
using UnityEngine;

[CreateAssetMenu(fileName = "AIConfig", menuName = "Hide/AIConfig", order = 1)]
public class AIConfig : ScriptableObject
{
	public ExternalBehaviorTree defaultThiefAI;

	public ExternalBehaviorTree defaultPoliceAI;

	public ExternalBehaviorTree conservativeAI;

	public ExternalBehaviorTree defaultAI;

	private static AIConfig aiConfig;

	public static AIConfig Instance
	{
		get
		{
			if (aiConfig == null)
			{
				aiConfig = ResManager.Load<AIConfig>("AIConfig");
			}
			return aiConfig;
		}
	}
}
