using UnityEngine;

public class BubbleBuff : BuffManager.Buff
{
	public override bool BuffStart(BuffManager buffManager, PlayerController playerController)
	{
		if (PlayerController.FindPlayer(createUserID) != null && !playerController.BuffManager.ContainsBuff(522))
		{
			Bubble bubble = (Bubble)playerController.SkillManager.RoleSkill;
			icon = LocalResources.BuffTable.Find(521).Icon + Mathf.Clamp(bubble.Sleepiness, 1, 3);
			return true;
		}
		return false;
	}
}
