using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DirectionalObject : PlaceableObject
{
	public AnimationCurve m_SpeedCurve;

	public AnimationCurve m_ColliderSizeCurve;

	public GameObject m_Colliders;

	public Vector3 m_StartOffset;

	public bool m_RootOffset;

	public float m_StartDelay;

	public float m_MinHeight = 0.01f;

	public float m_SpeedScale = 1f;

	public float m_VehicleExtraSpeed;

	public float m_MinHitTime = 0.02f;

	public float m_MinHitDistance;

	public float m_Timeout;

	public float m_ExplosionRadius;

	public float m_FallAccelerated = 30f;

	public GameObject m_HitEffect;

	public Vector3 m_HitEffectOffset;

	public GameObject m_TrailEffect;

	public Vector3 m_TrailEffectOffset;

	public bool m_IsGrounder;

	[HideInInspector]
	public PlayerController m_PlayerController;

	protected int m_ID;

	protected bool m_Launched;

	protected bool m_Hit;

	protected bool m_Falling;

	private float m_GroundHeight;

	protected Vector3 m_StartDir;

	protected Vector3 m_StartPos;

	protected float m_StartTime;

	private bool m_OnVehicle;

	private float m_FallTime;

	private bool m_HitEffectShowed;

	private GameObject m_TrailEffectInst;

	private PlaceableCreater m_PlaceableCreater;

	protected bool m_Trigger;

	protected float m_TriggerTime;

	private Vector3 m_AutoAimiedTargetPos;

	protected bool m_IsTimeOut;

	protected List<Vector3> m_CheckFallPos = new List<Vector3>();

	protected bool WaitRpcTrigger
	{
		get
		{
			if (m_Trigger)
			{
				return Time.realtimeSinceStartup - m_TriggerTime <= 0.2f;
			}
			return false;
		}
	}

	public int ID
	{
		get
		{
			return m_ID;
		}
		set
		{
			m_ID = value;
		}
	}

	protected new void Start()
	{
		m_MobileDefaultPlaceDistance = 1f;
		if (!string.IsNullOrEmpty(base.UserId))
		{
			m_PlayerController = PlayerController.FindPlayer(base.UserId);
			m_PlaceableCreater = m_PlayerController.GetComponent<PlaceableCreater>();
			m_Hit = false;
			m_Falling = false;
			m_Launched = false;
			m_Trigger = false;
			m_IsTimeOut = false;
			m_OnVehicle = (m_PlayerController.OnVehichle != null || ShapeShifter.IsShapeShiftingVehicle(m_PlayerController.gameObject) || ShapeShifter.IsShapeShiftingSkateBoard(m_PlayerController.gameObject));
			m_PreviewArea.SetActive(value: false);
			m_Root.SetActive(value: false);
			m_StartDir = base.PreviewDirection;
			if (!m_OnVehicle && !m_PlayerController.Shifter.IsMissile)
			{
				m_PlayerController.SetTargetDirection(m_StartDir, immediately: true);
			}
			Invoke("StartMove", m_StartDelay);
		}
		else
		{
			m_PlayerController = PlayerController.Inst;
			if (m_PreviewArea != null)
			{
				m_PreviewArea.transform.rotation = Quaternion.identity;
			}
		}
		base.Start();
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		CancelInvoke("StartMove");
	}

	protected void StartMove()
	{
		if (this == null)
		{
			return;
		}
		m_StartTime = Time.realtimeSinceStartup;
		if (!m_RootOffset)
		{
			m_StartPos = m_PlayerController.transform.TransformPoint(m_StartOffset);
			base.transform.position = m_StartPos;
		}
		else
		{
			if (m_PlayerController.Shifter.IsShapeShifting)
			{
				m_StartOffset = m_StartOffset.FlattenZ();
			}
			m_StartPos = m_PlayerController.transform.position;
			base.transform.position = m_StartPos;
			m_Root.transform.localPosition = m_StartOffset;
		}
		base.transform.rotation = Quaternion.LookRotation(m_StartDir);
		if (m_TrailEffect != null)
		{
			m_TrailEffectInst = PoolSpawner.Spawn(m_TrailEffect);
			m_TrailEffectInst.transform.SetParent(m_Root.transform);
			m_TrailEffectInst.transform.localPosition = m_TrailEffectOffset;
			m_TrailEffectInst.transform.localRotation = Quaternion.identity;
			m_TrailEffectInst.transform.localScale = Vector3.one;
		}
		m_Launched = true;
		m_Root.SetActive(value: true);
		StartCoroutine(DelayShow());
	}

	public virtual IEnumerator DelayShow()
	{
		yield return null;
		if ((m_PlayerController.IsLocalPlayer || m_PlayerController.AI.enabled) && IsForwardBarrier())
		{
			RpcFinishHit();
		}
	}

	private void SetCollidersSize(float ratio)
	{
		m_Colliders.transform.localScale = Vector3.one * ratio;
	}

	public override void BatchUpdate()
	{
		base.BatchUpdate();
		if (!string.IsNullOrEmpty(base.UserId) && !m_Hit && m_Launched && !WaitRpcTrigger)
		{
			UpdateMoving(base.transform.position);
			UpdateFall();
			if (InGameScene.Inst.Map.IsWorldPositionOutOfBorder(base.transform.position, 0f))
			{
				RpcFinishHit();
			}
			UpdateTime();
		}
	}

	protected virtual void UpdateMoving(Vector3 pos)
	{
		float time = Time.realtimeSinceStartup - m_StartTime;
		float num = m_OnVehicle ? m_VehicleExtraSpeed : 0f;
		float num2 = m_SpeedScale + num;
		Vector3 a = m_SpeedCurve.Evaluate(time) * num2 * m_StartDir;
		pos += Time.deltaTime * a;
		base.transform.position = pos;
		SetCollidersSize(m_ColliderSizeCurve.Evaluate(time));
	}

	protected void UpdateFall()
	{
		Vector3 position = base.transform.position;
		float num = 0f;
		if (CheckFall(base.transform.position))
		{
			if (!m_Falling)
			{
				m_FallTime = Time.time;
				m_Falling = true;
			}
			else
			{
				float num2 = Time.time - m_FallTime;
				num = m_FallAccelerated * num2 * Time.deltaTime;
			}
		}
		else
		{
			m_Falling = false;
		}
		position.y -= num;
		position.y = Mathf.Max(position.y, m_MinHeight + m_GroundHeight);
		base.transform.position = position;
	}

	protected virtual void UpdateTime()
	{
		if (Time.realtimeSinceStartup - m_StartTime > m_Timeout && m_Timeout > 0f && !m_IsTimeOut)
		{
			m_IsTimeOut = true;
			OnTimeOut();
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (!m_Launched || m_Hit || m_Trigger || !CheckTrigger(other))
		{
			return;
		}
		DamagableTarget component = other.GetComponent<DamagableTarget>();
		bool flag = false;
		int numID = 0;
		int viewID = 0;
		int localNum = 0;
		Vector3 position = base.transform.position;
		if (component != null)
		{
			if (CanTriggerTarget(component, ref numID, ref viewID, ref localNum))
			{
				flag = true;
			}
		}
		else
		{
			flag = true;
		}
		if (flag)
		{
			m_Trigger = true;
			m_TriggerTime = Time.realtimeSinceStartup;
			ShowHitEffect();
			RpcFinishHit(position, numID, viewID, localNum);
		}
	}

	private bool CheckTrigger(Collider other)
	{
		if (other.CompareTag("InGame/IgnoreTrigger"))
		{
			return false;
		}
		if ((m_PlayerController.IsLocalPlayer || m_PlayerController.AI.enabled) && IsForwardBarrier() && Time.realtimeSinceStartup - m_StartTime <= m_MinHitTime && Vector3.Distance(base.transform.position, m_StartPos) <= m_MinHitDistance)
		{
			DamagableTarget component = other.GetComponent<DamagableTarget>();
			if (component != null && component.m_TargetType == DamagableTarget.TargetType.Player)
			{
				PlayerController playerController = (PlayerController)component.Target;
				if (playerController.UserId == m_PlayerController.UserId)
				{
					return true;
				}
				if (IsMyPassenger(playerController))
				{
					return false;
				}
			}
			RpcFinishHit();
			return false;
		}
		return true;
	}

	protected virtual void GetCheckFallPos(Vector3 pos)
	{
		m_CheckFallPos.Clear();
		Vector3 b = Vector3.Cross(Vector3.up, base.transform.forward).normalized * 0.3f;
		m_CheckFallPos.Add(pos);
		m_CheckFallPos.Add(pos + b);
		m_CheckFallPos.Add(pos - b);
	}

	private bool CheckFall(Vector3 pos)
	{
		if (!m_IsGrounder)
		{
			return false;
		}
		LayerMask mask = 1 << LayerMask.NameToLayer("Default");
		float num = 0.1f;
		if (pos.y >= 1f)
		{
			GetCheckFallPos(pos);
			num = 0f;
			for (int i = 0; i < m_CheckFallPos.Count; i++)
			{
				Vector3 vector = m_CheckFallPos[i];
				if (Physics.Raycast(vector.FlattenY(vector.y + 0.1f), Vector3.down, out RaycastHit hitInfo, vector.y + 0.1f, mask))
				{
					string tag = hitInfo.collider.tag;
					if ((hitInfo.collider.name.Contains("Ground") || tag.Contains("Wall") || tag.Contains("Door") || tag.Contains("Block")) && hitInfo.point.y > num)
					{
						num = hitInfo.point.y;
					}
				}
			}
		}
		m_GroundHeight = num;
		if (pos.y - num > m_MinHeight)
		{
			return true;
		}
		return false;
	}

	protected bool IsForwardBarrier(float distance = 1f)
	{
		bool result = false;
		LayerMask mask = 1 << LayerMask.NameToLayer("Default");
		Vector3 b = new Vector3(0f, 0.2f, 0f);
		Vector3 origin = base.transform.position + b;
		float num = Vector3.Distance(base.transform.position, m_PlayerController.transform.position);
		float num2 = Time.realtimeSinceStartup - m_StartTime;
		if (num < 0.5f || num2 < 0.2f)
		{
			origin = m_PlayerController.transform.position + b;
		}
		int num3 = Physics.RaycastNonAlloc(origin, base.transform.forward, GameObjectUtility.CacheRaycastHits, distance, mask);
		for (int i = 0; i < num3; i++)
		{
			RaycastHit raycastHit = GameObjectUtility.CacheRaycastHits[i];
			if (!(raycastHit.collider == null))
			{
				string tag = raycastHit.collider.tag;
				if (tag.Contains("Wall") || tag.Contains("Door") || tag.Contains("Window") || raycastHit.collider.name.Contains("border") || raycastHit.collider.name.Contains("门"))
				{
					result = true;
					break;
				}
			}
		}
		return result;
	}

	public override void StartPreview()
	{
		m_Root.SetActive(value: false);
		m_PreviewArea.SetActive(value: true);
		base.StartPreview();
	}

	protected override void UpdatePreviewArea()
	{
		base.UpdatePreviewArea();
		if (PlayerController.Inst != null && m_PreviewArea != null)
		{
			Vector3 position = base.transform.position;
			Vector2 posInScreen = WorldToScreenPoint(base.PreviewPosition);
			Vector3 lhs = ScreenPositionToTargetDirection(m_PlayerController.transform.position, posInScreen);
			base.PreviewDirection = lhs.FlattenY().normalized;
			m_PreviewArea.transform.rotation = Quaternion.LookRotation(base.PreviewDirection);
			m_PreviewArea.transform.position = position;
		}
	}

	protected override Vector3 GetPreviewTouchWorldOffset(float maxDistance)
	{
		if (PreviewAreaController.Inst != null)
		{
			return PreviewAreaController.Inst.GetPreviewWorldOffset(maxDistance, AttackArea.AreaType.Line, GameSettings.Inst.CardJoystickSensitivityFloat, m_MobileAutoAime, m_MobileAutoAimeEnemy, m_MobileAutoAimeDead, m_MobileAutoAimeSpeed);
		}
		return Vector3.zero;
	}

	protected virtual bool CanTriggerTarget(DamagableTarget target, ref int numID, ref int viewID, ref int localNum)
	{
		return false;
	}

	protected virtual void CalculateHit()
	{
	}

	protected virtual void RpcFinishHit(Vector3 hitPos = default(Vector3), int numID = 0, int viewID = 0, int localNum = 0)
	{
		if (m_PlayerController.IsLocalPlayer || m_PlayerController.AI.enabled)
		{
			m_PlaceableCreater.RpcFinishHit(m_ID, hitPos, numID, viewID, localNum);
		}
	}

	public virtual void OnFinishHit(Vector3 hitPos, int numID, int viewID, int localNum)
	{
		m_Hit = true;
		m_Launched = false;
		CalculateHit();
		ShowHitEffect();
	}

	protected virtual void OnTimeOut()
	{
	}

	protected void SafeDestroy()
	{
		if (m_PhotonView != null)
		{
			if (m_PhotonView.isMine)
			{
				PhotonNetwork.Destroy(m_PhotonView);
			}
		}
		else if (m_IsPoolable)
		{
			m_Root.SetActive(value: false);
			PoolSpawner.DeSpawn(base.gameObject);
		}
		else
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
	}

	protected void ShowHitEffect()
	{
		if (!m_HitEffectShowed)
		{
			m_HitEffectShowed = true;
			if (m_HitEffect != null)
			{
				GameObject gameObject = PoolSpawner.Spawn(m_HitEffect);
				gameObject.transform.position = base.transform.position + m_HitEffectOffset;
				gameObject.transform.rotation = base.transform.rotation;
			}
			if (m_TrailEffectInst != null)
			{
				PoolSpawner.DeSpawn(m_TrailEffectInst);
			}
		}
	}

	public static Vector2 WorldToScreenPoint(Vector3 worldPos)
	{
		Vector2 vector = SceneCamera.Inst.Camera.WorldToScreenPoint(worldPos);
		vector.x = Mathf.Clamp(vector.x, 0f, Screen.width);
		vector.y = Mathf.Clamp(vector.y, 0f, Screen.height);
		return vector;
	}

	public static Vector3 ScreenPositionToTargetDirection(Vector3 pos, Vector2 posInScreen)
	{
		return GameUtility.ScreenPosToWorldPosition(posInScreen, pos.y) - pos;
	}

	protected bool IsMyPassenger(PlayerController player)
	{
		if ((m_PlayerController.Shifter.IsVehicle || m_PlayerController.Shifter.IsSkateBoard) && player.OnVehichle != null && player.OnVehichle.viewID == m_PlayerController.m_PhotonView.viewID)
		{
			return true;
		}
		return false;
	}

	protected bool IsMyCar(PlayerController player)
	{
		if (m_PlayerController.OnVehichle != null && m_PlayerController.OnVehichle.viewID == player.m_PhotonView.viewID)
		{
			return true;
		}
		return false;
	}
}
