using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class ChatPageGift_GiftItemTemplate
{
	public UIDataBinder m_Host;

	public HeadItem m_Giver;

	public HeadItem m_Receiver;

	public Image m_Icon;

	public Text m_Gift;

	public PlayerSpaceButton m_GetButton;

	public Text m_Time;

	private string m_GiftFormat;

	public static int m_RecordID;

	public void Bind(CommonDataCollection args)
	{
		if (m_GiftFormat == null)
		{
			m_GiftFormat = m_Gift.text;
		}
		int index = args["index"];
		GiftRecordInfo record = GiftUtility.GetGiftRecordByIndex(index);
		if (record != null)
		{
			GiftInfo giftInfo = LocalResources.GiftInfo.Find(record.giftID);
			m_Icon.sprite = SpriteSource.Inst.Find(giftInfo.Icon);
			m_Gift.text = string.Format(m_GiftFormat, giftInfo.Name, record.count);
			m_Time.text = UITimeText.GetFormatTimeShort(Mathf.Max(0, UtcTimeStamp.Now - record.time), withAgo: true);
			m_GetButton.SetPlayerID(record.receiverID);
			m_GetButton.gameObject.SetActive(record.giftWars > 0);
			m_GetButton.OnClickedSpace = delegate
			{
				m_RecordID = record.id;
				GiftUtility.GetGiftRecord(record.id);
			};
			SocialCacheManager.Inst.AcquireHeadInfo(record.giverID, delegate(HeadInfo head)
			{
				m_Giver.SetInfo(head);
			});
			SocialCacheManager.Inst.AcquireHeadInfo(record.receiverID, delegate(HeadInfo head)
			{
				m_Receiver.SetInfo(head);
			});
		}
	}
}
