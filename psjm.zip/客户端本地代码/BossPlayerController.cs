using LightUtility;
using SimpleJson;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class BossPlayerController : PoliceController
{
	[Serializable]
	public class MaterialFX
	{
		public SkinnedMeshCombiner SkinnedMeshCombiner;

		public Material NormalFXMaterial;

		public Material RageFXMaterial;

		public RuntimeAnimatorController MaterialAnimator;
	}

	private enum State
	{
		State1,
		State2,
		State3
	}

	public Transform m_AttackRangePreview;

	public AnimationCurve m_ShakeDistanceFallout;

	public AnimationCurve m_ShakeTimeFallout;

	public float m_ShakeMovementSelf = 0.1f;

	public float m_ShakeMovementOther = 0.15f;

	public float m_ShakeAttackSelfRatio = 0.8f;

	public float m_CameraOffset = 0.3f;

	public float m_SkillRotationFactor = 900f;

	public MaterialFX m_MaterialFX;

	public AudioItem m_DieSpeech;

	public GameObject[] m_InvincibleCollider;

	public Texture m_StateTexture2;

	public Texture m_StateTexture3;

	public float m_State2;

	public float m_State3;

	public GameObject m_BossShield;

	public Image m_StateSplit2;

	public Image m_StateSplit3;

	public static List<BossPlayerController> AllBossPlayers = new List<BossPlayerController>();

	private SkillLauncher m_SkillLauncher;

	private bool m_LastIsMoving;

	private float m_StartMovingTime;

	private float m_DieGameTime;

	private Material[] m_NormalMaterials;

	private Material[] m_RageMaterials;

	private Animator m_MaterialAnimator;

	private bool m_UsingRageMaterials;

	private State m_State;

	private float ShakeExtraRatio => 1f / (float)Mathf.Min(2, AllBossPlayers.Count);

	private bool NeedControlRotation
	{
		get
		{
			if (!SkillLauncher.IsSkillPlaying(SkillKind.TigerJump) && !SkillLauncher.IsSkillPlaying(SkillKind.Snipe))
			{
				return SkillLauncher.IsSkillPlaying(SkillKind.Normal);
			}
			return true;
		}
	}

	public override RoleType PlayingRole => RoleType.Boss;

	public override bool ControllingPosition
	{
		get
		{
			if (!NeedControlRotation)
			{
				if (base.ControllingPosition)
				{
					return !IsDying;
				}
				return false;
			}
			return true;
		}
	}

	protected override float RotationFactor
	{
		get
		{
			if (!NeedControlRotation)
			{
				return base.RotationFactor;
			}
			return m_SkillRotationFactor;
		}
	}

	public SkillLauncher SkillLauncher => m_SkillLauncher;

	public int BloodPercentage => (int)(100f * m_BattleProperties.life / m_BattleProperties.maxLife);

	public float DieGameTime => m_DieGameTime;

	public override bool FinalDeadOrEscaped
	{
		get
		{
			if (GameRuntime.PlayersState == null)
			{
				return false;
			}
			return IsDying;
		}
	}

	public override bool CanShowUI
	{
		get
		{
			if (IsDying)
			{
				return false;
			}
			return base.CanShowUI;
		}
	}

	public static int AllBloodPercentage
	{
		get
		{
			if (AllBossPlayers.Count == 0)
			{
				return 0;
			}
			int num = 0;
			foreach (BossPlayerController allBossPlayer in AllBossPlayers)
			{
				num += allBossPlayer.BloodPercentage;
			}
			return num / AllBossPlayers.Count;
		}
	}

	protected new void Awake()
	{
		m_BattleProperties.maxLife *= 1f + GetLifeRatio();
		m_BattleProperties.life = m_BattleProperties.maxLife;
		base.Awake();
		if (base.IsLocalPlayer)
		{
			SceneCamera.Inst.Camera.transform.localPosition = new Vector3(0f, m_CameraOffset, 0f);
		}
		m_SkillLauncher = GetComponent<SkillLauncher>();
		m_AttackRangePreview.gameObject.SetActive(value: true);
		m_AttackRangePreview.gameObject.SetActive(value: false);
		AllBossPlayers.Add(this);
		OnDamageApplied = (UnityAction<float>)Delegate.Combine(OnDamageApplied, new UnityAction<float>(CheckState));
	}

	private float GetLifeRatio()
	{
		if (GameRuntime.IsCustomRoom)
		{
			return 0f;
		}
		return GameRuntime.BossBloodRatio;
	}

	protected new void Start()
	{
		Image stateSplit;
		Image stateSplit2;
		if (!GameRuntime.IsCustomRoom && GameRuntime.PlayingRole == RoleType.Thief)
		{
			m_BloodBar.gameObject.SetActive(value: false);
			m_BloodBar = InGameBossBlood.Inst.m_BloodBar;
			m_NameText = InGameBossBlood.Inst.m_NameText;
			stateSplit = InGameBossBlood.Inst.m_StateSplit2;
			stateSplit2 = InGameBossBlood.Inst.m_StateSplit3;
		}
		else
		{
			InGameBossBlood.Inst.gameObject.SetActive(value: false);
			stateSplit = m_StateSplit2;
			stateSplit2 = m_StateSplit3;
		}
		base.Start();
		float width = stateSplit.transform.parent.GetComponent<RectTransform>().rect.width;
		stateSplit.rectTransform.anchoredPosition = new Vector2(width * m_State2, stateSplit.rectTransform.anchoredPosition.y);
		stateSplit2.rectTransform.anchoredPosition = new Vector2(width * m_State3, stateSplit2.rectTransform.anchoredPosition.y);
		OnDied = (UnityAction)Delegate.Combine(OnDied, new UnityAction(OnBossDied));
		if (base.ProjectileLauncher != null)
		{
			base.ProjectileLauncher.DoLocalSetWeaponID(120);
			base.ProjectileLauncher.DoLocalSetMagazine(10000000, showReloadBar: false);
		}
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		AllBossPlayers.Remove(this);
	}

	public override void BatchUpdate()
	{
		base.BatchUpdate();
		bool flag = base.IsTransformOwnershipLocked && !m_SkillLauncher.IsAttacking;
		if (m_LastIsMoving != flag)
		{
			m_LastIsMoving = flag;
			if (flag)
			{
				m_StartMovingTime = Time.time;
			}
		}
		UpdateFXMaterials();
	}

	private void OnBossDied()
	{
		SoundManager.PlayOnce(m_DieSpeech);
		m_DieGameTime = InGameScene.Inst.GameTime;
	}

	private void UpdateFXMaterials()
	{
		SkinnedMeshRenderer combinedRenderer = m_MaterialFX.SkinnedMeshCombiner.CombinedRenderer;
		if (!(combinedRenderer != null) || !combinedRenderer.gameObject.activeInHierarchy)
		{
			return;
		}
		if (m_NormalMaterials == null)
		{
			m_NormalMaterials = new Material[2]
			{
				combinedRenderer.sharedMaterials[0],
				m_MaterialFX.NormalFXMaterial
			};
			m_RageMaterials = new Material[3]
			{
				combinedRenderer.sharedMaterials[0],
				m_MaterialFX.NormalFXMaterial,
				m_MaterialFX.RageFXMaterial
			};
			m_MaterialAnimator = combinedRenderer.gameObject.AddComponent<Animator>();
			m_MaterialAnimator.runtimeAnimatorController = m_MaterialFX.MaterialAnimator;
			m_MaterialAnimator.cullingMode = AnimatorCullingMode.CullCompletely;
			combinedRenderer.sharedMaterials = m_NormalMaterials;
		}
		if (BuffManager.ContainsBuff(301))
		{
			if (!m_UsingRageMaterials)
			{
				combinedRenderer.sharedMaterials = m_RageMaterials;
				m_UsingRageMaterials = true;
			}
			m_MaterialAnimator.SetBool("raging", value: true);
		}
		else
		{
			if (m_UsingRageMaterials)
			{
				combinedRenderer.sharedMaterials = m_NormalMaterials;
				m_UsingRageMaterials = false;
			}
			m_MaterialAnimator.SetBool("raging", value: false);
		}
		m_MaterialAnimator.SetBool("dying", IsDying);
		m_MaterialAnimator.SetBool("bombing", SkillLauncher.IsSkillPlaying(SkillKind.BigBomb));
	}

	private void CheckState(float damage)
	{
		switch (m_State)
		{
		case State.State3:
			break;
		case State.State1:
			if (m_BattleProperties.life < m_BattleProperties.maxLife * m_State2)
			{
				m_State = State.State2;
				InGameBossBlood.Inst.m_StateSplit2.gameObject.SetActive(value: false);
				StartCoroutine(DoChangeState(State.State2, delegate
				{
					BuffManager.CreateCorrelatedBuff(this, 509, BuffCorrelation.Boss);
					GameObject[] invincibleCollider = m_InvincibleCollider;
					for (int i = 0; i < invincibleCollider.Length; i++)
					{
						invincibleCollider[i].gameObject.SetActive(value: false);
					}
				}));
			}
			break;
		case State.State2:
			if (m_BattleProperties.life < m_BattleProperties.maxLife * m_State3)
			{
				m_State = State.State3;
				InGameBossBlood.Inst.m_StateSplit3.gameObject.SetActive(value: false);
				StartCoroutine(DoChangeState(State.State3, delegate
				{
					BuffManager.CreateCorrelatedBuff(this, 510, BuffCorrelation.Boss);
					BuffManager.LocalClearAllDeBuffs(force: true);
					UnityEngine.Object.Instantiate(m_BossShield, base.transform);
				}));
			}
			break;
		}
	}

	private IEnumerator DoChangeState(State state, Action action)
	{
		while (m_SkillLauncher.PlayingSkill != null)
		{
			yield return Yielders.FixedUpdate;
		}
		yield return Yielders.FixedUpdate;
		if (base.IsLocalPlayer)
		{
			SwipeController.Inst.gameObject.SetActive(value: false);
			m_SkillLauncher.DisableSkill = true;
			if (m_SkillLauncher.PreviewingSkill != null)
			{
				m_SkillLauncher.PreviewingSkill.ShowPreview(show: false, tryCancel: true);
			}
		}
		m_MaterialFX.SkinnedMeshCombiner.CombinedRenderer.material.mainTexture = ((state == State.State2) ? m_StateTexture2 : m_StateTexture3);
		BuffManager.CreateCorrelatedBuff(this, 511, BuffCorrelation.Boss);
		m_Animator.SetTrigger("attack2");
		ShowChangeStateTips((state != State.State2) ? 1 : 0);
		yield return Yielders.GetWaitForSeconds(2.8f);
		if (base.IsLocalPlayer)
		{
			SwipeController.Inst.gameObject.SetActive(value: true);
			m_SkillLauncher.DisableSkill = false;
		}
		action();
	}

	private void RefreshState(State state)
	{
		SkinnedMeshRenderer combinedRenderer = m_MaterialFX.SkinnedMeshCombiner.CombinedRenderer;
		if (state == State.State2 || state == State.State3)
		{
			GameObject[] invincibleCollider = m_InvincibleCollider;
			for (int i = 0; i < invincibleCollider.Length; i++)
			{
				invincibleCollider[i].gameObject.SetActive(value: false);
			}
			InGameBossBlood.Inst.m_StateSplit2.gameObject.SetActive(value: false);
			combinedRenderer.material.mainTexture = ((state == State.State2) ? m_StateTexture2 : m_StateTexture3);
			if (state == State.State3)
			{
				InGameBossBlood.Inst.m_StateSplit3.gameObject.SetActive(value: false);
				UnityEngine.Object.Instantiate(m_BossShield, base.transform);
			}
		}
	}

	private void ShowChangeStateTips(int state)
	{
		InGameBossSkillUI.Inst.m_TipsBossChangeState.State = state;
		InGameBossSkillUI.Inst.m_TipsBossChangeState.gameObject.SetActive(value: true);
	}

	public override void OnPlayMovement()
	{
		if (PlayerController.Inst != null)
		{
			float time = Vector3.Distance(PlayerController.Inst.transform.position, base.transform.position);
			float num = m_ShakeDistanceFallout.Evaluate(time) * m_ShakeTimeFallout.Evaluate(Time.time - m_StartMovingTime) * ((PlayerController.Inst.PlayingRole == RoleType.Boss) ? m_ShakeMovementSelf : m_ShakeMovementOther);
			if (num > 0f)
			{
				SceneCamera.Inst.Shake(0.5f, num * ShakeExtraRatio);
			}
		}
	}

	public void PlayBegin()
	{
		m_Animator.SetTrigger("begin");
	}

	public void Shake(float intensity, float duration)
	{
		if (PlayerController.Inst != null)
		{
			float time = Vector3.Distance(PlayerController.Inst.transform.position, base.transform.position);
			float num = m_ShakeDistanceFallout.Evaluate(time);
			intensity = intensity * num * ((PlayerController.Inst.PlayingRole == RoleType.Boss) ? m_ShakeAttackSelfRatio : 1f);
			if (intensity > 0f)
			{
				SceneCamera.Inst.Shake(duration, intensity * ShakeExtraRatio);
			}
		}
	}

	public void ShowPreview(bool show, Vector3 center = default(Vector3), float radius = 0f, bool ignoreParent = false)
	{
		m_AttackRangePreview.gameObject.SetActive(show);
		if (show)
		{
			Vector3 vector = Vector3.one * (radius / 2.5f);
			m_AttackRangePreview.position = center;
			m_AttackRangePreview.localScale = vector;
			m_AttackRangePreview.GetComponent<PlayerRoleScale>().SetDefaultScale(vector.x);
		}
		if (ignoreParent && show)
		{
			m_AttackRangePreview.transform.SetParent(null, worldPositionStays: true);
		}
		else
		{
			m_AttackRangePreview.transform.SetParent(base.transform, worldPositionStays: true);
		}
	}

	public override bool CheckGameOver()
	{
		if (InGameScene.Inst.GameTime < 10f)
		{
			return false;
		}
		if (InGameNewbieDirector.Inst != null && !InGameNewbieDirector.Inst.CanShowGameOver)
		{
			return false;
		}
		if (GameRuntime.CheckThiefsAllDying() || IsDying)
		{
			return true;
		}
		return false;
	}

	protected override void OnReSyncWrite(object data)
	{
		base.OnReSyncWrite(data);
		(data as JsonObject)["bossState"] = (int)m_State;
	}

	protected override void OnReSyncRead(object data)
	{
		base.OnReSyncRead(data);
		JsonObject jsonObject = data as JsonObject;
		if (jsonObject.ContainsKey("bossState"))
		{
			m_State = (State)jsonObject.AsInt("bossState");
			RefreshState(m_State);
		}
	}

	public override float GetCommonCooldownTime()
	{
		return base.GetCommonCooldownTime();
	}

	protected override float LimitSpeed(float speed)
	{
		return speed;
	}
}
