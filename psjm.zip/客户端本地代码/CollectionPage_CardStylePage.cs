using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_CardStylePage
{
	public UIDataBinder m_Host;

	public Text m_CollectProgress;

	public Text m_Personality;

	public UITemplateInitiator m_Content;

	public GameObject m_Empty;

	public GameObject m_CardStylesPanel;

	public GameObject m_PreviewPort;

	public UIScrollRect m_ScrollView;

	public Text m_DescTips;

	public Button m_ButtonGain;

	public UIPage m_CardDetailUI;

	public Text m_GainTips;

	private uint m_PlayerID;

	private bool m_IsEmpty;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private string m_CollectFormat;

	private int m_AllCardStyleNum;

	public void Bind(CommonDataCollection args)
	{
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_ButtonGain.gameObject.SetActive(value: false);
		if (m_CollectFormat == null)
		{
			m_CollectFormat = m_CollectProgress.text;
		}
		CollectionPage_CardStyleItem.Selected = 0;
		LoadCardSkinData();
		m_CollectProgress.text = string.Format(m_CollectFormat, CollectionUtility.GetForeverCardStyleCount(m_PlayerInfo), m_AllCardStyleNum);
		DropItem[] foreverCardStyleItems = CollectionUtility.GetForeverCardStyleItems(m_PlayerInfo);
		m_Personality.text = foreverCardStyleItems.Sum((DropItem a) => a.Personality).ToString();
		m_ScrollView.ScrollToStart(immediately: true);
		CardStyleInfo styleInfo = LocalResources.CardStyleTable.Get(LocalResources.DropItemTable.Get(CollectionPage_CardStyleItem.Selected).TypeParam);
		string obj = LocalResources.DropItemTable.Find((DropItem x) => x.TypeParam == styleInfo.BasicCardSkinId).Name.Split('(')[0];
		string str = obj.Remove(obj.Length - 1, 1);
		if (m_IsEmpty)
		{
			m_DescTips.gameObject.SetActive(value: false);
		}
		else
		{
			m_DescTips.gameObject.SetActive(value: true);
			m_DescTips.text = str + Localization.StyleDescPostTips;
		}
		m_GainTips.text = styleInfo.GainTips;
		m_Host.EventProxy(m_ButtonGain, "OnGainButtonClick");
	}

	private void LoadCardSkinData()
	{
		m_AllCardStyleNum = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		DropItem[] array = (from a in LocalResources.DropItemTable
			where a.Type == DropItemType.CardStyle && a.expiredTime == 0
			orderby a.Quality descending, LocalResources.CardStyleTable.Get(a.TypeParam).BasicCardSkinId
			select a).ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(LocalResources.DropItemTable.Get(array[i].Id).TypeParam);
			bool flag = CollectionUtility.OwnedForever(array[i], m_PlayerInfo);
			if (flag || cardStyleInfo.SellStartTime == 0 || cardStyleInfo.SellStartTime <= UtcTimeStamp.Now)
			{
				if (flag)
				{
					list.Add(array[i].Id);
				}
				else
				{
					list2.Add(array[i].Id);
				}
				m_AllCardStyleNum++;
			}
		}
		int num = 0;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (list.Count > 0)
		{
			commonDataCollection[num]["state"] = 0;
			commonDataCollection[num]["items"].val = list.ToList();
			commonDataCollection[num]["roleID"].val = m_PlayerID;
			commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			num++;
		}
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
		{
			if (list2.Count > 0)
			{
				commonDataCollection[num]["state"] = 2;
				commonDataCollection[num]["items"].val = list2.ToList();
				commonDataCollection[num]["roleID"].val = m_PlayerID;
				commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			}
			m_CardStylesPanel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
			m_Empty.SetActive(value: false);
			m_IsEmpty = false;
		}
		else if (list.Count > 0)
		{
			m_Empty.SetActive(value: false);
			m_IsEmpty = false;
			m_CardStylesPanel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
		}
		else
		{
			m_CardStylesPanel.SetActive(value: false);
			m_PreviewPort.SetActive(value: false);
			m_Empty.SetActive(value: true);
			m_IsEmpty = true;
		}
		m_Content.Args = commonDataCollection;
		m_Content.UpdateImmediately(withChildren: true);
	}

	public void OnGainButtonClick()
	{
		int selected = CollectionPage_CardStyleItem.Selected;
		DropItem dropItem = LocalResources.DropItemTable.Get(selected);
		CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(dropItem.TypeParam);
		UILobby.Current.ShowUI(m_CardDetailUI, CardUtility.CardDetailUIArgsWraper(cardStyleInfo.CardID, CardUtility.GetCardLevel(cardStyleInfo.CardID)));
		CardConfigEditPage_CardSkinItemTemplate.globalSelected = cardStyleInfo.BasicCardSkinId;
		StyleItemTemplate.GlobleSelectedStyleId = cardStyleInfo.Id;
		CardConfigEditPage_PageCardSkin.HadSetCardSkinDefaultSelect = true;
		UIDataEvents.Inst.InvokeEvent("CardStylePreviewChanged");
	}
}
