using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ActivityGiftUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public RemoteTexture m_Icon;

	public UITemplateInitiator m_TemplateInitiatorHorizontal;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public MultiTargetGraphicButton m_BuyButton;

	public Text m_Price;

	public GameObject m_HadBuyTips;

	public Text m_Limit;

	public UIStateItem m_Effect;

	public Text m_Discount;

	public Text m_Orig;

	public Image m_OrigIcon;

	protected Activity m_Activity;

	protected ActivityGiftInfo m_ActivityGiftInfo;

	private ActivityGiftUI m_ActivityGiftUI;

	private GoodsInfo m_goodsInfo;

	private string m_PriceFormat;

	private int m_expiredTime;

	private string m_DiscountFormat;

	private string m_OrigFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_PriceFormat))
		{
			m_PriceFormat = m_Price.text;
		}
		if (string.IsNullOrEmpty(m_DiscountFormat))
		{
			m_DiscountFormat = m_Discount.text;
		}
		m_Activity = (args["activity"].val as Activity);
		DataItem item = args["index"];
		m_Effect.State = item;
		m_expiredTime = args["expiredTime"];
		m_ActivityGiftUI = (args["ActivityGiftUI"].val as ActivityGiftUI);
		m_ActivityGiftInfo = (args["ActivityGift"].val as ActivityGiftInfo);
		m_Discount.text = string.Format(m_DiscountFormat, m_ActivityGiftInfo.discount);
		m_Name.text = m_ActivityGiftInfo.mainName;
		SetDropItems(m_ActivityGiftInfo.items);
		m_Icon.SetTexture(m_ActivityGiftInfo.mainItemURL);
		m_goodsInfo = LocalResources.GoodsTable.Get(m_ActivityGiftInfo.goodsId);
		m_Price.text = string.Format(m_PriceFormat, m_goodsInfo.Price / 10);
		SetLimitType();
		m_Host.EventProxy(m_BuyButton, "OnClickBuy");
		SetOrig();
	}

	private void SetLimitType()
	{
		bool flag = m_ActivityGiftInfo.buyTimes >= m_ActivityGiftInfo.buyLimitTimes;
		m_BuyButton.gameObject.SetActive(!flag);
		m_HadBuyTips.gameObject.SetActive(flag);
		UIStateItem component = m_HadBuyTips.GetComponent<UIStateItem>();
		switch (m_ActivityGiftInfo.limitType)
		{
		case 0:
			m_Limit.text = string.Format(Localization.GiftActivityLimit, m_ActivityGiftInfo.buyTimes, m_ActivityGiftInfo.buyLimitTimes);
			if (component != null)
			{
				component.State = 0;
			}
			break;
		case 1:
			m_Limit.text = string.Format(Localization.GiftActivityLimitWeek, m_ActivityGiftInfo.buyTimes, m_ActivityGiftInfo.buyLimitTimes);
			if (component != null)
			{
				component.State = ((UtcTimeStamp.GetNextMonday(UtcTimeStamp.Now) < m_Activity.endTime) ? 1 : 0);
			}
			break;
		case 2:
			m_Limit.text = string.Format(Localization.GiftActivityLimitDay, m_ActivityGiftInfo.buyTimes, m_ActivityGiftInfo.buyLimitTimes);
			if (component != null)
			{
				component.State = (UtcTimeStamp.IsCrossDay(UtcTimeStamp.Now, m_Activity.endTime) ? 2 : 0);
			}
			break;
		}
	}

	protected virtual void SetDropItems(ItemInfo[] items)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < items.Length; i++)
		{
			commonDataCollection[i]["dropItemInfo"].val = items[i];
		}
		m_TemplateInitiatorHorizontal.Args = commonDataCollection;
	}

	private void SetOrig()
	{
		if (!(m_Orig != null) || !(m_OrigIcon != null))
		{
			return;
		}
		if (m_ActivityGiftInfo.orig != null)
		{
			m_Orig.gameObject.SetActive(value: true);
			if (string.IsNullOrEmpty(m_OrigFormat))
			{
				m_OrigFormat = m_Orig.text;
			}
			if (m_ActivityGiftInfo.orig.itemID != 99)
			{
				m_OrigIcon.gameObject.SetActive(value: true);
				m_OrigIcon.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(m_ActivityGiftInfo.orig.itemID).Icon);
				m_Orig.text = string.Format(m_OrigFormat, m_ActivityGiftInfo.orig.itemCount);
			}
			else
			{
				m_Orig.text = string.Format(m_OrigFormat, m_ActivityGiftInfo.orig.itemCount / 10);
			}
		}
		else
		{
			m_Orig.gameObject.SetActive(value: false);
			m_OrigIcon.gameObject.SetActive(value: false);
		}
	}

	public void OnClickBuy()
	{
		if (m_ActivityGiftInfo.buyTimes < m_ActivityGiftInfo.buyLimitTimes)
		{
			if (UtcTimeStamp.Now > m_expiredTime)
			{
				UILobby.Current.ShowTips(Localization.OutOfDate);
			}
			else
			{
				PaymentUtility.DoPay(m_ActivityGiftInfo.goodsId, m_goodsInfo.ItemDesc, null, delegate(int value)
				{
					if (value == m_ActivityGiftInfo.goodsId)
					{
						bool flag = false;
						ItemInfo[] items = m_ActivityGiftInfo.items;
						foreach (ItemInfo itemInfo in items)
						{
							DropItem dropItem = LocalResources.DropItemTable.Get(itemInfo.itemID);
							if (dropItem.Type == DropItemType.RandomCardPiece || dropItem.Type == DropItemType.RandomCardPieceType)
							{
								flag = true;
								break;
							}
						}
						if (flag)
						{
							HttpRequestRechargeGiftRandomDrop requset = new HttpRequestRechargeGiftRandomDrop
							{
								goodsID = m_ActivityGiftInfo.goodsId
							};
							GameHttpManager.Inst.Send(requset, delegate(HttpResponseRechargeGiftRandomDrop onResponse)
							{
								CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
								commonRewardPopupUI.AddItems(onResponse.items);
								commonRewardPopupUI.SetTitleAndTips("", "");
							});
						}
						else
						{
							ActivityGiftUI_ItemTemplate activityGiftUI_ItemTemplate = this;
							List<int> list = new List<int>();
							List<ItemInfo> normalItem = new List<ItemInfo>();
							items = m_ActivityGiftInfo.items;
							foreach (ItemInfo itemInfo2 in items)
							{
								DropItem dropItem2 = LocalResources.DropItemTable.Get(itemInfo2.itemID);
								if (dropItem2.Type == DropItemType.Character)
								{
									list.Add(dropItem2.TypeParam);
								}
								else if (dropItem2.Type == DropItemType.SkinSuite)
								{
									ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(dropItem2.TypeParam);
									for (int j = 0; j < shopSuiteInfo.ShopItemIDs.Length; j++)
									{
										normalItem.Add(new ItemInfo(shopSuiteInfo.ShopItemIDs[j], itemInfo2.itemCount));
									}
								}
								else
								{
									normalItem.Add(itemInfo2);
								}
							}
							GameAsyncSequence gameAsyncSequence = new GameAsyncSequence();
							foreach (int character in list)
							{
								gameAsyncSequence.Add(() => activityGiftUI_ItemTemplate.TryShowGainCharacter(character));
							}
							gameAsyncSequence.Add(() => activityGiftUI_ItemTemplate.TryShowGainCommonReward(normalItem));
							gameAsyncSequence.Run();
						}
						m_ActivityGiftUI.m_Host.UpdateBinding();
					}
					else
					{
						UnityEngine.Debug.LogError("valus is invalid ! " + value);
					}
				}, SocialModuleType.RechargeGift);
			}
		}
	}

	private GameAsyncCallback TryShowGainCharacter(int characterId)
	{
		GameAsyncCallback cb = new GameAsyncCallback();
		CharacterFeatureUI.Inst.TryShowNewCharacter(characterId, delegate
		{
			cb.onSuccess();
		});
		return cb;
	}

	private GameAsyncCallback TryShowGainCommonReward(List<ItemInfo> items)
	{
		GameAsyncCallback cb = new GameAsyncCallback();
		CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI, delegate
		{
			cb.onSuccess();
		});
		commonRewardPopupUI.AddItems(items.ToArray());
		commonRewardPopupUI.SetTitleAndTips("", "");
		return cb;
	}
}
