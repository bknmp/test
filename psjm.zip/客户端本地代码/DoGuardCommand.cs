using BehaviorDesigner.Runtime.Tasks;
using LightUtility;
using UnityEngine;

public class DoGuardCommand : Action
{
	private AIController ai;

	private float startInitTime = -1f;

	private float initTimeInterval = -1f;

	private const float guardMinInterval = 1f;

	private const float guardMaxInterval = 5f;

	private float lastGuardTime = -1f;

	private float guardTimeInterval = -1f;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
		initTimeInterval = Random.Range(ai.m_IdleTimeMin, ai.m_IdleTimeMax);
		lastGuardTime = Time.time;
		guardTimeInterval = Random.Range(1f, 5f);
		if (ai.InModeRange(transform.localPosition))
		{
			Vector3 targetPosition = ai.m_GuardPosition + Random.insideUnitCircle.ExpandZ().SwapYZ() * ai.m_GuardRange;
			ai.RecalculatePath(targetPosition);
		}
		else
		{
			ai.RecalculatePath(ai.m_GuardPosition);
		}
	}

	public override TaskStatus OnUpdate()
	{
		if (!ai.InMode(AIMode.Guard))
		{
			return TaskStatus.Failure;
		}
		if (!ai.IsMoving)
		{
			if (startInitTime < 0f)
			{
				startInitTime = Time.time;
			}
			else if (Time.time - startInitTime > initTimeInterval)
			{
				startInitTime = -1f;
				initTimeInterval = Random.Range(ai.m_IdleTimeMin, ai.m_IdleTimeMax);
				RecaculateGuardPath();
			}
		}
		else if (Time.time - lastGuardTime > guardTimeInterval)
		{
			lastGuardTime = Time.time;
			guardTimeInterval = Random.Range(1f, 5f);
			RecaculateGuardPath();
		}
		ai.MoveToTarget();
		return TaskStatus.Running;
	}

	private void RecaculateGuardPath()
	{
		if (ai.InModeRange(transform.localPosition))
		{
			Vector3 targetPosition = ai.m_GuardPosition + Random.insideUnitCircle.ExpandZ().SwapYZ() * ai.m_GuardRange;
			ai.RecalculatePath(targetPosition);
		}
		else
		{
			ai.RecalculatePath(ai.m_GuardPosition);
		}
	}
}
