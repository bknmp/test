using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CharacterActivityUI : ActivityCollectionPageBase
{
	public Button m_HelpBt;

	public UIPopup m_LotteryRuleUI;

	protected ActivityLobbyInfo m_CurrentActivityInfo;

	protected override void OnTabChanged()
	{
		base.OnTabChanged();
		if (!(m_HelpBt == null) && !(m_LotteryRuleUI == null))
		{
			Activity activity = m_ActivityList[Mathf.Clamp(m_DataTabPage.TabPage.GetSelectedTabIndex(), 0, m_ActivityList.Count - 1)];
			m_CurrentActivityInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
			m_HelpBt.onClick.RemoveAllListeners();
			m_HelpBt.onClick.AddListener(PopUpHelp);
		}
	}

	private void PopUpHelp()
	{
		new CommonDataCollection();
		ActivityLobby.ShowInfoPopupUI("", m_CurrentActivityInfo.Desc);
	}

	private int GetActivityIndex(ActivityType type)
	{
		int result = -1;
		for (int i = 0; i < m_ActivityList.Count; i++)
		{
			if (LocalResources.ActivityLobbyInfos.Get(m_ActivityList[i].activityId).Type == type)
			{
				result = i;
				break;
			}
		}
		return result;
	}

	public void JumpTabByActivityType(ActivityType type)
	{
		int activityIndex = GetActivityIndex(type);
		if (activityIndex != -1)
		{
			if (m_DataTabPage.TabPage.m_Buttons.Count > activityIndex)
			{
				m_DataTabPage.TabPage.SetSelectedTabIndex(activityIndex);
			}
			else
			{
				m_JumpIndex = activityIndex;
			}
		}
	}
}
