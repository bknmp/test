using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(UIPopup))]
public sealed class CommonRewardPopupUI : MonoBehaviour
{
	public const string POPUP_PREFAB_NAME = "CommonRewardPopupUI";

	public CommonRewardItem m_ItemTemplate;

	public Transform m_SingleItemContainer;

	public Transform m_MultiItemContainer;

	public GameObject m_Buttons;

	public AudioItem m_AudioClip;

	public Text m_Title;

	public Text m_Tips;

	public float m_InitialTweenDelay = 0.3f;

	public GameObject m_UseBtn;

	public GameObject m_CardLotteryButton;

	public GameObject m_CardComposeButton;

	private int m_MultiNum = 7;

	private Transform m_ItemContainer;

	private Delegates.VoidCallback m_OnComplete;

	private List<CommonRewardItem> m_RewardItems = new List<CommonRewardItem>();

	private List<ItemInfo> m_AllItems = new List<ItemInfo>();

	private List<ItemInfo> m_notOwnPermanentItems = new List<ItemInfo>();

	private string m_DefaultTitle;

	private bool dirty;

	private bool m_ShowExpAdd;

	private bool m_hadRefreshAsset;

	private bool m_GotAnyForeverItem;

	private int m_canComposeCardId;

	private CardLotteryUI.LotteryState m_cardLotteryState;

	private bool m_DoubleClick;

	private float m_LastClickedTime;

	private float m_StartTime;

	private bool m_PassExp;

	private void Awake()
	{
		if (m_Title != null)
		{
			m_DefaultTitle = m_Title.text;
		}
		m_ItemTemplate.gameObject.SetActive(value: false);
	}

	private void OnEnable()
	{
		SoundManager.PlayOnce(m_AudioClip);
		m_Buttons.SetActive(value: false);
		Invoke("EnableButton", m_InitialTweenDelay);
	}

	private void EnableButton()
	{
		m_Buttons.SetActive(value: true);
	}

	private void OnDisable()
	{
		LocalPlayerDatabase.RefreshAssetsInfo();
		if (m_GotAnyForeverItem)
		{
			LocalPlayerDatabase.RefreshFlashSaleGift();
		}
		if (ExpAddTips.Inst != null && m_ShowExpAdd)
		{
			ExpAddTips.Inst.ShowAll();
		}
		if (m_PassExp)
		{
			PassUtility.RefreshPassInfo();
		}
		Clear();
	}

	public void OnOKClicked()
	{
		GetComponent<UIPopup>().GoBack();
		if (m_OnComplete != null)
		{
			m_OnComplete();
		}
	}

	private void Clear()
	{
		for (int i = 0; i < m_RewardItems.Count; i++)
		{
			UnityEngine.Object.Destroy(m_RewardItems[i].gameObject);
		}
		m_RewardItems.Clear();
		m_AllItems.Clear();
		m_canComposeCardId = 0;
		m_GotAnyForeverItem = false;
		m_cardLotteryState = CardLotteryUI.LotteryState.None;
		m_PassExp = false;
	}

	public void AddItems(ItemInfo[] itemList)
	{
		m_AllItems.AddRange(itemList);
		dirty = true;
	}

	public void AddItem(int itemID, int amount)
	{
		m_AllItems.Add(new ItemInfo(itemID, amount));
		dirty = true;
	}

	public void AddItem(DropItem dropItem, int amount)
	{
		m_AllItems.Add(new ItemInfo(dropItem.Id, amount));
		dirty = true;
	}

	public void SetTitleAndTips(string title, string tips)
	{
		if (m_Title != null)
		{
			m_Title.text = (string.IsNullOrEmpty(title) ? m_DefaultTitle : title);
		}
		if (m_Tips != null)
		{
			m_Tips.text = tips;
		}
	}

	private void Update()
	{
		if (dirty)
		{
			dirty = false;
			m_AllItems.Sort(delegate(ItemInfo x, ItemInfo y)
			{
				DropItem dropItem = LocalResources.DropItemTable.Get(x.itemID);
				DropItem dropItem2 = LocalResources.DropItemTable.Get(y.itemID);
				return -dropItem.SortValue.CompareTo(dropItem2.SortValue);
			});
			m_notOwnPermanentItems = GetNotOwnPermanentItems(m_AllItems);
			m_ItemContainer = ((m_AllItems.Count > m_MultiNum) ? m_MultiItemContainer : m_SingleItemContainer);
			foreach (ItemInfo allItem in m_AllItems)
			{
				bool addExp = m_notOwnPermanentItems.Contains(allItem);
				ShowItem(allItem, addExp);
			}
			TryShowButton();
		}
		if (m_DoubleClick && (Input.GetMouseButtonDown(0) || (UnityEngine.Input.touchCount > 0 && UnityEngine.Input.GetTouch(0).phase == TouchPhase.Began)) && !(Time.time - m_StartTime < 0.5f))
		{
			if (m_LastClickedTime > 0f && Time.time - m_LastClickedTime < 0.3f)
			{
				OnOKClicked();
				m_LastClickedTime = 0f;
				m_DoubleClick = false;
			}
			else
			{
				m_LastClickedTime = Time.time;
			}
		}
	}

	private List<ItemInfo> GetNotOwnPermanentItems(List<ItemInfo> items)
	{
		List<ItemInfo> list = new List<ItemInfo>();
		for (int i = 0; i < items.Count; i++)
		{
			ItemInfo itemInfo = items[i];
			if (LocalPlayerDatabase.NotOwnPermanentItem(itemInfo.itemID, includeNormal: true))
			{
				list.Add(itemInfo);
			}
		}
		return list;
	}

	private void ShowItem(ItemInfo info, bool addExp)
	{
		DropItem dropItem = LocalResources.DropItemTable.Get(info.itemID);
		CommonRewardItem commonRewardItem = UnityEngine.Object.Instantiate(m_ItemTemplate);
		commonRewardItem.GetComponent<TweenScale>().m_Delay = m_InitialTweenDelay;
		commonRewardItem.gameObject.SetActive(value: true);
		commonRewardItem.transform.SetParent(m_ItemContainer, worldPositionStays: false);
		DropItemUI component = commonRewardItem.GetComponent<DropItemUI>();
		component.SetInfo(info.itemID, info.itemCount);
		if (commonRewardItem.m_CardPieceProcessBar != null)
		{
			if (dropItem.Type == DropItemType.CardPiece)
			{
				commonRewardItem.m_CardPieceProcessBar.gameObject.SetActive(value: true);
				component.m_ItemName.gameObject.SetActive(value: false);
			}
			else
			{
				commonRewardItem.m_CardPieceProcessBar.gameObject.SetActive(value: false);
				component.m_ItemName.gameObject.SetActive(value: true);
			}
		}
		if (commonRewardItem.m_Tips != null)
		{
			commonRewardItem.m_Tips.text = info.GetExchangeTips(Localization.TipsExchangeFormat, dropItem);
		}
		if (dropItem.Type == DropItemType.CardPiece)
		{
			commonRewardItem.m_CardPieceProcessBar.DropCardPiece(dropItem.Id, info.itemCount, tween: true, m_InitialTweenDelay + commonRewardItem.GetComponent<TweenScale>().m_Duration, m_hadRefreshAsset);
		}
		TrySetRedPointData(dropItem);
		StartCoroutine(ShowEffect(dropItem, commonRewardItem, m_InitialTweenDelay));
		m_RewardItems.Add(commonRewardItem);
		if (ExpAddTips.Inst != null && addExp)
		{
			ExpAddTips.Inst.AddDropItem(dropItem.Id);
		}
		if (dropItem.Type == DropItemType.PassExp)
		{
			m_PassExp = true;
		}
	}

	private IEnumerator ShowEffect(DropItem item, CommonRewardItem rewardItem, float delay)
	{
		rewardItem.m_SkinEffect.gameObject.SetActive(item.Type != DropItemType.CardPiece && item.Type != DropItemType.PropCard);
		yield return new WaitForSeconds(delay);
		rewardItem.m_SkinEffect.State = item.Quality;
	}

	public void OnClickUse()
	{
		List<DropItem> list = new List<DropItem>();
		for (int i = 0; i < m_notOwnPermanentItems.Count; i++)
		{
			list.Add(LocalResources.DropItemTable.Get(m_notOwnPermanentItems[i].itemID));
		}
		TryToUse(list.ToArray());
		GetComponent<UIPopup>().GoBack();
		if (m_OnComplete != null)
		{
			m_OnComplete();
		}
	}

	public void ClickCardLotteryButton()
	{
		CardLotteryUI.m_LotteryState = m_cardLotteryState;
		OnOKClicked();
		JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
	}

	public void ClickCardComposeButton()
	{
		CardConfigEditPage_ItemTemplate.ScrollItemID = m_canComposeCardId;
		OnOKClicked();
		JumpModuleManager.Inst.DoJump(JumpModule.PropCardUI);
	}

	private void TryShowButton()
	{
		bool flag = false;
		bool flag2 = false;
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		foreach (ItemInfo notOwnPermanentItem in m_notOwnPermanentItems)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(notOwnPermanentItem.itemID);
			if (dropItem.Type == DropItemType.SkinPart && !CharacterUtility.OwnPermanentSkinPart(dropItem.TypeParam) && CharacterUtility.IsOwnCharacter(LocalResources.SkinPartTable.Get(dropItem.TypeParam).CharacterID))
			{
				num++;
			}
			if (dropItem.Type == DropItemType.SkinSuite && CharacterUtility.IsOwnCharacter(LocalResources.ShopSuiteTable.Get(dropItem.TypeParam).CharacterID))
			{
				num++;
			}
			if (dropItem.Type == DropItemType.CardSkin && !CardUtility.OwnPermanentCardSkin(dropItem.TypeParam))
			{
				num2++;
			}
			if (dropItem.Type == DropItemType.CardStyle && CardUtility.OwnPermanentCardSkin(LocalResources.CardStyleTable.Get(dropItem.TypeParam).BasicCardSkinId))
			{
				num4++;
			}
			if (dropItem.Type == DropItemType.Lightness)
			{
				num3++;
			}
			if (dropItem.expiredTime == 0 && (dropItem.Type == DropItemType.SkinPart || dropItem.Type == DropItemType.SkinSuite || dropItem.Type == DropItemType.CardSkin))
			{
				m_GotAnyForeverItem = true;
			}
			if (dropItem.Type == DropItemType.CardLotteryTicket)
			{
				flag2 = true;
				if (dropItem.Id == 19)
				{
					m_cardLotteryState = CardLotteryUI.LotteryState.Rainbow;
				}
				else if (m_cardLotteryState == CardLotteryUI.LotteryState.None)
				{
					m_cardLotteryState = CardLotteryUI.LotteryState.Normal;
				}
			}
			if (m_canComposeCardId == 0 && dropItem.Type == DropItemType.CardPiece && !CardUtility.IsOwned(dropItem.TypeParam))
			{
				int ownCardPieceNum = CardUtility.GetOwnCardPieceNum(dropItem.TypeParam);
				int num5 = m_hadRefreshAsset ? ownCardPieceNum : (ownCardPieceNum + notOwnPermanentItem.itemCount);
				int cardComposePieceNum = CardUtility.GetCardComposePieceNum(dropItem.TypeParam);
				if (num5 >= cardComposePieceNum)
				{
					m_canComposeCardId = dropItem.TypeParam;
				}
			}
		}
		flag = ((num > 0 && num2 == 0 && num3 == 0 && num4 == 0) || (num == 0 && num2 > 0 && num3 == 0 && num4 == 0) || (num == 0 && num2 == 0 && num3 > 0 && num4 == 0) || (num == 0 && num2 == 0 && num3 == 0 && num4 > 0));
		int num6 = 0;
		num6 = ((flag && m_UseBtn != null) ? (num6 + 1) : num6);
		num6 = ((flag2 && m_CardLotteryButton != null) ? (num6 + 1) : num6);
		num6 = ((m_canComposeCardId > 0 && m_CardComposeButton != null) ? (num6 + 1) : num6);
		if (num6 > 1)
		{
			flag = (flag2 = false);
			m_canComposeCardId = 0;
		}
		if (m_UseBtn != null)
		{
			m_UseBtn.SetActive(flag);
		}
		if (m_CardLotteryButton != null)
		{
			m_CardLotteryButton.SetActive(flag2);
		}
		if (m_CardComposeButton != null)
		{
			m_CardComposeButton.gameObject.SetActive(m_canComposeCardId > 0);
		}
	}

	public static void TryToUse(DropItem[] items)
	{
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		List<int> list3 = new List<int>();
		foreach (DropItem dropItem in items)
		{
			if (dropItem.Type == DropItemType.SkinPart || dropItem.Type == DropItemType.SkinGroup)
			{
				SkinInfo skinInfo = CharacterUtility.GetSkinInfo(dropItem.TypeParam);
				if (!CharacterUtility.IsOwnCharacter(skinInfo.CharacterID))
				{
					continue;
				}
				if (ShopUtility.IsGroup(skinInfo.Id))
				{
					SkinGroupInfo skinGroupInfo = skinInfo as SkinGroupInfo;
					list.AddRange(skinGroupInfo.SkinPartIds);
					int[] skinPartIds = skinGroupInfo.SkinPartIds;
					foreach (int num in skinPartIds)
					{
						bool isLast = skinGroupInfo.SkinPartIds[skinGroupInfo.SkinPartIds.Length - 1] == num;
						ChangeSkinPart(LocalResources.SkinPartTable.Get(num), isLast);
					}
					continue;
				}
				SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(skinInfo.Id);
				PlayerCharacterInfo playerCharacterInfo = LocalPlayerDatabase.PlayerInfo.ownedCharacters.Find((PlayerCharacterInfo x) => x.characterID == skinPartInfo.CharacterID);
				CharacterUtility.SkinPartArray realChangedParts = CharacterUtility.GetRealChangedParts(skinInfo.Id, playerCharacterInfo.currentSkinInfo.skinPartIDs);
				for (int k = 0; k < realChangedParts.skinPartIDs.Length; k++)
				{
					int num2 = realChangedParts.skinPartIDs[k];
					list.Add(num2);
					bool isLast2 = k == realChangedParts.skinPartIDs.Length - 1;
					ChangeSkinPart(LocalResources.SkinPartTable.Get(num2), isLast2);
				}
			}
			else if (dropItem.Type == DropItemType.SkinSuite)
			{
				ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(dropItem.TypeParam);
				if (CharacterUtility.IsOwnCharacter(shopSuiteInfo.CharacterID))
				{
					int[] suiteParts = CharacterUtility.GetSuiteParts(shopSuiteInfo);
					list.AddRange(suiteParts);
					int[] skinPartIds = suiteParts;
					foreach (int num3 in skinPartIds)
					{
						bool isLast3 = suiteParts[suiteParts.Length - 1] == num3;
						ChangeSkinPart(LocalResources.SkinPartTable.Get(num3), isLast3);
					}
				}
			}
			else if (dropItem.Type == DropItemType.CardSkin)
			{
				list2.Add(dropItem.TypeParam);
			}
			else if (dropItem.Type == DropItemType.CardStyle)
			{
				list3.Add(dropItem.TypeParam);
			}
			else if (dropItem.Type == DropItemType.Lightness)
			{
				NewLightnessTips.Inst.TryToClear(dropItem.TypeParam);
				LocalPlayerDatabase.PlayerInfo.lightness.config = dropItem.TypeParam;
				WardrobeUI_PageLightness.SaveConfig(dropItem.TypeParam, sendNoWait: false);
				LobbyScene.Inst.CurrentCharacter.LightnessController.ShowLight(dropItem.TypeParam);
			}
		}
		if (list.Count > 0)
		{
			CharacterUtility.SetSkinPart(list);
		}
		if (list2.Count > 0)
		{
			for (int l = 0; l < list2.Count; l++)
			{
				CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(list2[l]);
				CardUtility.SetCardSkin(cardSkinInfo.CardID, cardSkinInfo.Id);
				NewCardSkinTips.Inst.TryToClear(cardSkinInfo.Id);
			}
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
			HttpRequestSetCardSkin httpRequestSetCardSkin = new HttpRequestSetCardSkin();
			httpRequestSetCardSkin.cardSkinID = list2.ToArray();
			GameHttpManager.Inst.Send(httpRequestSetCardSkin, null);
		}
		if (list3.Count > 0)
		{
			for (int m = 0; m < list3.Count; m++)
			{
				CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(list3[m]);
				CardUtility.SetCardStyle(cardStyleInfo.BasicCardSkinId, cardStyleInfo.Id);
				NewCardSkinTips.Inst.TryToClear(cardStyleInfo.Id);
			}
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
			HttpRequestSetCardSkin httpRequestSetCardSkin2 = new HttpRequestSetCardSkin();
			int[] array = new int[list3.Count];
			for (int n = 0; n < list3.Count; n++)
			{
				array[n] = LocalResources.CardStyleTable.Get(list3[n]).BasicCardSkinId;
			}
			httpRequestSetCardSkin2.cardStyleID = list3.ToArray();
			httpRequestSetCardSkin2.styleRelatedSkinID = array;
			GameHttpManager.Inst.Send(httpRequestSetCardSkin2, null);
		}
	}

	private static void ChangeSkinPart(SkinPartInfo info, bool isLast)
	{
		NewSkinPartTips.Inst.TryToClear(info.Id);
		int ownedSkinPartColor = CharacterUtility.GetOwnedSkinPartColor(info.Id);
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == info.CharacterID)
			{
				playerCharacterInfo.currentSkinInfo.skinPartIDs[(int)info.PartType] = info.Id;
				playerCharacterInfo.currentSkinInfo.skinPartColors[(int)info.PartType] = ownedSkinPartColor;
				break;
			}
		}
		if (LobbyScene.Inst.CurrentCharacter.CharacterID == info.CharacterID)
		{
			LobbyScene.Inst.CurrentCharacter.ChangePart(info.Id, ownedSkinPartColor, isInGame: false, isLast);
		}
	}

	public static void TrySetRedPointData(DropItem dropItem)
	{
		switch (dropItem.Type)
		{
		case DropItemType.SkinPart:
		case DropItemType.SkinGroup:
			NewSkinPartTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.CardSkin:
		case DropItemType.CardStyle:
			NewCardSkinTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.HeadBox:
		case DropItemType.BubbleBox:
			HeadBubbleBoxUtility.TryToSetNewHeadBubbleBoxData(dropItem.TypeParam);
			break;
		case DropItemType.IngameEmotion:
			NewIngameEmotionTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.Lightness:
			NewLightnessTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.SkinSuite:
		{
			int[] shopItemIDs = LocalResources.ShopSuiteTable.Get(dropItem.TypeParam).ShopItemIDs;
			foreach (int id in shopItemIDs)
			{
				NewSkinPartTips.Inst.TryToSetNew(LocalResources.DropItemTable.Get(id).TypeParam);
			}
			break;
		}
		case DropItemType.FortuneCard:
			LocalPlayerDatabase.SetPrefValue("GainFortuneCards", value: true);
			break;
		}
	}

	public static CommonRewardPopupUI Show(CommonRewardPopupUI prefab, Delegates.VoidCallback onComplete = null, bool showExpAdd = true, bool hadRefreshAsset = false, bool doubleClick = false)
	{
		UILobby.Current.Popup(prefab.GetComponent<UIPopup>());
		CommonRewardPopupUI component = UILobby.Current.CurrentPopup().GetComponent<CommonRewardPopupUI>();
		component.Clear();
		component.m_OnComplete = onComplete;
		component.m_ShowExpAdd = showExpAdd;
		component.m_hadRefreshAsset = hadRefreshAsset;
		component.SetTitleAndTips(string.Empty, string.Empty);
		component.m_DoubleClick = doubleClick;
		component.m_StartTime = Time.time;
		return component;
	}

	public static void ShowGoodsRewardsUI(CommonRewardPopupUI prefab, int goodsID, ItemInfo[] items, Delegates.VoidCallback onComplete = null, bool showExpAdd = true, bool hadRefreshAsset = false, bool doubleClick = false)
	{
		bool flag = false;
		foreach (ItemInfo itemInfo in items)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(itemInfo.itemID);
			if (dropItem.Type == DropItemType.RandomCardPiece || dropItem.Type == DropItemType.RandomCardPieceType)
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			HttpRequestRechargeGiftRandomDrop httpRequestRechargeGiftRandomDrop = new HttpRequestRechargeGiftRandomDrop();
			httpRequestRechargeGiftRandomDrop.goodsID = goodsID;
			GameHttpManager.Inst.Send(httpRequestRechargeGiftRandomDrop, delegate(HttpResponseRechargeGiftRandomDrop onResponse)
			{
				CommonRewardPopupUI commonRewardPopupUI2 = Show(prefab, onComplete, showExpAdd, hadRefreshAsset, doubleClick);
				commonRewardPopupUI2.AddItems(onResponse.items);
				commonRewardPopupUI2.SetTitleAndTips("", "");
			});
		}
		else
		{
			CommonRewardPopupUI commonRewardPopupUI = Show(prefab, onComplete, showExpAdd, hadRefreshAsset, doubleClick);
			commonRewardPopupUI.AddItems(items);
			commonRewardPopupUI.SetTitleAndTips("", "");
		}
	}
}
