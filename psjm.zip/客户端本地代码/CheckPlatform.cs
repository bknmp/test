using GameMessages;
using LightUI;
using UnityEngine;

public class CheckPlatform : MonoBehaviour
{
	public PlatformID m_PlatformID;

	public UIPopup m_UIPopup;

	private void Start()
	{
		if (m_PlatformID != 0)
		{
			base.gameObject.SetActive(m_PlatformID == LocalPlayerDatabase.LoginPlatformID);
		}
		else
		{
			base.gameObject.SetActive(value: false);
		}
	}

	public void OpenVIPUI()
	{
		if (m_UIPopup != null)
		{
			UILobby.Current.Popup(m_UIPopup);
		}
	}
}
