using GameMessages;
using LightUI;
using System.Text.RegularExpressions;
using UnityEngine.UI;

public class AddressEditorPopupUI
{
	public UIDataBinder m_Host;

	public InputField m_UIInputField_Name;

	public InputField m_UIInputField_Phone;

	public InputField m_UIInputField_Address;

	public Button m_SaveBtn;

	public UIToggleButton m_DefaultAddressToggle;

	private int m_Id;

	private int m_Type;

	protected CommonDataCollection m_args = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		ExchangeAddressUtility.TryRefreshAddress(delegate
		{
			m_args = args;
			m_Type = args["type"];
			m_Id = args["id"];
			if (m_Type.Equals(0))
			{
				m_UIInputField_Name.text = "";
				m_UIInputField_Phone.text = "";
				m_UIInputField_Address.text = "";
				m_DefaultAddressToggle.Toggle(on: true);
				AddressList.Inst.m_AddressDropdown[0].value = 0;
				AddressList.Inst.SetCurrentProvince();
			}
			else if (m_Type.Equals(1))
			{
				m_UIInputField_Name.text = args["playerName"];
				m_UIInputField_Phone.text = args["phone"];
				AddressList.Inst.InitProvinceIndex(args["address1"]);
				AddressList.Inst.InitCityIndex(args["address2"]);
				AddressList.Inst.InitZoneIndex(args["address3"]);
				m_UIInputField_Address.text = args["address4"];
				m_DefaultAddressToggle.Toggle(m_Id == ExchangeAddressUtility.CacheAddress.defaultId);
			}
			m_Host.EventProxy(m_SaveBtn, "OnClickSaveBtn");
		});
	}

	public void OnClickSaveBtn()
	{
		switch (CheckInfo())
		{
		case 0:
			EditAddress();
			break;
		case 1:
			UILobby.Current.ShowTips(Localization.ErrorPhone);
			break;
		case 2:
			UILobby.Current.ShowTips(Localization.ErrorAddress);
			break;
		case 3:
			UILobby.Current.ShowTips(Localization.ErrorEmptyName);
			break;
		}
	}

	private bool HasNoChangeChange()
	{
		if (m_UIInputField_Name.text.Equals(m_args["playerName"]) && m_UIInputField_Phone.text.Equals(m_args["phone"]) && m_UIInputField_Address.text.Equals(m_args["address4"]) && AddressList.Inst.CurrentProvince.Equals(m_args["address1"]) && AddressList.Inst.CurrentCity.Equals(m_args["address2"]) && AddressList.Inst.CurrentZone.Equals(m_args["address3"]) && ((m_DefaultAddressToggle.m_IsOn && ExchangeAddressUtility.CacheAddress.defaultId == m_Id) || (!m_DefaultAddressToggle.m_IsOn && ExchangeAddressUtility.CacheAddress.defaultId != m_Id)))
		{
			return true;
		}
		return false;
	}

	public int CheckInfo()
	{
		if (!IsHandset(m_UIInputField_Phone.text))
		{
			return 1;
		}
		if (m_UIInputField_Address.text.Length < 6)
		{
			return 2;
		}
		if (m_UIInputField_Name.text.Length <= 0)
		{
			return 3;
		}
		return 0;
	}

	public static bool IsHandset(string str_handset)
	{
		return Regex.IsMatch(str_handset, "^1[3456789]\\d{9}$");
	}

	private void EditAddress()
	{
		int id = 0;
		if (m_Id == -1)
		{
			m_Id = 0;
			id = 0;
		}
		else if (m_Type.Equals(0))
		{
			id = 0;
			if (ExchangeAddressUtility.CacheAddress.addressInfo.Length.Equals(0) || !HasDefaultAddress())
			{
				m_DefaultAddressToggle.Toggle(on: true);
			}
		}
		else if (m_Type.Equals(1))
		{
			id = m_Id;
		}
		if (HasNoChangeChange())
		{
			UILobby.Current.GoBack();
		}
		else
		{
			ExchangeAddressUtility.EditAddress(id, m_UIInputField_Name.text, m_UIInputField_Phone.text, AddressList.Inst.CurrentProvince, AddressList.Inst.CurrentCity, AddressList.Inst.CurrentZone, m_UIInputField_Address.text, m_DefaultAddressToggle.m_IsOn, delegate
			{
				UILobby.Current.ShowTips(Localization.SetAddressSuccess);
				UIDataEvents.Inst.InvokeEvent("OnSelectAddressEvent");
				UILobby.Current.GoBack();
			});
		}
	}

	private bool HasDefaultAddress()
	{
		AddressInfo[] addressInfo = ExchangeAddressUtility.CacheAddress.addressInfo;
		for (int i = 0; i < addressInfo.Length; i++)
		{
			if (addressInfo[i].id.Equals(ExchangeAddressUtility.CacheAddress.defaultId))
			{
				return true;
			}
		}
		return false;
	}
}
