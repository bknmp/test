using LightUI;
using LightUtility;

internal class CollectionPage_CardSkin
{
	public UIDataBinder m_Host;

	public UITabPage m_TabPage;

	private CommonDataCollection m_Args;

	public void Bind(CommonDataCollection args)
	{
		m_Args = args;
		OnTabChange();
		SetTabButtons();
		m_Host.EventProxy(m_TabPage, "OnTabChange");
	}

	public void SetTabButtons()
	{
		bool active = false;
		foreach (DropItem item in LocalResources.DropItemTable.FindAll((DropItem x) => x.Type == DropItemType.CardStyle))
		{
			int typeParam = item.TypeParam;
			CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(typeParam);
			if (cardStyleInfo != null && (cardStyleInfo.SellStartTime == 0 || cardStyleInfo.SellStartTime <= UtcTimeStamp.Now) && (cardStyleInfo.SellEndTime == 0 || cardStyleInfo.SellEndTime >= UtcTimeStamp.Now))
			{
				active = true;
				break;
			}
		}
		m_TabPage.m_Buttons[1].gameObject.SetActive(active);
	}

	public void OnTabChange()
	{
		m_TabPage.m_Buttons[m_TabPage.GetSelectedTabIndex()].m_TabContent.GetComponent<UIDataBinder>().Args = m_Args;
	}
}
