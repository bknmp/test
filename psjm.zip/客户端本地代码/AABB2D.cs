using UnityEngine;

namespace LightUtility
{
	public struct AABB2D
	{
		public Vector2 Min;

		public Vector2 Max;

		public bool IsValid => (Max - Min).All();

		public Vector2 size => Max - Min;

		public Vector2 extents => (Max - Min) * 0.5f;

		public Vector2 center => (Max + Min) * 0.5f;

		public void Clear()
		{
			Min = Vector2.one * float.MaxValue;
			Max = Vector2.one * float.MinValue;
		}

		public void Encapsulate(Vector2 pt)
		{
			Min = Vector2.Min(pt, Min);
			Max = Vector2.Max(pt, Max);
		}

		public bool Contains(Vector2 pt)
		{
			if (Min.x <= pt.x && Min.y <= pt.y && pt.x <= Max.x)
			{
				return pt.y <= Max.y;
			}
			return false;
		}

		public bool Intersect(Bounds bounds)
		{
			Vector2 b = bounds.extents;
			Vector2 vector = Min - b;
			Vector2 vector2 = Max + b;
			Vector3 center = bounds.center;
			if (vector.x <= center.x && vector.y <= center.y && center.x <= vector2.x)
			{
				return center.y <= vector2.y;
			}
			return false;
		}

		public bool Intersect(AABB2D bounds)
		{
			Vector2 extents = bounds.extents;
			Vector2 vector = Min - extents;
			Vector2 vector2 = Max + extents;
			Vector2 center = bounds.center;
			if (vector.x <= center.x && vector.y <= center.y && center.x <= vector2.x)
			{
				return center.y <= vector2.y;
			}
			return false;
		}

		public void Enlarge(float extent)
		{
			Enlarge(Vector2.one * extent);
		}

		public void Enlarge(Vector2 extent)
		{
			Min -= extent;
			Max += extent;
		}

		public static implicit operator Bounds(AABB2D aabb)
		{
			Vector2 v = (aabb.Min + aabb.Max) * 0.5f;
			return new Bounds(size: aabb.Max - aabb.Min, center: v);
		}
	}
}
