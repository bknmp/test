using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;

public class BindFriendsUtility
{
	public static BindFriendsInfo MyBindFriendsInfo;

	public static List<BindFriendsReview> BindFriendsReviews = new List<BindFriendsReview>();

	public static string ShareText = "";

	public static bool NewFriendReviews;

	public static bool FriendPointsAdd;

	private static int[] defaultArray = new int[5];

	public static bool HadRedpoint()
	{
		if (LocalPlayerDatabase.PrivatePlayerInfo.bindFriendRedPoint == 2)
		{
			NewFriendReviews = true;
			LocalPlayerDatabase.PrivatePlayerInfo.bindFriendRedPoint = 0;
		}
		if (NewFriendReviews)
		{
			return true;
		}
		if (BindFriendsReviews == null || BindFriendsReviews.Count <= 0)
		{
			return false;
		}
		return BindFriendsReviews[0].reviewState == 0;
	}

	public static bool HadFriendPointAdd()
	{
		if (LocalPlayerDatabase.PrivatePlayerInfo.bindFriendRedPoint == 1)
		{
			FriendPointsAdd = true;
			LocalPlayerDatabase.PrivatePlayerInfo.bindFriendRedPoint = 0;
		}
		return FriendPointsAdd;
	}

	public static void ClearFriendAdd()
	{
		MyBindFriendsInfo.typePointsAdd = defaultArray;
	}

	public static void TryShowPointAdd()
	{
		if (HadFriendPointAdd())
		{
			UILobby.Current.Popup("FriendPointAddPopUp");
			FriendPointsAdd = false;
		}
	}

	public static void RefreshMyBindFriendsInfo(bool clearPointAdd = false, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestBindFriendsInfo httpRequestBindFriendsInfo = new HttpRequestBindFriendsInfo();
		httpRequestBindFriendsInfo.clearAdd = clearPointAdd;
		GameHttpManager.Inst.Send(httpRequestBindFriendsInfo, delegate(HttpResponseBindFriendsInfo response)
		{
			MyBindFriendsInfo = response.bindFriendsInfo;
			if (!string.IsNullOrEmpty(response.shareText))
			{
				ShareText = response.shareText;
			}
		}, onSuccess);
	}

	public static void ApplyBindFriend(uint playerID, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestApplyBindFriends httpRequestApplyBindFriends = new HttpRequestApplyBindFriends();
		httpRequestApplyBindFriends.playerID = playerID;
		GameHttpManager.Inst.Send(httpRequestApplyBindFriends, null, onSuccess);
	}

	public static void RefreshBindFriendsReviews(Delegates.VoidCallback onSuccess = null)
	{
		UnityEngine.Debug.Log("RequestBindFriendsReviews");
		GameHttpManager.Inst.Send(new HttpRequestBindFriendsReviews(), delegate(HttpResponseBindFriendsReviews response)
		{
			BindFriendsReviews.Clear();
			for (int i = 0; i < response.roleID.Length; i++)
			{
				BindFriendsReview item = new BindFriendsReview
				{
					roleID = response.roleID[i],
					status = response.status[i],
					time = response.time[i],
					reviewState = response.reviewState[i]
				};
				BindFriendsReviews.Add(item);
			}
			BindFriendsReviews.Sort(delegate(BindFriendsReview left, BindFriendsReview right)
			{
				if (left.reviewState != right.reviewState)
				{
					if (left.reviewState <= right.reviewState)
					{
						return -1;
					}
					return 1;
				}
				return (left.time != right.time) ? ((left.time >= right.time) ? (-1) : 1) : 0;
			});
			if (onSuccess != null)
			{
				onSuccess();
			}
		});
	}

	public static GameAsyncCallback SetReviewStatus(uint playerID, int status, Action<HttpResponseBindFriendsReviewsStatus> onResponse = null, Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		HttpRequestBindFriendsReviewsStatus httpRequestBindFriendsReviewsStatus = new HttpRequestBindFriendsReviewsStatus();
		httpRequestBindFriendsReviewsStatus.playerID = playerID;
		httpRequestBindFriendsReviewsStatus.status = status;
		return GameHttpManager.Inst.Send(httpRequestBindFriendsReviewsStatus, delegate(HttpResponseBindFriendsReviewsStatus res)
		{
			if (onResponse != null)
			{
				onResponse(res);
			}
		}, onSuccess, onFailure);
	}
}
