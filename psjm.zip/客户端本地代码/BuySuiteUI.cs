using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class BuySuiteUI : BuyUI
{
	public static bool[] ItemSelected;

	public static bool Reset;

	public UIDataBinder m_Host;

	public UITemplateInitiator m_TicketTemplateInitiator;

	public Button m_ButtonBuy;

	public UITemplateInitiator m_DiamondTemplateInitiator;

	public GameObject m_TicketButton;

	public GameObject m_DiamondButton;

	public UITabPage m_Page;

	public CommonRewardPopupUI m_StoreRewardPopupUI;

	public UITemplateInitiator m_ItemTemplateInitiator;

	public Text m_SuiteName;

	public GameObject m_EmptyTips;

	public UIDataBinder m_DiscountTips;

	public GameObject m_ExpAdd;

	private List<int> m_SuiteIDs;

	private bool m_IsFromRecommendPage;

	private bool m_IsHotAndNew;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_ButtonBuy, "OnClickBuy");
		m_Host.EventProxy(m_Page, "ChangeCurrency");
		args["buyUI"].val = this;
		m_SuiteIDs = (args["suiteIDs"].val as List<int>);
		if (args["IsFromRecommend"] != null && (bool)args["IsFromRecommend"])
		{
			m_IsFromRecommendPage = true;
			if (args["IsHotAndNew"] != null && (bool)args["IsHotAndNew"])
			{
				m_IsHotAndNew = true;
			}
		}
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(m_SuiteIDs[0]);
		int[] selectedShopItemIDs = ShopSuiteUtility.GetSelectedShopItemIDs(shopSuiteInfo.ShopItemIDs);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < shopSuiteInfo.ShopItemIDs.Length; i++)
		{
			commonDataCollection[i]["id"] = LocalResources.ShopTable.Get(shopSuiteInfo.ShopItemIDs[i]).DropItemID;
			commonDataCollection[i]["idx"] = i;
		}
		m_ItemTemplateInitiator.Args = commonDataCollection;
		m_SuiteName.text = shopSuiteInfo.Name;
		m_EmptyTips.SetActive(selectedShopItemIDs.Length == 0);
		m_ButtonBuy.gameObject.SetActive(selectedShopItemIDs.Length != 0);
		m_ExpAdd.SetActive(selectedShopItemIDs.Length != 0);
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		CommonDataCollection commonDataCollection3 = new CommonDataCollection();
		for (int j = 0; j < m_SuiteIDs.Count; j++)
		{
			shopSuiteInfo = LocalResources.ShopSuiteTable.Get(m_SuiteIDs[j]);
			selectedShopItemIDs = ShopSuiteUtility.GetSelectedShopItemIDs(shopSuiteInfo.ShopItemIDs);
			if (selectedShopItemIDs.Length == 0)
			{
				break;
			}
			ShopInfo shopInfo = LocalResources.ShopTable.Get(selectedShopItemIDs[0]);
			ShopSuiteUtility.SuitePrice suitePrice = ShopSuiteUtility.CalculateSuitePrice(selectedShopItemIDs);
			if (suitePrice.CostTicket != 0)
			{
				int arraySize = commonDataCollection2.ArraySize;
				commonDataCollection2[arraySize]["id"] = shopInfo.Id;
				commonDataCollection2[arraySize]["currency"] = 4;
				commonDataCollection2[arraySize]["price"] = suitePrice.CostTicket;
				commonDataCollection2[arraySize]["index"] = arraySize;
				commonDataCollection2[arraySize]["amount"] = 1;
				commonDataCollection2[arraySize]["exp"] = suitePrice.ExpValue;
				commonDataCollection2[arraySize]["ItemNameIsTime"] = true;
				commonDataCollection2[arraySize]["BuyGoodsUI"].val = this;
			}
			if (suitePrice.CostDiamond != 0)
			{
				int arraySize2 = commonDataCollection3.ArraySize;
				commonDataCollection3[arraySize2]["id"] = shopInfo.Id;
				commonDataCollection3[arraySize2]["currency"] = 2;
				commonDataCollection3[arraySize2]["price"] = suitePrice.CostDiamond;
				commonDataCollection3[arraySize2]["index"] = arraySize2;
				commonDataCollection3[arraySize2]["amount"] = 1;
				commonDataCollection3[arraySize2]["exp"] = suitePrice.ExpValue;
				commonDataCollection3[arraySize2]["ItemNameIsTime"] = true;
				commonDataCollection3[arraySize2]["BuyGoodsUI"].val = this;
			}
		}
		if (Reset)
		{
			base.GlobalSelectID = -1;
			m_globalIndex = 0;
			if (args.ContainsKey("defaultSelectIdx"))
			{
				m_globalIndex = args["defaultSelectIdx"];
				if (m_globalIndex == -1)
				{
					m_globalIndex = Mathf.Max(commonDataCollection3.ArraySize, commonDataCollection2.ArraySize) - 1;
				}
			}
		}
		m_TicketButton.SetActive(commonDataCollection2.ArraySize > 0);
		m_DiamondButton.SetActive(commonDataCollection3.ArraySize > 0);
		m_TicketTemplateInitiator.Args = commonDataCollection2;
		m_DiamondTemplateInitiator.Args = commonDataCollection3;
		m_DiscountTips.Args = args;
		if (Reset)
		{
			for (int k = 0; k < m_Page.m_Buttons.Count; k++)
			{
				if (m_Page.m_Buttons[k].IsActive())
				{
					m_Page.SetSelectedTabIndex(k);
					break;
				}
			}
		}
		Reset = false;
	}

	public void OnClickBuy()
	{
		if (m_globalSelectID > 0)
		{
			int id = m_SuiteIDs[m_globalIndex];
			ShopSuiteInfo suiteInfo = LocalResources.ShopSuiteTable.Get(id);
			ShopSuiteUtility.SuitePrice suitePrice = ShopSuiteUtility.CalculateSuitePrice(ShopSuiteUtility.GetSelectedShopItemIDs(suiteInfo.ShopItemIDs));
			int price = 0;
			if (m_selectedType == CurrencyType.Diamonds)
			{
				price = suitePrice.CostDiamond;
			}
			else if (m_selectedType == CurrencyType.Tickets)
			{
				price = suitePrice.CostTicket;
			}
			DropItem dropItem = LocalResources.DropItemTable.Find((DropItem x) => x.Type == DropItemType.SkinSuite && x.TypeParam == suiteInfo.Id);
			ShopUtility.CheckMoneyEnough(m_selectedType, price, Buy, dropItem.Id);
		}
	}

	private void Buy()
	{
		int suiteID = m_SuiteIDs[m_globalIndex];
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suiteID);
		int[] shopItemIDs = ShopSuiteUtility.GetSelectedShopItemIDs(shopSuiteInfo.ShopItemIDs);
		HttpRequestSuiteBuyItem httpRequestSuiteBuyItem = new HttpRequestSuiteBuyItem();
		httpRequestSuiteBuyItem.type = m_selectedType;
		httpRequestSuiteBuyItem.itemIDs = shopItemIDs;
		GameHttpManager.Inst.Send(httpRequestSuiteBuyItem, delegate
		{
			m_Host.GetComponent<UIPopup>().GoBack();
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_StoreRewardPopupUI);
			int[] array = shopItemIDs;
			foreach (int id in array)
			{
				commonRewardPopupUI.AddItem(LocalResources.ShopTable.Get(id).DropItemID, 1);
				commonRewardPopupUI.SetTitleAndTips(null, null);
			}
			if (m_IsFromRecommendPage)
			{
				LocalPlayerDatabase.ReportClickEvent(m_IsHotAndNew ? ClickEventParam.POPULAR_SUIT_SUCCESS_CLICK : ClickEventParam.RECOMM_SUIT_SUCCESS_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString(), suiteID.ToString());
			}
		});
	}

	public void ChangeCurrency()
	{
		m_globalSelectID = -1;
		foreach (UIDataBinder item in m_TicketTemplateInitiator.Items)
		{
			item.UpdateBinding();
		}
		foreach (UIDataBinder item2 in m_DiamondTemplateInitiator.Items)
		{
			item2.UpdateBinding();
		}
	}
}
