using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AccountSetPwdSuccessUI : MonoBehaviour
{
	public AccountInfoController m_Account;

	public Text m_Platform;

	public Text m_Pwd;

	public Button m_ScreenShot;

	public Button m_Close;

	private Delegates.VoidCallback OnCloseUI;

	private void Awake()
	{
		m_Platform.text = LoginManager.PlatformInfo.ChannelName;
		m_ScreenShot.onClick.AddListener(SaveScreenShot);
		m_Close.onClick.AddListener(CloseUI);
	}

	private void Init(int accountNum, string accountName, string pwd, Delegates.VoidCallback onCloseUI)
	{
		m_Account.SetAccountInfo(accountNum, accountName);
		m_Pwd.text = pwd;
		OnCloseUI = onCloseUI;
	}

	private void SaveScreenShot()
	{
		ScreenShot.Init.SaveScreenShot("DmmAccount_" + UtcTimeStamp.Now, 5f);
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
		OnCloseUI?.Invoke();
	}

	public static void ShowUI(int accountNum, string accountName, string pwd, Delegates.VoidCallback onCloseUI)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountSetPwdSuccessUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountSetPwdSuccessUI>().Init(accountNum, accountName, pwd, onCloseUI);
	}
}
