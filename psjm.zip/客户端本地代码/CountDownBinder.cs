using LightUI;
using LightUtility;
using System;
using UnityEngine.UI;

internal class CountDownBinder
{
	public UIDataBinder m_Host;

	public Text m_CountDown;

	private string m_CountDownFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_CountDownFormat))
		{
			m_CountDownFormat = m_CountDown.text;
		}
		int num = (int)args["time"].val;
		if (num <= 0)
		{
			return;
		}
		int num2 = num - UtcTimeStamp.Now;
		if (num2 > 0)
		{
			if (args.ContainsKey("isTimeShort2"))
			{
				m_CountDown.text = string.Format(m_CountDownFormat, UITimeText.GetFormatTimeShort2(num2, withAgo: false));
			}
			else
			{
				m_CountDown.text = string.Format(m_CountDownFormat, UITimeText.GetFormatTimeShort(num2, withAgo: false));
			}
			return;
		}
		Action action = args["finishCallBack"].val as Action;
		if (action != null)
		{
			action();
			args["finishCallBack"].val = null;
			action = null;
		}
	}
}
