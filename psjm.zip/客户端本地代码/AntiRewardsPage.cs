using LightUI;
using UnityEngine;

internal class AntiRewardsPage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_RewardsInitiator;

	public GameObject m_HadClaim;

	public void Bind(CommonDataCollection args)
	{
		if (m_HadClaim != null)
		{
			m_HadClaim.SetActive(AntiAddictionUtility.Verified);
		}
		CommonDataCollection wrapAntiRewardArgs = AntiAddictionUtility.WrapAntiRewardArgs;
		m_RewardsInitiator.gameObject.SetActive(wrapAntiRewardArgs.ArraySize > 0);
		m_RewardsInitiator.Args = wrapAntiRewardArgs;
	}
}
