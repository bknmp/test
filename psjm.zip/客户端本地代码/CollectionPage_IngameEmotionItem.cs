using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_IngameEmotionItem
{
	public UIDataBinder m_Host;

	public Text m_Personality;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_Selected;

	public Text m_NameText;

	public Button m_Button;

	public GameObject m_NotCollected;

	public GameObject m_NotHaveTips;

	public GameObject m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeason;

	public static int Selected;

	private CollectionPage_IngameEmotionPage page;

	private IngameEmotionInfo m_info;

	private bool m_own;

	public void Bind(CommonDataCollection args)
	{
		DropItem dropItem = args["dropItem"].val as DropItem;
		m_info = LocalResources.IngameEmotionInfo.Get(dropItem.TypeParam);
		m_own = args["own"];
		page = (args["page"].val as CollectionPage_IngameEmotionPage);
		if (m_own)
		{
			m_Personality.text = dropItem.Personality.ToString();
			m_Personality.gameObject.SetActive(value: true);
			m_NotCollected.gameObject.SetActive(value: false);
		}
		else
		{
			m_Personality.gameObject.SetActive(value: false);
			m_NotCollected.gameObject.SetActive(value: true);
		}
		m_QualityBG.State = dropItem.Quality;
		m_Effect.State = dropItem.Quality;
		m_Effect.gameObject.SetActive(m_own);
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		if (Selected == 0)
		{
			Selected = m_info.Id;
			Show();
		}
		int limitedEdition = m_info.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		UpdateSelectState();
		m_Host.EventProxy(m_Button, "OnClick");
	}

	private void Show()
	{
		page.Preview(m_info);
		m_NameText.text = m_info.Name;
		m_NotHaveTips.gameObject.SetActive(!m_own);
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_info.Id == Selected;
			m_Selected.SetActive(active);
		}
	}

	public void OnClick()
	{
		if (Selected != m_info.Id)
		{
			Selected = m_info.Id;
			Show();
			UIDataEvents.Inst.InvokeEvent("OnIngameEmotionSelectedChange");
		}
	}
}
