using LightUI;
using UnityEngine.UI;

internal class DonateCardSummaryUI_Item
{
	public UIDataBinder m_Host;

	public Text m_Text;

	private string m_Format;

	public void Bind(CommonDataCollection args)
	{
		if (m_Format == null)
		{
			m_Format = m_Text.text;
		}
		m_Text.text = string.Format(m_Format, args["name"], args["count"]);
	}
}
