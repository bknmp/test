using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class ChangeBoxSprite : MonoBehaviour
{
	public Image m_Icon;

	public Image m_Lid;

	public int m_FrameCount = 4;

	private Sprite[] m_Seq;

	private string[] m_SeqNameEnds;

	private void LateUpdate()
	{
		ReplaceSprite();
	}

	private void ReplaceSprite()
	{
		if (m_Seq != null)
		{
			ReplaceSprite(m_Icon, 0, 1);
			ReplaceSprite(m_Lid, 2, 3);
		}
	}

	private void ReplaceSprite(Image image, int startFrame, int endFrame)
	{
		int num = startFrame;
		while (true)
		{
			if (num <= endFrame)
			{
				if (image.sprite != null && image.sprite.name.EndsWith(m_SeqNameEnds[num]))
				{
					break;
				}
				num++;
				continue;
			}
			return;
		}
		image.sprite = m_Seq[num];
	}

	public void SetBoxId(int boxID)
	{
		string icon = LocalResources.BoxTable.Get(boxID).Icon;
		m_Seq = new Sprite[m_FrameCount];
		m_SeqNameEnds = new string[m_FrameCount];
		for (int i = 0; i < m_FrameCount; i++)
		{
			m_Seq[i] = SpriteSource.Inst.Find(icon + "_" + i);
			m_SeqNameEnds[i] = "_" + i;
		}
	}
}
