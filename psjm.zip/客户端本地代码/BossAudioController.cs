using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class BossAudioController : PlayerAudioController
{
	private SkillLauncher m_SkillLauncher;

	private SkillLauncher SkillLauncher
	{
		get
		{
			if (m_SkillLauncher == null && base.GetPlayerController != null)
			{
				m_SkillLauncher = base.GetPlayerController.GetComponent<SkillLauncher>();
			}
			return m_SkillLauncher;
		}
	}

	public void PlayHit()
	{
		if (SkillLauncher != null)
		{
			SkillLauncher.OnHitSkill();
		}
	}

	public override void PlayJump()
	{
		base.PlayJump();
		if (SkillLauncher != null)
		{
			SkillLauncher.PlayJump();
		}
	}

	public void PlayJet(int type)
	{
		if (SkillLauncher != null)
		{
			SkillLauncher.PlayJet(type);
		}
	}
}
