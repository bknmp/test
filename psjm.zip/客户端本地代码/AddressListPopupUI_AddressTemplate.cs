using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AddressListPopupUI_AddressTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Text m_Phone;

	public Text m_Address;

	public Button m_EditAddressBtn;

	public UIStateItem m_SelectedAddressState;

	public UIPopup m_AddressEditorPopupUI;

	public Button m_SelectBtn;

	public GameObject m_DefaultTag;

	public Button m_DeleteBtn;

	private int m_Id = -1;

	private int m_Type = -1;

	private string m_Address1;

	private string m_Address2;

	private string m_Address3;

	private string m_Address4;

	protected CommonDataCollection m_args = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		m_Id = -1;
		m_Type = -1;
		m_Id = args["id"];
		m_Type = args["type"];
		m_Name.text = args["playerName"];
		m_Phone.text = args["phone"];
		m_Address1 = args["address1"];
		m_Address2 = args["address2"];
		m_Address3 = args["address3"];
		m_Address4 = args["address4"];
		m_Address.text = m_Address1 + m_Address2 + m_Address3 + m_Address4;
		m_SelectedAddressState.gameObject.SetActive(m_Type != 0);
		m_SelectBtn.gameObject.SetActive(m_Type != 0);
		RefreshSelectState();
		m_Host.EventProxy(m_EditAddressBtn, "OnClickEditAddress");
		m_Host.EventProxy(m_SelectBtn, "OnClickSelectAddress");
		m_Host.EventProxy(m_DeleteBtn, "OnClickDeleteBtn");
	}

	public void OnClickSelectAddress()
	{
		ExchangeAddressUtility.CurrentSelectedId = m_Id;
		UIDataEvents.Inst.InvokeEvent("OnSelectAddressEvent");
	}

	public void OnClickEditAddress()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["type"] = 1;
		commonDataCollection["id"] = m_Id;
		commonDataCollection["playerName"] = m_Name.text;
		commonDataCollection["phone"] = m_Phone.text;
		commonDataCollection["address1"] = m_Address1;
		commonDataCollection["address2"] = m_Address2;
		commonDataCollection["address3"] = m_Address3;
		commonDataCollection["address4"] = m_Address4;
		UILobby.Current.ShowUI(m_AddressEditorPopupUI, commonDataCollection);
	}

	public void RefreshSelectState()
	{
		if (m_Type == 0)
		{
			m_DefaultTag.SetActive(m_Id.Equals(ExchangeAddressUtility.CacheAddress.defaultId));
			return;
		}
		m_DefaultTag.SetActive(value: false);
		m_SelectedAddressState.State = ((m_Id == ExchangeAddressUtility.CurrentSelectedId) ? 1 : 0);
	}

	public void OnClickDeleteBtn()
	{
		UILobby.Current.ShowMessageBoxYesNo(Localization.DeleteAddressTips, Localization.Yes, Localization.No, Localization.MsgBoxTitle, delegate
		{
			ExchangeAddressUtility.DeleteAddress(m_Id);
		}, null);
	}
}
