using GameMessages;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class CharacterFreeBar : MonoBehaviour
{
	public GameObject m_Root;

	public Text m_Time;

	private string m_TimeFormat;

	private void OnEnable()
	{
		SetActivityBar();
	}

	private void SetActivityBar()
	{
		Activity characterFreeActivity = CharacterFreeUtility.CharacterFreeActivity;
		m_Root.SetActive(characterFreeActivity != null);
		if (m_Root.activeSelf)
		{
			if (m_TimeFormat == null)
			{
				m_TimeFormat = m_Time.text;
			}
			DateTime date = UtcTimeStamp.GetDate(characterFreeActivity.startTime);
			DateTime date2 = UtcTimeStamp.GetDate(characterFreeActivity.endTime);
			m_Time.text = string.Format(m_TimeFormat, date.Month, date.Day, date2.Month, date2.Day);
		}
	}
}
