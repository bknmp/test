using LightUtility;

public class CheatingReasonInfo : IdBased
{
	public string Reason;

	public string Tips;
}
