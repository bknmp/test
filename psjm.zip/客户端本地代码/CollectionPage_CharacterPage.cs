using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CollectionPage_CharacterPage
{
	public UIDataBinder m_Host;

	public RawImage m_ThiefPreviewPort;

	public RawImage m_PolicePreviewPort;

	public RankShow m_RankShow;

	public Text m_PersonalityText;

	public Text m_CharacterText;

	public Text m_SkinPartText;

	public Text m_CardSkinText;

	public UIPointerBehaviour m_ThiefInput;

	public UIPointerBehaviour m_PoliceInput;

	public Text m_HeadBubbleBoxText;

	public Text m_IngameEmotionText;

	public Text m_ThiefCharacterName;

	public Text m_ThiefLevel;

	public Text m_PoliceCharacterName;

	public Text m_PoliceLevel;

	public Text m_LightnessText;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	private string m_CharacterFormat;

	private string m_SkinPartFormat;

	private string m_CardSkinFormat;

	private string m_HeadBubbleBoxFormat;

	private string m_LevelFormat;

	private string m_LightnessFormat;

	public void Bind(CommonDataCollection args)
	{
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		if (m_CharacterFormat == null || m_SkinPartFormat == null || m_CardSkinFormat == null || m_LevelFormat == null)
		{
			m_CharacterFormat = m_CharacterText.text;
			m_SkinPartFormat = m_SkinPartText.text;
			m_CardSkinFormat = m_CardSkinText.text;
			m_HeadBubbleBoxFormat = m_HeadBubbleBoxText.text;
			m_LevelFormat = m_ThiefLevel.text;
			m_LightnessFormat = m_LightnessText.text;
		}
		m_RankShow.SetRank(m_PlayerInfo.personalityRank);
		m_PersonalityText.text = m_PlayerInfo.personality.ToString();
		m_CharacterText.text = string.Format(m_CharacterFormat, CollectionUtility.GetForeverCharacterCount(m_PlayerInfo), CollectionUtility.GetAllCharacterCount());
		m_SkinPartText.text = string.Format(m_SkinPartFormat, CollectionUtility.GetForeverSkinPartCount(m_PlayerInfo), CollectionUtility.GetAllSkinPartCount());
		m_CardSkinText.text = string.Format(m_CardSkinFormat, CollectionUtility.GetForeverCardSkinAndStyleCount(m_PlayerInfo), CollectionUtility.GetAllCardSkinAndStyleCount());
		m_HeadBubbleBoxText.text = string.Format(m_HeadBubbleBoxFormat, CollectionUtility.GetForeverHeadBubbleBoxCount(m_PlayerInfo), CollectionUtility.GetAllHeadBubbleBoxCount());
		m_IngameEmotionText.text = string.Format(m_HeadBubbleBoxFormat, CollectionUtility.GetForeverIngameEmotionCount(m_PlayerInfo), LocalResources.IngameEmotionInfo.Count);
		m_LightnessText.text = string.Format(m_LightnessFormat, CollectionUtility.GetForeverLightnessCount(m_PlayerInfo), LocalResources.LightnessInfo.Count - 1);
		PreviewRole(RoleType.Police);
		PreviewRole(RoleType.Thief);
	}

	private void PreviewRole(RoleType roleType)
	{
		PlayerCharacterInfo activeCharacter = CharacterUtility.GetActiveCharacter(roleType, m_PlayerInfo);
		RawImage target = (roleType == RoleType.Police) ? m_PolicePreviewPort : m_ThiefPreviewPort;
		UIPointerBehaviour intputPointer = (roleType == RoleType.Police) ? m_PoliceInput : m_ThiefInput;
		Text text = (roleType == RoleType.Police) ? m_PoliceCharacterName : m_ThiefCharacterName;
		Text obj = (roleType == RoleType.Police) ? m_PoliceLevel : m_ThiefLevel;
		text.text = LocalResources.CharacterTable.Get(activeCharacter.characterID).Name;
		obj.text = string.Format(m_LevelFormat, activeCharacter.ExpLevel);
		MatchPlayerData matchPlayerData = null;
		matchPlayerData = ((m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID) ? CharacterUtility.GetPlayerData(m_PlayerID, activeCharacter.characterID, m_PlayerInfo, m_PlayerCardConfigs) : CharacterUtility.GetPlayerData(activeCharacter.characterID));
		if (matchPlayerData != null)
		{
			LobbyScene.Inst.UpdateCampPanel(roleType, m_PlayerInfo.publicInfo.name, activeCharacter, matchPlayerData, target, notRTMethod: false, intputPointer, closeOppositeRole: false, disableChangePartAnim: true);
		}
	}
}
