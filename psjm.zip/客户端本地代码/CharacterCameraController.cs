using UnityEngine;

public class CharacterCameraController : MonoBehaviour
{
	private enum State
	{
		Idle,
		LobbyEntrance
	}

	public Animator m_Animator;

	private State m_State;

	private void Awake()
	{
		StartIdle();
	}

	public void StartLobbyEntrance()
	{
		if (m_State != State.LobbyEntrance)
		{
			m_Animator.SetTrigger("lobbyEntrance");
			m_State = State.LobbyEntrance;
		}
	}

	public void StartIdle()
	{
		if (m_State != 0)
		{
			m_Animator.SetTrigger("idle");
			m_State = State.Idle;
		}
	}
}
