using DG.Tweening;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.Events;

public class ChatPanel : MonoBehaviour
{
	public RectTransform m_Panel;

	public UITabPage m_TabPage;

	public GameObject m_NewMessageRedPoint;

	public GameObject m_TeamButton;

	public GameObject m_ChatChannelUIPrefab;

	public GameObject m_BackgroundButton;

	public AudioItem m_ShowSound;

	public AudioItem m_HideSound;

	public UIPopup m_SetBubbleBoxUI;

	public GameObject m_EmojiPanel;

	private ChatChannelUI m_ChatChannelUIInst;

	private bool m_Showed;

	public static UIDataBinder m_ChatUIInst;

	[HideInInspector]
	public bool ReloadChatMessages;

	public bool IsShowed => m_Showed;

	public bool IsFriendChatShowed
	{
		get
		{
			if (m_ChatUIInst != null)
			{
				return m_ChatUIInst.gameObject.activeSelf;
			}
			return false;
		}
	}

	public bool IsPublicChatShowed => m_TabPage.GetSelectedTabIndex() == 0;

	public uint CurrentChatRoleID
	{
		get
		{
			return ChatPageFriends_ItemTemplate.Selected;
		}
		set
		{
			ChatPageFriends_ItemTemplate.Selected = value;
		}
	}

	private void Awake()
	{
		m_Panel.anchoredPosition = new Vector2(0f - m_Panel.rect.width, m_Panel.anchoredPosition.y);
	}

	private void Start()
	{
		UILobby current = UILobby.Current;
		current.OnGoToPage = (UnityAction<UIPage>)Delegate.Combine(current.OnGoToPage, new UnityAction<UIPage>(OnGoToPage));
		UILobby current2 = UILobby.Current;
		current2.OnGoBack = (UnityAction<UILobbyElement>)Delegate.Combine(current2.OnGoBack, new UnityAction<UILobbyElement>(OnGoBack));
		UIDataEvents.Inst.AddEventListener("OnFriendChatEvent", this, UpdateNewMessageRedPoint);
		UIDataEvents.Inst.AddEventListener("OnFriendChatReadChanged", this, UpdateNewMessageRedPoint);
		UIDataEvents.Inst.AddEventListener("OnDeleteFriendEvent", this, HideChatUI);
		UpdateNewMessageRedPoint();
		OnTabChanged();
		m_TabPage.OnTabChanged.RemoveAllListeners();
		m_TabPage.OnTabChanged.AddListener(OnTabChanged);
	}

	private void OnDestroy()
	{
		if (UILobby.Current != null)
		{
			UILobby current = UILobby.Current;
			current.OnGoToPage = (UnityAction<UIPage>)Delegate.Remove(current.OnGoToPage, new UnityAction<UIPage>(OnGoToPage));
			UILobby current2 = UILobby.Current;
			current2.OnGoBack = (UnityAction<UILobbyElement>)Delegate.Remove(current2.OnGoBack, new UnityAction<UILobbyElement>(OnGoBack));
		}
	}

	private void SetVignette(bool active)
	{
		if (LobbyScene.Inst != null)
		{
			LobbyScene.Inst.m_Vignette.SetActive(active);
		}
	}

	public void OnTabChanged()
	{
		int selectedTabIndex = m_TabPage.GetSelectedTabIndex();
		if (selectedTabIndex != -1)
		{
			GameObject tabContent = m_TabPage.m_Buttons[selectedTabIndex].m_TabContent;
			if (tabContent != null)
			{
				ChatTabPageAnchor component = tabContent.GetComponent<ChatTabPageAnchor>();
				component.Initialize();
				if (component.m_UpdateChanged)
				{
					component.UpdateBinding();
				}
			}
			if (selectedTabIndex == 0)
			{
				ReloadChatChannelUI();
			}
		}
		HideEmojiPanel();
	}

	private void UpdateNewMessageRedPoint()
	{
		m_NewMessageRedPoint.SetActive(SocialChatManager.CheckAnyUnreadMessage());
	}

	private void OnGoToPage(UIPage page)
	{
		if (page.GetComponent<MySpacePanel>() == null && IsShowed)
		{
			Hide();
		}
	}

	private void OnGoBack(UILobbyElement ui)
	{
		if (ui is UIPage && ui.GetComponent<MySpacePanel>() == null && IsShowed)
		{
			Hide();
		}
		if (m_Showed && PublicChatManager.Inst != null)
		{
			PublicChatManager.Inst.TryRefreshChatInfo();
		}
	}

	public void Show(int tabIndex = -1, bool immediately = false)
	{
		m_TeamButton.SetActive(TeamRoomUI.IsShowing);
		if (!m_Showed)
		{
			SoundManager.PlayOnce(m_ShowSound);
			base.gameObject.SetActive(value: true);
			m_BackgroundButton.SetActive(value: true);
			SetVignette(active: false);
			if (!immediately)
			{
				m_Panel.DOKill();
				m_Panel.DOAnchorPosX(0f, 0.2f);
			}
			else
			{
				m_Panel.anchoredPosition = new Vector2(0f, m_Panel.anchoredPosition.y);
			}
			UpdateNewMessageRedPoint();
		}
		if (tabIndex != -1)
		{
			HideChatUI();
			ReloadChatChannelUI();
			m_TabPage.SetSelectedTabIndex(tabIndex);
		}
		if (PublicChatManager.Inst != null)
		{
			PublicChatManager.Inst.TryRefreshChatInfo();
		}
		m_Showed = true;
		UIDataEvents.Inst.InvokeEvent("OnChatPanelChanged");
		LobbyScene.Inst.SocialPanel.Hide();
		HideEmojiPanel();
	}

	public void Hide(bool immediately = false)
	{
		if (m_Showed)
		{
			SoundManager.PlayOnce(m_HideSound);
			m_Showed = false;
			if (!immediately)
			{
				m_Panel.DOKill();
				m_Panel.DOAnchorPosX(0f - m_Panel.rect.width, 0.2f).OnComplete(delegate
				{
					base.gameObject.SetActive(value: false);
				});
			}
			else
			{
				m_Panel.anchoredPosition = new Vector2(0f - m_Panel.rect.width, m_Panel.anchoredPosition.y);
				base.gameObject.SetActive(value: false);
			}
			m_BackgroundButton.SetActive(value: false);
			SetVignette(active: true);
			UIDataEvents.Inst.InvokeEvent("OnChatPanelChanged");
			HideEmojiPanel();
		}
	}

	public void ShowChatUI(uint roleID)
	{
		Show(1);
		CurrentChatRoleID = roleID;
	}

	public void HideChatUI()
	{
		if (IsFriendChatShowed)
		{
			CurrentChatRoleID = 0u;
			m_ChatUIInst.gameObject.SetActive(value: false);
			m_ChatUIInst = null;
		}
	}

	public void ReloadChatUI()
	{
		ReloadChatMessages = true;
		UIDataEvents.Inst.InvokeEvent("OnFriendChatEvent");
	}

	public void ShowChatChannelUI()
	{
		if (m_ChatChannelUIInst == null)
		{
			m_ChatChannelUIInst = UnityEngine.Object.Instantiate(m_ChatChannelUIPrefab, UILobby.Current.m_PopupContainer).GetComponent<ChatChannelUI>();
		}
		m_ChatChannelUIInst.Show();
	}

	public void HideChatChannelUI()
	{
		if (m_ChatChannelUIInst != null)
		{
			m_ChatChannelUIInst.Hide();
		}
	}

	public void ReloadChatChannelUI()
	{
		ChatPagePublic.m_LastChannelID = 0;
	}

	public void SetBubbleBoxUI()
	{
		if (m_SetBubbleBoxUI != null)
		{
			UILobby.Current.Popup(m_SetBubbleBoxUI);
		}
	}

	public void ToggleEmojiPanel()
	{
		m_EmojiPanel.SetActive(!m_EmojiPanel.activeSelf);
	}

	public void HideEmojiPanel()
	{
		m_EmojiPanel.SetActive(value: false);
	}
}
