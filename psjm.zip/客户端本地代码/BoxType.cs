public enum BoxType
{
	Newbie,
	DailyTask
}
