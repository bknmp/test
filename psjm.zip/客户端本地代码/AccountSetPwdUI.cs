using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AccountSetPwdUI : MonoBehaviour
{
	public AccountInfoController m_AccountInfo;

	public InputField m_Pwd;

	public UIStateItem m_PwdTips;

	public InputField m_RepeatPwd;

	public GameObject m_RepeatTips;

	public Button m_OkBtn;

	public Button m_CloseBtn;

	public UIStateItem m_ButtonState;

	private bool m_PwdConform;

	private int m_AccountNum;

	private string m_AccountName;

	private string m_MailCodeKey;

	private string m_RecoverCode;

	private Delegates.IntCallback m_SetPwdCallback;

	private void Awake()
	{
		m_OkBtn.onClick.AddListener(OnOkButtonClick);
		m_CloseBtn.onClick.AddListener(CloseUI);
		m_Pwd.onValueChanged.AddListener(OnPwdValueChang);
		m_RepeatPwd.onValueChanged.AddListener(OnRepeatPwdValueChang);
	}

	private void Init(int accountNum, string accountName, string mailCodeKey, string recoverCode, Delegates.IntCallback callback)
	{
		m_AccountNum = accountNum;
		m_AccountName = accountName;
		m_MailCodeKey = mailCodeKey;
		m_RecoverCode = recoverCode;
		m_SetPwdCallback = callback;
		m_AccountInfo.SetAccountInfo(accountNum, accountName);
		m_PwdConform = false;
		m_Pwd.text = "";
		m_RepeatPwd.text = "";
		m_RepeatTips.SetActive(value: false);
		m_PwdTips.State = 0;
		m_ButtonState.State = 0;
	}

	private void OnPwdValueChang(string input)
	{
		m_Pwd.text = AccountUtility.PwdRemoveForbidWord(input);
		m_PwdTips.State = CheckPwdFormat();
		m_RepeatTips.SetActive(!CheckRepeatSame());
		SetButtonState();
	}

	private void OnRepeatPwdValueChang(string input)
	{
		m_RepeatPwd.text = AccountUtility.PwdRemoveForbidWord(input);
		m_RepeatTips.SetActive(!CheckRepeatSame());
		SetButtonState();
	}

	private void OnOkButtonClick()
	{
		AccountUtility.ChangeAccountPwd((uint)m_AccountNum, m_Pwd.text, m_MailCodeKey, m_RecoverCode, delegate
		{
			CloseUI();
			AccountUtility.OnChangeRedPoint?.Invoke();
			AccountSetPwdSuccessUI.ShowUI(m_AccountNum, m_AccountName, m_Pwd.text, delegate
			{
				m_SetPwdCallback?.Invoke(m_AccountNum);
			});
		});
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	private int CheckPwdFormat()
	{
		string text = m_Pwd.text;
		m_PwdConform = false;
		if (text.Length < 6)
		{
			return 1;
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		char[] array = text.ToCharArray();
		for (int i = 0; i < array.Length; i++)
		{
			if (char.IsDigit(array[i]))
			{
				num = 1;
			}
			else if (char.IsLetter(array[i]))
			{
				num2 = 1;
			}
			else
			{
				num3 = 1;
			}
			num4 = num2 + num + num3;
			if (num4 >= 2)
			{
				break;
			}
		}
		if (num4 < 2)
		{
			return 2;
		}
		if (num4 == 2)
		{
			m_PwdConform = true;
			return 3;
		}
		m_PwdConform = true;
		return 4;
	}

	private bool CheckRepeatSame()
	{
		if (m_PwdConform && !string.IsNullOrEmpty(m_RepeatPwd.text) && !m_Pwd.text.Equals(m_RepeatPwd.text))
		{
			return false;
		}
		return true;
	}

	private void SetButtonState()
	{
		m_ButtonState.State = ((m_PwdConform && m_Pwd.text.Equals(m_RepeatPwd.text)) ? 1 : 0);
	}

	public static void ShowUI(int accountNum, string accountName, string mailCodeKey = "", string recoverCode = "", Delegates.IntCallback onSuccess = null)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountSetPwdUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountSetPwdUI>().Init(accountNum, accountName, mailCodeKey, recoverCode, onSuccess);
	}
}
