using UnityEngine;

public class AutomateTestManager : MonoBehaviour
{
	private static AutomateTestManager Inst;
}
