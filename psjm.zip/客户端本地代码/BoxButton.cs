using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class BoxButton
{
	public UIDataBinder m_Host;

	public UIStateItem m_BoxTips;

	public Text m_Time;

	public Text m_Text;

	public Button m_BoxButton;

	private Coroutine m_Coroutine;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_BoxButton, "OnClick");
		if (BoxUtility.HaveBoxCanOpen())
		{
			m_BoxTips.gameObject.SetActive(value: true);
			m_BoxTips.State = 0;
		}
		else if (BoxUtility.HaveBoxCanBeUnlocked())
		{
			m_BoxTips.gameObject.SetActive(value: true);
			m_BoxTips.State = 0;
		}
		else if (BoxUtility.HaveBoxUnlocking() > 0)
		{
			m_BoxTips.gameObject.SetActive(value: true);
			m_BoxTips.State = 1;
			int remainTime = BoxUtility.HaveBoxUnlocking();
			if (m_Coroutine != null)
			{
				m_Host.StopCoroutine(m_Coroutine);
			}
			m_Coroutine = m_Host.StartCoroutine(BoxUtility.UpdateBoxShortTime(remainTime, m_Time, delegate
			{
				m_BoxTips.gameObject.SetActive(value: true);
				m_BoxTips.State = 0;
				if (m_Text != null)
				{
					m_Text.gameObject.SetActive(value: true);
				}
			}));
		}
		else
		{
			m_BoxTips.gameObject.SetActive(value: false);
		}
		if (m_Text != null)
		{
			m_Text.gameObject.SetActive(!m_BoxTips.gameObject.activeSelf || m_BoxTips.State != 1);
		}
	}

	public void OnClick()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.BoxUI);
		AntiAddictionUtility.TryShowVerifyGuide(VerifyGuideTrigger.BoxButton);
	}
}
