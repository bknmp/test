using DG.Tweening;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonObject : MonoBehaviour
{
	public Transform m_Rotate;

	public float m_Duration = 0.5f;

	public float m_Interval = 2f;

	public float m_LaunchDistance = 8f;

	public float m_LaunchDuration = 1.5f;

	public float m_Gravity = 20f;

	public AudioClip m_Audio;

	private TiledBlock m_TiledBlock;

	private float m_StateTime;

	private AudioSource m_AudioSource;

	public static List<CannonObject> AllCannonObjects = new List<CannonObject>();

	private void Awake()
	{
		m_TiledBlock = GetComponent<TiledBlock>();
		m_AudioSource = GetComponent<AudioSource>();
		AllCannonObjects.Add(this);
	}

	private void OnDestroy()
	{
		AllCannonObjects.Remove(this);
	}

	private void Update()
	{
		if (PhotonNetwork.isMasterClient && InGameScene.Inst.LocalGameTime - m_StateTime > m_Interval)
		{
			m_StateTime = InGameScene.Inst.LocalGameTime;
			RpcSyncState(((int)(m_Rotate.localEulerAngles.y / 90f) + 1) * 90);
		}
	}

	private void RpcSyncState(float angle)
	{
		InGameScene.Inst.m_PhotonView.RPC("SyncCannonState", PhotonTargets.AllViaServer, m_TiledBlock.x, m_TiledBlock.y, angle);
	}

	public void SyncState(float angle)
	{
		Rotate(angle);
	}

	private void RpcLaunch(string userID, Vector3 dir, int localNum)
	{
		InGameScene.Inst.m_PhotonView.RPC("SyncLaunch", PhotonTargets.All, m_TiledBlock.x, m_TiledBlock.y, userID, dir, localNum);
	}

	public void SyncLaunch(string userID, Vector3 dir, int localNum)
	{
		PlayerController playerController = PlayerController.FindPlayer(userID);
		if (localNum == 1 && playerController.PuppetPlayer != null)
		{
			playerController = playerController.PuppetPlayer;
		}
		StartLaunching(playerController, dir);
		m_AudioSource.PlayOneShot(m_Audio);
	}

	public static void CheckOnCannon(PlayerController player)
	{
		if (player.OnVehichle != null || player.OnHookJoint || player.WaterEscaping)
		{
			return;
		}
		Vector3 position = player.PhysicsBody.position;
		if (!InGameScene.Inst.IsCannon(position) || !player.IsMine || player.Launching || position.y >= 0.5f)
		{
			return;
		}
		CannonObject runtimeTileInstance = InGameScene.Inst.GetRuntimeTileInstance<CannonObject>(position);
		if (runtimeTileInstance != null)
		{
			Vector3 forward = runtimeTileInstance.m_Rotate.forward;
			runtimeTileInstance.RpcLaunch(player.UserId, forward, player.LocalNum);
			GameTaskUtility.UpdateEvent(EventHow.Hit, 1, null, player, EventObject.Cannon);
			if (player.Shifter.IsVehicle || player.Shifter.IsSkateBoard)
			{
				foreach (PlayerController allPlayersAndPuppet in PlayerController.AllPlayersAndPuppets)
				{
					if (allPlayersAndPuppet.OnVehichle != null && allPlayersAndPuppet.OnVehichle.viewID == player.m_PhotonView.viewID)
					{
						runtimeTileInstance.RpcLaunch(allPlayersAndPuppet.UserId, forward, allPlayersAndPuppet.LocalNum);
						GameTaskUtility.UpdateEvent(EventHow.Hit, 1, null, allPlayersAndPuppet, EventObject.Cannon);
					}
				}
			}
		}
	}

	private void StartLaunching(PlayerController player, Vector3 dir)
	{
		GameUtility.CheckGroundHeight(base.transform.position + dir * m_LaunchDistance, base.transform.forward, out float groundHeight);
		Vector3 position = player.PhysicsBody.position;
		float speedH = m_LaunchDistance / m_LaunchDuration;
		float speedV = 0.5f * m_Gravity * m_LaunchDuration - position.y;
		StartCoroutine(Launching(player, speedH, speedV, dir, groundHeight));
	}

	private IEnumerator Launching(PlayerController player, float speedH, float speedV, Vector3 dir, float groundHeight)
	{
		SetPlayerLaunching(launching: true, player);
		float launchTime = 0f;
		float startLaunchTime = InGameScene.Inst.LocalGameTime;
		while (player.Launching && launchTime <= m_LaunchDuration)
		{
			speedV -= Time.deltaTime * m_Gravity;
			Vector3 a = dir * speedH + Vector3.up * speedV;
			Vector3 vector = player.PhysicsBody.position;
			vector += Time.deltaTime * a;
			player.m_PhysicsBody.position = vector;
			player.m_PhotonTransformView.Warp(vector);
			launchTime = InGameScene.Inst.LocalGameTime - startLaunchTime;
			if (launchTime >= 0.5f * m_LaunchDuration && vector.y <= groundHeight)
			{
				vector.y = groundHeight;
				player.Launching = false;
			}
			yield return null;
		}
		SetPlayerLaunching(launching: false, player);
	}

	private void Rotate(float angle)
	{
		Vector3 endValue = m_Rotate.localEulerAngles.FlattenY(angle);
		m_Rotate.DOKill();
		m_Rotate.DOLocalRotate(endValue, m_Duration, RotateMode.FastBeyond360).SetEase(Ease.Linear);
	}

	private static void SetPlayerLaunching(bool launching, PlayerController player)
	{
		player.PhysicsBody.rigidbody.useGravity = !launching;
		player.Launching = launching;
	}
}
