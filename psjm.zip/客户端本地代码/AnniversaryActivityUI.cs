public class AnniversaryActivityUI : ActivityCollectionPageBase
{
	private int GetActivityIndex(ActivityType type)
	{
		int result = -1;
		for (int i = 0; i < m_ActivityList.Count; i++)
		{
			if (LocalResources.ActivityLobbyInfos.Get(m_ActivityList[i].activityId).Type == type)
			{
				result = i;
				break;
			}
		}
		return result;
	}

	private int GetActivityIndex(int activityID)
	{
		int result = -1;
		for (int i = 0; i < m_ActivityList.Count; i++)
		{
			if (activityID == m_ActivityList[i].activityId)
			{
				result = i;
				break;
			}
		}
		return result;
	}

	public void JumpTabByActivityID(int activityID)
	{
		int activityIndex = GetActivityIndex(activityID);
		JumpTabByIndex(activityIndex);
	}

	public void JumpTabByActivityType(ActivityType type)
	{
		int activityIndex = GetActivityIndex(type);
		JumpTabByIndex(activityIndex);
	}

	public void JumpTabByIndex(int index)
	{
		if (index != -1)
		{
			if (m_DataTabPage.TabPage.m_Buttons.Count > index)
			{
				m_DataTabPage.TabPage.SetSelectedTabIndex(index);
			}
			else
			{
				m_JumpIndex = index;
			}
		}
	}
}
