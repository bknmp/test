using LightUI;
using UnityEngine;

internal class CharacterUI_RedPoint
{
	public UIDataBinder m_Host;

	public GameObject m_SkinPartRedPoint;

	public GameObject m_RedPointHead;

	public GameObject m_RedPointHand;

	public GameObject m_RedPointClothes;

	public GameObject m_RedPointTrouser;

	public GameObject m_RedPointShoe;

	public GameObject m_RedPointSuite;

	public GameObject m_RedPointSkinGroup;

	public GameObject m_TalentRedPoint;

	public GameObject m_SelectCharacterRedPoint;

	public UITabButton m_SelectCharacter;

	public UITabButton m_Talent;

	public GameObject m_LightRedPoint;

	public GameObject m_IngameEmotionRedPoint;

	public GameObject m_DecalRedPoint;

	public GameObject m_AnimationRedPoint;

	public void Bind(CommonDataCollection args)
	{
		int globalSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		if (m_SkinPartRedPoint != null)
		{
			m_SkinPartRedPoint.SetActive(NewSkinPartTips.Inst.CharacterHaveNewSkinPart(globalSelected));
			GameObject[] array = new GameObject[7]
			{
				m_RedPointHead,
				m_RedPointHand,
				m_RedPointClothes,
				m_RedPointTrouser,
				m_RedPointShoe,
				m_RedPointSuite,
				m_RedPointSkinGroup
			};
			for (int i = 0; i <= 6; i++)
			{
				if (i == 5)
				{
					array[i].SetActive(NewSkinPartTips.Inst.HaveNewSuite(globalSelected));
				}
				else
				{
					array[i].SetActive(NewSkinPartTips.Inst.CharacterAndTypeHaveNew(globalSelected, (SkinPartType)i));
				}
			}
		}
		if (m_TalentRedPoint != null)
		{
			if (!m_Talent.m_IsSelected)
			{
				CharacterInfo characterInfo = LocalResources.CharacterTable.Get(globalSelected);
				m_TalentRedPoint.SetActive(TalentUtility.HasTalentCanUpgrade(CharacterUtility.GetOwnedCharacterInfo(globalSelected), characterInfo));
			}
			else
			{
				m_TalentRedPoint.SetActive(value: false);
			}
		}
		if (m_SelectCharacterRedPoint != null)
		{
			bool active = false;
			if (!m_SelectCharacter.m_IsSelected)
			{
				foreach (CharacterInfo item in LocalResources.CharacterTable)
				{
					if (item.Id != globalSelected && item.IsVisibleInUI && (TalentUtility.HasTalentCanUpgrade(CharacterUtility.GetOwnedCharacterInfo(item.Id), item) || NewSkinPartTips.Inst.CharacterHaveNewSkinPart(item.Id) || NewIngameEmotionTips.Inst.CharaterHaveNewIngameEmotionData(item.Id, excludeDecal: true)))
					{
						active = true;
						break;
					}
				}
			}
			m_SelectCharacterRedPoint.SetActive(active);
		}
		if (m_IngameEmotionRedPoint != null)
		{
			m_IngameEmotionRedPoint.SetActive(NewIngameEmotionTips.Inst.CharaterHaveNewIngameEmotionData(globalSelected));
			m_DecalRedPoint.SetActive(NewIngameEmotionTips.Inst.CharacterAndTypeHaveNew(globalSelected, 0));
			m_AnimationRedPoint.SetActive(NewIngameEmotionTips.Inst.CharacterAndTypeHaveNew(globalSelected, 1));
		}
		if (m_LightRedPoint != null)
		{
			m_LightRedPoint.SetActive(NewLightnessTips.Inst.HaveNew());
		}
	}
}
