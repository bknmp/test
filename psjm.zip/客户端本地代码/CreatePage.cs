using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine.UI;

internal class CreatePage
{
	public enum Type
	{
		None,
		Diamond,
		Ticket
	}

	public UIDataBinder m_Host;

	public InputField m_NameInputField;

	public InputField m_NoticeInputField;

	public Toggle m_ReviewToggle;

	public UnionBadgeItem m_Badge;

	public CycleSelector m_IconSelector;

	public CycleSelector m_FrameSelector;

	public CycleSelector m_FlagSelector;

	public Text m_DiamondPrice;

	public Text m_TicketPrice;

	public Text m_DiamondMemberNum;

	public Text m_TicketMemberNum;

	public Button m_CreateButton;

	public UIPopup m_CreateTipsUI;

	public UIStateItem m_Btns;

	public Text m_UnlockTips;

	public Slider m_GradeSlider;

	public Text m_GradeName;

	public ToggleGroup m_CreateToggleGroup;

	public Toggle m_DiamondToggle;

	public Toggle m_TicketToggle;

	private int m_IconID;

	private int m_FrameID;

	private int m_FlagID;

	private string m_DiamondPriceFormat;

	private string m_TicketPriceFormat;

	private string m_UnlockTipsFormat;

	public void Bind(CommonDataCollection args)
	{
		m_NameInputField.GetComponent<SensitiveWordFilter>().SetMaxInputCount(6);
		m_NameInputField.placeholder.GetComponent<Text>().text = string.Format(Localization.TipsMaxInputCount, 6);
		m_NoticeInputField.GetComponent<SensitiveWordFilter>().SetMaxInputCount(80);
		m_NoticeInputField.placeholder.GetComponent<Text>().text = string.Format(Localization.TipsMaxInputCount, 80);
		if (m_DiamondPriceFormat == null)
		{
			m_DiamondPriceFormat = m_DiamondPrice.text;
		}
		if (m_TicketPriceFormat == null)
		{
			m_TicketPriceFormat = m_TicketPrice.text;
		}
		if (m_UnlockTipsFormat == null)
		{
			m_UnlockTipsFormat = m_UnlockTips.text;
		}
		m_DiamondPrice.text = string.Format(m_DiamondPriceFormat, UnionUtility.Settings.createCostDiamond);
		m_TicketPrice.text = string.Format(m_TicketPriceFormat, UnionUtility.Settings.createCostTicket);
		m_DiamondMemberNum.text = string.Format(m_DiamondMemberNum.text, 30);
		m_TicketMemberNum.text = string.Format(m_TicketMemberNum.text, 20);
		m_DiamondToggle.isOn = true;
		if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < UnionUtility.Settings.createUnlockGrade)
		{
			GradeMappingInfo mapping;
			GradeInfo gradeInfo = LocalResources.GetGradeInfo(UnionUtility.Settings.createUnlockGrade, out mapping);
			m_UnlockTips.text = string.Format(m_UnlockTipsFormat, gradeInfo.Name);
			m_Btns.State = 1;
		}
		else
		{
			m_Btns.State = 0;
		}
		InitSelectors();
		m_Host.EventProxy(m_CreateButton, "OnCreateClicked");
		m_IconSelector.OnPageChanged.AddListener(UpdateBadge);
		m_FrameSelector.OnPageChanged.AddListener(UpdateBadge);
		m_FlagSelector.OnPageChanged.AddListener(UpdateBadge);
		int gradeId = LocalResources.GetGradeMapping(UnionUtility.Settings.openUnlockGrade).GradeId;
		int id = LocalResources.GradeTable.Last.Id;
		m_GradeSlider.onValueChanged.RemoveAllListeners();
		m_GradeSlider.onValueChanged.AddListener(OnGradeLimitChanged);
		m_GradeSlider.minValue = gradeId;
		m_GradeSlider.maxValue = id;
		m_GradeSlider.value = gradeId;
		OnGradeLimitChanged(gradeId);
	}

	private void OnGradeLimitChanged(float grade)
	{
		int id = (int)grade;
		m_GradeName.text = LocalResources.GradeTable.Get(id).Name;
	}

	private void InitSelectors()
	{
		List<UnionBadgeInfo> unionBadgesByType = LocalResources.GetUnionBadgesByType(UnionBadgeType.Icon);
		m_IconSelector.SetIndex(0, unionBadgesByType.Count);
		List<UnionBadgeInfo> unionBadgesByType2 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Frame);
		m_FrameSelector.SetIndex(0, unionBadgesByType2.Count);
		List<UnionBadgeInfo> unionBadgesByType3 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Flag);
		m_FlagSelector.SetIndex(0, unionBadgesByType3.Count);
		UpdateBadge();
	}

	private void UpdateBadge()
	{
		UnionBadgeInfo unionBadgeInfo = LocalResources.GetUnionBadgesByType(UnionBadgeType.Icon)[m_IconSelector.Index];
		UnionBadgeInfo unionBadgeInfo2 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Frame)[m_FrameSelector.Index];
		UnionBadgeInfo unionBadgeInfo3 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Flag)[m_FlagSelector.Index];
		m_IconSelector.UpdateText(unionBadgeInfo.Name);
		m_FrameSelector.UpdateText(unionBadgeInfo2.Name);
		m_FlagSelector.UpdateText(unionBadgeInfo3.Name);
		m_IconID = unionBadgeInfo.Id;
		m_FrameID = unionBadgeInfo2.Id;
		m_FlagID = unionBadgeInfo3.Id;
		m_Badge.SetBadge(m_IconID, m_FrameID, m_FlagID);
	}

	public void OnCreateClicked()
	{
		if (string.IsNullOrEmpty(m_NameInputField.text.Trim()))
		{
			UILobby.Current.ShowTips(Localization.CreateUnionEmptyName);
		}
		else if (m_DiamondToggle.isOn)
		{
			ShopUtility.CheckMoneyEnough(CurrencyType.Diamonds, UnionUtility.Settings.createCostDiamond, CreateUnion);
		}
		else if (m_TicketToggle.isOn)
		{
			ShopUtility.CheckMoneyEnough(CurrencyType.Tickets, UnionUtility.Settings.createCostTicket, CreateUnion, -137, currentUIGoBack: false);
		}
	}

	private void CreateUnion()
	{
		string text = m_NameInputField.text.Trim();
		if (GameSettings.Inst.ValidateName(text))
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["unionName"] = text;
			commonDataCollection["notice"] = m_NoticeInputField.text.Trim();
			commonDataCollection["iconID"] = m_IconID;
			commonDataCollection["frameID"] = m_FrameID;
			commonDataCollection["flagID"] = m_FlagID;
			commonDataCollection["review"] = (m_ReviewToggle.isOn ? 1 : 0);
			commonDataCollection["type"] = 0;
			commonDataCollection["type"] = 0;
			if (m_DiamondToggle.isOn)
			{
				commonDataCollection["type"] = 1;
			}
			if (m_TicketToggle.isOn)
			{
				commonDataCollection["type"] = 2;
			}
			int gradeID = (int)m_GradeSlider.value;
			GradeMappingInfo gradeMappingInfo = LocalResources.GradeMappingTable.Find((GradeMappingInfo a) => a.GradeId == gradeID);
			commonDataCollection["grade"] = gradeMappingInfo.Id;
			UILobby.Current.ShowUI(m_CreateTipsUI, commonDataCollection);
		}
	}
}
