using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CommentUI : UIEventListener
{
	public RawImage m_RawImage;

	public UIPointerBehaviour m_Input;

	private Dictionary<int, bool> m_likeData = new Dictionary<int, bool>();

	private Dictionary<string, float> m_PublishCommentTime;

	private int m_type;

	private int m_id;

	private void OnEnable()
	{
		if (m_RawImage.texture == null && m_type > 0 && m_id > 0)
		{
			ShowPreview();
		}
	}

	private void ShowPreview()
	{
		if (m_type == 1)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_id);
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID);
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, cardSkinInfo.Prefabs + "_Lobby", m_RawImage, m_Input);
		}
		else if (m_type == 3)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_id);
			PlayerCharacterInfo characterDefaultInfo = CharacterUtility.GetCharacterDefaultInfo(m_id);
			MatchPlayerData playerData = CharacterUtility.GetPlayerData(m_id);
			LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, LocalPlayerDatabase.PlayerInfo.publicInfo.name, characterDefaultInfo, playerData, m_RawImage, notRTMethod: false, m_Input, closeOppositeRole: true);
		}
	}

	private void OnDisable()
	{
		TrySentCommentLikeData();
	}

	public override void OnExitUI()
	{
		m_type = 0;
		m_id = 0;
	}

	public void SetInfo(int type, int id)
	{
		m_type = type;
		m_id = id;
		ShowPreview();
	}

	public void LocalLikeComment(int commmentID, bool like)
	{
		if (!m_likeData.ContainsKey(commmentID))
		{
			m_likeData.Add(commmentID, like);
		}
		else
		{
			m_likeData[commmentID] = like;
		}
	}

	public void TrySentCommentLikeData()
	{
		if (m_likeData.Count > 0)
		{
			List<int> list = new List<int>();
			List<bool> list2 = new List<bool>();
			HttpRequestCommentLike httpRequestCommentLike = new HttpRequestCommentLike();
			httpRequestCommentLike.type = m_type;
			httpRequestCommentLike.param = m_id;
			foreach (KeyValuePair<int, bool> likeDatum in m_likeData)
			{
				list.Add(likeDatum.Key);
				list2.Add(likeDatum.Value);
			}
			httpRequestCommentLike.commentID = list.ToArray();
			httpRequestCommentLike.like = list2.ToArray();
			GameHttpManager.Inst.SendNoWait(httpRequestCommentLike);
			m_likeData.Clear();
		}
	}

	public bool HadLocalLickData(int commmentID, out bool like)
	{
		if (m_likeData.ContainsKey(commmentID))
		{
			like = m_likeData[commmentID];
			return true;
		}
		like = false;
		return false;
	}

	public void OnPublishComment(int type, int id)
	{
		string key = type + "_" + id;
		if (m_PublishCommentTime == null)
		{
			m_PublishCommentTime = new Dictionary<string, float>();
		}
		if (!m_PublishCommentTime.ContainsKey(key))
		{
			m_PublishCommentTime.Add(key, Time.realtimeSinceStartup);
		}
		else
		{
			m_PublishCommentTime[key] = Time.realtimeSinceStartup;
		}
	}

	public float GetLastPublishTime(int type, int id)
	{
		string key = type + "_" + id;
		if (m_PublishCommentTime == null || !m_PublishCommentTime.ContainsKey(key))
		{
			return 0f;
		}
		return m_PublishCommentTime[key];
	}
}
