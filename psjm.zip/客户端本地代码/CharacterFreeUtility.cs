using GameMessages;
using LightUI;
using LightUtility;

public class CharacterFreeUtility
{
	private static bool needActivityEndTips;

	private static Activity m_CharacterFreeActivity;

	private static Activity m_CharacterFreeActivityInMatch;

	public static Activity CharacterFreeActivity
	{
		get
		{
			if (m_CharacterFreeActivity == null || m_CharacterFreeActivity.exchangeEndTime < UtcTimeStamp.Now)
			{
				m_CharacterFreeActivity = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.CHARACTER_FREE_ACTIVITY, ActivityCollectionType.NONE);
			}
			return m_CharacterFreeActivity;
		}
	}

	public static bool IsCharacterFree => CharacterFreeActivity != null;

	public static Activity CharacterFreeActivityInMatch
	{
		get
		{
			if (m_CharacterFreeActivityInMatch == null || (float)m_CharacterFreeActivityInMatch.exchangeEndTime < (float)UtcTimeStamp.Now - 5f)
			{
				m_CharacterFreeActivityInMatch = CharacterFreeActivity;
			}
			return m_CharacterFreeActivityInMatch;
		}
	}

	public static bool IsCharacterFreeInMatch => CharacterFreeActivityInMatch != null;

	public static void JudgeActivityStartOrEnd()
	{
		if (CharacterFreeActivity == null)
		{
			PlayerCharacterInfo activeCharacter = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole);
			if (activeCharacter == null || !CharacterUtility.IsOwnCharacter(activeCharacter.characterID))
			{
				needActivityEndTips = true;
				if (LobbyScene.Inst != null)
				{
					TipsActivityFinished();
				}
			}
		}
		else if (!UtcTimeStamp.IsCrossDay(CharacterFreeActivity.startTime, UtcTimeStamp.Now))
		{
			CardUtility.RequestCardConfigs(force: true);
		}
	}

	public static void TipsActivityFinished()
	{
		if (needActivityEndTips)
		{
			CharacterUtility.SetActiveCharacter((GameRuntime.PlayingRole == RoleType.Thief) ? 200 : 100);
			UILobby.Current.ShowMessageBoxOK(Localization.CharacterFreeEnd, Localization.MsgBoxKnow, Localization.MsgBoxTitle, delegate
			{
				needActivityEndTips = false;
			});
		}
	}
}
