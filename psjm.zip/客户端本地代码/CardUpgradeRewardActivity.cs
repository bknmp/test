using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardUpgradeRewardActivity
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Container;

	public Text m_Time;

	public CardUpgradeRewardActivityUI m_CardUpgradeRewardUI;

	private static bool m_RedPointFlag;

	private static HttpResponseCardUpgradeRewardActivity m_Infos;

	private string m_TimeFormat;

	private const int m_halfPageItemNum = 3;

	public Delegates.ObjectCallback2<int, float> OnScrollViewValueChange;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		Activity activity = args["Activity"].val as Activity;
		m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		LocalPlayerDatabase.SetPrefValue("CardUpgradeRewardActivity", activity.startTime);
		HttpRequestCardUpgradeRewardActivity requset = new HttpRequestCardUpgradeRewardActivity();
		GameHttpManager.Inst.Send(requset, delegate(HttpResponseCardUpgradeRewardActivity OnHttpResponse)
		{
			m_RedPointFlag = false;
			m_Infos = OnHttpResponse;
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < OnHttpResponse.infos.Length; i++)
			{
				commonDataCollection[i]["CardUpgradeRewardInfo"].val = OnHttpResponse.infos[i];
				commonDataCollection[i]["CardUpgradeRewardUI"].val = this;
			}
			OnScrollViewValueChange = null;
			m_Container.Args = commonDataCollection;
			if (m_CardUpgradeRewardUI.FirstEnterUI)
			{
				m_CardUpgradeRewardUI.FirstEnterUI = false;
				m_Container.OnItemsChanged.AddListener(SetDefaultScrollView);
			}
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	private void SetDefaultScrollView()
	{
		int num = -1;
		m_Container.OnItemsChanged.RemoveListener(SetDefaultScrollView);
		CardUpgradeRewardActivityInfo[] infos = m_Infos.infos;
		foreach (CardUpgradeRewardActivityInfo cardUpgradeRewardActivityInfo in infos)
		{
			int num2 = CardUtility.IsOwned(cardUpgradeRewardActivityInfo.cardId) ? CardUtility.GetCardLevel(cardUpgradeRewardActivityInfo.cardId) : 0;
			for (int j = 0; j < num2; j++)
			{
				if (!cardUpgradeRewardActivityInfo.claimed[j] && (j < num || num < 0))
				{
					num = j;
					break;
				}
			}
		}
		int idx = Mathf.Max(num + 1 - 3, 0);
		UIScrollRect componentInChildren = m_Container.GetComponentInChildren<UIScrollRect>();
		if (componentInChildren != null)
		{
			componentInChildren.ScrollToItem(idx, tween: true);
		}
	}

	public static void OnRefreshRedPoint()
	{
		m_RedPointFlag = true;
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	public static bool GetRedPointState()
	{
		if (IsFirstCheck() || m_RedPointFlag)
		{
			return true;
		}
		if (m_Infos == null)
		{
			return false;
		}
		CardUpgradeRewardActivityInfo[] infos = m_Infos.infos;
		foreach (CardUpgradeRewardActivityInfo cardUpgradeRewardActivityInfo in infos)
		{
			int num = CardUtility.IsOwned(cardUpgradeRewardActivityInfo.cardId) ? CardUtility.GetCardLevel(cardUpgradeRewardActivityInfo.cardId) : 0;
			for (int j = 0; j < cardUpgradeRewardActivityInfo.claimed.Length; j++)
			{
				if (!cardUpgradeRewardActivityInfo.claimed[j] && num >= j + 1)
				{
					return true;
				}
			}
		}
		return false;
	}

	private static bool IsFirstCheck()
	{
		if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.activitys == null)
		{
			return false;
		}
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.NEW_CARD_UPGRADE_REWARD, ActivityCollectionType.NEW_CARD_ACTIVITY);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (activityByActivityTypeAndCollectionType.startTime == LocalPlayerDatabase.GetPrefValueInt("CardUpgradeRewardActivity"))
		{
			return false;
		}
		return true;
	}
}
