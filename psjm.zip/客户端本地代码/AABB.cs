using UnityEngine;

namespace LightUtility
{
	public struct AABB
	{
		public Vector3 Min;

		public Vector3 Max;

		public static AABB Infinite
		{
			get
			{
				AABB result = default(AABB);
				result.Min = new Vector3(-1000000f, -1000000f, -1000000f);
				result.Max = new Vector3(1000000f, 1000000f, 1000000f);
				return result;
			}
		}

		public bool IsValid => (Max - Min).All();

		public Vector3 size => Max - Min;

		public Vector3 extents => (Max - Min) * 0.5f;

		public Vector3 center => (Max + Min) * 0.5f;

		public void Clear()
		{
			Min = Vector3.one * float.MaxValue;
			Max = Vector3.one * float.MinValue;
		}

		public void Encapsulate(Vector3 pt)
		{
			Min = Vector3.Min(pt, Min);
			Max = Vector3.Max(pt, Max);
		}

		public bool Contains(Vector3 pt)
		{
			if (Min.x <= pt.x && Min.y <= pt.y && Min.z <= pt.z && pt.x <= Max.x && pt.y <= Max.y)
			{
				return pt.z <= Max.z;
			}
			return false;
		}

		public bool Contains(Vector2 pt)
		{
			if (Min.x <= pt.x && Min.y <= pt.y && pt.x <= Max.x)
			{
				return pt.y <= Max.y;
			}
			return false;
		}

		public bool Intersect(Bounds bounds)
		{
			Vector3 extents = bounds.extents;
			Vector3 vector = Min - extents;
			Vector3 vector2 = Max + extents;
			Vector3 center = bounds.center;
			if (vector.x <= center.x && vector.y <= center.y && vector.z <= center.z && center.x <= vector2.x && center.y <= vector2.y)
			{
				return center.z <= vector2.z;
			}
			return false;
		}

		public bool Intersect(AABB bounds)
		{
			Vector3 extents = bounds.extents;
			Vector3 vector = Min - extents;
			Vector3 vector2 = Max + extents;
			Vector3 center = bounds.center;
			if (vector.x <= center.x && vector.y <= center.y && vector.z <= center.z && center.x <= vector2.x && center.y <= vector2.y)
			{
				return center.z <= vector2.z;
			}
			return false;
		}

		public void Enlarge(float extent)
		{
			Enlarge(Vector3.one * extent);
		}

		public void Enlarge(Vector3 extent)
		{
			Min -= extent;
			Max += extent;
		}

		public static implicit operator Bounds(AABB aabb)
		{
			Vector3 center = (aabb.Min + aabb.Max) * 0.5f;
			Vector3 size = aabb.Max - aabb.Min;
			return new Bounds(center, size);
		}
	}
}
