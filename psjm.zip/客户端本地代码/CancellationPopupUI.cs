using LightUI;
using UnityEngine.UI;

public class CancellationPopupUI
{
	public UIDataBinder m_Host;

	public Button m_NextBtn;

	public UIPopup m_CancellationPopupVerifyUI;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_NextBtn, "OnConfirmBtnClick");
	}

	public void OnConfirmBtnClick()
	{
		UILobby.Current.ShowUI(m_CancellationPopupVerifyUI, null);
	}
}
