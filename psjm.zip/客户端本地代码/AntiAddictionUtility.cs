using GameMessages;
using LightUI;
using LightUtility;
using System;

public static class AntiAddictionUtility
{
	private static bool VerifiedSuccess;

	private static bool HasGuideBinding;

	private static readonly string TriggerCountKey = "VerifyGuideTriggerCount";

	private static readonly string LastTriggerTimeKey = "LastVerifyGuideTime";

	private static int LastTriggerTime;

	public static bool Verified
	{
		get
		{
			if (LocalPlayerDatabase.LoginInfo != null)
			{
				return LocalPlayerDatabase.LoginInfo.audit != 2;
			}
			return false;
		}
	}

	public static bool IsAudlt
	{
		get
		{
			if (LocalPlayerDatabase.LoginInfo != null)
			{
				return LocalPlayerDatabase.LoginInfo.audit == 1;
			}
			return false;
		}
	}

	public static bool CanPlay
	{
		get
		{
			if (TouristSystem.CanPlay)
			{
				return AntiAddictionSystem.CanPlay;
			}
			return false;
		}
	}

	private static int LogicAge
	{
		get
		{
			HttpResponseLogin loginInfo = LocalPlayerDatabase.LoginInfo;
			if (loginInfo != null)
			{
				if (loginInfo.audit == 2)
				{
					return 1;
				}
				return loginInfo.age;
			}
			return 0;
		}
	}

	public static CommonDataCollection WrapAntiRewardArgs
	{
		get
		{
			ItemInfo[] array = LocalPlayerDatabase.Settings.realNameRewards;
			if (array == null)
			{
				array = new ItemInfo[0];
			}
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < array.Length; i++)
			{
				commonDataCollection[i]["dropItemInfo"].val = array[i];
			}
			return commonDataCollection;
		}
	}

	public static CommonDataCollection WrapBindRewardArgs
	{
		get
		{
			ItemInfo[] array = LocalPlayerDatabase.Settings.bindingRewards;
			if (array == null)
			{
				array = new ItemInfo[0];
			}
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < array.Length; i++)
			{
				commonDataCollection[i]["dropItemInfo"].val = array[i];
			}
			return commonDataCollection;
		}
	}

	public static bool VerifyGuideEnable
	{
		get
		{
			if (LocalPlayerDatabase.Settings != null && LocalPlayerDatabase.Settings.verifyGuide != null && LocalPlayerDatabase.Settings.verifyGuide.tdyLimit != 0)
			{
				return !TouristSystem.IsTourist();
			}
			return false;
		}
	}

	private static int TdyTriggerCount
	{
		get
		{
			int prefValueInt = LocalPlayerDatabase.GetPrefValueInt(LastTriggerTimeKey);
			int now = UtcTimeStamp.Now;
			if (UtcTimeStamp.IsCrossDay(prefValueInt, now))
			{
				LocalPlayerDatabase.SetPrefValue(LastTriggerTimeKey, now);
				LocalPlayerDatabase.SetPrefValue(TriggerCountKey, 0);
				return 0;
			}
			return LocalPlayerDatabase.GetPrefValueInt(TriggerCountKey);
		}
		set
		{
			LocalPlayerDatabase.SetPrefValue(TriggerCountKey, value);
			LocalPlayerDatabase.SetPrefValue(LastTriggerTimeKey, UtcTimeStamp.Now);
		}
	}

	public static GameAsyncCallback RequestCertification(string realName, string idNumber, Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		HttpRequestCertification httpRequestCertification = new HttpRequestCertification();
		httpRequestCertification.realName = realName;
		httpRequestCertification.idNumber = idNumber;
		return GameHttpManager.Inst.Send(httpRequestCertification, delegate(HttpResponseCertification res)
		{
			OnCertificationResponse(res, onSuccess, onFailure);
		});
	}

	public static GameAsyncCallback RequestSDKVerified(int audit, int age, Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		if (audit == 2)
		{
			LocalPlayerDatabase.Invoke(onFailure);
			return null;
		}
		if (AndroidSDKAdapter.AndroidChannel == AndroidChannel.MI)
		{
			UILobby.Current.ShowMessageBoxOK(Localization.VerifiedSuccessRelogin, Localization.MsgBoxReLogin, Localization.RealName, delegate
			{
				ResManager.LoadScene("Loading");
			}, showCloseButton: false);
			return null;
		}
		HttpRequestVerified httpRequestVerified = new HttpRequestVerified();
		httpRequestVerified.audit = audit;
		httpRequestVerified.age = age;
		return GameHttpManager.Inst.Send(httpRequestVerified, delegate(HttpResponseCertification res)
		{
			OnCertificationResponse(res, onSuccess, onFailure);
		});
	}

	private static void OnCertificationResponse(HttpResponseCertification response, Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		if (response.audit == 2)
		{
			LocalPlayerDatabase.Invoke(onFailure);
			UILobby.Current.ShowTips(Localization.TipsVerifiedFailure);
			return;
		}
		OnVerifyStatusChanged();
		LocalPlayerDatabase.LoginInfo.audit = response.audit;
		LocalPlayerDatabase.LoginInfo.age = response.age;
		VerifiedSuccess = true;
		if (response.items == null || response.items.Length == 0)
		{
			LocalPlayerDatabase.Invoke(onSuccess);
			LocalPlayerDatabase.OnLoginInfoChanged();
			UILobby.Current.ShowTips(Localization.TipsNameIDSubmited);
		}
		else
		{
			CommonRewardPopupUI result = null;
			using (ResManager.Load("CommonRewardPopupUI", out result))
			{
				CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(result, delegate
				{
					LocalPlayerDatabase.Invoke(onSuccess);
					LocalPlayerDatabase.OnLoginInfoChanged();
				});
				commonRewardPopupUI.AddItems(response.items);
				commonRewardPopupUI.SetTitleAndTips(Localization.TipsNameIDSubmited, null);
			}
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.RECEIVE_REAL_NAME_REWARD);
		}
	}

	public static bool RechargeUnderAgeJudge(float price)
	{
		bool flag = LocalPlayerDatabase.Settings.NoRealNameLimitRecharge && LocalPlayerDatabase.LoginInfo.audit == 2;
		bool flag2 = LocalPlayerDatabase.Settings.RNSUnderAgeRechargeFlag == 1 && LocalPlayerDatabase.LoginInfo.audit != 1;
		if (flag2 | flag)
		{
			int limitAge = 0;
			int index = 0;
			int age = (!flag2 && flag) ? 17 : LogicAge;
			int rechargeLimitInOneMonth = GetRechargeLimitInOneMonth(age, out limitAge, out index);
			int rechargeLimitInOneTime = GetRechargeLimitInOneTime(age, out limitAge, out index);
			float num = LocalPlayerDatabase.PrivatePlayerInfo.rechargeInOneMonth;
			if (price > (float)rechargeLimitInOneTime || price + num > (float)rechargeLimitInOneMonth)
			{
				string text = "";
				text = ((index <= 0) ? string.Format(Localization.TipsUnderAgeRechargeLimit_2, limitAge) : string.Format(Localization.TipsUnderAgeRechargeLimit_1, limitAge, rechargeLimitInOneTime, rechargeLimitInOneMonth, num));
				if (flag2)
				{
					ShowWarningPopup(text, canGoBack: true);
				}
				else
				{
					ShowWarningPopup(Localization.TipsUnderAgeRechargeLimit_3, canGoBack: true);
				}
				return false;
			}
			return true;
		}
		return true;
	}

	public static int GetRechargeLimitInOneTime(int age, out int limitAge, out int index)
	{
		int[] underAgeSegmentNode = LocalPlayerDatabase.Settings.underAgeSegmentNode;
		int[] underAgeRechargeLimitOneTime = LocalPlayerDatabase.Settings.underAgeRechargeLimitOneTime;
		int num = 0;
		for (int i = 0; i < underAgeSegmentNode.Length; i++)
		{
			if (age >= underAgeSegmentNode[i] && age < underAgeSegmentNode[i + 1])
			{
				num = i;
			}
		}
		limitAge = underAgeSegmentNode[num + 1];
		int result = underAgeRechargeLimitOneTime[num];
		index = num;
		return result;
	}

	public static int GetRechargeLimitInOneMonth(int age, out int limitAge, out int index)
	{
		int[] underAgeSegmentNode = LocalPlayerDatabase.Settings.underAgeSegmentNode;
		int[] underAgeRechargeLimitOneMonth = LocalPlayerDatabase.Settings.underAgeRechargeLimitOneMonth;
		int num = 0;
		for (int i = 0; i < underAgeSegmentNode.Length; i++)
		{
			if (age >= underAgeSegmentNode[i] && age < underAgeSegmentNode[i + 1])
			{
				num = i;
			}
		}
		limitAge = underAgeSegmentNode[num + 1];
		int result = underAgeRechargeLimitOneMonth[num];
		index = num;
		return result;
	}

	public static bool IsNameValid(string s)
	{
		for (int i = 0; i < s.Length; i++)
		{
			if (s[i] < '\u0080')
			{
				return false;
			}
		}
		return true;
	}

	public static bool CheckIDCard(string Id, out int age)
	{
		age = 0;
		if (Id.Length == 18)
		{
			return CheckIDCard18(Id, out age);
		}
		if (Id.Length == 15)
		{
			return CheckIDCard15(Id, out age);
		}
		return false;
	}

	public static bool CheckIDCard18(string Id, out int age)
	{
		long result = 0L;
		age = 0;
		if (!long.TryParse(Id.Remove(17), out result) || (double)result < Math.Pow(10.0, 16.0) || !long.TryParse(Id.Replace('x', '0').Replace('X', '0'), out result))
		{
			return false;
		}
		if ("11x22x35x44x53x12x23x36x45x54x13x31x37x46x61x14x32x41x50x62x15x33x42x51x63x21x34x43x52x64x65x71x81x82x91".IndexOf(Id.Remove(2)) == -1)
		{
			return false;
		}
		string s = Id.Substring(6, 8).Insert(6, "-").Insert(4, "-");
		DateTime result2 = default(DateTime);
		if (!DateTime.TryParse(s, out result2))
		{
			return false;
		}
		age = (int)((DateTime.Now - result2).TotalDays / 365.0);
		string[] array = "1,0,x,9,8,7,6,5,4,3,2".Split(',');
		string[] array2 = "7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2".Split(',');
		char[] array3 = Id.Remove(17).ToCharArray();
		int num = 0;
		for (int i = 0; i < 17; i++)
		{
			num += int.Parse(array2[i]) * int.Parse(array3[i].ToString());
		}
		int result3 = -1;
		Math.DivRem(num, 11, out result3);
		if (array[result3] != Id.Substring(17, 1).ToLower())
		{
			return false;
		}
		return true;
	}

	public static bool CheckIDCard15(string Id, out int age)
	{
		long result = 0L;
		age = 0;
		if (!long.TryParse(Id, out result) || (double)result < Math.Pow(10.0, 14.0))
		{
			return false;
		}
		if ("11x22x35x44x53x12x23x36x45x54x13x31x37x46x61x14x32x41x50x62x15x33x42x51x63x21x34x43x52x64x65x71x81x82x91".IndexOf(Id.Remove(2)) == -1)
		{
			return false;
		}
		string s = Id.Substring(6, 6).Insert(4, "-").Insert(2, "-");
		DateTime result2 = default(DateTime);
		if (!DateTime.TryParse(s, out result2))
		{
			return false;
		}
		age = (int)((DateTime.Now - result2).TotalDays / 365.0);
		return true;
	}

	public static string GetAntiAddictionTips()
	{
		string str = "\u3000\u3000";
		float num = 0f / 3600f;
		if (num < 1f)
		{
			return str + (AntiAddictionSystem.Inst.Filled ? Localization.AntiAddictionTipsFilled : Localization.AntiAddictionTipsNotFilled);
		}
		if (num < 3f)
		{
			return str + string.Format(Localization.AntiAddictionTips1, (int)num);
		}
		if ((double)num < 3.5)
		{
			return str + string.Format(Localization.AntiAddictionTips2, (int)num);
		}
		if (num < 4f)
		{
			return str + string.Format(Localization.AntiAddictionTips2, (double)(int)num + 0.5);
		}
		if ((double)num < 4.5)
		{
			return str + string.Format(Localization.AntiAddictionTips2, (int)num);
		}
		if (num < 5f)
		{
			return str + string.Format(Localization.AntiAddictionTips2, (double)(int)num + 0.5);
		}
		return str + string.Format(Localization.AntiAddictionTips3);
	}

	public static string GetProceedsTips()
	{
		string result = "";
		switch (AntiAddictionSystem.Inst.ProceedsPercent)
		{
		case 50:
			result = Localization.AntiAddictionProceedsHalf;
			break;
		case 0:
			result = Localization.AntiAddictionProceedsZero;
			break;
		}
		return result;
	}

	public static string GetProceedsTipsFormat(string text, int proceeds)
	{
		string result = "";
		switch (AntiAddictionSystem.Inst.ProceedsPercent)
		{
		case 100:
			result = $"{text}{proceeds}";
			break;
		case 50:
			result = string.Format(Localization.AntiAddictionProceedsHalfFormat, text, (int)((float)proceeds * 0.5f));
			break;
		case 0:
			result = Localization.AntiAddictionProceedsZeroFormat;
			break;
		}
		return result;
	}

	public static void TryShowVerify(Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		if (LocalPlayerDatabase.Settings.RNSUseSelfSystem == 1 || (TouristSystem.IsTourist(ignoreTreatTouristAsOffice: true) && LocalPlayerDatabase.Settings.treatTouristAsOffice))
		{
			JumpModuleManager.Inst.DoJump(JumpModule.AntiAddictionFillUI).OnCloseOnce = delegate
			{
				if (VerifiedSuccess)
				{
					VerifiedSuccess = false;
					LocalPlayerDatabase.Invoke(onSuccess);
				}
				else
				{
					LocalPlayerDatabase.Invoke(onFailure);
				}
			};
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CALL_REAL_NAME_PAGE);
		}
		else if (LocalPlayerDatabase.Settings.verifiedNeedReLogin == 1)
		{
			UILobby.Current.ShowMessageBoxOK(Localization.AntiAddictionReLoginText, Localization.MsgBoxGoVerified, Localization.RealName, delegate
			{
				ResManager.LoadScene("Loading");
			}, showCloseButton: true, UILobby.Current.GoBack);
		}
		else if (AndroidSDKAdapter.SDKVerified)
		{
			if (!AndroidSDKAdapter.Logined)
			{
				LoginUtility.LoginSDK(delegate(bool success)
				{
					if (success)
					{
						if (LoginManager.FCM != 2)
						{
							RequestSDKVerified(LoginManager.FCM, LoginManager.Age, onSuccess, onFailure);
						}
						else
						{
							AndroidSDKAdapter.Instance.Verified(delegate(int audit, int age)
							{
								RequestSDKVerified(audit, age, onSuccess, onFailure);
							});
						}
					}
					else
					{
						onFailure?.Invoke();
					}
				});
			}
			else
			{
				AndroidSDKAdapter.Instance.Verified(delegate(int audit, int age)
				{
					RequestSDKVerified(audit, age, onSuccess, onFailure);
				});
			}
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CALL_REAL_NAME_PAGE);
		}
	}

	public static bool CanReVerify()
	{
		if (LocalPlayerDatabase.Settings.RNSUseSelfSystem == 1)
		{
			return true;
		}
		return AndroidSDKAdapter.CanReVerify;
	}

	public static void TryStartAntiAddictionOrTouristSystem(GameAsyncSequence sequence = null)
	{
		if (TouristSystem.CanOpen || TouristSystem.BindedAccountCanOpen)
		{
			if (TouristSystem.Inst != null)
			{
				TouristSystem.Inst.TryStart();
				if (sequence != null && TouristSystem.Inst.ShowingPopup)
				{
					GameAsyncCallback cb2 = new GameAsyncCallback();
					UIPopup uIPopup = UILobby.Current.CurrentPopup();
					uIPopup.OnCloseOnce = (Delegates.VoidCallback)Delegate.Combine(uIPopup.OnCloseOnce, (Delegates.VoidCallback)delegate
					{
						cb2.onSuccess();
					});
					sequence.Add(() => cb2);
				}
			}
		}
		else if (AntiAddictionSystem.Inst != null)
		{
			AntiAddictionSystem.Inst.TryStartMonitoring();
			if (sequence != null && AntiAddictionSystem.Inst.ShowingPopup)
			{
				GameAsyncCallback cb = new GameAsyncCallback();
				UIPopup uIPopup2 = UILobby.Current.CurrentPopup();
				uIPopup2.OnCloseOnce = (Delegates.VoidCallback)Delegate.Combine(uIPopup2.OnCloseOnce, (Delegates.VoidCallback)delegate
				{
					cb.onSuccess();
				});
				sequence.Add(() => cb);
			}
		}
	}

	public static void TryClearAntiAddictionOrTouristSystem()
	{
		if (AntiAddictionSystem.Inst != null)
		{
			AntiAddictionSystem.Inst.DestroySelf();
		}
		if (TouristSystem.Inst != null)
		{
			TouristSystem.Inst.DestroySelf();
		}
	}

	public static void ShowWarningPopup(string tips, bool canGoBack, Delegates.ObjectCallback<bool> showPopup = null)
	{
		if (!canGoBack && TeamRoomManager.InTeam && TeamRoomManager.Inst != null)
		{
			TeamRoomManager.Inst.QuitTeamRoom(force: true);
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["message"].val = tips;
		commonDataCollection["IsGobackOrQuit"] = canGoBack;
		UILobby.Current.ShowUI("AntiAddictionMessageBoxUI", commonDataCollection);
		LocalPlayerDatabase.Invoke(showPopup, par: true);
		UIPopup uIPopup = UILobby.Current.CurrentPopup();
		uIPopup.OnCloseOnce = (Delegates.VoidCallback)Delegate.Combine(uIPopup.OnCloseOnce, (Delegates.VoidCallback)delegate
		{
			LocalPlayerDatabase.Invoke(showPopup, par: false);
		});
		LastTriggerTime = UtcTimeStamp.Now;
		if (!canGoBack)
		{
			TimeSpanSender.Inst.ForceSendNotice();
		}
	}

	public static bool CheckCanSendInput(SpeakType type = SpeakType.OtherChat)
	{
		bool flag = true;
		switch (type)
		{
		case SpeakType.OtherChat:
			flag = !LocalPlayerDatabase.Settings.closeRealNameInputLimit;
			break;
		case SpeakType.PublicChat:
			flag = !LocalPlayerDatabase.Settings.closeRNILPublicChat;
			break;
		case SpeakType.InGameChat:
			flag = !LocalPlayerDatabase.Settings.closeRNILInGame;
			break;
		}
		if (!flag)
		{
			return true;
		}
		if (TouristSystem.IsTourist(ignoreTreatTouristAsOffice: true))
		{
			UILobby.Current.ShowTips(Localization.TipsNeedBinding);
			return false;
		}
		if (!Verified)
		{
			UILobby.Current.ShowTips(Localization.TipsNeedCertification);
			return false;
		}
		return true;
	}

	public static void RequestCertificationRewards(Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestCertificationRewards requset = new HttpRequestCertificationRewards();
		GameHttpManager.Inst.Send(requset, delegate(HttpResponseCommonRewards response)
		{
			OnVerifyStatusChanged();
			CommonRewardPopupUI result = null;
			using (ResManager.Load("CommonRewardPopupUI", out result))
			{
				CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(result, delegate
				{
					LocalPlayerDatabase.Invoke(onSuccess);
				});
				commonRewardPopupUI.AddItems(response.items);
				commonRewardPopupUI.SetTitleAndTips(Localization.TipsNameIDSubmited, null);
			}
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.RECEIVE_REAL_NAME_REWARD);
		});
	}

	private static void OnVerifyStatusChanged()
	{
		LocalPlayerDatabase.Settings.verifyGuide = null;
		UIDataEvents.Inst.InvokeEvent("OnVerifyStatusChanged");
	}

	public static void TryShowVerifyGuide(VerifyGuideTrigger trigger)
	{
		if (Verified || !VerifyGuideEnable || InGameScene.Inst != null)
		{
			return;
		}
		VerifyGuide verifyGuide = LocalPlayerDatabase.Settings.verifyGuide;
		if (verifyGuide.triggers == null || verifyGuide.triggers.Length < (int)(trigger + 1) || verifyGuide.triggers[(int)trigger] == 0)
		{
			return;
		}
		int now = UtcTimeStamp.Now;
		if (now - LastTriggerTime >= verifyGuide.triggerPeriod)
		{
			int tdyTriggerCount = TdyTriggerCount;
			if (tdyTriggerCount < LocalPlayerDatabase.Settings.verifyGuide.tdyLimit)
			{
				LastTriggerTime = now;
				TdyTriggerCount = tdyTriggerCount + 1;
				ShowVerifyGuide(trigger);
			}
		}
	}

	public static void ShowVerifyGuide(VerifyGuideTrigger trigger = VerifyGuideTrigger.Default)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["trigger"] = (int)trigger;
		UILobby.Current.ShowUI("VerifyGuideUI", commonDataCollection);
		if (trigger == VerifyGuideTrigger.Default)
		{
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.REAL_NAME_CLICK);
			return;
		}
		int num = (int)trigger;
		LocalPlayerDatabase.ReportClickEvent(ClickEventParam.AUTO_GUIDE_REAL_NAME, num.ToString());
	}
}
