using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class BindReviews_Bind
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Content;

	public GameObject m_Empty;

	public UIScrollRect m_ScrollView;

	public Button m_CloseButton;

	public static bool NeedUpdate;

	public void Bind(CommonDataCollection args)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (BindFriendsUtility.BindFriendsReviews == null || BindFriendsUtility.BindFriendsReviews.Count <= 0)
		{
			m_Empty.SetActive(value: true);
		}
		else
		{
			m_Empty.SetActive(value: false);
			for (int i = 0; i < BindFriendsUtility.BindFriendsReviews.Count; i++)
			{
				commonDataCollection[i]["index"] = i;
			}
		}
		m_Content.Args = commonDataCollection;
		m_Host.EventProxy(m_CloseButton, "GoBack");
	}

	public void GoBack()
	{
		UILobby.Current.GoBack();
		if (NeedUpdate)
		{
			BindFriendsUtility.RefreshMyBindFriendsInfo(clearPointAdd: true, delegate
			{
				BindFriendsUtility.TryShowPointAdd();
				LocalPlayerDatabase.RefreshAssetsInfo();
			});
			NeedUpdate = false;
		}
	}

	public void OnDisable()
	{
		m_ScrollView.ScrollToStart(immediately: true);
		BindFriendsUtility.NewFriendReviews = false;
		UIDataEvents.Inst.InvokeEvent("OnBindFriendsRedPoint");
	}
}
