using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;

public class DamagableTarget : MonoBehaviour
{
	public enum TargetType
	{
		Player,
		Monitor,
		BlockBar,
		Dog,
		Movable,
		Portal,
		Imprison,
		MagicWall,
		Genius,
		TrampolineObject,
		GeneratorObject,
		Bubble,
		IceWall,
		Mine
	}

	public TargetType m_TargetType;

	public bool m_IsRoot;

	private MonoBehaviour m_Target;

	private string m_ColliderName;

	private List<Collider> m_CacheColliders = new List<Collider>();

	public static Dictionary<int, DamagableTarget> AllDamagableTarget = new Dictionary<int, DamagableTarget>();

	public MonoBehaviour Target => m_Target;

	private void OnDeSpawn()
	{
	}

	private void OnDestroy()
	{
		int instanceID = base.gameObject.GetInstanceID();
		AllDamagableTarget.Remove(instanceID);
	}

	private void Awake()
	{
		if (m_IsRoot)
		{
			InitializeTarget();
			OnHierachyUpdated();
		}
		m_ColliderName = base.gameObject.name;
		int instanceID = base.gameObject.GetInstanceID();
		AllDamagableTarget[instanceID] = this;
	}

	private void InitializeTarget()
	{
		switch (m_TargetType)
		{
		case TargetType.Player:
			m_Target = GetComponent<PlayerController>();
			break;
		case TargetType.Monitor:
			m_Target = GetComponent<MonitorObject>();
			break;
		case TargetType.BlockBar:
			m_Target = GetComponent<BlockBarObject>();
			break;
		case TargetType.IceWall:
			m_Target = GetComponent<WaterEscapeObject>();
			break;
		case TargetType.Dog:
			m_Target = GetComponent<DogObject>();
			break;
		case TargetType.Movable:
			m_Target = GetComponent<MovableObject>();
			break;
		case TargetType.Portal:
			m_Target = GetComponent<PortalObject>();
			break;
		case TargetType.Imprison:
			m_Target = GetComponent<ImprisonObject>();
			break;
		case TargetType.MagicWall:
			m_Target = GetComponent<MagicWallObject>();
			break;
		case TargetType.Genius:
			m_Target = GetComponent<GeniusObject>();
			break;
		case TargetType.TrampolineObject:
			m_Target = GetComponent<TrampolineObject>();
			break;
		case TargetType.GeneratorObject:
			m_Target = GetComponent<GeneratorObject>();
			break;
		case TargetType.Bubble:
			m_Target = GetComponent<BubbleObject>();
			break;
		case TargetType.Mine:
			m_Target = GetComponent<MineObject>();
			break;
		}
	}

	public bool CanTrigger(ProjectileLauncher launcher)
	{
		try
		{
			switch (m_TargetType)
			{
			case TargetType.Player:
			{
				if (GameRuntime.IsCustomRoom && !string.IsNullOrEmpty(m_ColliderName) && m_ColliderName.Contains("HeadSlot"))
				{
					return false;
				}
				PlayerController playerController = (PlayerController)m_Target;
				bool flag = (!(launcher.Controller is PlayerController)) ? (playerController.PlayingRole == launcher.Controller.PlayingRole) : playerController.InSameTeam((PlayerController)launcher.Controller);
				return !flag && playerController.CanBeAttacked;
			}
			case TargetType.Monitor:
				return ((MonitorObject)m_Target).m_RoleType != launcher.Controller.PlayingRole;
			case TargetType.Dog:
			{
				DogObject dogObject = (DogObject)m_Target;
				return !dogObject.IsDead && !dogObject.PlayerController.InSameTeam((PlayerController)launcher.Controller);
			}
			case TargetType.Portal:
				return false;
			case TargetType.Imprison:
				if (((ImprisonObject)m_Target).Level == 1)
				{
					return false;
				}
				return true;
			case TargetType.MagicWall:
			{
				MagicWallObject magicWallObject = (MagicWallObject)m_Target;
				return magicWallObject.Effective && !magicWallObject.UserPlayer.InSameTeam((PlayerController)launcher.Controller);
			}
			case TargetType.GeneratorObject:
				return !((GeneratorObject)m_Target).PlayerController.InSameTeam((PlayerController)launcher.Controller);
			case TargetType.Genius:
			{
				GeniusObject geniusObject = (GeniusObject)m_Target;
				return !geniusObject.IsDead && geniusObject.PlayerController != null && !geniusObject.PlayerController.InSameTeam((PlayerController)launcher.Controller);
			}
			case TargetType.Bubble:
				return false;
			case TargetType.Mine:
				return ((MineObject)m_Target).CanBeAttack((PlayerController)launcher.Controller);
			default:
				return true;
			}
		}
		catch (Exception ex)
		{
			UnityEngine.Debug.LogError("CanTrigger" + ex.Message);
			return false;
		}
	}

	public bool TryApplyDamage(BulletObject bullet)
	{
		int numID = UserId2NumId.Get(bullet.Launcher.Controller.UserId);
		DamageSourceType damageSourceType = DamageSourceType.Projectile;
		if (bullet is SaberObject)
		{
			damageSourceType = DamageSourceType.Saber;
		}
		else if (bullet is ThrownObject)
		{
			damageSourceType = DamageSourceType.ThrownBullet;
		}
		else if (bullet is MissileCarBoomObject)
		{
			damageSourceType = DamageSourceType.Missile;
		}
		switch (m_TargetType)
		{
		case TargetType.Player:
		{
			PlayerController playerController = (PlayerController)m_Target;
			bool flag = (!(bullet.Launcher.Controller is PlayerController)) ? (playerController.PlayingRole == bullet.Launcher.Controller.PlayingRole) : playerController.InSameTeam((PlayerController)bullet.Launcher.Controller);
			if (!flag && playerController.CanBeAttacked)
			{
				if (bullet.CheckBulletThroughBarried(playerController.transform.position) && damageSourceType != DamageSourceType.Missile)
				{
					return false;
				}
				float rate;
				bool flag2 = CheckCritical(bullet, out rate);
				float damage = (flag2 ? rate : 1f) * bullet.Attack;
				DamageExtraInfo extraInfo = default(DamageExtraInfo);
				extraInfo.explosionPos = bullet.transform.position;
				extraInfo.explosionRadius = bullet.m_ExposionRadius;
				extraInfo.rrt = PhotonNetwork.networkingPeer.RoundTripTime;
				extraInfo.cardID = bullet.CardID;
				extraInfo.critical = (short)(flag2 ? 1 : 0);
				extraInfo.time = Time.realtimeSinceStartup - bullet.StartTime;
				if (bullet is ProjectileObject && flag2)
				{
					damageSourceType = DamageSourceType.ProjectileCritical;
				}
				bullet.Launcher.Controller.TalentManager.LocalCheckPressure(damage, playerController, damageSourceType, bullet.Launcher.TalentTriggerFactor);
				playerController.RpcApplyDamage(damage, numID, damageSourceType, 0, extraInfo);
				bullet.Launcher.Controller.TalentManager.CheckTalents(TalentTrigger.AttackHit, bullet.Launcher.TalentTriggerFactor);
				return true;
			}
			return false;
		}
		case TargetType.Monitor:
		{
			MonitorObject monitorObject = (MonitorObject)m_Target;
			if (monitorObject.m_RoleType != bullet.Launcher.Controller.PlayingRole)
			{
				monitorObject.RpcApplyDamage(bullet.Attack, numID);
				return true;
			}
			return false;
		}
		case TargetType.BlockBar:
		{
			BlockBarObject blockBarObject = (BlockBarObject)m_Target;
			if (string.IsNullOrEmpty(blockBarObject.UserId))
			{
				return false;
			}
			blockBarObject.RpcApplyDamage(bullet.Attack, numID);
			return true;
		}
		case TargetType.IceWall:
		{
			WaterEscapeObject waterEscapeObject = (WaterEscapeObject)m_Target;
			if (string.IsNullOrEmpty(waterEscapeObject.UserId))
			{
				return false;
			}
			if (damageSourceType != DamageSourceType.Missile)
			{
				Vector3 position2 = bullet.transform.position;
				waterEscapeObject.RpcApplyDamage(bullet.Attack, position2, numID);
			}
			else
			{
				waterEscapeObject.TryApplyRangeDamage(bullet.Attack, bullet.transform.position, bullet.m_ExposionRadius, numID);
			}
			return true;
		}
		case TargetType.MagicWall:
		{
			MagicWallObject magicWallObject = (MagicWallObject)m_Target;
			if (magicWallObject.Effective && magicWallObject.UserPlayer != null && !magicWallObject.UserPlayer.InSameTeam((PlayerController)bullet.Launcher.Controller))
			{
				magicWallObject.RpcApplyDamage(bullet.Attack, numID);
				return true;
			}
			return false;
		}
		case TargetType.Dog:
		{
			DogObject dogObject = (DogObject)m_Target;
			if (dogObject.PlayerController != null && !dogObject.PlayerController.InSameTeam((PlayerController)bullet.Launcher.Controller))
			{
				dogObject.RpcApplyDamage(bullet.Attack, numID, damageSourceType);
				return true;
			}
			return false;
		}
		case TargetType.Movable:
		{
			MovableObject movableObject = (MovableObject)m_Target;
			Vector3 position3 = movableObject.transform.position;
			switch (damageSourceType)
			{
			case DamageSourceType.Projectile:
				movableObject.RpcApplyExplosionForce(bullet.m_HitForce * bullet.transform.forward, position3);
				break;
			case DamageSourceType.Saber:
			case DamageSourceType.ThrownBullet:
			{
				Vector3 normalized = (position3 - bullet.transform.position).FlattenY().normalized;
				movableObject.RpcApplyExplosionForce(bullet.m_HitForce * normalized, position3);
				break;
			}
			}
			return true;
		}
		case TargetType.Imprison:
		{
			ImprisonObject imprisonObject = (ImprisonObject)m_Target;
			if (imprisonObject.Level == 2 && imprisonObject.PlayingRole != bullet.Launcher.Controller.PlayingRole)
			{
				if (damageSourceType != DamageSourceType.Missile)
				{
					Vector3 position = bullet.transform.position;
					imprisonObject.RpcApplyDamage(bullet.Attack, position, numID);
				}
				else
				{
					imprisonObject.TryApplyRangeDamage(bullet.Attack, bullet.transform.position, bullet.m_ExposionRadius, numID);
				}
			}
			else if (imprisonObject.Level == 1)
			{
				return false;
			}
			return true;
		}
		case TargetType.Genius:
		{
			GeniusObject geniusObject = (GeniusObject)m_Target;
			if (!geniusObject.IsDead && geniusObject.PlayerController != null && !geniusObject.PlayerController.InSameTeam((PlayerController)bullet.Launcher.Controller))
			{
				geniusObject.RpcApplyDamage(bullet.Attack, numID, damageSourceType);
				return true;
			}
			return false;
		}
		case TargetType.TrampolineObject:
			((TrampolineObject)m_Target).RpcApplyDamage(bullet.Attack, numID);
			return true;
		case TargetType.GeneratorObject:
		{
			GeneratorObject generatorObject = (GeneratorObject)m_Target;
			if (generatorObject.PlayerController != null && !generatorObject.PlayerController.InSameTeam((PlayerController)bullet.Launcher.Controller))
			{
				generatorObject.RpcApplyDamage(bullet.Attack, numID);
				return true;
			}
			return false;
		}
		case TargetType.Bubble:
			return false;
		case TargetType.Mine:
		{
			MineObject mineObject = (MineObject)m_Target;
			if (mineObject.CanBeAttack((PlayerController)bullet.Launcher.Controller))
			{
				mineObject.RpcApplyDamage(bullet.Attack, numID, damageSourceType);
			}
			return true;
		}
		default:
			return false;
		}
	}

	private bool CheckCritical(BulletObject bullet, out float rate)
	{
		if (bullet.Launcher.Controller.PlayingRole == RoleType.Boss && bullet.Launcher.Controller.BuffManager.ContainsBuff(301))
		{
			rate = 1.7f;
			return true;
		}
		if (bullet.BrokenStealth)
		{
			rate = 1.5f;
			return true;
		}
		if (bullet is MissileCarBoomObject)
		{
			rate = 1f;
			return false;
		}
		if (bullet.Launcher.Controller.BuffManager.CriticalGain > 0f && UnityEngine.Random.Range(0f, 1f) < bullet.Launcher.Controller.BuffManager.CriticalGain)
		{
			rate = 1.5f;
			return true;
		}
		if (bullet.Launcher.Controller.TalentManager.CheckCriticalHit(out rate, bullet.Launcher.TalentTriggerFactor))
		{
			return PlayerController.Inst == bullet.Launcher.Controller;
		}
		return false;
	}

	public void OnHierachyUpdated()
	{
		if (m_IsRoot)
		{
			SeparatePhysicsBody componentInChildren = GetComponentInChildren<SeparatePhysicsBody>();
			if (componentInChildren != null && componentInChildren.gameObject != base.gameObject)
			{
				DamagableTarget damagableTarget = AddDamageTarget(componentInChildren.gameObject);
				damagableTarget.m_IsRoot = true;
				damagableTarget.OnHierachyUpdated();
			}
			else
			{
				GetComponentsInChildren(m_CacheColliders);
				foreach (Collider cacheCollider in m_CacheColliders)
				{
					AddDamageTarget(cacheCollider.gameObject);
				}
				m_CacheColliders.Clear();
			}
		}
	}

	private DamagableTarget AddDamageTarget(GameObject child)
	{
		DamagableTarget damagableTarget = child.GetComponent<DamagableTarget>();
		if (damagableTarget == null)
		{
			damagableTarget = child.AddComponent<DamagableTarget>();
		}
		damagableTarget.m_TargetType = m_TargetType;
		damagableTarget.m_Target = m_Target;
		damagableTarget.m_IsRoot = false;
		return damagableTarget;
	}

	public void OnHierachyAdded(Transform child)
	{
		if (child.GetComponent<Collider>() != null || child.GetComponent<DamagableTarget>() != null)
		{
			AddDamageTarget(child.gameObject);
		}
	}
}
