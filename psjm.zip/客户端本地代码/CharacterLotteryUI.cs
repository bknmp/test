using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterLotteryUI
{
	public UIDataBinder m_Host;

	public Image m_LuckyProgress;

	public Text m_LuckyTitle;

	public Text m_LuckyDescript;

	public Button m_WishOneBt;

	public Button m_WishMultiBt;

	public CharacterLotteryController m_LotteryCtrl;

	public Text m_ActivityCountdown;

	public UICooldownBar m_CoolDownUI;

	public LotteryBoxUI m_BoxBar;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public GameObject m_RedPoint;

	public Button m_HelpBt;

	public UIPopup m_LotteryRuleUI;

	public UIPage m_MultiRewardPopupUI;

	public GameObject m_SuccessMsg;

	public GameObject m_UnSuccessMsg;

	public Texture2D m_FreeWishIcon;

	public Texture2D m_OneWishIcon;

	public GameObject m_CrystalGrowFx;

	public GameObject m_LuckyProgressFx;

	public GameObject m_Wheel;

	public LotteryRewardShow m_RewardShow;

	public GameObject m_OneCost;

	public Image m_CurrencyIcon1;

	public Image m_CurrencyIcon2;

	public Text m_OneTimeCostText;

	public Text m_MultTimeCostText;

	public GameObject m_Mask;

	public Toggle m_JumpAnim;

	private int m_NextFreeTime = int.MaxValue;

	private int m_OneTimeCost;

	private int m_MultiTimeCost;

	private int m_Currency;

	private List<int> m_SupperRewardList = new List<int>();

	private List<int> m_Special = new List<int>();

	private int m_CurWishTimes;

	private Activity m_activity;

	private bool m_IsShowingEffect;

	public static float m_PreClickTime;

	public const float ClickCoolTime = 0.5f;

	private float part1 = 0.1f;

	private float weight1 = 1.4f;

	private float part2 = 0.5f;

	private float weight2 = 1f;

	private float part3 = 0.7f;

	private float weight3 = 1.1f;

	private float part4 = 1f;

	private float weight4 = 0.8f;

	private const string NextFreeTimeKey = "CharacterLottery_NextFreeTime";

	public void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		bool dirty = m_activity != null && m_activity.activityId != activity.activityId;
		m_activity = activity;
		DateTime date = UtcTimeStamp.GetDate(m_activity.startTime);
		DateTime date2 = UtcTimeStamp.GetDate(m_activity.endTime);
		string text = string.Format("{0}" + Localization.Month + "{1}" + Localization.Day2 + "-{2}" + Localization.Month + "{3}" + Localization.Day2, date.Month, date.Day, date2.Month, date2.Day);
		m_ActivityCountdown.text = text;
		m_RedPoint.SetActive(value: false);
		m_Special.Clear();
		List<CharacterLotteryItemInfo> list = new List<CharacterLotteryItemInfo>();
		foreach (CharacterLotteryItemInfo item in LocalResources.CharacterLotteryInfo)
		{
			if (item.ActivityId == m_activity.activityId)
			{
				list.Add(item);
			}
		}
		m_SupperRewardList.Clear();
		foreach (CharacterLotteryItemInfo item2 in list)
		{
			if (item2.PopValue > 0)
			{
				m_SupperRewardList.Add(item2.ItemId);
			}
			if (item2.Prize > 0)
			{
				m_Special.Add(item2.ItemId);
			}
		}
		m_LotteryCtrl.Init(list, dirty);
		RefreshCharacterLotteryInfo();
		CheckOwnedStatus();
		m_Host.EventProxy(m_WishOneBt, "OnClickWishOne");
		m_Host.EventProxy(m_WishMultiBt, "OnClickWishMulti");
		if (m_HelpBt != null)
		{
			m_Host.EventProxy(m_HelpBt, "PopUpHelp");
		}
		m_BoxBar.Init(m_activity.activityId);
		SetJumpToggleState();
		OnTurningProgress(inProgress: false);
	}

	protected void OnDisable()
	{
		if (m_IsShowingEffect)
		{
			LocalPlayerDatabase.RefreshAssetsInfo();
		}
	}

	public virtual void CheckOwnedStatus()
	{
		bool flag = true;
		foreach (int item in m_Special)
		{
			if (LocalPlayerDatabase.NotOwnPermanentItem(item))
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			m_SuccessMsg.SetActive(value: true);
			m_UnSuccessMsg.SetActive(value: false);
		}
		else
		{
			m_SuccessMsg.SetActive(value: false);
			m_UnSuccessMsg.SetActive(value: true);
		}
	}

	public void PopUpHelp()
	{
		new CommonDataCollection();
		ActivityLobby.ShowInfoPopupUI("", LocalResources.ActivityLobbyInfos.Get(m_activity.activityId).Desc);
	}

	public void OnTurningProgress(bool inProgress)
	{
		m_Mask.gameObject.SetActive(inProgress);
		UILobby.Current.SetUIGraphic(!inProgress);
		m_IsShowingEffect = inProgress;
	}

	public void OnClickWishOne()
	{
		if (m_NextFreeTime <= UtcTimeStamp.Now)
		{
			StartWish(CharacterLotteryType.Free);
		}
		else if (m_Currency == 2 || m_Currency == 4)
		{
			int reason = -500000 - m_activity.activityId;
			ShopUtility.CheckMoneyEnough((Currency)m_Currency, m_OneTimeCost, delegate
			{
				StartWish(CharacterLotteryType.OneTime);
			}, reason, currentUIGoBack: false);
		}
		else if (ShopUtility.GetCurrencyAmount(m_Currency) >= m_OneTimeCost)
		{
			StartWish(CharacterLotteryType.OneTime);
		}
		else
		{
			LobbyScene_Money.BuyGoods(m_Currency);
		}
	}

	private void DebugWishItems(ItemInfo[] items)
	{
	}

	public void OnClickWishMulti()
	{
		if (m_Currency == 2 || m_Currency == 4)
		{
			int reason = -500000 - m_activity.activityId;
			ShopUtility.CheckMoneyEnough((Currency)m_Currency, m_MultiTimeCost, delegate
			{
				StartWish(CharacterLotteryType.MultiTimes);
			}, reason, currentUIGoBack: false);
		}
		else if (ShopUtility.GetCurrencyAmount(m_Currency) >= m_MultiTimeCost)
		{
			StartWish(CharacterLotteryType.MultiTimes);
		}
		else
		{
			LobbyScene_Money.BuyGoods(m_Currency);
		}
	}

	private bool StartWish(CharacterLotteryType type)
	{
		if (Time.time - m_PreClickTime <= 0.5f)
		{
			return false;
		}
		UILobby.Current.ShowWait();
		HttpRequestCharacterLotteryStartWish httpRequestCharacterLotteryStartWish = new HttpRequestCharacterLotteryStartWish();
		httpRequestCharacterLotteryStartWish.type = (int)type;
		httpRequestCharacterLotteryStartWish.activityId = m_activity.activityId;
		GameHttpManager.Inst.Send(httpRequestCharacterLotteryStartWish, delegate(HttpResponseCharacterLotteryStartWish OnHttpResponse)
		{
			UILobby.Current.HideWait();
			OnTurningProgress(inProgress: true);
			bool flag = m_JumpAnim != null && m_JumpAnim.isOn;
			ItemInfo[] items = OnHttpResponse.rewardItems;
			DebugWishItems(items);
			RefreshCharacterLotteryInfo(flag);
			switch (type)
			{
			case CharacterLotteryType.Free:
				m_BoxBar.Refresh(1);
				break;
			case CharacterLotteryType.OneTime:
				m_BoxBar.Refresh(1);
				break;
			case CharacterLotteryType.MultiTimes:
				m_BoxBar.Refresh(5);
				break;
			}
			if (flag)
			{
				ShowReward(items);
			}
			else
			{
				m_LuckyProgressFx.SetActive(value: false);
				m_LuckyProgressFx.SetActive(value: true);
				m_LotteryCtrl.StartTurning(OnHttpResponse.gridIDs, items, delegate
				{
					if (m_RewardShow != null)
					{
						m_RewardShow.ClearShow();
						m_Wheel.SetActive(value: true);
					}
					ShowReward(items);
				}, delegate(int itemId, int itemCount)
				{
					if (type == CharacterLotteryType.MultiTimes && m_RewardShow != null)
					{
						m_Wheel.SetActive(value: false);
						m_RewardShow.AddShowItem(itemId, itemCount);
					}
				});
			}
		});
		return false;
	}

	private void ShowReward(ItemInfo[] items)
	{
		m_LuckyProgressFx.SetActive(value: false);
		EnableAllFx(enable: false);
		OnTurningProgress(inProgress: false);
		CommonDataCollection args = MultiRewardPopupUI.DataWapper(items, m_MultiTimeCost, (CurrencyType)m_Currency, delegate
		{
		}, m_SupperRewardList, delegate
		{
			EnableAllFx(enable: true);
		}, showBuyAgainBt: false, showPopValue: false, forceSkipAnim: true);
		UILobby.Current.ShowUI(m_MultiRewardPopupUI, args);
		m_LotteryCtrl.Refresh();
		CheckOwnedStatus();
	}

	private void EnableAllFx(bool enable)
	{
		if (enable && m_CurWishTimes > 0)
		{
			m_CrystalGrowFx.SetActive(value: true);
		}
		else
		{
			m_CrystalGrowFx.SetActive(value: false);
		}
		m_BoxBar.EnableFx(enable);
	}

	public virtual float GetLuckyProgress(int luckyVal, int maxLucky)
	{
		float num = 0f;
		num = (((float)luckyVal > part4 * (float)maxLucky) ? ((float)maxLucky) : (((float)luckyVal > part3 * (float)maxLucky && luckyVal <= maxLucky) ? (((float)luckyVal - part3 * (float)maxLucky) * weight4 + part1 * (float)maxLucky * weight1 + (part2 - part1) * (float)maxLucky * weight2 + (part3 - part2) * (float)maxLucky * weight3) : (((float)luckyVal > part2 * (float)maxLucky && (float)luckyVal <= part3 * (float)maxLucky) ? (((float)luckyVal - part2 * (float)maxLucky) * weight3 + part1 * (float)maxLucky * weight1 + (part2 - part1) * (float)maxLucky * weight2) : (((float)luckyVal > part1 * (float)maxLucky && (float)luckyVal <= part2 * (float)maxLucky) ? (((float)luckyVal - part1 * (float)maxLucky) * weight2 + part1 * (float)maxLucky * weight1) : ((luckyVal < 0 || !((float)luckyVal <= part1 * (float)maxLucky)) ? 0f : ((float)luckyVal * weight1))))));
		return 0.9f * num / (float)maxLucky;
	}

	private void RefreshCharacterLotteryInfo(bool jumpAnim = false)
	{
		HttpRequestCharacterLotteryInfo httpRequestCharacterLotteryInfo = new HttpRequestCharacterLotteryInfo();
		httpRequestCharacterLotteryInfo.activityId = m_activity.activityId;
		GameHttpManager.Inst.Send(httpRequestCharacterLotteryInfo, delegate(HttpResponseCharacterLotteryInfo OnHttpResponse)
		{
			LocalPlayerDatabase.SetPrefValue("CharacterLottery_NextFreeTime" + m_activity.activityId, OnHttpResponse.nextFreeTime);
			m_Currency = OnHttpResponse.currency;
			m_OneTimeCost = OnHttpResponse.oneTimeCost;
			m_MultiTimeCost = OnHttpResponse.multiTimeCost;
			if (m_CurrencyIcon1 != null)
			{
				Sprite sprite3 = m_CurrencyIcon1.sprite = (m_CurrencyIcon2.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(m_Currency).Icon));
			}
			m_OneTimeCostText.text = $"x{m_OneTimeCost}";
			m_MultTimeCostText.text = $"x{m_MultiTimeCost}";
			m_CurWishTimes = OnHttpResponse.curLuckyValue;
			m_LuckyTitle.text = string.Format(Localization.ShowCharacterLotteryLuckVal, m_CurWishTimes);
			m_LuckyProgress.fillAmount = GetLuckyProgress(m_CurWishTimes, OnHttpResponse.maxLuckyValue);
			if (m_CurWishTimes > 0 && !jumpAnim)
			{
				m_CrystalGrowFx.SetActive(value: true);
			}
			else
			{
				m_CrystalGrowFx.SetActive(value: false);
			}
			m_NextFreeTime = OnHttpResponse.nextFreeTime;
			m_RedPoint.SetActive(value: false);
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
			int num = m_NextFreeTime - UtcTimeStamp.Now;
			if (num <= 0)
			{
				m_RedPoint.SetActive(value: true);
				UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
				m_CoolDownUI.gameObject.SetActive(value: false);
				m_WishOneBt.GetComponent<RawImage>().texture = m_FreeWishIcon;
				m_OneCost.SetActive(value: false);
			}
			else
			{
				m_CoolDownUI.gameObject.SetActive(value: true);
				m_WishOneBt.GetComponent<RawImage>().texture = m_OneWishIcon;
				m_OneCost.SetActive(value: true);
				m_CoolDownUI.SetTime(num, 1f, delegate
				{
					m_RedPoint.SetActive(value: true);
					UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
					m_CoolDownUI.gameObject.SetActive(value: false);
					m_WishOneBt.GetComponent<RawImage>().texture = m_FreeWishIcon;
					m_OneCost.SetActive(value: false);
				});
			}
		});
	}

	private void SetJumpToggleState()
	{
		if (m_JumpAnim != null)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(m_activity.activityId);
			int activityType = (int)activityLobbyInfo.Type;
			m_JumpAnim.isOn = LocalPlayerDatabase.GetPrefValue("LotteryJumpAnim" + activityType);
			m_JumpAnim.onValueChanged.RemoveAllListeners();
			m_JumpAnim.onValueChanged.AddListener(delegate(bool isOn)
			{
				LocalPlayerDatabase.SetPrefValue("LotteryJumpAnim" + activityType, isOn);
				if (m_IsShowingEffect && isOn)
				{
					m_LotteryCtrl.EndTurning();
					m_IsShowingEffect = false;
				}
			});
		}
	}

	public static bool GetRedPoint(int activityId)
	{
		if (LocalPlayerDatabase.GetPrefValueInt("CharacterLottery_NextFreeTime" + activityId) <= UtcTimeStamp.Now)
		{
			return true;
		}
		if (LotteryBoxUI.GetRedPointState(activityId))
		{
			return true;
		}
		return false;
	}
}
