using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class BoxUtility
{
	public static GameAsyncCallback RefreshBoxList(Delegates.VoidCallback onSuccess = null)
	{
		return GameHttpManager.Inst.Send(new HttpRequestBoxList(), delegate(HttpResponseBoxList response)
		{
			LocalPlayerDatabase.BoxListInfo = response;
			OnBoxInfoChanged();
		}, onSuccess);
	}

	public static GameAsyncCallback RequestUnlockBox(int boxPosition, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestBoxUnlock httpRequestBoxUnlock = new HttpRequestBoxUnlock();
		httpRequestBoxUnlock.boxPosition = boxPosition;
		return GameHttpManager.Inst.Send(httpRequestBoxUnlock, delegate(HttpResponseBoxUnlock response)
		{
			UpdateBoxInfo(response.boxPosition, response.cdEndTimestamp);
		}, onSuccess);
	}

	public static GameAsyncCallback RequestOpenBoxByPosition(int boxPosition, Action<ItemInfo[]> onResponse, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestBoxOpenByPosition httpRequestBoxOpenByPosition = new HttpRequestBoxOpenByPosition();
		httpRequestBoxOpenByPosition.boxPosition = boxPosition;
		return GameHttpManager.Inst.Send(httpRequestBoxOpenByPosition, delegate(HttpResponseBoxOpenByPosition response)
		{
			if (onResponse != null)
			{
				onResponse(response.itemList);
			}
			RemoveBoxInfo(response.boxPosition);
		}, onSuccess);
	}

	public static GameAsyncCallback RequestOpenBoxByID(int boxID, Action<ItemInfo[]> onResponse, Delegates.VoidCallback onComplete = null, int lotteryTicket = 0, int count = 1)
	{
		HttpRequestBoxOpenByTypeID httpRequestBoxOpenByTypeID = new HttpRequestBoxOpenByTypeID();
		httpRequestBoxOpenByTypeID.boxID = boxID;
		httpRequestBoxOpenByTypeID.lotteryTicket = lotteryTicket;
		httpRequestBoxOpenByTypeID.count = count;
		return GameHttpManager.Inst.Send(httpRequestBoxOpenByTypeID, delegate(HttpResponseBoxOpenByTypeID response)
		{
			if (onResponse != null)
			{
				onResponse(response.itemList);
			}
		}, onComplete);
	}

	public static BoxItemInfo GetBoxInfoByPosition(int boxPosition)
	{
		BoxItemInfo[] boxList = LocalPlayerDatabase.BoxListInfo.boxList;
		foreach (BoxItemInfo boxItemInfo in boxList)
		{
			if (boxItemInfo.boxPosition == boxPosition)
			{
				return boxItemInfo;
			}
		}
		return null;
	}

	public static void UpdateBoxInfo(BoxItemInfo boxItemInfo, int boxPosition)
	{
		for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
		{
			if (LocalPlayerDatabase.BoxListInfo.boxList[i].boxPosition == boxPosition)
			{
				LocalPlayerDatabase.BoxListInfo.boxList[i] = boxItemInfo;
				return;
			}
		}
		ArrayUtility.Add(ref LocalPlayerDatabase.BoxListInfo.boxList, boxItemInfo);
	}

	public static int OpenBoxCostDamond(int leftTime, float openCostDiamond)
	{
		if (leftTime < 0)
		{
			return 0;
		}
		return Mathf.CeilToInt((float)Mathf.CeilToInt((float)leftTime / 60f) * openCostDiamond);
	}

	public static int OpenBoxCostTicket(int leftTime, float openCostDiamond)
	{
		if (leftTime < 0)
		{
			return 0;
		}
		return Mathf.CeilToInt((float)Mathf.CeilToInt((float)leftTime / 60f) * openCostDiamond * 10f);
	}

	private static void UpdateBoxInfo(int boxPosition, int cdEndTimestamp)
	{
		int num = 0;
		while (true)
		{
			if (num < LocalPlayerDatabase.BoxListInfo.boxList.Length)
			{
				if (LocalPlayerDatabase.BoxListInfo.boxList[num].boxPosition == boxPosition)
				{
					break;
				}
				num++;
				continue;
			}
			return;
		}
		LocalPlayerDatabase.BoxListInfo.boxList[num].cdEndTimestamp = cdEndTimestamp;
		OnBoxInfoChanged();
	}

	public static bool IsScoreBoxCanOpen()
	{
		if (LocalPlayerDatabase.BoxListInfo != null)
		{
			ScoreBoxItemInfo scoreBox = LocalPlayerDatabase.BoxListInfo.scoreBox;
			int needPoint = LocalResources.BoxTable.Find(scoreBox.boxID).NeedPoint;
			if (!scoreBox.claimed)
			{
				return scoreBox.progress >= needPoint;
			}
			return false;
		}
		return false;
	}

	public static bool HaveBoxCanOpen()
	{
		if (LocalPlayerDatabase.BoxListInfo != null)
		{
			for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
			{
				if (LocalPlayerDatabase.BoxListInfo.boxList[i].CanOpen)
				{
					return true;
				}
			}
		}
		return false;
	}

	public static bool HaveBoxCanBeUnlocked()
	{
		if (LocalPlayerDatabase.BoxListInfo != null)
		{
			if (HaveBoxUnlocking() > 0)
			{
				return false;
			}
			for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
			{
				if (LocalPlayerDatabase.BoxListInfo.boxList[i].CanUnlock)
				{
					return true;
				}
			}
		}
		return false;
	}

	public static int HaveBoxUnlocking()
	{
		if (LocalPlayerDatabase.BoxListInfo != null)
		{
			for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
			{
				BoxItemInfo boxItemInfo = LocalPlayerDatabase.BoxListInfo.boxList[i];
				if (boxItemInfo.Unlocking)
				{
					return boxItemInfo.LeftTime;
				}
			}
		}
		return 0;
	}

	public static bool IsAnotherUnlocking(int boxPosition)
	{
		if (LocalPlayerDatabase.BoxListInfo != null)
		{
			for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
			{
				BoxItemInfo boxItemInfo = LocalPlayerDatabase.BoxListInfo.boxList[i];
				if (boxItemInfo.Unlocking && boxPosition != boxItemInfo.boxPosition)
				{
					return true;
				}
			}
		}
		return false;
	}

	public static int CurrentBoxSlotCount()
	{
		return LocalPlayerDatabase.BoxListInfo.boxList.Length;
	}

	public static bool HaveEmptyBoxSlot()
	{
		return LocalPlayerDatabase.BoxListInfo.boxList.Length < 4;
	}

	public static bool IsAllBoxSlotEmpty()
	{
		return LocalPlayerDatabase.BoxListInfo.boxList.Length == 0;
	}

	public static CommonDataCollection BoxPreviewUIArgsWraper(int boxID, int boxPos = -1, int shopID = -1)
	{
		return new CommonDataCollection
		{
			["boxID"] = boxID,
			["boxPos"] = boxPos,
			["shopID"] = shopID
		};
	}

	public static CommonDataCollection BoxUpgradePreviewUIArgsWraper(int boxID, int boxUpgradeID, int boxPos = -1)
	{
		return new CommonDataCollection
		{
			["boxID"] = boxID,
			["boxUpgradeID"] = boxUpgradeID,
			["boxPos"] = boxPos
		};
	}

	public static CommonDataCollection BoxOpenUIArgsWraper(int boxID, ItemInfo[] items)
	{
		return new CommonDataCollection
		{
			["boxID"] = boxID,
			["items"] = 
			{
				val = items
			}
		};
	}

	private static void RemoveBoxInfo(int boxPosition)
	{
		int index = 0;
		for (int i = 0; i < LocalPlayerDatabase.BoxListInfo.boxList.Length; i++)
		{
			if (LocalPlayerDatabase.BoxListInfo.boxList[i].boxPosition == boxPosition)
			{
				index = i;
				break;
			}
		}
		ArrayUtility.RemoveAt(ref LocalPlayerDatabase.BoxListInfo.boxList, index);
		OnBoxInfoChanged();
	}

	private static void OnBoxInfoChanged()
	{
		UIDataEvents.Inst.InvokeEvent("OnBoxInfoChanged");
	}

	public static IEnumerator UpdateBoxShortTime(int remainTime, Text text, Action onComplete = null)
	{
		WaitForSeconds second = new WaitForSeconds(1f);
		while (remainTime > 0)
		{
			remainTime--;
			TimeSpan timeSpan = new TimeSpan(0, 0, remainTime);
			if (timeSpan.TotalHours > 1.0)
			{
				text.text = $"{(int)timeSpan.TotalHours:0}{Localization.Hour}{Mathf.Max(1, timeSpan.Minutes):0}{Localization.Minute}";
			}
			else if (timeSpan.TotalMinutes > 1.0)
			{
				text.text = $"{(int)timeSpan.TotalMinutes:0}{Localization.Minute}";
			}
			else
			{
				text.text = $"{(int)timeSpan.TotalSeconds:0}{Localization.Second}";
			}
			yield return second;
		}
		onComplete?.Invoke();
	}

	public static BoxInfo[] GetTimeBoxes(int gradeID)
	{
		List<BoxInfo> list = new List<BoxInfo>();
		foreach (BoxInfo item in LocalResources.BoxTable)
		{
			if (item.Type >= 2 && item.Type <= 5 && LocalResources.GetGradeMapping(item.GradesRange[0]).GradeId == gradeID)
			{
				list.Add(item);
			}
		}
		return list.ToArray();
	}

	public static BoxInfo GetDailyBox(int gradeID)
	{
		return LocalResources.BoxTable.Find((BoxInfo info) => (info.Type == 1 && LocalResources.GetGradeMapping(info.GradesRange[0]).GradeId == gradeID) ? true : false);
	}

	public static ItemInfo[] MergeItems(ItemInfo[] items1, ItemInfo[] items2)
	{
		List<ItemInfo> list = new List<ItemInfo>();
		list.AddRange(items1);
		foreach (ItemInfo item in items2)
		{
			ItemInfo itemInfo = list.Find((ItemInfo x) => x.itemID == item.itemID);
			if (itemInfo != null)
			{
				itemInfo.itemCount += item.itemCount;
			}
			else
			{
				list.Add(item);
			}
		}
		return list.ToArray();
	}

	public static BoxInfo GetUpgradeBoxId(int boxID)
	{
		BoxInfo boxItemInfo = LocalResources.BoxTable.Find(boxID);
		try
		{
			return LocalResources.BoxTable.Find((BoxInfo x) => x.Type == boxItemInfo.Type + 1 && x.GradesRange[0] == boxItemInfo.GradesRange[0] && x.GradesRange[1] == boxItemInfo.GradesRange[1]);
		}
		catch (Exception ex)
		{
			UnityEngine.Debug.LogError("BoxUtility.GetUpgradeBoxId" + ex.Message);
			return null;
		}
	}
}
