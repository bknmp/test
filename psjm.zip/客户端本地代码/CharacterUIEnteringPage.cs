using LightUI;

internal class CharacterUIEnteringPage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_ThiefContent;

	public UITemplateInitiator m_PoliceContent;

	public UIScrollRect m_ThiefScrollView;

	public UIScrollRect m_PoliceScrollView;

	public void Bind(CommonDataCollection args)
	{
	}
}
