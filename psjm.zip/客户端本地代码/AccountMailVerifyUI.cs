using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class AccountMailVerifyUI : MonoBehaviour
{
	public Text Desc;

	public InputField m_Mail;

	public InputField m_Code;

	public Button m_SendCode;

	public Text m_CountDown;

	public Button m_OK;

	public Button m_Close;

	private MailCodeType m_MailCodeType;

	private Delegates.VoidCallback OnVerifySuccess;

	private Delegates.VoidCallback OnVerifyCancel;

	private int m_LastSendTime;

	private int m_LoginRoleId;

	private string m_LoginAuthKey;

	private void Awake()
	{
		m_SendCode.onClick.AddListener(OnSendCodeClick);
		m_OK.onClick.AddListener(OnOKClick);
		m_Close.onClick.AddListener(OnCloseClick);
	}

	private void OnEnable()
	{
		if (UtcTimeStamp.Now - m_LastSendTime <= 60)
		{
			m_CountDown.transform.parent.gameObject.SetActive(value: true);
			StartCoroutine(ButtonCountDown(60 - UtcTimeStamp.Now + m_LastSendTime));
		}
		else
		{
			m_CountDown.transform.parent.gameObject.SetActive(value: false);
		}
	}

	private void OnDisable()
	{
		StopAllCoroutines();
	}

	private void Init(MailCodeType type, string desc, string defaultMail, Delegates.VoidCallback onSuccess, Delegates.VoidCallback onCancel, CommonDataCollection param)
	{
		m_MailCodeType = type;
		Desc.text = desc;
		Desc.gameObject.SetActive(!string.IsNullOrEmpty(desc));
		m_Mail.text = defaultMail;
		m_Mail.interactable = string.IsNullOrEmpty(defaultMail);
		OnVerifySuccess = onSuccess;
		OnVerifyCancel = onCancel;
		m_Code.text = "";
		if (param != null)
		{
			m_LoginRoleId = param["roleId"];
			m_LoginAuthKey = param["authKey"];
		}
	}

	private void OnSendCodeClick()
	{
		if (CheckPwdAndMailFormat())
		{
			AccountUtility.SendMailCode(m_MailCodeType, m_Mail.text, delegate
			{
				m_LastSendTime = UtcTimeStamp.Now;
				StopAllCoroutines();
				StartCoroutine(ButtonCountDown(60));
				m_CountDown.transform.parent.gameObject.SetActive(value: true);
			}, m_LoginRoleId, m_LoginAuthKey);
		}
	}

	private bool CheckPwdAndMailFormat(bool checkCode = false)
	{
		if (m_Mail.text.Length < 5 || !m_Mail.text.Contains("@"))
		{
			UILobby.Current.ShowTips(Localization.TipsMailError);
			return false;
		}
		string[] array = m_Mail.text.Split('@');
		if (array[0].Length <= 0 || !array[1].Contains("."))
		{
			UILobby.Current.ShowTips(Localization.TipsMailError);
			return false;
		}
		if (checkCode && m_Code.text.Length <= 0)
		{
			UILobby.Current.ShowTips(Localization.TipsInvalidCode);
			return false;
		}
		return true;
	}

	private IEnumerator ButtonCountDown(int time)
	{
		while (time > 0)
		{
			m_CountDown.text = time.ToString();
			yield return new WaitForSeconds(1f);
			time--;
		}
		m_CountDown.transform.parent.gameObject.SetActive(value: false);
	}

	private void OnOKClick()
	{
		if (CheckPwdAndMailFormat(checkCode: true))
		{
			AccountUtility.CheckMailCode(m_MailCodeType, m_Mail.text, int.Parse(m_Code.text), delegate
			{
				UILobby.Current.ShowTips(Localization.VerifySuccess);
				m_LastSendTime = 0;
				CloseUI();
				if (OnVerifySuccess != null)
				{
					OnVerifySuccess();
				}
			}, m_LoginRoleId, m_LoginAuthKey);
		}
	}

	private void OnCloseClick()
	{
		CloseUI();
		if (OnVerifyCancel != null)
		{
			OnVerifyCancel();
		}
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI(MailCodeType type, string desc, string defaultMail, Delegates.VoidCallback onSuccess, Delegates.VoidCallback onCancel = null, CommonDataCollection param = null)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountMailVerifyUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountMailVerifyUI>().Init(type, desc, defaultMail, onSuccess, onCancel, param);
	}
}
