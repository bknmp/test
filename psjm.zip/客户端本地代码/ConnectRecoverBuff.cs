public class ConnectRecoverBuff : BuffManager.Buff
{
	public override bool BuffStart(BuffManager buffManager, PlayerController playerController)
	{
		TalentManager.Talent talent = PlayerController.FindPlayer(createUserID).TalentManager.GetTalent(130);
		if (talent != null)
		{
			damage = 0f - talent.Param;
		}
		return true;
	}
}
