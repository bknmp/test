public enum CardGrowthType
{
	Time,
	BuyCooldown,
	Amount,
	Discount,
	ReloadTime,
	FireTime,
	SpeedRatio,
	Length
}
