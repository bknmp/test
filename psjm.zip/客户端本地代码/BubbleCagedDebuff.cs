public class BubbleCagedDebuff : BuffManager.Buff
{
	public override bool BuffStart(BuffManager buffManager, PlayerController playerController)
	{
		TalentManager.Talent talent = PlayerController.FindPlayer(createUserID).TalentManager.GetTalent(132);
		if (talent != null)
		{
			damage = talent.Param;
		}
		damageSourceType = DamageSourceType.Bubble;
		return true;
	}
}
