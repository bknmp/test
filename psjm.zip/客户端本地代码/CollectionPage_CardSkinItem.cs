using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_CardSkinItem
{
	public UIDataBinder m_Host;

	public Text m_Personality;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_Selected;

	public Text m_CardSkinText;

	public RawImage m_Preview;

	public UIPointerBehaviour m_Input;

	public Button m_Button;

	public GameObject m_NotCollected;

	public GameObject m_NotHaveTips;

	public GameObject m_NotOwnedText;

	public GameObject m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeason;

	private string m_PersonalityFormat;

	private int m_ItemID;

	private DropItem m_ItemInfo;

	private bool m_Owned;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	public static int Selected;

	public void Bind(CommonDataCollection args)
	{
		if (m_PersonalityFormat == null)
		{
			m_PersonalityFormat = m_Personality.text;
		}
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_ItemID = args["itemID"];
		m_ItemInfo = LocalResources.DropItemTable.Find(m_ItemID);
		int limitedEdition = LocalResources.CardSkinTable.Get(m_ItemInfo.TypeParam).LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		if (CollectionUtility.OwnedForever(m_ItemInfo, m_PlayerInfo))
		{
			m_Owned = true;
			m_Personality.text = string.Format(m_PersonalityFormat, m_ItemInfo.Personality);
		}
		else
		{
			m_Owned = false;
		}
		m_Personality.gameObject.SetActive(m_Owned);
		m_NotCollected.SetActive(!m_Owned);
		m_NotOwnedText.SetActive(!m_Owned);
		string icon = m_ItemInfo.Icon;
		m_Icon.sprite = SpriteSource.Inst.Find(icon);
		m_QualityBG.State = m_ItemInfo.Quality;
		m_Effect.State = m_ItemInfo.Quality;
		m_Effect.gameObject.SetActive(m_Owned);
		if (Selected == 0)
		{
			Selected = m_ItemID;
			ShowCardSkin();
		}
		UpdateSelectState();
		m_Host.EventProxy(m_Button, "OnSelectButtonClick");
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_ItemID)
		{
			Selected = m_ItemID;
			ShowCardSkin();
			UIDataEvents.Inst.InvokeEvent("OnSelectCardSkinItemChanged");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_ItemID == Selected;
			m_Selected.SetActive(active);
		}
	}

	private void ShowCardSkin()
	{
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(m_ItemInfo.TypeParam);
		m_CardSkinText.text = cardSkinInfo.Name;
		m_CardSkinText.color = m_ItemInfo.QualityColor;
		m_NotHaveTips.SetActive(!m_Owned);
		m_ButtonGain.SetActive(!m_Owned && m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID);
		if (ResourceSource.Load(cardSkinInfo.Prefabs + "_Lobby") != null)
		{
			LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, cardSkinInfo.Prefabs + "_Lobby", m_Preview, m_Input);
		}
	}
}
