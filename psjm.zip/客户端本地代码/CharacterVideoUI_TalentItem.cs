using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterVideoUI_TalentItem
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Image m_Icon;

	public GameObject m_Selected;

	public VideoUI m_VideoUI;

	public MultiTargetGraphicButton m_Buttton;

	public UIStateImage m_Frame;

	public UIStateItem m_Type;

	public Text m_Desc;

	public UIDataBinder m_TalentDetail;

	public static int Selected;

	private int m_id;

	private string m_talentDetail;

	private CharacterVideoUI m_characterVideoUI;

	private CommonDataCollection m_arg = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		m_id = args["talent"];
		m_arg["id"] = m_id;
		m_characterVideoUI = (args["page"].val as CharacterVideoUI);
		TalentInfo talentInfo = LocalResources.TalentTable.Get(m_id);
		m_Name.text = talentInfo.Name;
		m_Icon.sprite = SpriteSource.Inst.Find(talentInfo.Icon);
		m_Frame.State = (int)talentInfo.Type;
		m_Type.State = (int)talentInfo.Type;
		List<object> list = new List<object>();
		for (int i = 1; i <= talentInfo.MaxLevel; i++)
		{
			list.Add(TalentUtility.GetTalentShowBonus(m_id, i));
		}
		m_talentDetail = string.Format(talentInfo.TakeEffectTips, list.ToArray());
		UpdateSelected();
		m_Host.EventProxy(m_Buttton, "OnClick");
	}

	private void UpdateSelected()
	{
		if (Selected == m_id)
		{
			m_Selected.gameObject.SetActive(value: true);
			m_Desc.text = m_talentDetail;
			if (VirtualUniqueDeviceID.IsLowMemory)
			{
				UILobby.Current.ShowTips(Localization.TipsNotSupportVedio);
			}
			else
			{
				m_VideoUI.TryDownloadAndPlay(3, m_id);
			}
			m_TalentDetail.Args = m_arg;
		}
		else
		{
			m_Selected.gameObject.SetActive(value: false);
		}
	}

	public void OnClick()
	{
		Selected = m_id;
		m_characterVideoUI.OnSelecteChange();
	}
}
