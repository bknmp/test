using DG.Tweening;
using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CardNewGainUI : UIEventListener
{
	public SceneCameraBlur m_Blur;

	public RawImage m_Background;

	public Image m_Frame;

	public GameObject m_TextGroup;

	public DropItemUI m_DropItem;

	public GameObject[] m_Effect;

	public GameObject[] m_ItemEffect;

	public Text m_CardTips;

	public AudioItem m_Sound;

	public UIStateItem m_CardPermanentEffect;

	public UIStateItem m_BackState;

	public Button m_VedioButton;

	public Button m_GoCheckButton;

	public Button m_CloseButton;

	public Button m_OKButton;

	public UIPage m_CardDetailUI;

	public UIPage m_CardVideoUI;

	public GameObject m_CloseBtn;

	private GameObject[] m_EffectInsts;

	private GameObject[] m_ItemEffectInsts;

	private Animator m_Animator;

	private int m_CardId;

	private bool m_IsFromOut;

	private RectTransform m_Card;

	private float m_EnterTime;

	private new void Awake()
	{
		base.Awake();
		m_EffectInsts = new GameObject[m_Effect.Length];
		m_ItemEffectInsts = new GameObject[m_ItemEffect.Length];
		m_IsFromOut = true;
		m_Animator = m_DropItem.GetComponent<Animator>();
		m_Card = m_DropItem.gameObject.transform.parent.GetComponent<RectTransform>();
		if (m_VedioButton != null)
		{
			m_VedioButton.onClick.AddListener(OnVedioClick);
		}
		if (m_GoCheckButton != null)
		{
			m_GoCheckButton.onClick.AddListener(OnGoCheckClick);
		}
		if (m_CloseButton != null)
		{
			m_CloseButton.onClick.AddListener(OnCloseClick);
		}
		if (m_OKButton != null)
		{
			m_OKButton.onClick.AddListener(OnCloseClick);
		}
	}

	private void OnEnable()
	{
		if (m_IsFromOut)
		{
			m_Animator.enabled = true;
			m_IsFromOut = false;
		}
		else
		{
			m_Animator.enabled = false;
		}
	}

	private void OnDisable()
	{
		ClearEffects();
		m_Animator.enabled = true;
		m_Card.DOComplete();
		CancelInvoke();
		ReportToBugly(12);
	}

	public override void OnEnterUI()
	{
		m_EnterTime = Time.realtimeSinceStartup;
		if (m_CloseBtn != null)
		{
			m_CloseBtn.SetActive(value: false);
			WaitCallback component = GetComponent<WaitCallback>();
			if (component != null)
			{
				component.StartWait();
			}
		}
		ReportToBugly(0);
		ReportClickToBugly();
	}

	public override void OnExitUI()
	{
		ReportToBugly(11);
	}

	private void ClearEffects()
	{
		GameObject[] effectInsts;
		if (m_EffectInsts != null)
		{
			effectInsts = m_EffectInsts;
			foreach (GameObject gameObject in effectInsts)
			{
				if (gameObject != null)
				{
					gameObject.SetActive(value: false);
				}
			}
		}
		if (m_ItemEffectInsts == null)
		{
			return;
		}
		effectInsts = m_ItemEffectInsts;
		foreach (GameObject gameObject2 in effectInsts)
		{
			if (gameObject2 != null)
			{
				gameObject2.SetActive(value: false);
			}
		}
	}

	public void ShowCard(int cardID)
	{
		ReportToBugly(1);
		bool flag = LobbyNewbieDirector.Inst == null || LobbyNewbieDirector.Inst.m_Dimmer == null || LobbyNewbieDirector.Inst.m_Dimmer.gameObject.activeSelf;
		ClearEffects();
		if (m_Blur != null)
		{
			m_Blur.OnBlurTextureCreate = delegate
			{
				m_Background.texture = m_Blur.BlurTexture;
			};
		}
		SoundManager.PlayOnce(m_Sound);
		m_CardId = cardID;
		int cardLevel = CardUtility.GetCardLevel(m_CardId);
		float cardLevelGrowthResult = CardUtility.GetCardLevelGrowthResult(m_CardId, cardLevel);
		int itemID = 10000 + m_CardId;
		m_DropItem.SetInfo(itemID, 1);
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_CardId);
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_CardPermanentEffect.State = inGameStoreInfo.Quality;
		if (m_EffectInsts[inGameStoreInfo.Quality] != null)
		{
			m_EffectInsts[inGameStoreInfo.Quality].SetActive(value: true);
		}
		else
		{
			GameObject gameObject = Object.Instantiate(m_Effect[inGameStoreInfo.Quality], m_DropItem.transform.parent);
			m_EffectInsts[inGameStoreInfo.Quality] = gameObject;
		}
		if (m_ItemEffectInsts[inGameStoreInfo.Quality] != null)
		{
			m_ItemEffectInsts[inGameStoreInfo.Quality].SetActive(value: true);
		}
		else
		{
			GameObject gameObject2 = Object.Instantiate(m_ItemEffect[inGameStoreInfo.Quality], m_DropItem.transform);
			m_ItemEffectInsts[inGameStoreInfo.Quality] = gameObject2;
		}
		m_CardTips.text = string.Format(inGameStoreInfo.SimpleDesc, cardLevelGrowthResult);
		ReportToBugly(2);
		if (m_VedioButton != null)
		{
			m_VedioButton.gameObject.SetActive(!flag);
		}
		if (m_GoCheckButton != null)
		{
			m_GoCheckButton.gameObject.SetActive(!flag);
		}
		if (m_OKButton != null)
		{
			m_OKButton.gameObject.SetActive(flag);
		}
		if (m_BackState != null)
		{
			m_BackState.State = (Application.isMobilePlatform ? 1 : 0);
		}
		TryShowCardAnimation();
		ReportToBugly(3);
	}

	private void TryShowCardAnimation()
	{
		m_Card.anchoredPosition = new Vector2(0f, 50f);
		m_TextGroup.gameObject.SetActive(value: false);
		m_CardPermanentEffect.gameObject.SetActive(value: false);
		Invoke("TryShowCardAnimation2", 3f);
	}

	private void TryShowCardAnimation2()
	{
		ReportToBugly(5);
		m_Animator.enabled = false;
		m_TextGroup.gameObject.SetActive(value: true);
		m_Card.DOAnchorPosX(-350f, 0.3f);
		Invoke("TryShowCardAnimation3", 0.5f);
	}

	private void TryShowCardAnimation3()
	{
		m_Card.DOAnchorPosY(60f, 1f).SetLoops(-1, LoopType.Yoyo);
		m_CardPermanentEffect.gameObject.SetActive(value: true);
		ReportToBugly(7);
	}

	private IEnumerator OnAnimationOver(int quality)
	{
		RectTransform rt = m_DropItem.transform.parent.GetComponent<RectTransform>();
		rt.DOKill();
		rt.anchoredPosition = new Vector2(0f, 50f);
		m_TextGroup.gameObject.SetActive(value: false);
		m_CardPermanentEffect.gameObject.SetActive(value: false);
		yield return new WaitForSeconds(3f);
		ReportToBugly(5);
		m_Animator.enabled = false;
		m_TextGroup.gameObject.SetActive(value: true);
		rt.DOAnchorPosX(-350f, 0.3f);
		yield return new WaitForSeconds(0.5f);
		rt.DOAnchorPosY(60f, 1f).SetLoops(-1, LoopType.Yoyo);
		m_CardPermanentEffect.gameObject.SetActive(value: true);
		m_CardPermanentEffect.State = quality;
		ReportToBugly(7);
	}

	private void OnVedioClick()
	{
		if (VirtualUniqueDeviceID.IsLowMemory)
		{
			UILobby.Current.ShowTips(Localization.TipsNotSupportVedio);
		}
		else if (m_CardVideoUI != null)
		{
			ReportClickToBugly(1);
			UILobby.Current.GoToPage(m_CardVideoUI);
			UILobby.Current.CurrentPage().GetComponent<VideoUI>().TryDownloadAndPlay(1, LocalResources.InGameStoreTable.Get(m_CardId).Id);
		}
	}

	private void OnGoCheckClick()
	{
		m_DropItem.gameObject.GetComponent<Animator>().enabled = false;
		CardConfigEditPage_CardSkinItemTemplate.globalSelected = LocalResources.InGameStoreTable.Get(m_CardId).DefaultSkinID;
		ReportClickToBugly(2);
		if (m_CardDetailUI != null)
		{
			UILobby.Current.ShowUI(m_CardDetailUI, CardUtility.CardDetailUIArgsWraper(m_CardId, CardUtility.GetCardLevel(m_CardId)));
		}
	}

	private void OnCloseClick()
	{
		ReportClickToBugly(3);
		m_IsFromOut = true;
		UILobby.Current.GoBack();
	}

	private void ReportToBugly(int progress)
	{
		BuglyManager.SetUserValue("Pro", progress.ToString());
		BuglyManager.SetUserValue("StayTime", (Time.realtimeSinceStartup - m_EnterTime).ToString("N2"));
	}

	private void ReportClickToBugly(int btn = 0)
	{
		BuglyManager.SetUserValue("click", btn.ToString());
		if (btn != 0)
		{
			ReportToBugly(9);
		}
	}
}
