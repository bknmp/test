using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class ChangeAccountNameUI : UIEventListener
{
	public InputField m_NewAccount;

	public Text m_TipsFreeTxt;

	public Text m_TipsDiamondTxt;

	public GameObject m_TipsNewbie;

	public GameObject m_CancelButton;

	public GameObject m_CloseButton;

	public GameObject m_SkipButton;

	public UIStateImage m_PriceType;

	public Text m_RecommendAccountName;

	public static string recommendAccountName = "";

	private bool m_NewbieShow;

	public void ShowNewbie(bool show)
	{
		m_CancelButton.SetActive(!show);
		m_CloseButton.SetActive(!show);
		m_TipsNewbie.SetActive(show);
		m_NewbieShow = show;
		m_SkipButton.SetActive(show);
	}

	private void OnEnable()
	{
		InitRecommendAccountName();
		LocalPlayerDatabase.RequestChangeAccountNameInfo(ShowChangeAccountNameInfo);
		m_NewAccount.text = "";
	}

	private void InitRecommendAccountName()
	{
		recommendAccountName = "";
		m_RecommendAccountName.text = "";
		m_RecommendAccountName.transform.parent.gameObject.SetActive(value: false);
	}

	private void OnDisable()
	{
		ShowNewbie(show: false);
	}

	private void ShowChangeAccountNameInfo()
	{
		m_SkipButton.SetActive(m_NewbieShow);
		if (m_NewbieShow)
		{
			return;
		}
		if (LocalPlayerDatabase.ChangeAccountNameInfo.freeCount > 0)
		{
			m_TipsFreeTxt.text = string.Format(Localization.FreeChangeNameTips, LocalPlayerDatabase.ChangeAccountNameInfo.freeCount);
			m_TipsFreeTxt.gameObject.SetActive(value: true);
			m_TipsDiamondTxt.gameObject.SetActive(value: false);
			return;
		}
		if (LocalPlayerDatabase.Settings.changeNameCostType == 0)
		{
			m_PriceType.State = 0;
			m_TipsDiamondTxt.text = string.Format(Localization.ChargeChangeNameTips, LocalPlayerDatabase.ChangeAccountNameInfo.diamonds);
		}
		else
		{
			m_PriceType.State = 1;
			m_TipsDiamondTxt.text = string.Format(Localization.ChargeChangeNameTips, LocalPlayerDatabase.ChangeAccountNameInfo.tickets);
		}
		m_TipsFreeTxt.gameObject.SetActive(value: false);
		m_TipsDiamondTxt.gameObject.SetActive(value: true);
	}

	private void Update()
	{
		if (UnityEngine.Input.GetKeyDown(KeyCode.KeypadEnter) || UnityEngine.Input.GetKeyDown(KeyCode.Return))
		{
			OnConfirmClicked();
		}
	}

	private bool CheckInput()
	{
		if (MathUtility.CalculateStringLengthInAscii(m_NewAccount.text, 1.5f) > 9)
		{
			UILobby.Current.ShowTips(Localization.TipsNameTooLong);
			string text = "";
			float num = 0f;
			int length = m_NewAccount.text.Length;
			for (int i = 0; i < length; i++)
			{
				num += ((m_NewAccount.text[i] > '\u007f') ? 1.5f : 1f);
				if (num <= 9f)
				{
					text += m_NewAccount.text[i].ToString();
				}
			}
			m_NewAccount.text = text;
			return false;
		}
		return true;
	}

	public void OnConfirmClicked()
	{
		if (!CheckInput() || LocalPlayerDatabase.ChangeAccountNameInfo == null)
		{
			return;
		}
		string playerName = m_NewAccount.text.Trim();
		if (!GameSettings.Inst.ValidateName(playerName))
		{
			return;
		}
		if (LocalPlayerDatabase.Settings.changeNameCostType == 0)
		{
			if (LocalPlayerDatabase.ChangeAccountNameInfo.freeCount <= 0 && LocalPlayerDatabase.PlayerInfo.diamonds < LocalPlayerDatabase.ChangeAccountNameInfo.diamonds)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.NotEnoughDiamonds, Localization.Yes, Localization.NextTime, "", delegate
				{
					JumpModuleManager.Inst.DoJump(JumpModule.Recharge);
				}, null);
				return;
			}
		}
		else if (LocalPlayerDatabase.ChangeAccountNameInfo.freeCount <= 0 && LocalPlayerDatabase.PlayerInfo.tickets < LocalPlayerDatabase.ChangeAccountNameInfo.tickets)
		{
			UILobby.Current.ShowTips(Localization.NotEnoughTicket);
			return;
		}
		ConfirmChangeAccountName();
	}

	private void ConfirmChangeAccountName()
	{
		LocalPlayerDatabase.ChangeAccountName(m_NewAccount.text.Trim().Replace("\r", "").Replace("\n", ""), delegate
		{
			if (!CheckRecommendAccountName())
			{
				PublicChatManager.m_PublicInfoChanged = true;
				UILobby.Current.ShowTips(Localization.TipsAccountNameChanged);
				LocalPlayerDatabase.RequestChangeAccountNameInfo(delegate
				{
					if (LocalPlayerDatabase.ChangeAccountNameInfo.freeCount <= 0 && LocalPlayerDatabase.ChangeAccountNameInfo.changedCount > 2)
					{
						if (LocalPlayerDatabase.Settings.changeNameCostType == 0)
						{
							LocalPlayerDatabase.PlayerInfo.diamonds -= LocalPlayerDatabase.ChangeAccountNameInfo.diamonds;
						}
						else
						{
							LocalPlayerDatabase.PlayerInfo.tickets -= LocalPlayerDatabase.ChangeAccountNameInfo.tickets;
						}
						LocalPlayerDatabase.OnPlayerInfoChanged();
					}
					ShowChangeAccountNameInfo();
				});
				if (AndroidSDKAdapter.AndroidChannel == AndroidChannel.QuickSDK && m_NewbieShow)
				{
					AndroidSDKAdapter.Instance.UploadRoleInfo(new RoleParams(LocalPlayerDatabase.LoginInfo.roleID.ToString(), LocalPlayerDatabase.LoginInfo.accountName, LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade.ToString(), "0", "1", "dmm"), isCreate: true);
				}
				GetComponent<UIPopup>().GoBack();
			}
		});
	}

	public bool CheckRecommendAccountName()
	{
		if (recommendAccountName.Length > 0)
		{
			if (!recommendAccountName.Equals("0"))
			{
				m_RecommendAccountName.transform.parent.gameObject.SetActive(value: true);
				m_RecommendAccountName.text = recommendAccountName;
				recommendAccountName = "";
				m_TipsNewbie.SetActive(value: false);
			}
			else
			{
				recommendAccountName = "";
				UILobby.Current.ShowTips(Localization.TheNameIsUsed);
			}
			return true;
		}
		return false;
	}

	public void Copy()
	{
		ClipboardTool.CopyToSystemClipboard(m_RecommendAccountName.text);
		m_NewAccount.text = m_RecommendAccountName.text;
		UILobby.Current.ShowTips(Localization.TipsCopyOK);
	}
}
