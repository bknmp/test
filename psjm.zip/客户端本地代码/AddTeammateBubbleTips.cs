using UnityEngine;
using UnityEngine.UI;

public class AddTeammateBubbleTips : MonoBehaviour
{
	public Text m_text;
}
