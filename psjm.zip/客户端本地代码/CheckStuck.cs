using BehaviorDesigner.Runtime.Tasks;
using UnityEngine;

public class CheckStuck : Conditional
{
	private AIController ai;

	private float lastUpdateTime;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
		lastUpdateTime = Time.time;
	}

	public override TaskStatus OnUpdate()
	{
		if (Time.time - lastUpdateTime > ai.m_StuckTimeThreshold)
		{
			lastUpdateTime = Time.time;
			if (ai.IsStuck())
			{
				return TaskStatus.Success;
			}
		}
		return TaskStatus.Failure;
	}
}
