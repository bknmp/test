using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSupplementBox : SupplementBox
{
	public static List<SupplementBox> AllBossSupplementBoxObjects = new List<SupplementBox>();

	protected override InGameCoinRewardReason CoinRewardReason => InGameCoinRewardReason.BossSupplementBox;

	public override UsableType UsableType => UsableType.BossSupplement;

	protected new void Awake()
	{
		AllBossSupplementBoxObjects.Add(this);
		base.Awake();
		InGameBossSkillUI.Inst.m_TipsBossBox.SetActive(value: true);
		StartCoroutine(HighlightBossSupplementBoxInMinimap(5f));
	}

	private IEnumerator HighlightBossSupplementBoxInMinimap(float duration)
	{
		yield return new WaitForSeconds(0.5f);
		InGameMinimap.Inst.ShowHighlight(this, show: true);
		yield return new WaitForSeconds(duration);
		InGameMinimap.Inst.ShowHighlight(this, show: false);
	}

	protected override void OnDestroy()
	{
		AllBossSupplementBoxObjects.Remove(this);
		base.OnDestroy();
	}
}
