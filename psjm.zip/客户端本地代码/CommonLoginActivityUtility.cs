using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;

public class CommonLoginActivityUtility
{
	public static Dictionary<int, HttpResponseContinueLoginActivity> CacheInfo = new Dictionary<int, HttpResponseContinueLoginActivity>();

	private static int lastRefreshTime;

	private static string Claimed = "CommonLoginPackageClaimed";

	public static void TryRefreshActivityInfo(int activityId, Delegates.VoidCallback OnSuccess)
	{
		if (ActivityLobby.GetActivityById(activityId) != null)
		{
			if (UtcTimeStamp.IsOverDay(lastRefreshTime, UtcTimeStamp.Now))
			{
				CacheInfo.Clear();
			}
			lastRefreshTime = UtcTimeStamp.Now;
			if (!CacheInfo.ContainsKey(activityId))
			{
				HttpRequestCommonLoginActivity httpRequestCommonLoginActivity = new HttpRequestCommonLoginActivity();
				httpRequestCommonLoginActivity.activityId = activityId;
				GameHttpManager.Inst.Send(httpRequestCommonLoginActivity, delegate(HttpResponseContinueLoginActivity onResponse)
				{
					if (!CacheInfo.ContainsKey(activityId))
					{
						CacheInfo.Add(activityId, onResponse);
						SetLocalClaimInfo(activityId);
					}
				}, OnSuccess);
			}
			else
			{
				OnSuccess?.Invoke();
			}
		}
	}

	public static int GetRewardCountWithDayIndex(int activityId, int index)
	{
		return LocalResources.CommonLoginActivityRewardTable.Find((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(activityId) && x.Days.Equals(index)).ItemId.Length;
	}

	public static void GetReward(int activityId, int index, Delegates.VoidCallback OnSuccess)
	{
		if (ActivityLobby.GetActivityById(activityId) == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return;
		}
		if (isRewardReceive(activityId, index))
		{
			UILobby.Current.ShowTips(Localization.hadClaim);
			return;
		}
		if (!isRewardAvailable(activityId, index))
		{
			UILobby.Current.ShowTips(Localization.CantClaim);
			return;
		}
		HttpRequestGetLoginActivityReward httpRequestGetLoginActivityReward = new HttpRequestGetLoginActivityReward();
		httpRequestGetLoginActivityReward.activityId = activityId;
		httpRequestGetLoginActivityReward.day = index;
		GameHttpManager.Inst.Send(httpRequestGetLoginActivityReward, delegate(HttpResponseGetLoginActivityReward onResponse)
		{
			bool flag = false;
			int[] rewardGetList = onResponse.rewardGetList;
			foreach (int num in rewardGetList)
			{
				if (index == num)
				{
					flag = true;
				}
			}
			if (flag)
			{
				int itemID = onResponse.items[0].itemID;
				if (LocalResources.DropItemTable.Find(itemID).Type == DropItemType.CardSkin)
				{
					LocalPlayerDatabase.RefreshAssetsInfo();
					CommonDataCollection args = new CommonDataCollection
					{
						["ItemInfo"] = 
						{
							val = onResponse.items[0]
						}
					};
					UILobby.Current.ShowUI(PrefabSource.Inst.Load<UIPage>("ExpensiveRewardUI"), args);
				}
				else
				{
					CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(PrefabSource.Inst.Load<CommonRewardPopupUI>("CommonRewardPopupUI"));
					commonRewardPopupUI.AddItems(onResponse.items);
					commonRewardPopupUI.SetTitleAndTips("", "");
				}
				if (CacheInfo.ContainsKey(activityId))
				{
					CacheInfo[activityId].rewardGetList = onResponse.rewardGetList;
					SetLocalClaimInfo(activityId);
				}
				UIDataEvents.Inst.InvokeEvent("OnClaimLoginAward");
				if (OnSuccess != null)
				{
					OnSuccess();
				}
			}
		});
	}

	public static void GetFinalReward(int activityId, Delegates.VoidCallback OnSuccess)
	{
		List<CommonLoginActivityRewardInfo> list = LocalResources.CommonLoginActivityRewardTable.FindAll((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(activityId));
		GetReward(activityId, list.Count, OnSuccess);
	}

	public static bool isRewardAvailable(int activityId, int index)
	{
		if (CacheInfo.ContainsKey(activityId) && index <= CacheInfo[activityId].signinTimes)
		{
			return true;
		}
		return false;
	}

	public static bool isNextDayRewardAvailable(int activityId, int index)
	{
		if (CacheInfo.ContainsKey(activityId) && index == CacheInfo[activityId].signinTimes + 1)
		{
			return true;
		}
		return false;
	}

	public static bool isRewardReceive(int activityId, int index)
	{
		if (CacheInfo.ContainsKey(activityId))
		{
			int[] rewardGetList = CacheInfo[activityId].rewardGetList;
			foreach (int num in rewardGetList)
			{
				if (index == num)
				{
					return true;
				}
			}
		}
		return false;
	}

	public static int GetFinalDayIndex(int activityId)
	{
		return LocalResources.CommonLoginActivityRewardTable.FindAll((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(activityId)).Count;
	}

	public static bool IsFinish(int activityId)
	{
		if (CacheInfo.ContainsKey(activityId))
		{
			List<CommonLoginActivityRewardInfo> list = LocalResources.CommonLoginActivityRewardTable.FindAll((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(activityId));
			return CacheInfo[activityId].signinTimes >= list.Count;
		}
		return false;
	}

	public static void SetLocalClaimInfo(int activityID)
	{
		LocalPlayerDatabase.SetPrefValue(Claimed + activityID, (CacheInfo[activityID].signinTimes - CacheInfo[activityID].rewardGetList.Length <= 0) ? 1 : 0);
		ActivityLobby.InvokeActivityLobbyRedPointChange();
	}

	public static bool GetRedPointState(int activityID)
	{
		if (LocalPlayerDatabase.GetPrefValueInt(Claimed + activityID) == 0)
		{
			return true;
		}
		return false;
	}
}
