using BehaviorDesigner.Runtime.Tasks;

[TaskName("买弹匣")]
[TaskCategory("躲猫猫AI/普通行为")]
[TaskDescription("买弹匣，金币不足返回fail")]
public class BuyMagazine : Action
{
	public SharedAIController ai;

	public override TaskStatus OnUpdate()
	{
		if (ai.Value.BuyMagazine())
		{
			return TaskStatus.Success;
		}
		return TaskStatus.Failure;
	}
}
