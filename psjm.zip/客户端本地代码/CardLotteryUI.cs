using DG.Tweening;
using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using UnityEngine;

public class CardLotteryUI : UIEventListener
{
	public enum LotteryState
	{
		None,
		Rainbow,
		Normal
	}

	public Vector3 m_BoxMoveOffset;

	public Vector3 m_RotationOffset;

	public float m_TweenDuration = 0.2f;

	public float m_RiseDelayOffset = -0.2f;

	public float m_RiseDuration = 0.1f;

	public GameObject m_Effect;

	public CanvasGroup m_Alpha;

	private Action m_OnCompleteMove;

	private bool m_IsOpening;

	private CardLotteryItem m_CurrentLotteryItem;

	public static CardLotteryUI Inst;

	public static bool PlayingAnimiation;

	public static LotteryState m_LotteryState;

	private static bool m_isLastOpenNormalLottery;

	public GameObject m_NormalLotteryTicket;

	public GameObject m_AdvanceLotteryTicket;

	public GameObject m_SuperLotteryTicket;

	public GameObject m_RainbowLotteryTicket;

	public UITemplateInitiator m_TemplateInitiator;

	public UITemplateInitiator m_TemplateInitiatorForRainbowCardLottery;

	public CardLotteryItem CurrentLotteryItem => m_CurrentLotteryItem;

	public static bool IsLastOpenNormalLottery => m_isLastOpenNormalLottery;

	private new void Awake()
	{
		base.Awake();
		Inst = this;
	}

	private void OnDestroy()
	{
		Inst = null;
	}

	private void OnEnable()
	{
		if (LobbyScene.Inst != null)
		{
			LobbyScene.Inst.m_Vignette.SetActive(value: false);
			LobbyScene.Inst.m_CardLotteryPanel.Root.gameObject.SetActive(value: true);
		}
	}

	private void OnDisable()
	{
		if (LobbyScene.Inst != null && !m_IsOpening)
		{
			LobbyScene.Inst.m_Vignette.SetActive(value: true);
			LobbyScene.Inst.m_CardLotteryPanel.Root.gameObject.SetActive(value: false);
		}
		PlayingAnimiation = false;
	}

	public override void OnEnterUI()
	{
		AutoHideLobbyCharacter.RequestHiding();
		if ((m_LotteryState == LotteryState.None || m_LotteryState == LotteryState.Rainbow) && ActivityLobby.IsActicityAvailable(ActivityType.BUY_NEW_CARD_DIRECT, ActivityCollectionType.NEW_CARD_ACTIVITY))
		{
			OpenRainbowLotteryScene();
		}
		else
		{
			OpenNormalLotteryScene();
		}
	}

	public override void OnExitUI()
	{
		m_LotteryState = LotteryState.None;
		OnDisable();
		AutoHideLobbyCharacter.ReleaseHiding();
	}

	private void SetUIElementActive(bool active)
	{
		m_Alpha.alpha = (active ? 1 : 0);
		m_Alpha.blocksRaycasts = active;
		if (m_Effect != null)
		{
			m_Effect.SetActive(active);
		}
	}

	private IEnumerator Play(CardLotteryItem box, Action action)
	{
		PlayingAnimiation = true;
		m_OnCompleteMove = action;
		SetUIElementActive(active: false);
		LobbyScene.Inst.ShowOtherLotteryItems(box, show: false);
		box.transform.DOLocalMoveX(0f, 0f);
		yield return Yielders.EndOfFrame;
		if (BoxOpenUI.Skip)
		{
			box.PlayAgainAnimation();
		}
		else
		{
			box.PlayOpenAnimation();
			float seconds = m_RiseDelayOffset + ((box.Type == CardLotteryType.Normal) ? 1.4f : ((box.Type == CardLotteryType.Advanced) ? 1.43f : 2f));
			yield return Yielders.GetWaitForSeconds(seconds);
			box.PlayExplosionEffect();
		}
		float duration = BoxOpenUI.Skip ? 0f : m_RiseDuration;
		m_CurrentLotteryItem.transform.DOLocalRotate(m_RotationOffset, duration);
		m_CurrentLotteryItem.transform.DOScale(0.8f, duration);
		m_CurrentLotteryItem.transform.DOLocalMove(m_BoxMoveOffset, duration);
		OnOpenComplete();
		PlayingAnimiation = false;
	}

	private void OnOpenComplete()
	{
		if (m_OnCompleteMove != null)
		{
			m_OnCompleteMove();
			m_OnCompleteMove = null;
		}
	}

	private void ResetBoxState(CardLotteryItem box)
	{
		box.ResetToStart();
		LobbyScene.Inst.ShowOtherLotteryItems(box, show: true);
		SetUIElementActive(active: true);
	}

	public void PlayAgain()
	{
		m_CurrentLotteryItem.PlayAgainAnimation();
	}

	public static void ClearLastOpenLotteryFlag()
	{
		m_isLastOpenNormalLottery = false;
	}

	public void OnOpenBox(int boxID, UILobbyElement openUI, CardLotteryItem lotteryItem, ItemInfo[] items)
	{
		m_CurrentLotteryItem = lotteryItem;
		if (m_CurrentLotteryItem.Type == CardLotteryType.Rainbow)
		{
			OpenRainbowLotteryScene(withNormalBackground: true);
		}
		else
		{
			OpenNormalLotteryScene();
		}
		StartCoroutine(Play(lotteryItem, delegate
		{
			m_IsOpening = true;
			UILobby.Current.ShowUI(openUI, BoxUtility.BoxOpenUIArgsWraper(boxID, items)).OnCloseOnce = delegate
			{
				m_isLastOpenNormalLottery = (m_CurrentLotteryItem.Type != CardLotteryType.Rainbow);
				m_IsOpening = false;
				LobbyScene.Inst.m_SceneRoot.gameObject.SetActive(value: true);
				ResetBoxState(lotteryItem);
				if (m_CurrentLotteryItem.Type == CardLotteryType.Rainbow)
				{
					OpenRainbowLotteryScene();
				}
			};
		}));
	}

	public static void OpenRainbowLotteryScene(bool withNormalBackground = false)
	{
		LobbyScene.Inst.m_CardLotteryPanel.PrefabRoot.Find("RainbowLottery").gameObject.SetActive(value: true);
		LobbyScene.Inst.m_CardLotteryPanel.Root.transform.Find("Orbit/SupplyBoxBgForRainbowLottery").gameObject.SetActive(!withNormalBackground);
		LobbyScene.Inst.m_CardLotteryPanel.PrefabRoot.Find("NormalLottery").gameObject.SetActive(value: false);
		LobbyScene.Inst.m_CardLotteryPanel.Root.transform.Find("Orbit/SupplyBoxBg").gameObject.SetActive(withNormalBackground);
		if (Inst != null)
		{
			Inst.m_NormalLotteryTicket.SetActive(value: false);
			Inst.m_AdvanceLotteryTicket.SetActive(value: false);
			Inst.m_SuperLotteryTicket.SetActive(value: false);
			Inst.m_RainbowLotteryTicket.SetActive(value: true);
			Inst.m_TemplateInitiatorForRainbowCardLottery.gameObject.SetActive(value: true);
			Inst.m_TemplateInitiator.gameObject.SetActive(value: false);
		}
	}

	public static void OpenNormalLotteryScene()
	{
		LobbyScene.Inst.m_CardLotteryPanel.PrefabRoot.Find("RainbowLottery").gameObject.SetActive(value: false);
		LobbyScene.Inst.m_CardLotteryPanel.Root.transform.Find("Orbit/SupplyBoxBgForRainbowLottery").gameObject.SetActive(value: false);
		LobbyScene.Inst.m_CardLotteryPanel.PrefabRoot.Find("NormalLottery").gameObject.SetActive(value: true);
		LobbyScene.Inst.m_CardLotteryPanel.Root.transform.Find("Orbit/SupplyBoxBg").gameObject.SetActive(value: true);
		if (Inst != null)
		{
			Inst.m_NormalLotteryTicket.SetActive(value: true);
			Inst.m_AdvanceLotteryTicket.SetActive(value: true);
			Inst.m_SuperLotteryTicket.SetActive(value: true);
			Inst.m_RainbowLotteryTicket.SetActive(value: false);
			Inst.m_TemplateInitiatorForRainbowCardLottery.gameObject.SetActive(value: false);
			Inst.m_TemplateInitiator.gameObject.SetActive(value: true);
		}
	}
}
