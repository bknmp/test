using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_Content
{
	public UIDataBinder m_Host;

	public UIStateItem m_ActiveStatus;

	public Button m_SetActiveCharacterBtn;

	public Button m_LeftBtn;

	public Button m_RightBtn;

	public Text m_Price;

	public Button m_BuyButton;

	public UIPopup m_BuyGoodsUI;

	public UIStateImage m_PriceIcon;

	public GameObject m_SetActiveEffect;

	public Text m_CharacterName;

	public Button m_TryCharacter;

	public Button m_VideoButton;

	public Button m_CommentButton;

	public UIPage m_CharacterVideoUI;

	public UIPopup m_CommentUI;

	public UIStateItem m_Role;

	public Button m_TryCharacterButtonBig;

	public UITabPage m_TabPage;

	public CharacterDetailUI m_CharacterDetailUI;

	public GameObject m_PreviewingButton;

	public Button m_BuyCharacterByActivity;

	public GameObject m_ComingSoon;

	public Button m_FreeCharacterBtn;

	public UIStateItem m_StateItem;

	public Text m_CurrentPrice;

	public Text m_OriginalPrice;

	public UIStateImage m_Good;

	public UIPopup m_CharacterActivityBuyUI;

	private ShopInfo m_ShopInfo;

	public void Bind(CommonDataCollection args)
	{
		if (!m_CharacterDetailUI.m_Init)
		{
			m_TabPage.SetSelectedTabIndex(args["arg"]);
			args["arg"] = 0;
			m_CharacterDetailUI.m_Init = true;
		}
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		m_CharacterName.text = characterInfo.Name;
		m_Role.State = (int)characterInfo.Role;
		UpdateStatus();
		m_Host.EventProxy(m_FreeCharacterBtn, "SetActiveCharacter");
		m_Host.EventProxy(m_SetActiveCharacterBtn, "SetActiveCharacter");
		m_Host.EventProxy(m_BuyCharacterByActivity, "OnClickBuyCharacterByActivity");
		m_Host.EventProxy(m_LeftBtn, "OnClickLast");
		m_Host.EventProxy(m_RightBtn, "OnClickNext");
		UpdateChangeCharacterBtns(ArrayUtility.IndexOf(CharacterUI_PageSelectCharacter.CharacterList.ToArray(), CharacterUI_SelectCharacterItemTemplate.globalSelected));
		m_Host.EventProxy(m_TryCharacter, "TryCharacter");
		m_Host.EventProxy(m_TryCharacterButtonBig, "TryCharacter");
		m_Host.EventProxy(m_VideoButton, "OnClickVideoBtn");
		m_Host.EventProxy(m_CommentButton, "OnClickComment");
		m_PreviewingButton.gameObject.SetActive(CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected));
		m_TryCharacter.gameObject.SetActive(CharacterUtility.IsOwnForeverCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected));
		m_TryCharacterButtonBig.gameObject.SetActive(!CharacterUtility.IsOwnForeverCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected));
		if (m_BuyButton.gameObject.activeSelf)
		{
			List<int> list = CharacterDiscountUtility.DiscountActivitys();
			if (list.Count > 0)
			{
				CheckDiscount(list);
				return;
			}
			m_StateItem.State = 0;
			m_Host.EventProxy(m_BuyButton, "OnClickBuy");
		}
	}

	private void CheckDiscount(List<int> activityIDs, int count = 0)
	{
		CharacterDiscountUtility.TryRefreshActivityInfo(activityIDs[count], delegate
		{
			int characterID = (m_ShopInfo.Id == 1001) ? 1000 : m_ShopInfo.Id;
			if (CharacterDiscountUtility.CacheInfo != null && CharacterDiscountUtility.IsCollectionCharacter(activityIDs[count], characterID))
			{
				m_StateItem.State = 1;
				m_CurrentPrice.text = CharacterDiscountUtility.GetCharacterOnlyPackageCurrentPrice(activityIDs[count], characterID).ToString();
				m_Host.EventProxy(m_BuyButton, "OnDiscountButtonClick", activityIDs[count]);
			}
			else
			{
				m_StateItem.State = 0;
				m_Host.EventProxy(m_BuyButton, "OnClickBuy");
				count++;
				if (count < activityIDs.Count)
				{
					CheckDiscount(activityIDs, count);
				}
			}
		}, null);
	}

	public void SetActiveCharacter()
	{
		CharacterUtility.SetActiveCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		PoolSpawner.Spawn(m_SetActiveEffect, LobbyScene.Inst.CurrentCharacter.transform);
		UILobby.Current.GoHome();
	}

	public void OnClickLast()
	{
		int num = ArrayUtility.IndexOf(CharacterUI_PageSelectCharacter.CharacterList.ToArray(), CharacterUI_SelectCharacterItemTemplate.globalSelected);
		if (num != 0)
		{
			num--;
			UpdateSelectedCharacter(num);
		}
	}

	public void OnClickNext()
	{
		int num = ArrayUtility.IndexOf(CharacterUI_PageSelectCharacter.CharacterList.ToArray(), CharacterUI_SelectCharacterItemTemplate.globalSelected);
		if (num != CharacterUI_PageSelectCharacter.CharacterList.Count - 1)
		{
			num++;
			UpdateSelectedCharacter(num);
		}
	}

	private void OnComeBackUI()
	{
		if (LobbyScene.Inst.m_CardSkinPanel.Root.gameObject.activeInHierarchy)
		{
			LobbyScene.Inst.ClosePreviewPanels();
		}
	}

	private void UpdateSelectedCharacter(int index)
	{
		TalentUI_TalentButton.SelectedID = -1;
		CharacterUI_SelectCharacterItemTemplate.globalSelected = CharacterUI_PageSelectCharacter.CharacterList[index];
		if (CharacterColorationUI.OnCancelPreview != null)
		{
			CharacterColorationUI.OnCancelPreview();
		}
		PreviewUtility.PreviewCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		LobbyScene.Inst.CurrentCharacter.StartLobbyEntrance();
		LobbyScene.Inst.ResetView();
		UpdateChangeCharacterBtns(index);
		UpdateStatus();
		UIDataEvents.Inst.InvokeEvent("OnCharacterSelectedChange");
	}

	private void UpdateChangeCharacterBtns(int index)
	{
		m_LeftBtn.gameObject.SetActive(index != 0);
		m_RightBtn.gameObject.SetActive(index != CharacterUI_PageSelectCharacter.CharacterList.Count - 1);
	}

	private void UpdateStatus()
	{
		bool flag = CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		m_ActiveStatus.gameObject.SetActive(flag);
		m_FreeCharacterBtn.gameObject.SetActive(CharacterFreeUtility.IsCharacterFree && !flag);
		if (flag)
		{
			m_ActiveStatus.State = 0;
			m_BuyButton.gameObject.SetActive(value: false);
			m_BuyCharacterByActivity.gameObject.SetActive(value: false);
			m_ComingSoon.gameObject.SetActive(value: false);
			return;
		}
		foreach (int item in ShopUtility.CharacterGoods[CharacterUI_SelectCharacterItemTemplate.globalSelected])
		{
			ShopInfo shopInfo = LocalResources.ShopTable.Get(item);
			if (!ShopUtility.ShopInfoNotInTime(shopInfo))
			{
				m_ShopInfo = shopInfo;
				break;
			}
		}
		if (LocalPlayerDatabase.NoticeInfo.isAudit && m_ShopInfo == null)
		{
			m_BuyCharacterByActivity.gameObject.SetActive(value: true);
			m_ComingSoon.gameObject.SetActive(value: false);
			m_BuyButton.gameObject.SetActive(value: false);
		}
		else if (m_ShopInfo.GainType == ShopGainType.Buy)
		{
			if (m_ShopInfo.CostGold > 0f)
			{
				m_Price.text = m_ShopInfo.CostGold.ToString();
				m_PriceIcon.State = 0;
				m_Good.State = 0;
			}
			else if (m_ShopInfo.CostTicket > 0f)
			{
				m_Price.text = m_ShopInfo.CostTicket.ToString();
				m_PriceIcon.State = 1;
				m_Good.State = 1;
			}
			else if (m_ShopInfo.CostDiamond > 0f)
			{
				m_Price.text = m_ShopInfo.CostDiamond.ToString();
				m_PriceIcon.State = 2;
				m_Good.State = 2;
			}
			m_OriginalPrice.text = m_Price.text;
			m_BuyButton.gameObject.SetActive(value: true);
			m_BuyCharacterByActivity.gameObject.SetActive(value: false);
			m_ComingSoon.gameObject.SetActive(value: false);
		}
		else
		{
			m_BuyButton.gameObject.SetActive(value: false);
			bool flag2 = ActivityLobby.IsActicityAvailable(ActivityType.CHARACTER_PREVIEW, ActivityCollectionType.CHARACTER_ACTIVITY);
			m_BuyCharacterByActivity.gameObject.SetActive(flag2);
			m_BuyCharacterByActivity.GetComponentInChildren<Text>().text = m_ShopInfo.GainTips;
			m_ComingSoon.gameObject.SetActive(!flag2);
		}
	}

	public void OnClickBuy()
	{
		UILobby.Current.Popup(m_BuyGoodsUI);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection[commonDataCollection.ArraySize]["Id"] = m_ShopInfo.Id;
		UILobby.Current.CurrentPopup().GetComponent<UIDataBinder>().Args = commonDataCollection;
	}

	public void OnDiscountButtonClick(int activityID)
	{
		int characterID = (m_ShopInfo.Id == 1001) ? 1000 : m_ShopInfo.Id;
		UILobby.Current.ShowUI(m_CharacterActivityBuyUI, CharacterDiscountUtility.GetCollectionArgByCharacterID(activityID, characterID));
	}

	public void TryCharacter()
	{
		int characterID = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		UILobby.Current.ShowMessageBoxYesNo(Localization.TryCharacter, Localization.Yes, Localization.No, "", delegate
		{
			m_Host.StartCoroutine(GameUtility.TryCharacter(characterID));
			GameRuntime.EnteringJumpModuleType = 3;
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.TRY_CHARACTER, characterID.ToString(), CharacterUtility.IsOwnCharacter(characterID) ? "1" : "0");
		}, null);
	}

	public void OnClickVideoBtn()
	{
		int globalSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["characterId"] = globalSelected;
		UILobby.Current.ShowUI(m_CharacterVideoUI, commonDataCollection);
		LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CHARACTER_VIDEO_CLICK, globalSelected.ToString(), CharacterUtility.IsOwnCharacter(globalSelected) ? "1" : "0");
	}

	public void OnClickComment()
	{
		int globalSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		UILobby.Current.ShowUI(m_CommentUI, CommentUIBinder.WrapperCommentData(globalSelected, 3));
		LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CHARACTER_COMMENT_CLICK, globalSelected.ToString(), CharacterUtility.IsOwnCharacter(globalSelected) ? "1" : "0");
	}

	public void OnClickBuyCharacterByActivity()
	{
		if (!ActivityLobby.IsActicityAvailable(ActivityType.CHARACTER_PREVIEW, ActivityCollectionType.CHARACTER_ACTIVITY))
		{
			m_Host.UpdateBinding();
		}
		else
		{
			JumpModuleManager.Inst.DoJump(JumpModule.CharacterActivity).GetComponent<CharacterActivityUI>().JumpTabByActivityType(ActivityType.CHARACTER_PREVIEW);
		}
	}
}
