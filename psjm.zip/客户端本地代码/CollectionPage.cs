using LightUI;

internal class CollectionPage
{
	public UIDataBinder m_Host;

	public UITabPage m_TabPages;

	private CommonDataCollection m_Args;

	public void Bind(CommonDataCollection args)
	{
		m_Args = args;
		m_TabPages.SetSelectedTabIndex(0);
		OnTabChange();
		m_Host.EventProxy(m_TabPages, "OnTabChange");
	}

	public void OnTabChange()
	{
		m_TabPages.m_Buttons[m_TabPages.GetSelectedTabIndex()].m_TabContent.GetComponent<UIDataBinder>().Args = m_Args;
	}
}
