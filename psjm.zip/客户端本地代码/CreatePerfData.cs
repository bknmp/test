using UnityEngine;

[SerializeField]
public class CreatePerfData
{
	public string roomName;

	public int mode;

	public int map;

	public int thiefCount = 4;

	public int policeCount = 1;
}
