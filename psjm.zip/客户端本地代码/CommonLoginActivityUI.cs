using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CommonLoginActivityUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiator;

	public Text m_Title;

	public Button m_FinalRewardButton;

	public UIStateItem m_FinalDayIndexState;

	public Text m_FinalDayText;

	public Button m_Mask;

	public GameObject m_AvailabFX;

	public Text m_GetRewardBtnText;

	public Button m_DetailBtn;

	public UIPage m_PreviewDetailUI;

	public UITipsDialogController m_Tips;

	public UIStateItem m_BtnState;

	public Button m_NextDayGetRewardBtn;

	public UIDataBinder m_DayItem;

	public UIDataBinder m_DayItem2;

	public UIDataBinder m_DayItem3;

	private DropItem m_RewardInfo;

	private string m_TimeFormat;

	private string prefabName;

	private int m_ActivityId;

	private Activity m_Activity;

	private int m_Type;

	private int m_Index;

	public void Bind(CommonDataCollection args)
	{
		if (TryGetActivityIdByPrefabName())
		{
			CommonLoginActivityUtility.TryRefreshActivityInfo(m_ActivityId, delegate
			{
				m_Type = ((!(m_FinalRewardButton != null)) ? 1 : 0);
				if (m_Type.Equals(0))
				{
					if (m_GetRewardBtnText == null)
					{
						m_GetRewardBtnText = m_FinalRewardButton.GetComponentInChildren<Text>();
					}
					m_Host.EventProxy(m_DetailBtn, "OnClickDetailBtn");
				}
				SetInfo();
				if (m_TemplateInitiator != null)
				{
					m_TemplateInitiator.Args = WrapData();
				}
				else
				{
					m_DayItem.Args = WrapData2(0);
					m_DayItem2.Args = WrapData2(1);
					m_DayItem3.Args = WrapData2(2);
				}
				if (m_Type.Equals(0))
				{
					SpecialFinalDayHandle();
				}
			});
		}
	}

	private void SetInfo()
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Title.text;
		}
		m_Title.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(m_Activity.startTime), UITimeText.GetDateTime(m_Activity.endTime));
	}

	private bool TryGetActivityIdByPrefabName()
	{
		if (string.IsNullOrEmpty(prefabName))
		{
			prefabName = m_Host.name;
			if (int.TryParse(prefabName.Split('_')[1].Replace("(Clone)", ""), out m_ActivityId))
			{
				m_Activity = ActivityLobby.GetActivityById(m_ActivityId);
				if (m_Activity == null)
				{
					return false;
				}
				return true;
			}
		}
		return true;
	}

	private void AvailableHandle()
	{
		if (CommonLoginActivityUtility.isNextDayRewardAvailable(m_ActivityId, m_Index))
		{
			m_BtnState.State = 2;
			m_Host.EventProxy(m_NextDayGetRewardBtn, "OnGetRewardNextDayBtnClick");
			return;
		}
		m_AvailabFX.gameObject.SetActive(CommonLoginActivityUtility.isRewardAvailable(m_ActivityId, m_Index));
		m_BtnState.State = (m_AvailabFX.gameObject.activeSelf ? 1 : 0);
		if (m_BtnState.State == 1)
		{
			m_Host.EventProxy(m_FinalRewardButton, "OnFinalRewardButtonClick");
		}
	}

	private void ClaimHandle()
	{
		if (CommonLoginActivityUtility.isRewardReceive(m_ActivityId, CommonLoginActivityUtility.GetFinalDayIndex(m_ActivityId)))
		{
			m_Mask.gameObject.SetActive(value: true);
			m_FinalRewardButton.gameObject.SetActive(value: false);
		}
	}

	private void SpecialFinalDayHandle()
	{
		if (m_FinalDayIndexState != null && m_FinalDayIndexState.gameObject.activeSelf)
		{
			m_FinalRewardButton.gameObject.SetActive(CommonLoginActivityUtility.IsFinish(m_ActivityId));
			if (m_FinalDayIndexState.State == 0)
			{
				m_FinalDayText.text = string.Format(Localization.LoginActivityTitle_Day, CommonLoginActivityUtility.GetFinalDayIndex(m_ActivityId));
			}
			m_Index = CommonLoginActivityUtility.GetFinalDayIndex(m_ActivityId);
			AvailableHandle();
			ClaimHandle();
			m_Host.EventProxy(m_Mask, "OnMaskClick");
		}
	}

	public void OnFinalRewardButtonClick()
	{
		if (IsActivityAvailable(m_ActivityId))
		{
			CommonLoginActivityUtility.GetFinalReward(m_ActivityId, delegate
			{
				m_Host.UpdateBinding();
			});
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}
	}

	public void OnGetRewardNextDayBtnClick()
	{
		UILobby.Current.ShowTips(Localization.NextDayAvailableHint);
	}

	public void OnClickDetailBtn()
	{
		if (IsActivityAvailable(m_ActivityId))
		{
			if (m_RewardInfo == null)
			{
				CommonLoginActivityRewardInfo commonLoginActivityRewardInfo = LocalResources.CommonLoginActivityRewardTable.Find((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(m_ActivityId) && x.Days.Equals(m_Index));
				m_RewardInfo = LocalResources.DropItemTable.Get(commonLoginActivityRewardInfo.ItemId[0]);
			}
			CommonDataCollection argWarpper = PreviewDetailUI.GetArgWarpper(m_RewardInfo.Id, string.Empty, string.Empty, 0, 0, string.Empty, null);
			UILobby.Current.ShowUI(m_PreviewDetailUI, argWarpper);
		}
	}

	public void OnMaskClick()
	{
		UILobby.Current.ShowTips(Localization.hadClaim);
	}

	private bool IsActivityAvailable(int activityID)
	{
		if (ActivityLobby.GetActivityById(activityID) == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return false;
		}
		return true;
	}

	protected CommonDataCollection WrapData()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		List<CommonLoginActivityRewardInfo> list = LocalResources.CommonLoginActivityRewardTable.FindAll((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(m_ActivityId));
		int num = (m_Type == 0) ? (list.Count - 1) : list.Count;
		for (int i = 0; i < num; i++)
		{
			commonDataCollection[i]["activityId"] = list[i].ActivityId;
			commonDataCollection[i]["index"] = list[i].Days;
			commonDataCollection[i]["type"] = m_Type;
		}
		return commonDataCollection;
	}

	protected CommonDataCollection WrapData2(int index)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		List<CommonLoginActivityRewardInfo> list = LocalResources.CommonLoginActivityRewardTable.FindAll((CommonLoginActivityRewardInfo x) => x.ActivityId.Equals(m_ActivityId));
		commonDataCollection["activityId"] = list[index].ActivityId;
		commonDataCollection["index"] = list[index].Days;
		commonDataCollection["type"] = m_Type;
		return commonDataCollection;
	}
}
