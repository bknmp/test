public enum BindListState
{
	Apply,
	Bind,
	TimeOut,
	New,
	Old,
	CanCallBack
}
