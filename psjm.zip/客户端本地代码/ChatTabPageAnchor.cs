public class ChatTabPageAnchor : TabPageAnchor
{
	public bool m_UpdateChanged;

	private void OnEnable()
	{
		m_TabPage.gameObject.SetActive(value: true);
	}

	private void OnDisable()
	{
		m_TabPage.gameObject.SetActive(value: false);
	}
}
