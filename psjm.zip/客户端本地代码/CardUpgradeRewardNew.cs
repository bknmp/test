using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CardUpgradeRewardNew
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	public Button m_LotteryButton;

	public MultiTargetGraphicButton m_DropProbabilityButton;

	public UIDataBinder m_Preview;

	public Text m_Time;

	private string m_TimeFormat;

	private CommonDataCollection m_rewardArgs = new CommonDataCollection();

	private static HttpResponseCardUpgradeRewardActivity m_Infos;

	private static bool m_RedPointFlag;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		m_Host.EventProxy(m_LotteryButton, "OnClickLotteryButton");
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.NEW_CARD_UPGRADE_REWARD, ActivityCollectionType.NEW_CARD_ACTIVITY);
		if (activityByActivityTypeAndCollectionType != null)
		{
			LocalPlayerDatabase.SetPrefValue("CardUpgradeRewardActivityNew", activityByActivityTypeAndCollectionType.startTime);
			m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activityByActivityTypeAndCollectionType.startTime), UITimeText.GetDateTime(activityByActivityTypeAndCollectionType.endTime));
		}
		RefreshInfo();
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		SetPreview();
	}

	private void SetPreview()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["dropItem"].val = LocalResources.DropItemTable.Get(19);
		m_Preview.Args = commonDataCollection;
	}

	private void OnDisable()
	{
		CameraOrbit component = LobbyScene.Inst.m_CardSkinPanel.Camera.GetComponent<CameraOrbit>();
		component.OrbitClampX = 50f;
		component.OrbitClampY = 50f;
		component.GetComponent<CameraRotation>().enabled = true;
	}

	public static void TryRefreshCardUpgradeReward()
	{
		if (ActivityLobby.IsActicityAvailable(ActivityType.NEW_CARD_UPGRADE_REWARD, ActivityCollectionType.NEW_CARD_ACTIVITY))
		{
			HttpRequestCardUpgradeRewardActivity request = new HttpRequestCardUpgradeRewardActivity();
			GameHttpManager.Inst.SendNoWait(request, delegate(HttpResponseCardUpgradeRewardActivity OnHttpResponse)
			{
				m_RedPointFlag = false;
				m_Infos = OnHttpResponse;
			});
		}
	}

	private void RefreshInfo()
	{
		CardUpgradeRewardActivityInfo info = new CardUpgradeRewardActivityInfo();
		HttpRequestCardUpgradeRewardActivity requset = new HttpRequestCardUpgradeRewardActivity();
		GameHttpManager.Inst.Send(requset, delegate(HttpResponseCardUpgradeRewardActivity OnHttpResponse)
		{
			m_RedPointFlag = false;
			m_Infos = OnHttpResponse;
			int num = 0;
			while (true)
			{
				if (num >= OnHttpResponse.infos.Length)
				{
					return;
				}
				if (num == 0)
				{
					break;
				}
				num++;
			}
			info = OnHttpResponse.infos[0];
			if (info != null)
			{
				SetInfo(info);
			}
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	private void SetInfo(CardUpgradeRewardActivityInfo info)
	{
		m_rewardArgs.Clear();
		for (int i = 0; i < LocalResources.CardUpgradeReward.Count; i++)
		{
			m_rewardArgs[i]["Id"] = LocalResources.CardUpgradeReward[i].Id;
			m_rewardArgs[i]["CardID"] = LocalResources.CardUpgradeReward[i].CardID;
			m_rewardArgs[i]["Desc"] = LocalResources.CardUpgradeReward[i].Desc;
			m_rewardArgs[i]["itemIds"].val = LocalResources.CardUpgradeReward[i].ItemID;
			m_rewardArgs[i]["itemCounts"].val = LocalResources.CardUpgradeReward[i].ItemCount;
			m_rewardArgs[i]["claimed"] = info.claimed[LocalResources.CardUpgradeReward[i].Id - 1];
			m_rewardArgs[i]["CardUpgradeRewardUI"].val = this;
		}
		m_DataScrollView.m_TemplateInitiator.Args = m_rewardArgs;
	}

	public static bool GetRedPointState()
	{
		if (IsFirstCheck() || m_RedPointFlag)
		{
			return true;
		}
		if (m_Infos == null)
		{
			return false;
		}
		CardUpgradeRewardActivityInfo[] infos = m_Infos.infos;
		foreach (CardUpgradeRewardActivityInfo cardUpgradeRewardActivityInfo in infos)
		{
			int num = CardUtility.IsOwned(cardUpgradeRewardActivityInfo.cardId) ? CardUtility.GetCardLevel(cardUpgradeRewardActivityInfo.cardId) : 0;
			for (int j = 0; j < cardUpgradeRewardActivityInfo.claimed.Length; j++)
			{
				for (int k = 0; k < LocalResources.CardUpgradeReward.Count; k++)
				{
					int num2 = LocalResources.CardUpgradeReward[k].Id - 1;
					if (j == num2 && !cardUpgradeRewardActivityInfo.claimed[j] && num >= j + 1)
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	public static void OnRefreshRedPoint()
	{
		m_RedPointFlag = true;
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	private static bool IsFirstCheck()
	{
		if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.activitys == null)
		{
			return false;
		}
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.NEW_CARD_UPGRADE_REWARD, ActivityCollectionType.NEW_CARD_ACTIVITY);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (activityByActivityTypeAndCollectionType.startTime == LocalPlayerDatabase.GetPrefValueInt("CardUpgradeRewardActivityNew"))
		{
			return false;
		}
		return true;
	}

	public void OnClickLotteryButton()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
	}
}
