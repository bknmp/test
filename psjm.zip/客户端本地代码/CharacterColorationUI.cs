using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;

public class CharacterColorationUI : MonoBehaviour
{
	public static Delegates.VoidCallback OnCancelPreview;

	private void Awake()
	{
		OnCancelPreview = delegate
		{
			SetDefaultSelectedColor();
			UIDataEvents.Inst.InvokeEvent("OnColorSelectedChanged");
		};
	}

	public void SetDefaultSelectedColor()
	{
		PlayerCharacterInfo ownedCharacterInfo = CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		for (int i = 0; i < ownedCharacterInfo.characterID.PartCount(); i++)
		{
			CharacterUtility.FindSkinPart(ownedCharacterInfo.currentSkinInfo, (SkinPartType)i, out int _, out int colorID);
			CharacterUI_PageColoration.Selected[(SkinPartType)i] = colorID;
		}
	}
}
