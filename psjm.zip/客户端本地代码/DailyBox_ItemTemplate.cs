using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class DailyBox_ItemTemplate
{
	public enum DailyBoxType
	{
		Ticket,
		Diamond
	}

	public UIDataBinder m_Host;

	public Text m_Name;

	public Image m_Icon;

	public Text m_Price;

	public UIStateImage m_PriceType;

	public UIStateRawImage m_QualityBG;

	public Text m_DiscountText;

	public Text m_LimitText;

	public Button m_SelectBtn;

	public UIPopup m_DailyBoxUI;

	public GameObject m_AlreadyBought;

	private DailyBoxType m_Type;

	private ShopRecommendInfo m_RecommendInfo;

	private DropItem m_BoxInfo;

	private ShopInfo m_ShopInfo;

	private int[] m_BuyNums;

	private int[] m_BuyLimitNums;

	private bool m_IsEnable;

	private int m_BuyNum;

	private int m_DailyLimitNum;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SelectBtn, "OnClickSelect");
		m_RecommendInfo = (args["ShopRecommendInfo"].val as ShopRecommendInfo);
		if (m_RecommendInfo == null)
		{
			return;
		}
		m_BoxInfo = LocalResources.DropItemTable.Get(m_RecommendInfo.Id);
		if (m_BoxInfo != null)
		{
			m_ShopInfo = LocalResources.ShopTable.Get(m_RecommendInfo.Id);
			if (m_ShopInfo != null)
			{
				m_Name.text = m_BoxInfo.Name;
				m_Icon.sprite = SpriteSource.Inst.Find(m_BoxInfo.Icon);
				m_Type = ((m_ShopInfo.CostTicket == 0f) ? DailyBoxType.Diamond : DailyBoxType.Ticket);
				m_PriceType.State = ((m_Type == DailyBoxType.Ticket) ? 1 : 2);
				m_QualityBG.State = m_BoxInfo.Quality;
				m_DiscountText.text = m_ShopInfo.Discount.ToString() + Localization.Discount;
				float num = (m_Type == DailyBoxType.Ticket) ? m_ShopInfo.CostTicket : m_ShopInfo.CostDiamond;
				m_Price.text = num.ToString();
				m_BuyNums = (args["BuyNums"].val as int[]);
				m_BuyLimitNums = (args["BuyLimitNums"].val as int[]);
				SetCanBuy();
			}
		}
	}

	private void SetCanBuy()
	{
		if (m_BuyNums != null && m_BuyLimitNums != null)
		{
			m_BuyNum = m_BuyNums[(int)m_Type];
			m_DailyLimitNum = m_BuyLimitNums[(int)m_Type];
			m_IsEnable = ((m_DailyLimitNum > m_BuyNum) ? true : false);
			m_PriceType.gameObject.SetActive(m_IsEnable);
			m_LimitText.text = string.Format(Localization.LimitBuy, m_BuyNum, m_DailyLimitNum);
			m_Price.gameObject.SetActive(m_IsEnable);
			m_AlreadyBought.SetActive(!m_IsEnable);
		}
	}

	public void OnClickSelect()
	{
		if (!m_IsEnable)
		{
			UILobby.Current.ShowTips(Localization.CantBuyDailyBox);
			return;
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["ShopRecommendInfo"].val = m_RecommendInfo;
		commonDataCollection["IsEnable"].val = m_IsEnable;
		commonDataCollection["AlreadyBuyNum"].val = m_BuyNum;
		commonDataCollection["DailyLimitNum"].val = m_DailyLimitNum;
		UILobby.Current.ShowUI(m_DailyBoxUI, commonDataCollection);
		if (m_Type == DailyBoxType.Ticket)
		{
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.DAILY_BOX_TICKET_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString());
		}
		else
		{
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.DAILY_BOX_DIAMOND_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString());
		}
	}
}
