using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardUpgradeReward_CardUpgradeRewardItem
{
	public UIDataBinder m_Host;

	public Text m_Level;

	public Image m_Frame;

	public Image m_Icon;

	public Text m_Amount;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public GameObject m_HadClaim;

	public Button m_ClaimBtn;

	public UITipsDialogController m_tips;

	public Button m_DetailBtn;

	public UIPage m_PreviewDetailUI;

	public UIStateImage m_State;

	public GameObject m_Effect;

	private string m_levelFormat;

	private int m_cardID;

	private int m_index;

	private int m_itemID;

	private int m_itemCount;

	private bool m_claimed;

	private int m_cardLevel;

	private CardUpgradeRewardActivity m_cardUpgradeRewardUI;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_levelFormat))
		{
			m_levelFormat = m_Level.text;
		}
		m_cardID = args["cardID"];
		m_itemID = args["itemId"];
		m_itemCount = args["itemCount"];
		m_index = args["index"];
		m_claimed = args["claimed"];
		m_cardLevel = args["cardLevel"];
		m_cardUpgradeRewardUI = (args["CardUpgradeRewardUI"].val as CardUpgradeRewardActivity);
		m_Level.text = string.Format(m_levelFormat, m_index + 1);
		DropItem dropItem = LocalResources.DropItemTable.Get(m_itemID);
		m_Frame.sprite = SpriteSource.Inst.Find(dropItem.Frame);
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_tips.SetDropItemTips(m_itemID);
		m_Amount.text = BuyGoodsUI_ItemTemplate.GetUnitString(dropItem, m_itemCount);
		m_ClaimBtn.gameObject.SetActive(!m_claimed && m_cardLevel >= m_index + 1);
		m_HadClaim.SetActive(m_claimed);
		m_Host.EventProxy(m_ClaimBtn, "OnClickClaim");
		if (m_claimed)
		{
			m_State.State = 2;
		}
		else if (m_cardLevel >= m_index + 1)
		{
			m_State.State = 1;
		}
		else
		{
			m_State.State = 0;
		}
		m_Effect.gameObject.SetActive(dropItem.Quality == 3 && !m_claimed);
		if (m_DetailBtn != null)
		{
			DropItemType type = LocalResources.DropItemTable.Get(m_itemID).Type;
			if (type == DropItemType.SkinPart || type == DropItemType.Character || type == DropItemType.CardSkin || type == DropItemType.SkinSuite || type == DropItemType.IngameEmotion)
			{
				m_Host.EventProxy(m_DetailBtn, "OnShowDetailUI");
			}
		}
	}

	public void OnClickClaim()
	{
		if (m_claimed)
		{
			UILobby.Current.ShowTips(Localization.hadClaim);
			return;
		}
		if (m_cardLevel < m_index + 1)
		{
			UILobby.Current.ShowTips(Localization.CantClaim);
			return;
		}
		HttpRequestClaimCardUpgradeRewardActivity httpRequestClaimCardUpgradeRewardActivity = new HttpRequestClaimCardUpgradeRewardActivity();
		httpRequestClaimCardUpgradeRewardActivity.cardId = m_cardID;
		httpRequestClaimCardUpgradeRewardActivity.level = m_index + 1;
		GameHttpManager.Inst.Send(httpRequestClaimCardUpgradeRewardActivity, delegate(HttpResponseClaimCardUpgradeRewardActivity onResponse)
		{
			m_cardUpgradeRewardUI.m_Host.UpdateBinding();
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.AddItems(onResponse.items);
			commonRewardPopupUI.SetTitleAndTips("", "");
		});
	}

	public void OnShowDetailUI()
	{
		CommonDataCollection argWarpper = PreviewDetailUI.GetArgWarpper(m_itemID, string.Empty, "", 0, 0, string.Empty, null);
		UILobby.Current.ShowUI(m_PreviewDetailUI, argWarpper);
	}
}
