using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BoxItemProBar : MonoBehaviour
{
	public GameObject m_ProLable;

	public Image m_ProImage;

	public GameObject m_Arrow;

	public GameObject m_CanComposeText;

	public GameObject m_BarProEffect;

	public bool m_Show;

	public void SetProBarInfo(float numerator, float denominator)
	{
		if (m_CanComposeText != null)
		{
			m_CanComposeText.SetActive(value: false);
		}
		m_Show = true;
		m_ProLable.GetComponent<Text>().text = $"{numerator.FormatAmount()}/{denominator.FormatAmount()}";
		float num = numerator / denominator;
		if (num < 1f)
		{
			m_ProLable.GetComponent<Outline>().effectColor = new Color(0.156f, 0.168f, 0.47f, 1f);
			m_ProImage.GetComponent<UIStateImage>().State = 0;
			m_Arrow.GetComponent<UIStateImage>().State = 0;
			m_ProImage.fillAmount = num;
			m_BarProEffect.GetComponent<UIStateItem>().State = 0;
			m_BarProEffect.SetActive(value: true);
			if (num < 0.06f)
			{
				m_ProImage.fillAmount = 0.06f;
			}
		}
		else
		{
			m_ProLable.GetComponent<Outline>().effectColor = new Color(0.047f, 0.4549f, 0.0117f, 1f);
			m_ProImage.fillAmount = 1f;
			m_ProImage.GetComponent<UIStateImage>().State = 1;
			m_Arrow.GetComponent<UIStateImage>().State = 1;
			m_BarProEffect.GetComponent<UIStateItem>().State = 1;
			m_BarProEffect.SetActive(value: true);
			if (m_CanComposeText != null)
			{
				m_CanComposeText.SetActive(value: true);
			}
		}
	}
}
