using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChannelActivityButton : MonoBehaviour
{
	public LayoutElement m_Element;

	public UIStateItem m_ActivityItem;

	public UIStateImage m_StImage;

	public UIPopup m_HykbPopup;

	public UIPopup m_M4399Popup;

	public UIPopup m_TmgpPopup;

	public GameObject m_RedPoint;

	private List<PlatformID> m_Entries = new List<PlatformID>
	{
		PlatformID.Hykb,
		PlatformID.M4399,
		PlatformID.PC4399,
		PlatformID.Tmgp
	};

	private ChannelActivity m_ChannelActivity;

	private void Awake()
	{
		m_RedPoint.SetActive(value: false);
		UIDataEvents.Inst.AddEventListener("OnActivityLobbyRedPointChange", this, UpdateRedPoint);
	}

	private void Start()
	{
		if (LocalPlayerDatabase.Settings == null || (LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice < LocalPlayerDatabase.Settings.loginAwardUnlockGrade && LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief < LocalPlayerDatabase.Settings.loginAwardUnlockGrade))
		{
			return;
		}
		int num = m_Entries.IndexOf(LocalPlayerDatabase.LoginPlatformID);
		if (num > -1)
		{
			m_StImage.State = num;
			m_ActivityItem.State = num;
			m_ChannelActivity = LocalPlayerDatabase.Settings.channelActivity;
			if (m_ChannelActivity != null && m_ChannelActivity.enable)
			{
				bool flag = UtcTimeStamp.Now >= m_ChannelActivity.startTime && UtcTimeStamp.Now <= m_ChannelActivity.endTime;
				ShowElement(flag);
				if (UtcTimeStamp.Now < m_ChannelActivity.startTime)
				{
					Invoke("Show", Mathf.Max(0, m_ChannelActivity.startTime - UtcTimeStamp.Now));
				}
			}
			else
			{
				Hide();
			}
		}
		else
		{
			base.gameObject.SetActive(value: false);
		}
	}

	private void ShowElement(bool flag)
	{
		if (flag)
		{
			Show();
		}
		else
		{
			Hide();
		}
	}

	private void UpdateRedPoint()
	{
		PlatformID loginPlatformID = LocalPlayerDatabase.LoginPlatformID;
		if (loginPlatformID == PlatformID.Tmgp)
		{
			string a = UtcTimeStamp.NowDateTime.ToShortDateString();
			bool flag = a == LocalPlayerDatabase.GetPrefValueString("Tmgp_Url");
			bool flag2 = a == LocalPlayerDatabase.GetPrefValueString("Tmgp_Reward");
			m_RedPoint.SetActive(!flag || !flag2);
		}
	}

	private void RequestRedPoint()
	{
		if (LocalPlayerDatabase.LoginPlatformID == PlatformID.Tmgp)
		{
			if (!(UtcTimeStamp.NowDateTime.ToShortDateString() == LocalPlayerDatabase.GetPrefValueString("Tmgp_Reward")))
			{
				HttpRequestCommonProgressActivity httpRequestCommonProgressActivity = new HttpRequestCommonProgressActivity();
				httpRequestCommonProgressActivity.type = 4;
				GameHttpManager.Inst.Send(httpRequestCommonProgressActivity, delegate(HttpResponseCommonProgressActivity res)
				{
					if (res.infos.Length != 0)
					{
						LocalPlayerDatabase.SetPrefValue("Tmgp_Reward", (!res.infos[0].received) ? "" : UtcTimeStamp.NowDateTime.ToShortDateString());
						UpdateRedPoint();
					}
				});
			}
			LocalPlayerDatabase.ReportEvent(GameMessages.Event.TMGP_ACTIVITY, 1.ToString());
		}
	}

	private void Show()
	{
		m_Element.ignoreLayout = false;
		m_ActivityItem.gameObject.SetActive(value: true);
		Invoke("Hide", Mathf.Max(0, m_ChannelActivity.endTime - UtcTimeStamp.Now));
		RequestRedPoint();
	}

	private void Hide()
	{
		m_Element.ignoreLayout = true;
		m_ActivityItem.gameObject.SetActive(value: false);
	}

	public void OnClick()
	{
		string textureUrl = LocalPlayerDatabase.Settings.channelActivity.textureUrl;
		UnityEngine.Debug.Log("openUrl:" + textureUrl);
		switch (LocalPlayerDatabase.LoginPlatformID)
		{
		case PlatformID.Hykb:
			if (textureUrl != null && textureUrl.StartsWith("http"))
			{
				CommonDataCollection commonDataCollection2 = new CommonDataCollection();
				commonDataCollection2["imageUrl"] = textureUrl;
				commonDataCollection2["time"] = LocalPlayerDatabase.Settings.channelActivity.text;
				UILobby.Current.ShowUI(m_HykbPopup, commonDataCollection2);
			}
			break;
		case PlatformID.M4399:
			if (textureUrl != null && textureUrl.StartsWith("http"))
			{
				CommonDataCollection commonDataCollection3 = new CommonDataCollection();
				commonDataCollection3["imageUrl"] = textureUrl;
				commonDataCollection3["time"] = LocalPlayerDatabase.Settings.channelActivity.text;
				UILobby.Current.ShowUI(m_M4399Popup, commonDataCollection3);
			}
			break;
		case PlatformID.PC4399:
			Application.OpenURL("http://huodong2.4399.com/funnycore/runjuvenile/");
			break;
		case PlatformID.Tmgp:
			if (!string.IsNullOrEmpty(textureUrl))
			{
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				commonDataCollection["openUrl"] = textureUrl;
				UILobby.Current.ShowUI(m_TmgpPopup, commonDataCollection);
				LocalPlayerDatabase.ReportEvent(GameMessages.Event.TMGP_ACTIVITY, 2.ToString());
			}
			break;
		}
	}
}
