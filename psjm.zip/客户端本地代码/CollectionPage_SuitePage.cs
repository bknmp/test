using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_SuitePage
{
	public UIDataBinder m_Host;

	public Text m_CollectProgress;

	public Text m_Personality;

	public UITemplateInitiator m_Content;

	public Button m_SwitchButton;

	public GameObject m_SkinPartPanel;

	public GameObject m_PreviewPort;

	public UIScrollRect m_ScrollView;

	public GameObject m_NotHaveTips;

	public Button m_ButtonGain;

	public UIPopup m_BuySuiteUI;

	public UIPopup m_BuyGoodsUI;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	private string m_CollectFormat;

	private int m_AllSuiteNum;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SwitchButton, "OnSwitchButtonClick");
		m_Host.EventProxy(m_ButtonGain, "OnGainButtonClick");
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		m_NotHaveTips.SetActive(value: false);
		m_SkinPartPanel.SetActive(value: false);
		m_PreviewPort.SetActive(value: true);
		m_ButtonGain.gameObject.SetActive(value: false);
		if (m_CollectFormat == null)
		{
			m_CollectFormat = m_CollectProgress.text;
		}
		CollectionPage_SuiteItem.Selected = 0;
		LoadSuitesData();
		m_CollectProgress.text = string.Format(m_CollectFormat, CollectionUtility.GetForeverSuiteCount(m_PlayerInfo, out List<ShopSuiteInfo> _), m_AllSuiteNum);
		int num = CollectionUtility.GetForeverSkinPartItems(m_PlayerInfo).Sum((DropItem a) => a.Personality);
		int num2 = CollectionUtility.GetForeverSkinPartItems_NotInSuite(m_PlayerInfo).Sum((DropItem a) => a.Personality);
		m_Personality.text = Mathf.Max(0, num - num2).ToString();
		m_ScrollView.ScrollToStart(immediately: true);
	}

	public void OnSwitchButtonClick()
	{
		m_SkinPartPanel.SetActive(!m_SkinPartPanel.activeSelf);
		m_PreviewPort.SetActive(!m_PreviewPort.activeSelf);
	}

	private void LoadSuitesData()
	{
		m_AllSuiteNum = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		List<int> list3 = new List<int>();
		ShopSuiteInfo[] array = (from a in LocalResources.ShopSuiteTable
			orderby a.Quality descending, a.Id
			select a).ToArray();
		foreach (ShopSuiteInfo shopSuiteInfo in array)
		{
			int num = shopSuiteInfo.ShopItemIDs.Length;
			if (!CollectionUtility.IsForeverSuite(shopSuiteInfo))
			{
				continue;
			}
			ShopInfo shopInfo = LocalResources.ShopTable.Get(shopSuiteInfo.ShopItemIDs[0]);
			if (shopInfo.SellStartTime == 0 || shopInfo.SellStartTime <= UtcTimeStamp.Now || CollectionUtility.GetSuiteCollectProgress(shopSuiteInfo.Id, m_PlayerInfo).Length != 0)
			{
				int num2 = CollectionUtility.GetSuiteCollectProgress(shopSuiteInfo.Id, m_PlayerInfo).Length;
				if (num2 == num)
				{
					list.Add(shopSuiteInfo.Id);
				}
				else if (num2 < num && num2 > 0)
				{
					list2.Add(shopSuiteInfo.Id);
				}
				else if (num2 == 0)
				{
					list3.Add(shopSuiteInfo.Id);
				}
				m_AllSuiteNum++;
			}
		}
		int num3 = 0;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (list.Count > 0)
		{
			commonDataCollection[num3]["state"] = 0;
			commonDataCollection[num3]["suites"].val = list.ToList();
			commonDataCollection[num3]["roleID"].val = m_PlayerID;
			commonDataCollection[num3]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num3]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num3++;
		}
		if (list2.Count > 0)
		{
			commonDataCollection[num3]["state"] = 1;
			commonDataCollection[num3]["suites"].val = list2;
			commonDataCollection[num3]["roleID"].val = m_PlayerID;
			commonDataCollection[num3]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num3]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num3++;
		}
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID && list3.Count > 0)
		{
			commonDataCollection[num3]["state"] = 2;
			commonDataCollection[num3]["suites"].val = list3.ToList();
			commonDataCollection[num3]["roleID"].val = m_PlayerID;
			commonDataCollection[num3]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num3]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num3++;
		}
		m_Content.Args = commonDataCollection;
		m_Content.UpdateImmediately(withChildren: true);
	}

	public void OnGainButtonClick()
	{
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Find(CollectionPage_SuiteItem.Selected);
		if (shopSuiteInfo.GainType == ShopGainType.Default)
		{
			int characterID2 = shopSuiteInfo.CharacterID;
			CharacterInfo characterInfo = LocalResources.CharacterTable.Find(characterID2);
			string msg = string.Format(Localization.TipsDefaultPartsBuy, CharacterUtility.GetColorRoleName(characterInfo.Role, characterInfo.Name));
			UILobby.Current.ShowMessageBoxYesNo(msg, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				DoBuyCharacter(characterID2);
			}, null);
		}
		else if (shopSuiteInfo.GainType == ShopGainType.Buy)
		{
			if (CharacterUtility.IsOwnCharacter(shopSuiteInfo.CharacterID))
			{
				DoBuySuite(shopSuiteInfo.Id);
				return;
			}
			int characterID = shopSuiteInfo.CharacterID;
			CharacterInfo characterInfo2 = LocalResources.CharacterTable.Find(characterID);
			string msg2 = string.Format(Localization.TipsBuyCharacterFirst, CharacterUtility.GetColorRoleName(characterInfo2.Role, characterInfo2.Name));
			UILobby.Current.ShowMessageBoxYesNo(msg2, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				DoBuyCharacter(characterID);
			}, null);
		}
		else
		{
			UILobby.Current.ShowTips(shopSuiteInfo.GainTips);
		}
	}

	private void DoBuyCharacter(int characterID)
	{
		CharacterUI_SelectCharacterItemTemplate.globalSelected = characterID;
		JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI);
	}

	private void DoBuySuite(int suiteID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["suiteIDs"].val = new List<int>
		{
			suiteID
		};
		BuySuiteUI.ItemSelected = ArrayUtility.Create(5, initialValue: true);
		BuySuiteUI.Reset = true;
		UILobby.Current.ShowUI(m_BuySuiteUI, commonDataCollection);
	}
}
