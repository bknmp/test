using DG.Tweening;
using LightUI;
using LightUtility;
using UnityEngine;

public class ChildTab : MonoBehaviour
{
	public float m_HideSize;

	public float m_ShowSize;

	public UITabButton m_ParentTabButton;

	public UITabPage m_PatentTabPage;

	public UIStateImage m_Arrow;

	public GameObject m_Root;

	public RectTransform m_ParentRect;

	private bool m_childTabShow;

	private UITabPage m_tabPage;

	private UIDataBinder m_targetBinder;

	private Tweener m_Tweener;

	private void Awake()
	{
		m_tabPage = GetComponent<UITabPage>();
		m_targetBinder = m_ParentTabButton.m_TabContent.GetComponent<UIDataBinder>();
		m_ParentTabButton.onButtonClicked.AddListener(OnClick);
		m_tabPage.OnTabChanged.AddListener(OnTabChange);
	}

	private void OnDestroy()
	{
		m_ParentTabButton.onButtonClicked.RemoveListener(OnClick);
		m_PatentTabPage.OnTabChanged.RemoveListener(OnParentTabChange);
		m_tabPage.OnTabChanged.RemoveListener(OnTabChange);
	}

	private void OnEnable()
	{
		m_childTabShow = IsSelected();
		UpdateSkinPartTabsView();
		if (m_childTabShow)
		{
			m_Arrow.State = 1;
		}
		else
		{
			m_Arrow.State = 0;
		}
		m_Arrow.transform.localScale = (m_childTabShow ? Vector3.one : m_Arrow.transform.localScale.FlattenY(-1f));
		OnTabChange();
		m_PatentTabPage.OnTabChanged.AddListener(OnParentTabChange);
	}

	private void OnDisable()
	{
		m_PatentTabPage.OnTabChanged.RemoveListener(OnParentTabChange);
	}

	private void OnClick()
	{
		if (IsSelected())
		{
			m_childTabShow = !m_childTabShow;
			UpdateSkinPartTabsView();
		}
	}

	private void OnParentTabChange()
	{
		if (IsSelected())
		{
			m_Arrow.State = 1;
			return;
		}
		m_Arrow.State = 0;
		if (m_childTabShow)
		{
			m_childTabShow = false;
			UpdateSkinPartTabsView();
		}
	}

	public void UpdateSkinPartTabsView()
	{
		float duration = 0.2f;
		m_Arrow.transform.localScale = (m_childTabShow ? Vector3.one : m_Arrow.transform.localScale.FlattenY(-1f));
		if (m_Tweener != null)
		{
			m_Tweener.Kill();
		}
		if (m_childTabShow)
		{
			int num = 90 * m_Root.GetComponentsInChildren<UITabButton>(includeInactive: false).Length;
			m_ParentRect.DOSizeDelta(new Vector2(m_ParentRect.sizeDelta.x, (float)num + m_HideSize), duration);
			RectTransform component = GetComponent<RectTransform>();
			component.DOSizeDelta(new Vector2(component.sizeDelta.x, num), duration);
			m_Tweener = m_Root.transform.DOScaleY(1f, duration);
			m_Root.gameObject.SetActive(value: true);
		}
		else
		{
			m_Tweener = m_Root.transform.DOScaleY(0f, duration).OnComplete(delegate
			{
				m_Root.gameObject.SetActive(value: false);
			});
			m_ParentRect.DOSizeDelta(new Vector2(m_ParentRect.sizeDelta.x, m_HideSize), duration);
		}
		if (m_tabPage == null)
		{
			m_tabPage = GetComponent<UITabPage>();
		}
		if (m_tabPage != null)
		{
			int selectedTabIndex = m_tabPage.GetSelectedTabIndex();
			if (selectedTabIndex >= 0 && !m_tabPage.m_Buttons[selectedTabIndex].gameObject.activeSelf)
			{
				int selectedTabIndex2 = (m_tabPage.m_Buttons.Count > 5) ? 5 : 0;
				m_tabPage.SetSelectedTabIndex(selectedTabIndex2);
			}
		}
		else
		{
			UnityEngine.Debug.LogError("ChildTab m_TabPage cannot be null");
		}
	}

	private void OnTabChange()
	{
		if (m_targetBinder != null)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["tabIndex"] = m_tabPage.GetSelectedTabIndex();
			m_targetBinder.Args = commonDataCollection;
		}
	}

	private bool IsSelected()
	{
		return m_PatentTabPage.m_Buttons[m_PatentTabPage.GetSelectedTabIndex()] == m_ParentTabButton;
	}

	public void Show()
	{
		m_childTabShow = true;
		m_Root.transform.DOKill();
		m_Root.gameObject.SetActive(value: true);
		UpdateSkinPartTabsView();
	}
}
