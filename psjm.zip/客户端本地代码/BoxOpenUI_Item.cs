using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

internal class BoxOpenUI_Item
{
	public UIDataBinder m_Host;

	public Text m_Card;

	public UIStateImage m_AssetIcon;

	public UINumberGrow m_AssetNumText;

	public UIStateItem m_YourAssets;

	public Animator m_Animator;

	public UIStateItem m_DescState;

	public CardPieceProcessBar m_CardProcessUI;

	public DropItemUI m_Item;

	public Text m_Level;

	public UIStateItem m_Effect;

	public GameObject m_NewCard;

	private string m_CardFormat;

	private string m_LevelFormat;

	private string m_YourAssetsFormat;

	private bool m_PlayAnim;

	public void Bind(CommonDataCollection args)
	{
		if (m_CardFormat == null)
		{
			m_CardFormat = m_Card.text;
		}
		if (m_LevelFormat == null)
		{
			m_LevelFormat = m_Level.text;
		}
		ItemInfo itemInfo = args["ItemInfo"].val as ItemInfo;
		m_PlayAnim = args["playAnim"];
		m_Animator.SetBool("StopAni", !m_PlayAnim);
		DropItem dropItem = LocalResources.DropItemTable.Find(itemInfo.itemID);
		m_Item.SetInfo(itemInfo.itemID, itemInfo.itemCount);
		m_NewCard.SetActive(value: false);
		switch (dropItem.Type)
		{
		case DropItemType.Diamond:
			m_AssetIcon.State = 5;
			m_Host.StartCoroutine(SetNum(LocalPlayerDatabase.PlayerInfo.diamonds, itemInfo.itemCount));
			m_DescState.State = 2;
			m_YourAssets.State = 3;
			break;
		case DropItemType.Gold:
			m_AssetIcon.State = 0;
			m_Host.StartCoroutine(SetNum(LocalPlayerDatabase.PlayerInfo.gold, itemInfo.itemCount));
			m_DescState.State = 2;
			m_YourAssets.State = 0;
			break;
		case DropItemType.ColoringAgent:
			m_AssetIcon.State = 1;
			m_Host.StartCoroutine(SetNum(LocalPlayerDatabase.PlayerInfo.coloringAgentNum, itemInfo.itemCount));
			m_DescState.State = 2;
			m_YourAssets.State = 1;
			break;
		case DropItemType.Ticket:
			m_AssetIcon.State = 2;
			m_Host.StartCoroutine(SetNum(LocalPlayerDatabase.PlayerInfo.tickets, itemInfo.itemCount));
			m_DescState.State = 2;
			m_YourAssets.State = 2;
			break;
		case DropItemType.CardPiece:
		{
			m_Card.text = string.Format(m_CardFormat, Regex.Replace(dropItem.QualityTips, "<.*?>", string.Empty));
			int typeParam = dropItem.TypeParam;
			int cardLevel = CardUtility.GetCardLevel(typeParam);
			m_Level.text = string.Format(m_LevelFormat, cardLevel);
			m_Host.StartCoroutine(SetCard(itemInfo.itemID, itemInfo.itemCount));
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(typeParam);
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID);
			m_Item.m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
			m_NewCard.SetActive(!CardUtility.IsOwned(typeParam));
			break;
		}
		case DropItemType.SkinPart:
			m_DescState.State = 4;
			break;
		case DropItemType.LimitLotteryTicket:
			m_AssetIcon.State = 0;
			m_AssetIcon.GetComponent<Image>().sprite = m_Item.m_Icon.sprite;
			m_Host.StartCoroutine(SetNum(ShopUtility.GetCurrencyAmount(dropItem.TypeParam), itemInfo.itemCount));
			m_DescState.State = 2;
			m_YourAssets.State = 5;
			if (m_YourAssetsFormat == null)
			{
				m_YourAssetsFormat = m_YourAssets.ActiveText.text;
			}
			m_YourAssets.ActiveText.text = string.Format(m_YourAssetsFormat, m_Item.m_ItemName.text);
			break;
		default:
			m_DescState.State = 0;
			break;
		}
		string exchangeTips = itemInfo.GetExchangeTips(Localization.TipsExchangeFormat, dropItem);
		if (!string.IsNullOrEmpty(exchangeTips))
		{
			m_DescState.State = 3;
			m_DescState.ActiveText.text = exchangeTips;
		}
		m_Effect.State = dropItem.Quality;
	}

	private IEnumerator SetNum(int current, int add)
	{
		m_AssetNumText.SetNumber(current);
		while (!m_AssetNumText.gameObject.activeInHierarchy)
		{
			yield return null;
		}
		if (m_PlayAnim)
		{
			m_AssetNumText.GrowTo(current + add);
		}
		else
		{
			m_AssetNumText.SetNumber(current + add);
		}
	}

	private IEnumerator SetCard(int itemID, int itemCount)
	{
		m_DescState.State = 1;
		while (!m_CardProcessUI.gameObject.activeInHierarchy)
		{
			yield return null;
		}
		if (m_PlayAnim)
		{
			m_CardProcessUI.DropCardPiece(itemID, itemCount, tween: true, 0.2f);
		}
		else
		{
			m_CardProcessUI.DropCardPiece(itemID, itemCount, tween: false);
		}
	}
}
