using LightUI;
using UnityEngine.UI;

internal class CharacterDetailUI_LabelItem
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public void Bind(CommonDataCollection args)
	{
		m_Name.text = args["label"];
	}
}
