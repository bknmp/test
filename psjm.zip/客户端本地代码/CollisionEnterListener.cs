using LightUtility;
using UnityEngine;

public class CollisionEnterListener : MonoBehaviour
{
	public Delegates.ObjectCallback<Collision> onCollisionEnter;

	private void OnCollisionEnter(Collision hit)
	{
		if (onCollisionEnter != null)
		{
			onCollisionEnter(hit);
		}
	}
}
