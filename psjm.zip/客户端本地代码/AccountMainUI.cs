using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AccountMainUI : MonoBehaviour
{
	public AccountInfoController m_AccountInfo;

	public Button m_SetPwd;

	public Button m_CloseBtn;

	public Button m_Switch;

	public Button m_Find;

	public Button m_Safe;

	public GameObject m_MailRedPoint;

	private void Awake()
	{
		m_SetPwd.onClick.AddListener(OnSetPwdClick);
		m_Switch.onClick.AddListener(OnSwitchClick);
		m_Find.onClick.AddListener(OnFindClick);
		m_Safe.onClick.AddListener(OnSafeClick);
		m_CloseBtn.onClick.AddListener(CloseUI);
	}

	private void OnEnable()
	{
		Init();
	}

	private void Init()
	{
		bool flag = GameRuntime.ActiveSceneName.Equals("Loading");
		if (AccountUtility.LoginAccountInfo == null)
		{
			m_AccountInfo.gameObject.SetActive(value: false);
			m_Safe.gameObject.SetActive(value: false);
		}
		else
		{
			m_AccountInfo.SetAccountInfo((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName);
			m_AccountInfo.gameObject.SetActive(value: true);
			m_SetPwd.transform.parent.gameObject.SetActive(!flag);
			m_Safe.gameObject.SetActive(!flag && AccountUtility.LoginAccountInfo.isSetPwd);
			m_Safe.GetComponent<UIStateItem>().State = ((!string.IsNullOrEmpty(AccountUtility.LoginAccountInfo.mail)) ? 1 : 0);
			m_SetPwd.GetComponent<UIStateItem>().State = ((!AccountUtility.LoginAccountInfo.isSetPwd) ? 1 : 0);
		}
		m_MailRedPoint.SetActive(AccountUtility.ShowMailRedPoint);
	}

	private void OnSetPwdClick()
	{
		if (!AccountUtility.LoginAccountInfo.isSetPwd)
		{
			AccountSetPwdUI.ShowUI((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName);
		}
		else if (string.IsNullOrEmpty(AccountUtility.LoginAccountInfo.mail))
		{
			UILobby.Current.ShowTips(Localization.TipsBindMail);
			AccountBindMailUI.ShowUI(isBind: true, OnSafeClick);
		}
		else
		{
			AccountMailVerifyUI.ShowUI(MailCodeType.SetPwd, Localization.TipsSetPwdByMail, AccountUtility.LoginAccountInfo.mail, delegate
			{
				AccountSetPwdUI.ShowUI((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName, AccountUtility.MailCodeResponse.codeKey);
			});
		}
	}

	private void OnSwitchClick()
	{
		if (LoginManager.HistoryAccountList == null || LoginManager.HistoryAccountList.Count <= 0)
		{
			AccountLoginUI.ShowUI(AccountUtility.DoSwitchAccount);
		}
		else
		{
			AccountSwitchUI.ShowUI();
		}
	}

	private void OnFindClick()
	{
		AccountFindUI.ShowUI();
	}

	private void OnSafeClick()
	{
		if (string.IsNullOrEmpty(AccountUtility.LoginAccountInfo.mail))
		{
			if (AccountUtility.LoginAccountInfo.isSetPwd)
			{
				AccountBindMailUI.ShowUI(isBind: true, delegate
				{
					AccountSafetyUI.ShowUI();
				});
			}
		}
		else
		{
			AccountSafetyUI.ShowUI();
		}
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI()
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountMainUI");
		UILobby.Current.ShowUI(ui, null);
	}
}
