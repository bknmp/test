using LightUtility;
using System;

[Serializable]
public class CommonRankReward : IdBased
{
	public int Type;

	public int ConditionMin;

	public int ConditionMax;

	public int[] ItemIdList;

	public int[] ItemCountList;
}
