using UnityEngine;

public class AutoRestartChecker : MonoBehaviour
{
	private float m_PauseTime;

	private bool m_IsPausePassively;

	public static int m_AutoRestartTime = 600;

	public static AutoRestartChecker m_Inst;

	private void Start()
	{
		AdSDKManager.m_BeforeShowAd += DoPausePassively;
		PaymentUtility.m_BeforeDoPay += DoPausePassively;
		ShareManager.m_BeforeShare += DoPausePassively;
		LoginUtility.BeforeLogin += DoPausePassively;
		if (m_Inst != null)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			return;
		}
		m_Inst = this;
		Object.DontDestroyOnLoad(base.gameObject);
	}

	private void OnDestroy()
	{
		AdSDKManager.m_BeforeShowAd -= DoPausePassively;
		PaymentUtility.m_BeforeDoPay -= DoPausePassively;
		ShareManager.m_BeforeShare -= DoPausePassively;
		LoginUtility.BeforeLogin -= DoPausePassively;
		if (m_Inst == this)
		{
			m_Inst = null;
		}
	}

	private void DoPausePassively()
	{
		m_IsPausePassively = true;
		CancelInvoke("WaitForPauseClear");
		Invoke("WaitForPauseClear", 60f);
	}

	private void WaitForPauseClear()
	{
		m_IsPausePassively = false;
	}

	private void OnApplicationPause(bool pauseStatus)
	{
		if (pauseStatus)
		{
			m_PauseTime = Time.realtimeSinceStartup;
			return;
		}
		CancelInvoke("WaitForPauseClear");
		if (m_IsPausePassively)
		{
			m_IsPausePassively = false;
		}
		else if (m_PauseTime > 0f && Time.realtimeSinceStartup - m_PauseTime >= (float)m_AutoRestartTime)
		{
			AndroidSDKAdapter.Instance.RestartUnityActivity();
		}
	}

	private void RestartUnityIOS()
	{
		ResManager.RelaunchGame();
	}
}
