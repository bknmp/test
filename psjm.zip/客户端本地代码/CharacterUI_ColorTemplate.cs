using DG.Tweening;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_ColorTemplate
{
	public UIDataBinder m_Host;

	public Image m_Color;

	public GameObject m_Selected;

	public GameObject m_Check;

	public GameObject m_Frame;

	public GameObject m_LoadEffect;

	private bool m_InitalSelection;

	private SkinPartType m_SkinPartType;

	private int m_ColorID;

	private int m_ColorIndex;

	private int m_PartID;

	private bool m_IsInGroup;

	private SkinPartInfo m_PartInfo;

	private SkinGroupInfo m_GroupInfo;

	private Tween m_tween;

	public static CharacterUI_ColorTemplate SelectedItem;

	public void Bind(CommonDataCollection args)
	{
		m_PartID = args["partID"];
		m_ColorID = args["colorID"];
		m_ColorIndex = args["colorIndex"];
		m_SkinPartType = (SkinPartType)args["skinPartType"].val;
		m_IsInGroup = ShopUtility.IsInGroup(m_PartID);
		if (m_IsInGroup)
		{
			int groupID = ShopUtility.GetGroupID(m_PartID);
			m_GroupInfo = LocalResources.SkinGroupTable.Get(groupID);
		}
		else
		{
			m_PartInfo = LocalResources.SkinPartTable.Get(m_PartID);
		}
		m_Color.color = LocalResources.ColorPaletteTable.Get(m_ColorID).Color;
		m_Frame.SetActive(value: true);
		m_Host.EventProxy(m_Color.GetComponent<Button>(), "OnIconClicked");
		bool flag = false;
		if (m_PartInfo != null)
		{
			flag = CharacterUtility.IsColor(m_ColorID, m_PartID, CharacterUtility.GetOwnedCharacterInfo(LobbyScene.Inst.CurrentCharacter.CharacterID).currentSkinInfo);
		}
		else
		{
			int[] skinPartIds = m_GroupInfo.SkinPartIds;
			for (int i = 0; i < skinPartIds.Length; i++)
			{
				int[] colorRandomIDs = LocalResources.SkinPartTable.Get(skinPartIds[i]).ColorRandomIDs;
				if (colorRandomIDs.Length >= 10)
				{
					flag = CharacterUtility.IsColor(colorRandomIDs[m_ColorIndex], skinPartIds[i], CharacterUtility.GetOwnedCharacterInfo(LobbyScene.Inst.CurrentCharacter.CharacterID).currentSkinInfo);
					if (!flag)
					{
						break;
					}
				}
			}
		}
		m_Selected.GetComponent<UIStateItem>().State = (flag ? 1 : 0);
		m_Check.SetActive(flag);
		bool selected = m_ColorID == CharacterUI_PageColoration.Selected[m_SkinPartType];
		UpdateSelection(selected);
	}

	private void UpdateSelection(bool selected)
	{
		if (selected == m_Selected.activeSelf && m_InitalSelection)
		{
			return;
		}
		if (selected)
		{
			m_tween = m_Host.transform.DOScale(1.1f, 0.2f).SetEase(Ease.OutBack);
			SelectedItem = this;
			PreviewColoring();
		}
		else
		{
			if (m_tween != null)
			{
				m_tween.Kill();
			}
			m_Host.transform.localScale = Vector3.one;
		}
		m_Selected.SetActive(selected);
		m_InitalSelection = true;
	}

	private void PreviewColoring()
	{
		LobbyScene.Inst.CurrentCharacter.m_SkinPartController.GetComponent<SkinColorationController>().ColorizeSkin(m_PartID, m_ColorIndex);
	}

	public void SpawnBuyEffect()
	{
		PoolSpawner.Spawn(m_LoadEffect, m_Color.transform);
	}

	public void OnIconClicked()
	{
		CharacterUI_PageColoration.Selected[m_SkinPartType] = m_ColorID;
		UIDataEvents.Inst.InvokeEvent("OnColorSelectedChanged");
	}
}
