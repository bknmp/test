using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

internal class ActivityModeUI
{
	public UIDataBinder m_Host;

	public Button m_ButtonStart;

	public Text m_TimeText;

	public Material m_UIDefaultOptimized;

	public Material m_UIDefaultGray;

	private MoreModeCondition m_MoreModeCondition;

	private Action m_OnStart;

	protected MapType m_MapType = MapType.TypeBattleRoyale;

	public void Bind(CommonDataCollection args)
	{
		m_MoreModeCondition = (args["condition"].val as MoreModeCondition);
		m_OnStart = (args["onStart"].val as Action);
		if (m_MoreModeCondition != null)
		{
			UpdateContent();
		}
	}

	private void UpdateContent()
	{
		m_Host.EventProxy(m_ButtonStart, "OnStart");
		int nearestTimeIdx = m_MoreModeCondition.GetNearestTimeIdx();
		uint num = m_MoreModeCondition.startHours[nearestTimeIdx];
		uint num2 = m_MoreModeCondition.endHours[nearestTimeIdx];
		m_TimeText.text = string.Format(Localization.ActivityTimeShortFormat, num + ":00", num2 + ":00");
		m_ButtonStart.GetComponentInChildren<RawImage>(includeInactive: true).material = ((m_MoreModeCondition.InTime() && m_MoreModeCondition.WeekTimeMatch()) ? m_UIDefaultOptimized : m_UIDefaultGray);
	}

	public void OnStart()
	{
		m_Host.GetComponent<UILobbyElement>().GoBack();
		if (LocalPlayerDatabase.Settings.idleSysOpen && LocalPlayerDatabase.PrivatePlayerInfo.idleBanTick > UtcTimeStamp.Now)
		{
			GameModePage component = UILobby.Current.CurrentPage().GetComponent<GameModePage>();
			if (component != null)
			{
				component.ShowTip();
			}
		}
		else if (!TeamRoomUI.IsShowing)
		{
			m_OnStart();
		}
	}
}
