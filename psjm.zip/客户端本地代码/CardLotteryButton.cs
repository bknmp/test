using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class CardLotteryButton
{
	public UIDataBinder m_Host;

	public GameObject m_DiscountTips;

	public Text m_DiscountTipsText;

	public Button m_Button;

	public GameObject m_RedPoint;

	public GameObject m_NewbieTips;

	public GameObject m_LobbyGuideEffectFinger;

	public UIStateItem m_NewbieText;

	private Coroutine m_DelayCoroutine;

	private string m_DiscountFormat;

	private int activityId;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_DiscountFormat))
		{
			m_DiscountFormat = m_DiscountTipsText.text;
		}
		if (LocalPlayerDatabase.CardLotteryInfo == null)
		{
			LocalPlayerDatabase.RefreshCardLotteryInfo(silent: true);
		}
		else
		{
			UpdateContent();
		}
		m_Host.EventProxy(m_Button, "OnClicked");
	}

	private void ShowNewbieTips()
	{
		bool prefValue = LocalPlayerDatabase.GetPrefValue("CardLotteryFreeClicked");
		m_NewbieTips.SetActive(prefValue);
		m_LobbyGuideEffectFinger.SetActive(!prefValue);
	}

	public void OnClicked()
	{
		if (m_RedPoint.activeSelf)
		{
			if (ActivityLobby.IsActicityAvailable(ActivityType.BUY_NEW_CARD_DIRECT, ActivityCollectionType.NEW_CARD_ACTIVITY, out activityId) && CardLotteryUtility.CheckStatus(CardLotteryUtility.OneTimeEvent.RainbowTicketOwned, CardLotteryUtility.OneTimeEventStatus.Happened))
			{
				CardLotteryUI.m_LotteryState = CardLotteryUI.LotteryState.Rainbow;
			}
			else
			{
				CardLotteryUI.m_LotteryState = CardLotteryUI.LotteryState.Normal;
			}
		}
		if (LocalPlayerDatabase.CardLotteryInfo != null)
		{
			CardLotteryUtility.ReadAllOneTimeEvents();
		}
		if (m_LobbyGuideEffectFinger.activeSelf)
		{
			LocalPlayerDatabase.SetPrefValue("CardLotteryFreeClicked", value: true);
			if (m_NewbieText.State == 0)
			{
				LocalPlayerDatabase.SetPrefValue("CardLotteryFirstFree_Blue", 1);
			}
			else
			{
				LocalPlayerDatabase.SetPrefValue("CardLotteryFirstFree_Purple", 1);
			}
		}
		if (m_NewbieTips.activeSelf)
		{
			if (m_NewbieText.State == 0)
			{
				LocalPlayerDatabase.SetPrefValue("CardLotteryFirstFree_Blue", 1);
			}
			else
			{
				LocalPlayerDatabase.SetPrefValue("CardLotteryFirstFree_Purple", 1);
			}
		}
		JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
	}

	private void UpdateContent()
	{
		CardLotteryInfo lotteryInfo = CardLotteryUtility.GetLotteryInfo(7);
		CardLotteryInfo lotteryInfo2 = CardLotteryUtility.GetLotteryInfo(8);
		CardLotteryInfo lotteryInfo3 = CardLotteryUtility.GetLotteryInfo(9);
		CardLotteryUtility.UpdateOneTimeEvents();
		int num = 0;
		if (CardLotteryUtility.CheckStatus(CardLotteryUtility.OneTimeEvent.SupperDiscount, CardLotteryUtility.OneTimeEventStatus.Happened))
		{
			m_DiscountTips.SetActive(value: true);
			m_DiscountTipsText.text = string.Format(m_DiscountFormat, lotteryInfo3.discount / 10);
			num = lotteryInfo3.discountTime;
		}
		else
		{
			m_DiscountTips.SetActive(value: false);
		}
		if (lotteryInfo2.IsFree() || lotteryInfo.IsFree())
		{
			m_RedPoint.SetActive(value: true);
		}
		else if (CardLotteryUtility.CheckStatus(CardLotteryUtility.OneTimeEvent.AdvanceTicketOwned, CardLotteryUtility.OneTimeEventStatus.Happened) || CardLotteryUtility.CheckStatus(CardLotteryUtility.OneTimeEvent.SuperTicketOwned, CardLotteryUtility.OneTimeEventStatus.Happened) || (ActivityLobby.IsActicityAvailable(ActivityType.BUY_NEW_CARD_DIRECT, ActivityCollectionType.NEW_CARD_ACTIVITY, out activityId) && CardLotteryUtility.CheckStatus(CardLotteryUtility.OneTimeEvent.RainbowTicketOwned, CardLotteryUtility.OneTimeEventStatus.Happened)))
		{
			m_RedPoint.SetActive(value: true);
		}
		else
		{
			m_RedPoint.SetActive(value: false);
			num = ((lotteryInfo.nextFreeTime >= lotteryInfo2.nextFreeTime) ? lotteryInfo2.nextFreeTime : lotteryInfo.nextFreeTime);
		}
		UpdateNewbieTips(lotteryInfo, lotteryInfo2);
		if (m_DelayCoroutine != null)
		{
			m_Host.StopCoroutine(m_DelayCoroutine);
			m_DelayCoroutine = null;
		}
		int num2 = num - UtcTimeStamp.Now;
		if (num2 > 0)
		{
			m_DelayCoroutine = m_Host.StartCoroutine(DelayUpdateContent(num2));
		}
	}

	private void UpdateNewbieTips(CardLotteryInfo normal, CardLotteryInfo advance)
	{
		if (!m_DiscountTips.gameObject.activeSelf)
		{
			if (normal.IsFree() && LocalPlayerDatabase.GetPrefValueInt("CardLotteryFirstFree_Blue") == 0)
			{
				ShowNewbieTips();
				m_NewbieText.State = 0;
			}
			else if (advance.IsFree() && LocalPlayerDatabase.GetPrefValueInt("CardLotteryFirstFree_Purple") == 0)
			{
				ShowNewbieTips();
				m_NewbieText.State = 1;
			}
			else
			{
				m_NewbieTips.SetActive(value: false);
				m_LobbyGuideEffectFinger.SetActive(value: false);
			}
		}
		else
		{
			m_NewbieTips.SetActive(value: false);
			m_LobbyGuideEffectFinger.SetActive(value: false);
		}
	}

	private IEnumerator DelayUpdateContent(float delay)
	{
		yield return Yielders.GetWaitForSeconds(delay);
		UpdateContent();
	}
}
