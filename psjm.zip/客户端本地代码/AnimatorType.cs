public enum AnimatorType
{
	WeaponRocket,
	WeaponMortar,
	WeaponSubmachine,
	WeaponSword,
	WeaponJumpyGun
}
