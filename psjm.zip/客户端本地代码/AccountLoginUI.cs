using AppleAuth;
using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AccountLoginUI : MonoBehaviour
{
	public InputField m_AccountNum;

	public InputField m_Pwd;

	public Button m_ShowPwd;

	public UIStateImage m_PwdState;

	public Button m_LoginBtn;

	public Button m_CloseButton;

	public MultiTargetGraphicButton m_ForgotPwd;

	public Button m_QQ;

	public Button m_WeChat;

	public Button m_Apple;

	public GameObject m_Others;

	private static Delegates.VoidCallback LoginSuccess;

	private void Awake()
	{
		m_ShowPwd.onClick.AddListener(ChangePwdState);
		m_LoginBtn.onClick.AddListener(OnLoginBtnClick);
		m_ForgotPwd.onClick.AddListener(OnForgotPwdClick);
		m_CloseButton.onClick.AddListener(CloseUI);
		m_Pwd.onValueChanged.AddListener(OnInputFieldValueChang);
		m_Others.SetActive(LoginUtility.MultiLoginType());
		m_Apple.gameObject.SetActive(AppleAuthManager.IsCurrentPlatformSupported);
		m_QQ.onClick.AddListener(OnQQClick);
		m_WeChat.onClick.AddListener(OnWeChatClick);
		m_Apple.onClick.AddListener(OnAppleClick);
	}

	private void Init(int account, Delegates.VoidCallback loginSuccess)
	{
		m_AccountNum.text = ((account > 0) ? account.ToString() : "");
		LoginSuccess = loginSuccess;
		m_PwdState.State = 0;
		m_Pwd.contentType = InputField.ContentType.Password;
		m_Pwd.text = "";
	}

	private void OnInputFieldValueChang(string input)
	{
		m_Pwd.text = AccountUtility.PwdRemoveForbidWord(input);
	}

	private void ChangePwdState()
	{
		bool flag = m_PwdState.State == 0;
		m_PwdState.State = (flag ? 1 : 0);
		m_Pwd.contentType = ((!flag) ? InputField.ContentType.Password : InputField.ContentType.Standard);
		string text = m_Pwd.text;
		m_Pwd.text = "";
		m_Pwd.text = text;
	}

	private void OnLoginBtnClick()
	{
		if (CheckAccountAndPwdFormat())
		{
			AccountUtility.LoginByDmmAccount(int.Parse(m_AccountNum.text), m_Pwd.text, "", OnLoginSuccess, null);
		}
	}

	private void OnForgotPwdClick()
	{
		AccountMailVerifyUI.ShowUI(MailCodeType.FindAccount, Localization.TipsFindByMail, "", delegate
		{
			AccountSetPwdUI.ShowUI(AccountUtility.MailCodeResponse.roleID, AccountUtility.MailCodeResponse.accountName, AccountUtility.MailCodeResponse.codeKey, "", delegate(int roleID)
			{
				m_AccountNum.text = roleID.ToString();
				m_Pwd.text = "";
			});
		});
	}

	private void OnQQClick()
	{
		LoginSDK(LoginType.QQ);
	}

	private void OnWeChatClick()
	{
		LoginSDK(LoginType.Wechat);
	}

	private void OnAppleClick()
	{
		LoginSDK(LoginType.Apple);
	}

	private void LoginSDK(LoginType loginType)
	{
		LoginUtility.LoginSDK(delegate(bool suc)
		{
			if (suc)
			{
				AccountUtility.LoginByOpenID(OnLoginSuccess, null);
			}
		}, loginType);
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	private void OnLoginSuccess()
	{
		CloseUI();
		if (LoginSuccess != null)
		{
			LoginSuccess();
		}
	}

	private bool CheckAccountAndPwdFormat()
	{
		if (m_AccountNum.text.Length < 7 || m_Pwd.text.Length < 6)
		{
			UILobby.Current.ShowTips(LocalResources.ErrorTable.Get(-19).Error);
			return false;
		}
		return true;
	}

	public static void ShowUI(Delegates.VoidCallback onSuccess, int defaultAccount = 0)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountLoginUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountLoginUI>().Init(defaultAccount, onSuccess);
	}
}
