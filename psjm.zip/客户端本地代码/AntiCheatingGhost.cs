public enum AntiCheatingGhost
{
	Projectile,
	Grenade,
	Medkit,
	Saber,
	ThrownBullet
}
