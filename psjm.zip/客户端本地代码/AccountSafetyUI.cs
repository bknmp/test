using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AccountSafetyUI : MonoBehaviour
{
	public UIStateItem m_MailBtnState;

	public Text m_Mail;

	public Button m_BindBtn;

	public Button m_UnBindBtn;

	public UIToggleButton m_SafeVerify;

	public Button m_CloseBtn;

	private UIStateItem m_MailState;

	private void Awake()
	{
		m_MailState = m_Mail.GetComponentInParent<UIStateItem>();
		m_BindBtn.onClick.AddListener(BindMail);
		m_UnBindBtn.onClick.AddListener(UnBindMail);
		m_SafeVerify.onButtonClicked.AddListener(OnSafeVerifyChanged);
		m_CloseBtn.onClick.AddListener(CloseUI);
	}

	private void OnEnable()
	{
		Init();
	}

	private void Init()
	{
		bool flag = !string.IsNullOrEmpty(AccountUtility.LoginAccountInfo.mail);
		m_MailBtnState.State = ((!flag) ? 1 : 0);
		m_MailState.State = ((!flag) ? 1 : 0);
		m_Mail.text = AccountUtility.LoginAccountInfo.mail;
		m_SafeVerify.m_IsOn = AccountUtility.LoginAccountInfo.accountSafe;
		m_SafeVerify.transform.parent.gameObject.SetActive(flag);
	}

	private void BindMail()
	{
		if (AccountUtility.LoginAccountInfo.isSetPwd)
		{
			AccountBindMailUI.ShowUI(isBind: true, Init);
		}
		else
		{
			AccountSetPwdUI.ShowUI((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName);
		}
	}

	private void UnBindMail()
	{
		AccountBindMailUI.ShowUI(isBind: false, CloseUI);
	}

	private void OnSafeVerifyChanged()
	{
		HttpRequestChangeAccountSafety msg = new HttpRequestChangeAccountSafety();
		msg.enable = m_SafeVerify.m_IsOn;
		GameHttpManager.Inst.Send(msg, null, delegate
		{
			AccountUtility.LoginAccountInfo.accountSafe = m_SafeVerify.m_IsOn;
			if (LocalPlayerDatabase.LoginInfo != null)
			{
				LocalPlayerDatabase.LoginInfo.accountSafe = m_SafeVerify.m_IsOn;
			}
		}, delegate
		{
			m_SafeVerify.m_IsOn = !msg.enable;
		});
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI()
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountSafetyUI");
		UILobby.Current.ShowUI(ui, null);
	}
}
