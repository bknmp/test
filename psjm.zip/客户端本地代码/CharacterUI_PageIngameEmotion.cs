using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;

internal class CharacterUI_PageIngameEmotion
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_Content;

	private int m_lastTabIndex = -1;

	private int m_lastCharacterSelected;

	public void Bind(CommonDataCollection args)
	{
		TryClearRedPoint();
		m_lastCharacterSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		if (args["tabIndex"] != null)
		{
			m_lastTabIndex = args["tabIndex"];
		}
		else
		{
			CharacterUI_IngameEmotionItemTemplate.Selected = 0;
		}
		m_Content.ResetContentPosition();
		OnTabChange();
	}

	private void OnDisable()
	{
		TryClearRedPoint();
		m_lastTabIndex = -1;
	}

	public void OnTabChange()
	{
		int lastTabIndex = m_lastTabIndex;
		PlayerIngameEmotionInfo ownedIngameEmotion = LocalPlayerDatabase.PlayerInfo.ownedIngameEmotion;
		Dictionary<IngameEmotionInfo, int> dictionary = new Dictionary<IngameEmotionInfo, int>();
		Dictionary<IngameEmotionInfo, int> dictionary2 = new Dictionary<IngameEmotionInfo, int>();
		for (int i = 0; i < ownedIngameEmotion.id.Length; i++)
		{
			if (ownedIngameEmotion.expiredTime[i] > 0 && ownedIngameEmotion.expiredTime[i] <= UtcTimeStamp.Now)
			{
				continue;
			}
			IngameEmotionInfo ingameEmotionInfo = LocalResources.IngameEmotionInfo.Get(ownedIngameEmotion.id[i]);
			if ((lastTabIndex == 2 || ingameEmotionInfo.Type == lastTabIndex) && (ingameEmotionInfo.Chararcter == CharacterUI_SelectCharacterItemTemplate.globalSelected || ingameEmotionInfo.Chararcter == 0))
			{
				if (NewIngameEmotionTips.Inst.IsNew(ingameEmotionInfo.Id))
				{
					dictionary2.Add(ingameEmotionInfo, ownedIngameEmotion.expiredTime[i]);
				}
				else
				{
					dictionary.Add(ingameEmotionInfo, ownedIngameEmotion.expiredTime[i]);
				}
			}
		}
		if (!CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(CharacterUI_SelectCharacterItemTemplate.globalSelected);
			IngameEmotionInfo ingameEmotionInfo2 = LocalResources.IngameEmotionInfo.Get(characterInfo.DefaultEmotionDoodle);
			IngameEmotionInfo ingameEmotionInfo3 = LocalResources.IngameEmotionInfo.Get(characterInfo.DefaultEmotionMotion);
			if ((lastTabIndex == 2 || ingameEmotionInfo2.Type == lastTabIndex) && !dictionary.ContainsKey(ingameEmotionInfo2))
			{
				dictionary.Add(ingameEmotionInfo2, 0);
			}
			if ((lastTabIndex == 2 || ingameEmotionInfo3.Type == lastTabIndex) && !dictionary.ContainsKey(ingameEmotionInfo3))
			{
				dictionary.Add(ingameEmotionInfo3, 0);
			}
		}
		dictionary2 = (from x in dictionary2
			orderby -1 * x.Key.Quality, -1 * x.Key.Type
			select x).ToDictionary((KeyValuePair<IngameEmotionInfo, int> o) => o.Key, (KeyValuePair<IngameEmotionInfo, int> p) => p.Value);
		dictionary = (from x in dictionary
			orderby -1 * x.Key.Quality, -1 * x.Key.Type
			select x).ToDictionary((KeyValuePair<IngameEmotionInfo, int> o) => o.Key, (KeyValuePair<IngameEmotionInfo, int> p) => p.Value);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		foreach (KeyValuePair<IngameEmotionInfo, int> item in dictionary2)
		{
			int arraySize = commonDataCollection.ArraySize;
			commonDataCollection[arraySize]["info"].val = item.Key;
			commonDataCollection[arraySize]["expiredTime"] = item.Value;
		}
		foreach (KeyValuePair<IngameEmotionInfo, int> item2 in dictionary)
		{
			int arraySize2 = commonDataCollection.ArraySize;
			commonDataCollection[arraySize2]["info"].val = item2.Key;
			commonDataCollection[arraySize2]["expiredTime"] = item2.Value;
		}
		m_Content.m_TemplateInitiator.Args = commonDataCollection;
	}

	private void TryClearRedPoint()
	{
		if (m_lastTabIndex >= 0)
		{
			if (m_lastTabIndex == 2)
			{
				NewIngameEmotionTips.Inst.ClearByCharacter(m_lastCharacterSelected);
			}
			else
			{
				NewIngameEmotionTips.Inst.ClearByCharacterAndType(m_lastCharacterSelected, m_lastTabIndex);
			}
			UIDataEvents.Inst.InvokeEvent("OnWardrobeUIRedPointChanged");
		}
	}
}
