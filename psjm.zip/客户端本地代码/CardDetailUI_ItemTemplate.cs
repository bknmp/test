using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CardDetailUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_IndexText;

	public Image m_Select;

	public MultiTargetGraphicButton m_Btn;

	private int m_Index;

	private CardSkinEditUI m_cardSkinEditUI;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["index"];
		UpdateSelectedState();
		m_IndexText.text = (m_Index + 1).ToString();
		m_Host.EventProxy(m_Btn, "OnClick");
		m_cardSkinEditUI = (args["cardSkinEditUI"].val as CardSkinEditUI);
	}

	private void UpdateSelectedState()
	{
		m_Select.gameObject.SetActive(m_Index == CardConfigEditPage_PageCardSkin.WeaponCardSkinIndex);
	}

	public void OnClick()
	{
		if (CardConfigEditPage_PageCardSkin.WeaponCardSkinIndex != m_Index)
		{
			m_cardSkinEditUI.ClearPending();
			CardConfigEditPage_PageCardSkin.WeaponCardSkinIndex = m_Index;
			UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
		}
	}
}
