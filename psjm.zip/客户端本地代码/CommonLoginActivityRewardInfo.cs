using LightUtility;

public class CommonLoginActivityRewardInfo : IdBased
{
	public int ActivityId;

	public int Days;

	public int[] Count;

	public int[] CountForUI;

	public int[] Items;

	public int[] ItemId;

	public bool ShowIcon;

	public string Tips;
}
