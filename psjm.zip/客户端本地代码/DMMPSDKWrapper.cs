using GameMessages;
using PerformanceSDK;
using PerformanceSDK.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class DMMPSDKWrapper
{
	private static string lastGameType = null;

	private static HttpRequestPerformanceReport.InGameInfo gameInfo = new HttpRequestPerformanceReport.InGameInfo();

	private static bool enabled
	{
		get
		{
			if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.clickEvents == null)
			{
				return false;
			}
			return LocalPlayerDatabase.Settings.clickEvents.Contains(ClickEventParam.PERFORMANCE_STATISTIC);
		}
	}

	public static void Init()
	{
		try
		{
			PerformanceSDK.PerformanceSDK.Instance.Init(new UserInfo
			{
				accountName = LocalPlayerDatabase.LoginInfo.accountName,
				roleID = LocalPlayerDatabase.LoginInfo.roleID,
				version = NativeUpdater.CompleteVersionCode,
				channelID = PlatformUtility.PlatformID
			});
		}
		catch (Exception exception)
		{
			UnityEngine.Debug.LogException(exception);
		}
	}

	public static void BeginInGameSample()
	{
		int roundTripTime = PhotonNetwork.networkingPeer.RoundTripTime;
		if (enabled)
		{
			try
			{
				string sampleId = $"{GameRuntime.GameMode.ToString()}-{GameRuntime.MapType.ToString()}";
				bool flag = false;
				int num = 0;
				if (GameSettings.Inst != null)
				{
					flag = (Application.targetFrameRate == 30);
					num = GameSettings.Inst.GraphicsQuality.Level;
				}
				gameInfo.gameCount++;
				gameInfo.roomName = GameRuntime.CurrentRoom.name;
				RuntimePlayerInfo runtimePlayerInfo = GameRuntime.RoomPlayers[LocalPlayerDatabase.PlayerInfo.publicInfo.name];
				if (runtimePlayerInfo != null)
				{
					List<int> list = new List<int>();
					list.Add(runtimePlayerInfo.CharacterInfo.characterID);
					list.AddRange(runtimePlayerInfo.CharacterInfo.currentSkinInfo.skinPartIDs);
					list.AddRange(runtimePlayerInfo.MatchData.cards);
					list.AddRange(runtimePlayerInfo.MatchData.cardSkins);
					list.AddRange(runtimePlayerInfo.MatchData.cardStyles);
					gameInfo.ids = list.ToArray();
				}
				Singleton<DataCollector>.Instance.BeginSample(sampleId, new SampleSetting[3]
				{
					new SampleSetting
					{
						type = SamplerType.FPS,
						tag = "fpsSampleData",
						userData = new Dictionary<string, object>
						{
							{
								"isLimitFPS",
								flag
							},
							{
								"graphicQuality",
								num
							},
							{
								"outlineEnable",
								GameSettings.Inst.OutlineEnable.Value > 0
							}
						}
					},
					new SampleSetting
					{
						type = SamplerType.Network,
						tag = "networkSampleData"
					},
					new SampleSetting
					{
						type = SamplerType.DeviceRuntimeInfo,
						tag = "deviceruntimeInfoSampleSampleData"
					}
				});
				lastGameType = sampleId;
			}
			catch (Exception exception)
			{
				lastGameType = null;
				UnityEngine.Debug.LogException(exception);
			}
		}
	}

	public static void EndInGameSample()
	{
		if (enabled)
		{
			try
			{
				string text = $"{GameRuntime.GameMode.ToString()}-{GameRuntime.MapType.ToString()}";
				if (lastGameType == null || text != lastGameType)
				{
					UnityEngine.Debug.LogFormat("EndInGameSample: Invalid Game Type {0}", text);
				}
				Singleton<DataCollector>.Instance.EndSample(text, gameInfo);
				lastGameType = null;
			}
			catch (Exception exception)
			{
				lastGameType = null;
				UnityEngine.Debug.LogException(exception);
			}
		}
	}
}
