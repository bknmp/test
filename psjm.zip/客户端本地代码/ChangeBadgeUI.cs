using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine.UI;

internal class ChangeBadgeUI
{
	public UIDataBinder m_Host;

	public Button m_Yes;

	public Text m_PriceText;

	public UnionBadgeItem m_Badge;

	public CycleSelector m_IconSelector;

	public CycleSelector m_FrameSelector;

	public CycleSelector m_FlagSelector;

	private int m_IconID;

	private int m_FrameID;

	private int m_FlagID;

	private string m_PriceFormat;

	public void Bind(CommonDataCollection args)
	{
		if (m_PriceFormat == null)
		{
			m_PriceFormat = m_PriceText.text;
		}
		m_IconSelector.OnPageChanged.AddListener(UpdateBadge);
		m_FrameSelector.OnPageChanged.AddListener(UpdateBadge);
		m_FlagSelector.OnPageChanged.AddListener(UpdateBadge);
		m_PriceText.text = string.Format(m_PriceFormat, UnionUtility.Settings.changeBadgeCostDiamond);
		m_Host.EventProxy(m_Yes, "OnYesClicked");
		InitSelectors();
	}

	private void InitSelectors()
	{
		List<UnionBadgeInfo> unionBadgesByType = LocalResources.GetUnionBadgesByType(UnionBadgeType.Icon);
		int index = unionBadgesByType.FindIndex((UnionBadgeInfo a) => a.Id == UnionUtility.MyUnionInfo.unionPublicinfo.badge.iconID);
		m_IconSelector.SetIndex(index, unionBadgesByType.Count);
		List<UnionBadgeInfo> unionBadgesByType2 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Frame);
		int index2 = unionBadgesByType2.FindIndex((UnionBadgeInfo a) => a.Id == UnionUtility.MyUnionInfo.unionPublicinfo.badge.frameID);
		m_FrameSelector.SetIndex(index2, unionBadgesByType2.Count);
		List<UnionBadgeInfo> unionBadgesByType3 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Flag);
		int index3 = unionBadgesByType3.FindIndex((UnionBadgeInfo a) => a.Id == UnionUtility.MyUnionInfo.unionPublicinfo.badge.flagID);
		m_FlagSelector.SetIndex(index3, unionBadgesByType3.Count);
		UpdateBadge();
	}

	private void UpdateBadge()
	{
		UnionBadgeInfo unionBadgeInfo = LocalResources.GetUnionBadgesByType(UnionBadgeType.Icon)[m_IconSelector.Index];
		UnionBadgeInfo unionBadgeInfo2 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Frame)[m_FrameSelector.Index];
		UnionBadgeInfo unionBadgeInfo3 = LocalResources.GetUnionBadgesByType(UnionBadgeType.Flag)[m_FlagSelector.Index];
		m_IconSelector.UpdateText(unionBadgeInfo.Name);
		m_FrameSelector.UpdateText(unionBadgeInfo2.Name);
		m_FlagSelector.UpdateText(unionBadgeInfo3.Name);
		m_IconID = unionBadgeInfo.Id;
		m_FrameID = unionBadgeInfo2.Id;
		m_FlagID = unionBadgeInfo3.Id;
		m_Badge.SetBadge(m_IconID, m_FrameID, m_FlagID);
	}

	public void OnYesClicked()
	{
		ShopUtility.CheckMoneyEnough(CurrencyType.Diamonds, UnionUtility.Settings.changeBadgeCostDiamond, DoChange, -134);
	}

	private void DoChange()
	{
		UnionBadge badge = new UnionBadge
		{
			iconID = m_IconID,
			frameID = m_FrameID,
			flagID = m_FlagID
		};
		UnionPublicInfo unionPublicinfo = UnionUtility.MyUnionInfo.unionPublicinfo;
		UnionUtility.ModifyUnionInfo(badge, unionPublicinfo.notice, unionPublicinfo.needReview, unionPublicinfo.gradeLimit, delegate
		{
			UILobby.Current.ShowTips(Localization.TipsUnionBadgeChanged);
			m_Host.GetComponent<UIPopup>().GoBack();
		});
	}
}
