using UnityEngine;

public class CirclePreviewArea : MonoBehaviour
{
	public GameObject m_PreviewArea;

	public float m_Radius = 3f;

	public float m_Ratio = 2.7f;

	protected void Awake()
	{
		InitPreviewArea();
	}

	public virtual void InitPreviewArea()
	{
		float d = m_Radius / m_Ratio;
		m_PreviewArea.transform.localScale = Vector3.one * d;
	}
}
