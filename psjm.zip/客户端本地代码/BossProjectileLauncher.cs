using LightUtility;
using UnityEngine;

public class BossProjectileLauncher : ProjectileLauncher
{
	protected override void DoSpawnFireProjectile(Vector3 pos, Vector3 posTarget, Vector3 dir)
	{
		string text = "Missile_Boss";
		if (LobbyScene.Inst != null)
		{
			text += "_Lobby";
		}
		GameObject prefab = PrefabSource.Inst.Load(text);
		Vector3 a = Vector3.Cross(Vector3.up, dir);
		switch (m_WeaponInfo.MultiShot)
		{
		case MultiShotType.Single:
			NewProjectile(prefab, pos, posTarget);
			break;
		case MultiShotType.Double:
			NewProjectileDir(prefab, pos + a * 0.5f, dir.normalized);
			NewProjectileDir(prefab, pos - a * 0.5f, dir.normalized);
			if (m_FiredProjectiles.Count >= 2)
			{
				BulletObject.GroupSharedHitData cacheGroupSharedHitData2 = BulletObject.GetCacheGroupSharedHitData();
				m_FiredProjectiles[m_FiredProjectiles.Count - 1].SetGroupSharedHitData(cacheGroupSharedHitData2);
				m_FiredProjectiles[m_FiredProjectiles.Count - 2].SetGroupSharedHitData(cacheGroupSharedHitData2);
			}
			break;
		case MultiShotType.Triple:
			NewProjectile(prefab, pos, posTarget);
			NewProjectileDir(prefab, pos + a * 0.2f, dir.normalized);
			NewProjectileDir(prefab, pos - a * 0.2f, dir.normalized);
			if (m_FiredProjectiles.Count >= 3)
			{
				BulletObject.GroupSharedHitData cacheGroupSharedHitData = BulletObject.GetCacheGroupSharedHitData();
				m_FiredProjectiles[m_FiredProjectiles.Count - 1].SetGroupSharedHitData(cacheGroupSharedHitData);
				m_FiredProjectiles[m_FiredProjectiles.Count - 2].SetGroupSharedHitData(cacheGroupSharedHitData);
				m_FiredProjectiles[m_FiredProjectiles.Count - 3].SetGroupSharedHitData(cacheGroupSharedHitData);
			}
			break;
		}
	}
}
