using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class BuffItem
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public UICooldownBar m_Progress;

	public void Bind(CommonDataCollection args)
	{
		BuffManager.Buff buff = args["buff"].val as BuffManager.Buff;
		BuffInfo buffInfo = LocalResources.BuffTable.Get(buff.id);
		m_Icon.sprite = SpriteSource.Inst.Find(buff.icon);
		m_Progress.gameObject.SetActive(buff.duration > 0f && !buffInfo.ProgressHided);
		m_Progress.SetTime(buff.remainedTime, buff.duration);
		m_Host.gameObject.SetActive(CheckVisible(buff.userID, buffInfo.Visible));
	}

	private bool CheckVisible(string userID, int visible)
	{
		if (string.IsNullOrEmpty(userID))
		{
			return true;
		}
		switch (visible)
		{
		case 0:
			return true;
		case 1:
			return PlayerController.FindPlayer(userID).PlayingRole == GameRuntime.PlayingRole;
		case 2:
			return userID == PlayerController.Inst.UserId;
		default:
			return false;
		}
	}
}
