using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class AntiAddictionFillUI
{
	public UIDataBinder m_Host;

	public InputField m_NameField;

	public InputField m_ID;

	public Button m_SubmitButton;

	public Text m_Tips;

	public UIPopup m_AntiAddictionTips2UI;

	public GameObject m_IDExample;

	public Copyable m_ContactText;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SubmitButton, "OnSubmitClicked");
		m_Tips.text = Localization.TipsAntiAddictionFill;
		m_IDExample.SetActive(!LocalPlayerDatabase.Settings.hideIDExample);
		string contact = LocalPlayerDatabase.NoticeInfo.contact1;
		m_ContactText.transform.parent.gameObject.SetActive(!string.IsNullOrEmpty(contact));
		if (!string.IsNullOrEmpty(contact))
		{
			m_ContactText.GetComponent<Text>().text = contact;
			string[] array = contact.Split(' ');
			if (array.Length == 2)
			{
				m_ContactText.m_RealText = array[1];
			}
		}
	}

	public void OnSubmitClicked()
	{
		string name = m_NameField.text.Trim();
		string id = m_ID.text.Trim();
		if (!AntiAddictionUtility.IsNameValid(name))
		{
			UILobby.Current.ShowTips(Localization.TipsNameNoChinese);
			return;
		}
		if (!AntiAddictionUtility.CheckIDCard(id, out int age))
		{
			UILobby.Current.ShowTips(Localization.TipsIDNotValid);
			return;
		}
		if (age >= 18)
		{
			DoCertification(name, id);
			return;
		}
		UILobby.Current.Popup(m_AntiAddictionTips2UI);
		UIPopup popup = UILobby.Current.CurrentPopup();
		Button[] componentsInChildren = popup.GetComponentsInChildren<Button>();
		componentsInChildren[0].onClick.RemoveAllListeners();
		componentsInChildren[0].onClick.AddListener(delegate
		{
			popup.GoBack();
			DoCertification(name, id);
		});
		componentsInChildren[1].onClick.RemoveAllListeners();
		componentsInChildren[1].onClick.AddListener(delegate
		{
			popup.GoBack();
		});
	}

	private void DoCertification(string name, string id)
	{
		UIPopup component = m_Host.GetComponent<UIPopup>();
		AntiAddictionUtility.RequestCertification(name, id, ((UILobbyElement)component).GoBack);
	}
}
