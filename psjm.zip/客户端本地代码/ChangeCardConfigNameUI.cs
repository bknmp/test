using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class ChangeCardConfigNameUI : UIEventListener
{
	public InputField m_NewName;

	private void OnEnable()
	{
		m_NewName.text = "";
	}

	private void Update()
	{
		if (UnityEngine.Input.GetKeyDown(KeyCode.KeypadEnter) || UnityEngine.Input.GetKeyDown(KeyCode.Return))
		{
			OnConfirmClicked();
		}
	}

	public void OnNameTextCheck()
	{
		if (MathUtility.CalculateStringLengthInAscii(m_NewName.text, 1.5f) <= 9)
		{
			return;
		}
		UILobby.Current.ShowTips(Localization.TipsNameTooLong);
		string text = "";
		float num = 0f;
		int length = m_NewName.text.Length;
		for (int i = 0; i < length; i++)
		{
			num += ((m_NewName.text[i] > '\u007f') ? 1.5f : 1f);
			if (num <= 9f)
			{
				text += m_NewName.text[i].ToString();
			}
		}
		m_NewName.text = text;
	}

	public void OnConfirmClicked()
	{
		string playerName = m_NewName.text.Trim();
		if (GameSettings.Inst.ValidateName(playerName))
		{
			ConfirmChangeName();
		}
	}

	private void ConfirmChangeName()
	{
		string name = m_NewName.text.Trim();
		CardUtility.ChangeCardConfigName(ActiveCardConfigView.CardConfigIndex, name, delegate
		{
			UILobby.Current.ShowTips(Localization.TipsCardConfigNameChanged);
			GetComponent<UIPopup>().GoBack();
		});
	}
}
