using LightUI;
using UnityEngine;

public class ChatPanelReparent : UIEventListener
{
	public Transform m_ChatParentRoot;

	private Transform m_OldParent;

	public override void OnEnterUI()
	{
		if (LobbyScene.Inst != null && LobbyScene.Inst.ChatPanel != null)
		{
			m_OldParent = LobbyScene.Inst.ChatPanel.transform.parent;
			LobbyScene.Inst.ChatPanel.transform.SetParent((m_ChatParentRoot == null) ? base.transform.parent : m_ChatParentRoot, worldPositionStays: false);
			LobbyScene.Inst.ChatPanel.transform.SetAsLastSibling();
		}
		if (m_ChatParentRoot != null)
		{
			m_ChatParentRoot.gameObject.SetActive(value: false);
		}
	}

	public override void OnExitUI()
	{
		if (LobbyScene.Inst != null && LobbyScene.Inst.ChatPanel != null)
		{
			LobbyScene.Inst.ChatPanel.transform.SetParent(m_OldParent, worldPositionStays: false);
		}
		if (m_ChatParentRoot != null)
		{
			m_ChatParentRoot.gameObject.SetActive(value: false);
		}
	}

	private void Start()
	{
		if (m_ChatParentRoot != null)
		{
			UIDataEvents.Inst.AddEventListener("OnChatPanelChanged", this, OnChatPanelChanged);
		}
	}

	private void OnChatPanelChanged()
	{
		m_ChatParentRoot.gameObject.SetActive(LobbyScene.Inst.ChatPanel.IsShowed);
	}
}
