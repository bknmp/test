using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CommonProgressActivity
{
	public UIDataBinder m_Host;

	public Slider m_ProgressBar;

	public Text m_PointerText;

	public UITemplateInitiator m_TemplateInitiatorHorizontal;

	public HorizontalLayoutGroup m_Container;

	protected HttpResponseCommonProgressActivity m_HttpResponseCache;

	protected CommonDataCollection m_itemArgs = new CommonDataCollection();

	protected Action m_updateAction;

	protected Action<int> m_OnPreviewCallBack;

	private static Dictionary<int, bool> m_RedPointStates;

	protected Activity m_activity;

	protected UINumberGrow m_PointNumGrow;

	protected int m_Type;

	private Coroutine m_Coroutine;

	public void Bind(CommonDataCollection args)
	{
		if (m_Coroutine != null)
		{
			m_Host.StopCoroutine(m_Coroutine);
		}
		m_PointNumGrow = m_PointerText.GetComponent<UINumberGrow>();
		m_updateAction = (args["ProgressUpdateAction"].val as Action);
		m_activity = (args["Activity"].val as Activity);
		if (args.ContainsKey("OnPreviewCallBack"))
		{
			m_OnPreviewCallBack = (args["OnPreviewCallBack"].val as Action<int>);
		}
		int num = args["RefreshInterval"];
		HttpRequestCommonProgressActivity httpRequestCommonProgressActivity = new HttpRequestCommonProgressActivity();
		m_Type = (int)GetCommonProgressActivityType(m_activity.activityId);
		httpRequestCommonProgressActivity.type = m_Type;
		GameHttpManager.Inst.Send(httpRequestCommonProgressActivity, delegate(HttpResponseCommonProgressActivity OnHttpResponse)
		{
			m_HttpResponseCache = OnHttpResponse;
			m_PointerText.text = m_HttpResponseCache.point.ToString();
			SetInfo();
		}, null, null, LocalPlayerDatabase.DummyWait);
		if (m_TemplateInitiatorHorizontal != null)
		{
			m_TemplateInitiatorHorizontal.OnItemsChanged.RemoveListener(UpdateProgressPos);
			m_TemplateInitiatorHorizontal.OnItemsChanged.AddListener(UpdateProgressPos);
		}
		if (num > 0)
		{
			m_Coroutine = m_Host.StartCoroutine(RefreshPoint(num));
		}
	}

	protected virtual void SetInfo()
	{
		m_itemArgs.Clear();
		bool flag = false;
		bool flag2 = true;
		for (int i = 0; i < m_HttpResponseCache.infos.Length; i++)
		{
			m_itemArgs[i]["index"] = i;
			m_itemArgs[i]["type"] = m_Type;
			m_itemArgs[i]["point"] = m_HttpResponseCache.point;
			m_itemArgs[i]["info"].val = m_HttpResponseCache.infos[i];
			m_itemArgs[i]["CommonProgressActivity"].val = this;
			m_itemArgs[i]["isLast"] = (i == m_HttpResponseCache.infos.Length - 1);
			m_itemArgs[i]["lastTarget"] = ((i != 0) ? m_HttpResponseCache.infos[i - 1].target : 0);
			if (!flag && !m_HttpResponseCache.infos[i].received && m_HttpResponseCache.point >= m_HttpResponseCache.infos[i].target)
			{
				flag = true;
			}
			if (flag2 && !m_HttpResponseCache.infos[i].received)
			{
				flag2 = false;
			}
		}
		m_TemplateInitiatorHorizontal.Args = m_itemArgs;
		if (GetRedPoint(m_activity.activityId) != flag)
		{
			RefreshRedPoint(m_activity.activityId, flag);
		}
		if (flag2)
		{
			SaveCommonProgressAllClaim(m_activity);
		}
		if (m_OnPreviewCallBack != null)
		{
			m_OnPreviewCallBack(m_HttpResponseCache.infos[m_HttpResponseCache.infos.Length - 1].rewards[0].itemID);
		}
	}

	public IEnumerator RefreshPoint(int interval)
	{
		float time = 0f;
		while (true)
		{
			if (!m_Host.gameObject.activeInHierarchy)
			{
				if (m_Coroutine != null)
				{
					m_Host.StopCoroutine(m_Coroutine);
				}
			}
			else if (time > (float)interval)
			{
				DoRefreshPoint();
				time = 0f;
			}
			else
			{
				time += 1f;
				yield return Yielders.GetWaitForSeconds(1f);
			}
		}
	}

	protected virtual void DoRefreshPoint()
	{
		HttpRequestCommonProgressActivitySimply httpRequestCommonProgressActivitySimply = new HttpRequestCommonProgressActivitySimply();
		httpRequestCommonProgressActivitySimply.type = m_Type;
		GameHttpManager.Inst.SendNoWait(httpRequestCommonProgressActivitySimply, delegate(HttpResponseCommonProgressActivitySimply OnHttpResponse)
		{
			if (m_PointNumGrow != null)
			{
				m_PointNumGrow.SetNumber(int.Parse(m_PointerText.text));
				m_PointNumGrow.GrowTo(OnHttpResponse.point);
			}
			else
			{
				m_PointerText.text = OnHttpResponse.point.ToString();
			}
			m_HttpResponseCache.point = OnHttpResponse.point;
			SetInfo();
		});
	}

	protected virtual void UpdateProgressPos()
	{
		if (m_HttpResponseCache != null)
		{
			m_Container.CalculateLayoutInputHorizontal();
			m_Container.SetLayoutHorizontal();
			if (m_ProgressBar != null)
			{
				m_ProgressBar.value = GetProgressPos();
			}
		}
	}

	protected float GetProgressPos(int point = -1)
	{
		if (point == -1)
		{
			point = m_HttpResponseCache.point;
		}
		int num = -1;
		int num2 = point;
		for (int i = 0; i < m_HttpResponseCache.infos.Length; i++)
		{
			if (point >= m_HttpResponseCache.infos[i].target)
			{
				num = i;
				num2 = point - m_HttpResponseCache.infos[i].target;
			}
		}
		Vector3[] array = new Vector3[4];
		m_ProgressBar.fillRect.parent.GetComponent<RectTransform>().GetWorldCorners(array);
		float x = array[0].x;
		float x2 = array[2].x;
		float num3 = x2 - x;
		float num4 = (num == -1) ? x : ((num >= m_HttpResponseCache.infos.Length) ? x2 : GetRectCenter(m_TemplateInitiatorHorizontal.Items[num].GetComponent<RectTransform>()).x);
		float num5 = (num + 1 == -1) ? x : ((num + 1 >= m_HttpResponseCache.infos.Length) ? x2 : GetRectCenter(m_TemplateInitiatorHorizontal.Items[num + 1].GetComponent<RectTransform>()).x);
		int num6 = (num == -1 || num + 1 >= m_HttpResponseCache.infos.Length) ? m_HttpResponseCache.infos[0].target : (m_HttpResponseCache.infos[num + 1].target - m_HttpResponseCache.infos[num].target);
		return Mathf.Clamp01((num4 - x) / num3 + (num5 - num4) / num3 * (float)num2 / (float)num6);
	}

	protected Vector2 GetRectCenter(RectTransform rect)
	{
		Vector3[] array = new Vector3[4];
		rect.GetWorldCorners(array);
		return (array[0] + array[2]) / 2f;
	}

	private void SaveCommonProgressAllClaim(Activity activity)
	{
		int commonProgressActivityType = (int)GetCommonProgressActivityType(activity.activityId);
		LocalPlayerDatabase.SetPrefValue("CommonProgressAllClaim_" + commonProgressActivityType, activity.startTime);
	}

	public void DoUpdate()
	{
		if (m_updateAction != null)
		{
			m_updateAction();
		}
		else
		{
			m_Host.UpdateBinding();
		}
	}

	public static CommonProgressActivityType GetCommonProgressActivityType(int activityId)
	{
		switch (LocalResources.ActivityLobbyInfos.Get(activityId).Type)
		{
		case ActivityType.CHARACTER_TASK_ACTIVITY:
			return CommonProgressActivityType.CharacterTaskActivity;
		case ActivityType.SHARE_ACTIVITY:
			return CommonProgressActivityType.ShareActivity;
		case ActivityType.NEW_CARD_ACTIVITY_REWARD:
			return CommonProgressActivityType.NewCardReward;
		case ActivityType.OLD_CARD_ACTIVITY_REWARD:
			return CommonProgressActivityType.OldCardReward;
		case ActivityType.OLD_CARD_COLLECTION_REWARD:
			return CommonProgressActivityType.OldCardCollectionReward;
		case ActivityType.LIGHT_UP_ACTIVITY:
			return CommonProgressActivityType.LightUpActivity;
		case ActivityType.CHARACTER_LOTTERY:
			return CommonProgressActivityType.LotteryActivity;
		case ActivityType.CHARACTER_SUITE_LOTTERY:
			return CommonProgressActivityType.LotteryActivity2;
		case ActivityType.LIMITLOTTERY_ACTIVITY:
			return CommonProgressActivityType.LimitLottery;
		default:
			return (CommonProgressActivityType)0;
		}
	}

	public static void RefreshRedPoint(int activityId, bool state = true)
	{
		RefreshRedPointByType((int)GetCommonProgressActivityType(activityId), state);
	}

	public static void RefreshRedPointByType(int type, bool state = true)
	{
		if (type != 0)
		{
			if (m_RedPointStates == null)
			{
				m_RedPointStates = new Dictionary<int, bool>();
			}
			if (m_RedPointStates.ContainsKey(type))
			{
				m_RedPointStates[type] = state;
			}
			else
			{
				m_RedPointStates.Add(type, state);
			}
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}
	}

	public static bool GetRedPoint(int activityId)
	{
		int commonProgressActivityType = (int)GetCommonProgressActivityType(activityId);
		if (commonProgressActivityType == 0)
		{
			return false;
		}
		if (m_RedPointStates == null || !m_RedPointStates.ContainsKey(commonProgressActivityType))
		{
			return false;
		}
		return m_RedPointStates[commonProgressActivityType];
	}

	public static bool GetRedPoint(CommonProgressActivityType type)
	{
		if (m_RedPointStates == null || !m_RedPointStates.ContainsKey((int)type))
		{
			return false;
		}
		return m_RedPointStates[(int)type];
	}

	public static int CommonProgressAllClaim(int activityId)
	{
		int commonProgressActivityType = (int)GetCommonProgressActivityType(activityId);
		return LocalPlayerDatabase.GetPrefValueInt("CommonProgressAllClaim_" + commonProgressActivityType);
	}

	public static float GetProgressValue(CommonProgressActivityInfo[] infos, int point)
	{
		if (point <= infos[0].target)
		{
			return 0f;
		}
		if (point >= infos[infos.Length - 1].target)
		{
			return 1f;
		}
		int num = 0;
		for (int i = 0; i < infos.Length; i++)
		{
			if (point >= infos[i].target)
			{
				num = i;
			}
		}
		return (float)num / (float)(infos.Length - 1) + ((float)point - (float)infos[num].target) / (float)(infos[num + 1].target - infos[num].target);
	}
}
