using LightUI;
using UnityEngine.UI;

internal class CharacterUI_Previewing
{
	public UIDataBinder m_Host;

	public Button m_Previewing;

	public void Bind(CommonDataCollection args)
	{
		bool flag = IsPreviewingColor();
		bool flag2 = IsPreviewingSkinPart();
		m_Previewing.gameObject.SetActive((!CharacterUI_PageColoration.IsRandomColoring && flag) | flag2);
		m_Host.EventProxy(m_Previewing, "OnCancelPreview");
	}

	public void OnCancelPreview()
	{
		CharacterUtility.RevertCurrentColors();
		PreviewUtility.RevertAllPreview();
		if (CharacterUI_PageSkinPart.OnCancelPreview != null)
		{
			CharacterUI_PageSkinPart.OnCancelPreview();
		}
		if (CharacterColorationUI.OnCancelPreview != null)
		{
			CharacterColorationUI.OnCancelPreview();
		}
		if (CharacterDetailBinder.OnCancelPreview != null)
		{
			CharacterDetailBinder.OnCancelPreview();
		}
	}

	private bool IsPreviewingColor()
	{
		int[] array = CharacterUtility.CurrentColorIDs();
		for (int i = 0; i < array.Length; i++)
		{
			CharacterUtility.FindSkinPart(CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected).currentSkinInfo, (SkinPartType)i, out int _, out int colorID);
			if (colorID != array[i])
			{
				return true;
			}
		}
		return false;
	}

	private bool IsPreviewingSkinPart()
	{
		int[] partIDs = LobbyScene.Inst.CurrentCharacter.m_SkinPartController.PartIDs;
		for (int i = 0; i < partIDs.Length; i++)
		{
			CharacterUtility.FindSkinPart(CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected).currentSkinInfo, (SkinPartType)i, out int partID, out int _);
			if (partID != partIDs[i])
			{
				return true;
			}
		}
		return false;
	}
}
