public class ActorProperties
{
	public const byte PlayerName = byte.MaxValue;

	public const byte IsInactive = 254;

	public const byte UserId = 253;
}
