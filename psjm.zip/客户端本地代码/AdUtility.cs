using GameMessages;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class AdUtility
{
	private const string DailySummaryCountKey = "AD_DailySummaryCount";

	private const string LastSummaryTimeKey = "AD_LastSummaryTime";

	private const string LastWatchTimeKey = "AD_LastWatchTime";

	private static Dictionary<AdScene, int> m_LastWatchTime = new Dictionary<AdScene, int>();

	private static Dictionary<AdScene, AdConfig> AdConfigs = new Dictionary<AdScene, AdConfig>();

	private static CompatibleRandom Rand;

	public static PlayerCharacterInfo TryPlayerCharacterInfo;

	private static Dictionary<AdScene, int> LastWatchTime
	{
		get
		{
			if (m_LastWatchTime.Count == 0 && LocalPlayerDatabase.HasPrefKey("AD_LastWatchTime"))
			{
				m_LastWatchTime = JsonUtility.FromJson<Serialization<AdScene, int>>(LocalPlayerDatabase.GetPrefValueString("AD_LastWatchTime")).ToDictionary();
			}
			return m_LastWatchTime;
		}
	}

	public static void ClearTryCharacter()
	{
		TryPlayerCharacterInfo = null;
	}

	public static bool IsAdEnable(AdScene scene)
	{
		if (!AdSDKManager.Inst.AdEnabled || LocalPlayerDatabase.PrivatePlayerInfo.adConfig == null)
		{
			return false;
		}
		AdConfig[] adConfig = LocalPlayerDatabase.PrivatePlayerInfo.adConfig;
		foreach (AdConfig adConfig2 in adConfig)
		{
			if (adConfig2.adScene != scene || adConfig2.usedCount >= adConfig2.dailyCount || LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < adConfig2.grade || (LastWatchTime.ContainsKey(scene) && UtcTimeStamp.Now - LastWatchTime[scene] < adConfig2.interval))
			{
				continue;
			}
			switch (scene)
			{
			case AdScene.TRY_SUITE:
				TryPlayerCharacterInfo = CharacterUtility.GetTrySuiteCharacter(CharacterUtility.GetTrySkinSuiteID((GameRuntime.PlayingRole == RoleType.Police) ? LocalPlayerDatabase.PlayerInfo.activeCharacterID[0] : LocalPlayerDatabase.PlayerInfo.activeCharacterID[1]));
				return TryPlayerCharacterInfo != null;
			case AdScene.TRY_CHARACTER:
			{
				int[] array = CharacterUtility.AllNotOwnedCharacters(GameRuntime.PlayingRole);
				if (array.Length != 0)
				{
					int characterID = array[Random.Range(0, array.Length)];
					if (GameRuntime.PlayingRole == RoleType.Thief && NewbiePage.IsNewbieRole(GameRuntime.PlayingRole) && array.Contains(400))
					{
						characterID = 400;
					}
					TryPlayerCharacterInfo = CharacterUtility.GetTryCharacter(characterID);
				}
				return TryPlayerCharacterInfo != null;
			}
			default:
				return true;
			}
		}
		return false;
	}

	public static bool IsSkipAd(AdScene scene)
	{
		AdConfig adConfig = GetAdConfig(scene);
		if (adConfig != null && adConfig.skipAdMoney > 0)
		{
			return LocalPlayerDatabase.PrivatePlayerInfo.rechargeAmount >= adConfig.skipAdMoney;
		}
		return false;
	}

	public static void RequestRewards(AdScene scene, int param1, Delegates.ObjectCallback<HttpResponseAdWatched> onResponse, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestAdWatched httpRequestAdWatched = new HttpRequestAdWatched();
		httpRequestAdWatched.scene = (int)scene;
		httpRequestAdWatched.param1 = param1;
		GameHttpManager.Inst.Send(httpRequestAdWatched, delegate(HttpResponseAdWatched response)
		{
			OnReward(scene);
			if (onResponse != null)
			{
				onResponse(response);
			}
		}, onSuccess);
	}

	public static void RequestNoRewards(AdScene scene, Delegates.VoidCallback onSuccess = null)
	{
		HttpRequestAdWatched httpRequestAdWatched = new HttpRequestAdWatched();
		httpRequestAdWatched.scene = (int)scene;
		httpRequestAdWatched.noReward = 1;
		GameHttpManager.Inst.Send(httpRequestAdWatched, delegate
		{
			OnReward(scene);
		}, onSuccess);
	}

	public static AdConfig GetAdConfig(AdScene scene)
	{
		if (AdConfigs.ContainsKey(scene))
		{
			return AdConfigs[scene];
		}
		return null;
	}

	public static void SetAdConfigs(AdConfig[] configs)
	{
		AdConfigs.Clear();
		if (configs != null)
		{
			foreach (AdConfig adConfig in configs)
			{
				AdConfigs.Add(adConfig.adScene, adConfig);
			}
		}
	}

	private static void OnReward(AdScene scene)
	{
		AdConfigs[scene].usedCount++;
		if (LastWatchTime.ContainsKey(scene))
		{
			LastWatchTime[scene] = UtcTimeStamp.Now;
		}
		else
		{
			LastWatchTime.Add(scene, UtcTimeStamp.Now);
		}
		SaveLastWatchTime();
	}

	private static void SaveLastWatchTime()
	{
		LocalPlayerDatabase.SetPrefValue("AD_LastWatchTime", JsonUtility.ToJson(new Serialization<AdScene, int>(m_LastWatchTime)));
	}

	public static bool SummaryAdExtraCondition()
	{
		if (UtcTimeStamp.IsCrossDay(LocalPlayerDatabase.GetPrefValueInt("AD_LastSummaryTime"), UtcTimeStamp.Now))
		{
			LocalPlayerDatabase.SetPrefValue("AD_LastSummaryTime", UtcTimeStamp.Now);
			LocalPlayerDatabase.SetPrefValue("AD_DailySummaryCount", 0);
		}
		int num = LocalPlayerDatabase.GetPrefValueInt("AD_DailySummaryCount");
		if (num <= 1)
		{
			LocalPlayerDatabase.SetPrefValue("AD_DailySummaryCount", ++num);
		}
		if (num > 1)
		{
			return Random01() < 0.75f;
		}
		return false;
	}

	public static float Random01()
	{
		if (Rand == null)
		{
			Rand = new CompatibleRandom((int)LocalPlayerDatabase.LoginInfo.roleID ^ UtcTimeStamp.Now);
		}
		return (float)Rand.NextDouble();
	}
}
