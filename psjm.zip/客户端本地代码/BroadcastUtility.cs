using GameMessages;
using LightUtility;

public class BroadcastUtility
{
	public static Delegates.ObjectCallback<BroadcastType> onNewBroadcast;

	public static void RefreshBroadcast(BroadcastType channel, int lastID, int count, Delegates.ObjectCallback<HttpResponseBroadcast> onResponse)
	{
		HttpRequestBroadcast httpRequestBroadcast = new HttpRequestBroadcast();
		httpRequestBroadcast.channel = (int)channel;
		httpRequestBroadcast.lastID = lastID;
		httpRequestBroadcast.count = count;
		GameHttpManager.Inst.SendNoWait(httpRequestBroadcast, onResponse);
	}
}
