using LightUI;
using LightUtility;
using System;
using UnityEngine;

public class CharacterDetailUI : UIEventListener
{
	public Vector3 m_ProjectionOffset;

	public float m_TweenDuration = 0.3f;

	[NonSerialized]
	public bool m_Init;

	public static bool IsShowing;

	private new void Awake()
	{
		base.Awake();
		GetComponent<UIPage>().SetTag(LobbyScene.Mode.Normal.ToString());
	}

	private void OnEnable()
	{
		SetCameraOffCenter();
		LobbyScene.Inst.ResetView();
		ShowCharacter();
	}

	private void OnDisable()
	{
		PreviewUtility.RevertAllPreview();
	}

	public override void OnEnterUI()
	{
		base.OnEnterUI();
		IsShowing = true;
		LobbyScene.Inst.CurrentCharacter.StartLobbyEntrance();
	}

	public override void OnExitUI()
	{
		base.OnExitUI();
		IsShowing = false;
		m_Init = false;
	}

	private CameraOffCenterProjection GetOffCenterProjection()
	{
		CameraOffCenterProjection cameraOffCenterProjection = LobbyScene.Inst.NormalCamera.GetComponent<CameraOffCenterProjection>();
		if (cameraOffCenterProjection == null)
		{
			cameraOffCenterProjection = LobbyScene.Inst.NormalCamera.gameObject.AddComponent<CameraOffCenterProjection>();
		}
		return cameraOffCenterProjection;
	}

	private void SetCameraOffCenter()
	{
		if (LobbyScene.Inst != null)
		{
			CameraOffCenterProjection offCenterProjection = GetOffCenterProjection();
			offCenterProjection.enabled = true;
			offCenterProjection.TweenOffset(m_ProjectionOffset, m_TweenDuration);
		}
	}

	private void ShowCharacter()
	{
		PreviewUtility.PreviewCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
	}
}
