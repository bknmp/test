using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using GameMessages;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[TaskName("创建AI")]
[TaskCategory("考驾照功能")]
public class CreateAIPlayer : BehaviorDesigner.Runtime.Tasks.Action
{
	[Serializable]
	public class AiConfig
	{
		public int id;

		public int coin;

		public ExternalBehaviorTree aiTree;

		public int aggressive;

		public int focus;

		public Vector3 position;

		public Vector3 eulerRotation = Vector3.zero;
	}

	public List<AiConfig> aiDatas;

	public override TaskStatus OnUpdate()
	{
		StartCoroutine(CreatePlayers());
		return TaskStatus.Success;
	}

	public IEnumerator CreatePlayers()
	{
		yield return new WaitForSeconds(0.5f);
		foreach (AiConfig config in aiDatas)
		{
			AIInfo aIInfo = LocalResources.AITable.Get(config.id);
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(aIInfo.CharacterID);
			PlayerCharacterInfo playerCharacterInfo = CharacterUtility.GetPlayerCharacterInfo(characterInfo, aIInfo.TalentLevels, aIInfo.SuiteID);
			MatchPlayerData matchPlayerData = CharacterUtility.GetMatchPlayerData(aIInfo.Cards, aIInfo.CardLevels);
			List<string> list = (characterInfo.Role == RoleType.Thief) ? GameRuntime.TotalThiefs : GameRuntime.TotalPolices;
			List<string> list2 = (characterInfo.Role == RoleType.Thief) ? ExamManager.Inst.tempThiefs : ExamManager.Inst.tempPolices;
			string name = aIInfo.Name;
			int num = 1;
			string realName = name;
			while (GameRuntime.TotalPolices.Contains(realName) || GameRuntime.TotalThiefs.Contains(realName))
			{
				realName = $"{name}#{num}";
			}
			list2.Add(realName);
			list.Add(realName);
			GameRuntime.RoomPlayers[realName].CharacterInfo = playerCharacterInfo;
			GameRuntime.RoomPlayers[realName].MatchData = matchPlayerData;
			CharacterPreLoader.Inst.PreLoadNewCharacter(realName);
			yield return new WaitForSeconds(0.3f);
			CharacterPreLoader.Inst.FinishPreLoad();
			GameObject gameObject = PhotonNetwork.InstantiateSceneObject(realName, config.position, Quaternion.Euler(config.eulerRotation), 0, null);
			PhotonView[] components = gameObject.GetComponents<PhotonView>();
			for (int i = 0; i < components.Length; i++)
			{
				components[i].TransferOwnership(PhotonPlayer.Find(realName));
			}
			if (GameRuntime.IsOfflineMode && realName != PhotonNetwork.player.UserId)
			{
				gameObject.GetComponent<AIController>().enabled = true;
			}
			PlayerController component = gameObject.GetComponent<PlayerController>();
			AIController component2 = gameObject.GetComponent<AIController>();
			component2.enabled = true;
			component2.SetAIConfig(config.aiTree);
			component2.SetPersonality(config.aggressive, config.focus);
			component2.ForceCardCoolDown();
			component.RpcAddCoin(InGameCoinRewardReason.ThiefInit, null, config.coin);
			yield return new WaitForSeconds(0.5f);
		}
	}
}
