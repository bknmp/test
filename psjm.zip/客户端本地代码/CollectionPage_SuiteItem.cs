using GameMessages;
using LightUI;
using LightUtility;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_SuiteItem
{
	public UIDataBinder m_Host;

	public Text m_Personality;

	public Text m_Progress;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_Selected;

	public Text m_SuiteText;

	public RawImage m_Preview;

	public UIPointerBehaviour m_Input;

	public UIDataBinder m_SkinPartPanel;

	public Button m_Button;

	public UIStateItem m_OwnedState;

	public GameObject m_NotHaveTips;

	public GameObject m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeason;

	private string m_ProgressFormat;

	private string m_PersonalityFormat;

	public static int Selected;

	private int m_SuiteID;

	private int m_State;

	private ShopSuiteInfo m_SuiteInfo;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	public void Bind(CommonDataCollection args)
	{
		if (m_ProgressFormat == null)
		{
			m_ProgressFormat = m_Progress.text;
		}
		if (m_PersonalityFormat == null)
		{
			m_PersonalityFormat = m_Personality.text;
		}
		m_SuiteID = args["suiteID"];
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_SuiteInfo = LocalResources.ShopSuiteTable.Find(m_SuiteID);
		DropItem[] suiteCollectProgress = CollectionUtility.GetSuiteCollectProgress(m_SuiteID, m_PlayerInfo);
		int limitedEdition = CharacterUtility.GetSkinInfo(LocalResources.DropItemTable.Get(m_SuiteInfo.ShopItemIDs[0]).TypeParam).LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		int num = m_SuiteInfo.ShopItemIDs.Length;
		int num2 = suiteCollectProgress.Length;
		if (num2 == num)
		{
			m_State = 0;
			m_Progress.transform.parent.gameObject.SetActive(value: false);
			m_Personality.text = string.Format(m_PersonalityFormat, CollectionUtility.CalculateItemsPersonality(m_SuiteInfo.ShopItemIDs));
			m_Personality.gameObject.SetActive(value: true);
			m_OwnedState.State = 0;
		}
		else if (num2 < num && num2 > 0)
		{
			m_State = 1;
			m_Progress.text = string.Format(m_ProgressFormat, num2, num);
			m_Progress.transform.parent.gameObject.SetActive(value: true);
			m_Personality.text = string.Format(m_PersonalityFormat, (from a in suiteCollectProgress
				select a.Personality).Sum());
			m_Personality.gameObject.SetActive(value: true);
			m_OwnedState.State = 1;
		}
		else
		{
			m_State = 2;
			m_Progress.transform.parent.gameObject.SetActive(value: false);
			m_Personality.gameObject.SetActive(value: false);
			m_OwnedState.State = 2;
		}
		m_Icon.sprite = SpriteSource.Inst.Find(m_SuiteInfo.Icon);
		m_QualityBG.State = m_SuiteInfo.Quality;
		m_Effect.State = m_SuiteInfo.Quality;
		m_Effect.gameObject.SetActive(m_State == 0);
		if (Selected == 0)
		{
			Selected = m_SuiteID;
			ShowCharacter();
		}
		UpdateSelectState();
		m_Host.EventProxy(m_Button, "OnSelectButtonClick");
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_SuiteID)
		{
			Selected = m_SuiteID;
			ShowCharacter();
			UIDataEvents.Inst.InvokeEvent("OnSelectSuiteItemChanged");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_SuiteID == Selected;
			m_Selected.SetActive(active);
		}
	}

	private void ShowCharacter()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["itemIDs"].val = m_SuiteInfo.ShopItemIDs.ToArray();
		commonDataCollection["playerInfo"].val = m_PlayerInfo;
		m_SkinPartPanel.Args = commonDataCollection;
		m_SuiteText.text = m_SuiteInfo.Name;
		m_SuiteText.color = m_SuiteInfo.QualityColor;
		m_NotHaveTips.SetActive(m_State == 2);
		m_ButtonGain.SetActive(m_State != 0 && m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID);
		int characterID = m_SuiteInfo.CharacterID;
		RoleType role = LocalResources.CharacterTable.Find(characterID).Role;
		PlayerCharacterInfo suiteCharacterInfo = CollectionUtility.GetSuiteCharacterInfo(characterID, m_PlayerInfo, m_SuiteInfo);
		MatchPlayerData matchPlayerData = null;
		matchPlayerData = ((m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID) ? CharacterUtility.GetPlayerData(m_PlayerID, suiteCharacterInfo.characterID, m_PlayerInfo, m_PlayerCardConfigs) : CharacterUtility.GetPlayerData(characterID));
		if (matchPlayerData != null)
		{
			LobbyScene.Inst.UpdateCampPanel(role, m_PlayerInfo.publicInfo.name, suiteCharacterInfo, matchPlayerData, m_Preview, notRTMethod: false, m_Input, closeOppositeRole: true);
		}
	}
}
