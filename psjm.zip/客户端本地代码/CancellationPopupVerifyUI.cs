using GameMessages;
using LightUI;
using UnityEngine.UI;

public class CancellationPopupVerifyUI
{
	public UIDataBinder m_Host;

	public Toggle m_Toggle;

	public Button m_NextBtn;

	public UIStateItem m_State;

	public UIPopup m_CancellationPopupResultUI;

	public Button m_ConfirmBtn;

	public Button m_Close;

	public Button m_GoBack;

	public Button m_GoBack2;

	public Text m_Content;

	public Text m_Verify;

	private HttpResponseCancellationContent m_Response;

	public void Bind(CommonDataCollection args)
	{
		m_State.State = 0;
		m_Toggle.isOn = false;
		if (m_Response == null)
		{
			GameHttpManager.Inst.Send(new HttpRequestCancellationContent(), delegate(HttpResponseCancellationContent onResponse)
			{
				m_Response = onResponse;
				m_Content.text = "\n" + m_Response.content;
				m_Verify.text = m_Response.verify;
			});
		}
		else
		{
			m_Content.text = "\n" + m_Response.content;
			m_Verify.text = m_Response.verify;
		}
		m_Host.EventProxy(m_NextBtn, "OnNextBtnClick");
		m_Host.EventProxy(m_ConfirmBtn, "OnConfirmBtnClick");
		m_Host.EventProxy(m_Close, "GoToSetting");
		m_Host.EventProxy(m_GoBack, "GoToSetting");
		m_Host.EventProxy(m_GoBack2, "GoToSetting");
	}

	public void OnNextBtnClick()
	{
		if (m_Toggle.isOn)
		{
			m_State.State = 1;
		}
		else
		{
			UILobby.Current.ShowTips(Localization.doubleCheckwithToggle);
		}
	}

	public void OnConfirmBtnClick()
	{
		GameHttpManager.Inst.Send(new HttpRequestCancellation(), delegate
		{
		}, delegate
		{
			CommonDataCollection args2 = new CommonDataCollection
			{
				["state"] = 0
			};
			UILobby.Current.ShowUI(m_CancellationPopupResultUI, args2);
			if (PlatformUtility.GetVersionCode() > 732000)
			{
				AndroidSDKAdapter.Adapter.NativeCallNoArgs("CloseAccount");
			}
		}, delegate
		{
			CommonDataCollection args = new CommonDataCollection
			{
				["state"] = 1
			};
			UILobby.Current.ShowUI(m_CancellationPopupResultUI, args);
		});
	}

	public void GoToSetting()
	{
		UILobby.Current.GoBack();
	}
}
