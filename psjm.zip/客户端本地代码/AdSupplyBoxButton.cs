using GameMessages;
using LightUI;
using UnityEngine;

public class AdSupplyBoxButton : MonoBehaviour
{
	public CommonRewardPopupUI supplyBoxRewardUI;

	public void OnClick()
	{
		AdScene adScene = AdScene.LOBBY_SUPPLY_BOX;
		if (AdUtility.IsAdEnable(adScene))
		{
			AdSDKManager.Inst.ShowAd(adScene, delegate
			{
				AdUtility.RequestRewards(adScene, 0, delegate(HttpResponseAdWatched response)
				{
					GetComponent<UIPopup>().GoBack();
					CommonRewardPopupUI.Show(supplyBoxRewardUI).AddItems(response.itemList);
					if (LobbyScene.Inst.AdSupplyBoxInst != null)
					{
						LocalPlayerDatabase.SetPrefValue("HasAdSupply", 0);
						UnityEngine.Object.Destroy(LobbyScene.Inst.AdSupplyBoxInst);
					}
				});
			});
		}
	}
}
