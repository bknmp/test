using GameMessages;
using LightUI;
using UnityEngine;

internal class AnniversaryPreview
{
	public UIDataBinder m_Host;

	public UIDataBinder m_Item1;

	public UIDataBinder m_Item2;

	public UIDataBinder m_Item3;

	public UIDataBinder m_Item4;

	public UIDataBinder m_Item5;

	public UIDataBinder m_Item6;

	public UIDataBinder m_Item7;

	public UIDataBinder m_Item8;

	public void Bind(CommonDataCollection args)
	{
		UIDataBinder[] array = new UIDataBinder[8]
		{
			m_Item1,
			m_Item2,
			m_Item3,
			m_Item4,
			m_Item5,
			m_Item6,
			m_Item7,
			m_Item8
		};
		AnniversaryActivityUI componentInParent = m_Host.GetComponentInParent<AnniversaryActivityUI>();
		if (componentInParent == null)
		{
			UnityEngine.Debug.LogError("Canot Find AnniversaryActivityUI");
			return;
		}
		ActivityLobbyInfo activityInfoByType = componentInParent.GetActivityInfoByType(ActivityType.PREVIEW);
		for (int i = 0; i < activityInfoByType.PreviewActivityIDs.Length; i++)
		{
			int num = activityInfoByType.PreviewActivityIDs[i];
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(num);
			Activity activityByID = componentInParent.GetActivityByID(num, includeNotOpen: true);
			if (activityLobbyInfo != null && activityByID != null)
			{
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				commonDataCollection["activity"].val = activityByID;
				commonDataCollection["activityInfo"].val = activityLobbyInfo;
				array[i].Args = commonDataCollection;
			}
		}
	}
}
