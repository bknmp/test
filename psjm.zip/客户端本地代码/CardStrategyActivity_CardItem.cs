using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CardStrategyActivity_CardItem
{
	public UIDataBinder m_Host;

	public UIStateImage m_Quality;

	public Image m_Icon;

	public MultiTargetGraphicButton m_Button;

	public UIPage m_CardDetailUI;

	private int m_ItemID;

	public void Bind(CommonDataCollection args)
	{
		m_ItemID = args["itemID"];
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_ItemID);
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(CardUtility.CurCardSkin(m_ItemID));
		m_Quality.State = inGameStoreInfo.Quality;
		m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
		m_Host.EventProxy(m_Button, "OnClick");
	}

	public void OnClick()
	{
		UILobby.Current.ShowUI(m_CardDetailUI, CardUtility.CardDetailUIArgsWraper(m_ItemID, 0));
		CardConfigEditPage_CardSkinItemTemplate.globalSelected = CardUtility.CurCardSkin(m_ItemID);
		CardConfigEditPage_PageCardSkin.HadSetCardSkinDefaultSelect = true;
		UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
	}
}
