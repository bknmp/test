using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;

public class CardPieceProcessBar : UIProgressBar
{
	private enum TipsState
	{
		CanCompose,
		CanUpgrade
	}

	public UIStateItem m_BarState;

	public UIStateItem m_TipsState;

	public Animator m_ArrowAnimator;

	public float m_MinSliderValue;

	public AudioItem m_AudioItem;

	public UIStateItem m_EnoughIcon;

	public UIStateItem m_NotEnoughIcon;

	public UIStateItem m_valueText;

	private bool m_owmCard;

	private bool m_showTips;

	private Animator m_animator;

	public bool IsFull
	{
		get
		{
			if (base.Current >= base.Total)
			{
				return base.Total > 0f;
			}
			return false;
		}
	}

	private new void Awake()
	{
		m_animator = GetComponent<Animator>();
		base.Awake();
	}

	private void OnDisable()
	{
		StopAllCoroutines();
		if (m_AudioItem != null)
		{
			SoundManager.StopLoop(m_AudioItem, 0f);
		}
	}

	public void SetInfo(int cardID)
	{
		m_showTips = false;
		m_BarState.gameObject.SetActive(value: true);
		if (!CardUtility.CanDropCardPiece(cardID))
		{
			SetProgress(0f, 0f);
			m_BarState.gameObject.SetActive(value: false);
			m_TipsState.gameObject.SetActive(value: false);
			return;
		}
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		CardGrowthInfo cardGrowthInfo = LocalResources.CardGrowthTable.Get(inGameStoreInfo.GrowthID);
		if (CardUtility.IsOwned(cardID))
		{
			int cardLevel = CardUtility.GetCardLevel(cardID);
			if (cardLevel >= cardGrowthInfo.MaxLevel)
			{
				SetProgress(0f, 0f);
				m_BarState.State = 2;
				if (m_valueText != null)
				{
					m_valueText.State = 1;
				}
				m_ProgressText.text = CardUtility.GetOwnCardPieceNum(cardID).ToString();
			}
			else
			{
				SetProgress(CardUtility.GetOwnCardPieceNum(cardID), cardGrowthInfo.PieceCostNew[cardLevel - 1]);
			}
			if (m_EnoughIcon != null && m_NotEnoughIcon != null)
			{
				int num3 = m_EnoughIcon.State = (m_NotEnoughIcon.State = 1);
			}
			if (m_valueText != null)
			{
				m_valueText.State = 1;
			}
		}
		else
		{
			SetProgress(CardUtility.GetOwnCardPieceNum(cardID), cardGrowthInfo.ComposePiece);
			if (m_EnoughIcon != null && m_NotEnoughIcon != null)
			{
				int num3 = m_EnoughIcon.State = (m_NotEnoughIcon.State = 0);
			}
			if (m_valueText != null)
			{
				m_valueText.State = ((!IsFull) ? 1 : 0);
			}
		}
	}

	public override void SetProgress(float current, float total, string showText = "")
	{
		m_Bar.transform.parent.parent.gameObject.SetActive(value: true);
		base.SetProgress(current, total);
		float num = Mathf.Round(current);
		m_ProgressText.text = string.Format(m_ProgressFormat, num, total);
		if (current >= total)
		{
			m_BarState.State = 1;
		}
		else
		{
			m_BarState.State = 0;
		}
		if (m_showTips)
		{
			TryShowTips();
		}
		else if (m_TipsState != null)
		{
			m_TipsState.gameObject.SetActive(value: false);
		}
	}

	public void DropCardPiece(int dropID, int num, bool tween = true, float tweenDelay = 0f, bool hadRefreshPlayerAssets = false)
	{
		if (m_valueText != null)
		{
			m_valueText.State = 1;
		}
		m_showTips = true;
		if (m_animator != null)
		{
			m_animator.speed = 0f;
		}
		DropItem dropItem = LocalResources.DropItemTable.Get(dropID);
		if (dropItem.Type != DropItemType.CardPiece)
		{
			m_Bar.transform.parent.parent.gameObject.SetActive(value: false);
			m_TipsState.gameObject.SetActive(value: false);
			return;
		}
		int typeParam = dropItem.TypeParam;
		int num2 = 0;
		int num3 = hadRefreshPlayerAssets ? (CardUtility.GetOwnCardPieceNum(typeParam) - num) : CardUtility.GetOwnCardPieceNum(typeParam);
		m_Bar.transform.parent.parent.gameObject.SetActive(value: true);
		m_owmCard = CardUtility.IsOwned(typeParam);
		if (m_owmCard)
		{
			int cardLevel = CardUtility.GetCardLevel(typeParam);
			CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(typeParam);
			if (cardLevel >= cardGrowth.MaxLevel)
			{
				m_BarState.State = 2;
				UINumberGrow component = m_ProgressText.GetComponent<UINumberGrow>();
				if (tween && component != null)
				{
					component.SetNumber(num3);
					component.GrowTo(num3 + num);
				}
				else
				{
					m_ProgressText.text = (num3 + num).ToString();
				}
				m_TipsState.gameObject.SetActive(value: false);
				return;
			}
			num2 = cardGrowth.PieceCostNew[cardLevel - 1];
			int num6 = m_EnoughIcon.State = (m_NotEnoughIcon.State = 1);
		}
		else
		{
			num2 = CardUtility.GetCardComposePieceNum(typeParam);
			int num6 = m_EnoughIcon.State = (m_NotEnoughIcon.State = 0);
		}
		if (tween)
		{
			SetProgress(num3, num2);
			float value = 0.1f * (float)num;
			value = Mathf.Clamp(value, 0.3f, 1f);
			StartCoroutine(ShowBarAnimator(num3 + num, value, tweenDelay));
		}
		else
		{
			SetProgress(num3 + num, num2);
		}
	}

	private IEnumerator ShowBarAnimator(float p, float m_duration, float delay)
	{
		if (m_ArrowAnimator != null)
		{
			m_ArrowAnimator.enabled = false;
		}
		yield return new WaitForSeconds(delay);
		if (m_AudioItem != null)
		{
			SoundManager.PlayLoop(m_AudioItem, 0f);
		}
		if (m_animator != null)
		{
			m_animator.speed = 1f;
		}
		TweenTo(p, m_duration);
		yield return new WaitForSeconds(m_duration);
		if (m_animator != null)
		{
			m_animator.speed = 0f;
		}
		if (m_ArrowAnimator != null)
		{
			m_ArrowAnimator.enabled = true;
		}
		if (m_AudioItem != null)
		{
			SoundManager.StopLoop(m_AudioItem, 0f);
		}
	}

	private void TryShowTips()
	{
		if (m_TipsState.gameObject == null)
		{
			return;
		}
		if (m_owmCard)
		{
			if (base.Current >= base.Total)
			{
				m_TipsState.State = 1;
				m_TipsState.gameObject.SetActive(value: true);
			}
			else
			{
				m_TipsState.gameObject.SetActive(value: false);
			}
		}
		else if (base.Current >= base.Total)
		{
			m_TipsState.State = 0;
			m_TipsState.gameObject.SetActive(value: true);
		}
		else
		{
			m_TipsState.gameObject.SetActive(value: false);
		}
	}

	protected override void SetBar(float ratio)
	{
		if (Mathf.Min(1f, ratio) == 0f)
		{
			base.SetBar(0f);
		}
		else
		{
			base.SetBar((1f - m_MinSliderValue) * ratio + m_MinSliderValue);
		}
	}
}
