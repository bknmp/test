using BehaviorDesigner.Runtime.Tasks;

[TaskName("破坏所有的监狱门")]
[TaskCategory("考驾照功能")]
public class BreakJailDoor : Action
{
	public override TaskStatus OnUpdate()
	{
		foreach (JailDoor allAutoOpenJailDoor in JailDoor.AllAutoOpenJailDoors)
		{
			if (!allAutoOpenJailDoor.IsBroken)
			{
				allAutoOpenJailDoor.BreakDoor();
			}
		}
		return TaskStatus.Success;
	}
}
