using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CharacterDiscountPackage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiator;

	public Text m_NextReward;

	public GameObject m_NextRewardBG;

	public Button m_ActivityInfoBtn;

	public UIScrollRect m_Scroll;

	public Button m_PreviewBtn1;

	public Button m_PreviewBtn2;

	private string m_RemainString;

	private string prefabName;

	protected int m_ActivityId;

	protected Activity m_Activity;

	public virtual void Bind(CommonDataCollection args)
	{
		m_Activity = (args["Activity"].val as Activity);
		if (m_Activity != null)
		{
			m_ActivityId = m_Activity.activityId;
			CharacterDiscountUtility.TryRefreshActivityInfo(m_ActivityId, delegate
			{
				if (IsCollectionAvailable())
				{
					CharacterDiscountUtility.SetLocalClaimInfo(m_ActivityId);
					if (m_NextReward != null && m_NextRewardBG != null)
					{
						SetInfo();
					}
					if (m_TemplateInitiator != null)
					{
						m_TemplateInitiator.Args = WrapData();
					}
					if (m_PreviewBtn1 != null)
					{
						m_Host.EventProxy(m_PreviewBtn1, "OnPreviewBtn1Click");
					}
					if (m_PreviewBtn2 != null)
					{
						m_Host.EventProxy(m_PreviewBtn2, "OnPreviewBtn2Click");
					}
					if (m_ActivityInfoBtn != null)
					{
						m_Host.EventProxy(m_ActivityInfoBtn, "OnActivityInfoBtnClick");
					}
				}
			}, delegate
			{
				UILobby.Current.GoHome();
			});
			if (m_Scroll != null && LocalPlayerDatabase.NoticeInfo.isAudit)
			{
				m_Scroll.enabled = true;
			}
		}
	}

	protected bool IsCollectionAvailable()
	{
		if (CharacterDiscountUtility.CacheInfo.ContainsKey(m_ActivityId) && CharacterDiscountUtility.packageInfo[m_ActivityId].Count == 0)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return false;
		}
		return true;
	}

	private void SetInfo()
	{
		if (string.IsNullOrEmpty(m_RemainString))
		{
			m_RemainString = m_NextReward.text;
		}
		string nextPackageCharacterName = CharacterDiscountUtility.GetNextPackageCharacterName(m_ActivityId, 1);
		string nextPackageCharacterName2 = CharacterDiscountUtility.GetNextPackageCharacterName(m_ActivityId, 2);
		if (string.IsNullOrEmpty(nextPackageCharacterName) || string.IsNullOrEmpty(nextPackageCharacterName2))
		{
			m_NextReward.gameObject.SetActive(value: false);
			m_NextRewardBG.SetActive(value: false);
		}
		else
		{
			m_NextReward.text = string.Format(m_RemainString, nextPackageCharacterName, nextPackageCharacterName2);
		}
	}

	public void OnPreviewBtn1Click()
	{
		IsActivityAvailable(m_ActivityId);
		CommonDataCollection loverPreviewArgs = CharacterDiscountUtility.GetLoverPreviewArgs(m_ActivityId, 1);
		loverPreviewArgs["index"] = 1;
		UIPage ui = PrefabSource.Inst.Load<UIPage>("CharacterGiftBagPreviewUI");
		UILobby.Current.ShowUI(ui, loverPreviewArgs);
	}

	public void OnPreviewBtn2Click()
	{
		IsActivityAvailable(m_ActivityId);
		CommonDataCollection loverPreviewArgs = CharacterDiscountUtility.GetLoverPreviewArgs(m_ActivityId, 2);
		loverPreviewArgs["index"] = 1;
		UIPage ui = PrefabSource.Inst.Load<UIPage>("CharacterGiftBagPreviewUI");
		UILobby.Current.ShowUI(ui, loverPreviewArgs);
	}

	public void OnActivityInfoBtnClick()
	{
		if (m_Activity == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
		}
		else
		{
			ActivityLobby.ShowInfoPopupUI(Localization.ActivityDesc, "", m_ActivityId);
		}
	}

	private bool IsActivityAvailable(int activityID)
	{
		if (ActivityLobby.GetActivityById(activityID) == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return false;
		}
		return true;
	}

	private CommonDataCollection WrapData()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int allCollectionCount = CharacterDiscountUtility.GetAllCollectionCount(m_ActivityId);
		if (allCollectionCount > 0)
		{
			for (int i = 0; i < allCollectionCount; i++)
			{
				commonDataCollection[i]["activityID"] = m_ActivityId;
				commonDataCollection[i]["collectionID"] = i + 1;
			}
		}
		return commonDataCollection;
	}
}
