using LightUtility;
using System;

[Serializable]
public class ChinaCityTable : IdBased
{
	public string Province;

	public string City;

	public string District;
}
