using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChatEntry
{
	public UIDataBinder m_Host;

	public Button m_Button;

	public UIDataScrollView m_DataScrollView;

	public GameObject m_RedPoint;

	public GameObject m_Empty;

	public GameObject m_BubbleBoxRedPoint;

	public UIDataBinder m_TeamRoomChat;

	private List<ChatInfo> newMessages = new List<ChatInfo>();

	public void Bind(CommonDataCollection args)
	{
		newMessages.Clear();
		ChatEntryManager.Inst.ExtractCacheMessages(newMessages);
		if (newMessages.Count > 0)
		{
			m_Empty.SetActive(value: false);
			args.Clear();
			for (int i = 0; i < newMessages.Count; i++)
			{
				args[i]["senderID"] = newMessages[i].senderID;
				args[i]["sender"] = newMessages[i].sender;
				args[i]["content"] = newMessages[i].content;
				args[i]["channel"] = (int)newMessages[i].channel;
				args[i]["membership"] = (newMessages[i].membershipInfos != null && MembershipUtility.IsInTime(0, newMessages[i].membershipInfos));
			}
			m_DataScrollView.AddItems(args.Array);
			m_DataScrollView.m_TemplateInitiator.UpdateImmediately();
			if (m_TeamRoomChat.gameObject.activeSelf)
			{
				m_TeamRoomChat.Args = args;
			}
		}
		int allUnreadCount = SocialChatManager.GetAllUnreadCount();
		if (allUnreadCount > 0)
		{
			m_RedPoint.SetActive(value: true);
			m_RedPoint.GetComponentInChildren<Text>().text = Mathf.Clamp(allUnreadCount, 1, 99).ToString();
		}
		else
		{
			m_RedPoint.SetActive(value: false);
		}
		m_BubbleBoxRedPoint.SetActive(!m_RedPoint.activeSelf && HeadBubbleBoxUtility.HasNewHeadBubbleBox(HeadBubbleBox.BubbleBox));
		m_Host.EventProxy(m_Button, "OnButtonClick");
		m_DataScrollView.m_ScrollRect.ScrollToEnd(immediately: true);
	}

	public void OnButtonClick()
	{
		int num = (LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Match) ? LobbyScene.Inst.m_MatchPanel.PlayerInstances.Count : LobbyScene.Inst.m_TeamPanel.PlayerInstances.Count;
		if ((TeamRoomUI.IsShowing || GameRuntime.IsMatching) && (GameRuntime.IsCustomRoom || GameRuntime.MapType != 0 || GameRuntime.PlayingRole != 0) && num > 1)
		{
			LobbyScene.Inst.ChatPanel.Show(2);
		}
		else if (SocialChatManager.CheckAnyUnreadMessage())
		{
			LobbyScene.Inst.ChatPanel.Show(1);
		}
		else
		{
			LobbyScene.Inst.ChatPanel.Show(0);
		}
	}
}
