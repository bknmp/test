using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_UpgradePage
{
	public UIDataBinder m_Host;

	public Text m_UpgradeGradeLimitTips;

	public MultiTargetGraphicButton m_UpgradeButton;

	public UIStateRawImage m_UpgradeButtonBG;

	public UIStateItem m_UpgradeButtonText;

	public Text m_GoldNum;

	public CardPieceProcessBar m_CardProcessUI;

	public Button m_GetCardPieceBtn;

	public UITemplateInitiator m_AttributeContent;

	public UIPage m_CardUpgradeUI;

	public MultiTargetGraphicButton m_GainTipsBtn;

	public MultiTargetGraphicButton m_ComposeBtn;

	public UIPopup m_GainCardTipsUI;

	public UIPopup m_CardComposeUI;

	public Text m_MaxLevelTips;

	public Text m_GradeLimitTips;

	public UIMultiButton m_PreviewMaxGradeBtn;

	private bool m_Initialized;

	private Color m_DefaultGlodColor;

	private string m_UpgradeGradeLimitFormat;

	private string m_UnlockGradeLimitFormat;

	private int m_cardID;

	private CardGrowthInfo m_GrowthInfo;

	private bool m_isLocalPlayer;

	private bool m_IsShowUpgradeBtn;

	private int m_cardLevel;

	private bool m_upgradeGradeLimit;

	private bool m_goldEnough;

	private bool m_pieceEnough;

	private CommonDataCollection m_ArrtArgs = new CommonDataCollection();

	public const float PlayerMoveSpeed = 2.8f;

	public void Bind(CommonDataCollection args)
	{
		if (!m_Initialized)
		{
			m_DefaultGlodColor = m_GoldNum.color;
			m_UpgradeGradeLimitFormat = m_UpgradeGradeLimitTips.text;
			m_UnlockGradeLimitFormat = m_GradeLimitTips.text;
			m_Initialized = true;
		}
		m_cardID = args["cardID"];
		m_isLocalPlayer = args["isLocalPlayer"];
		m_IsShowUpgradeBtn = args["showUpgradeBtn"];
		m_GrowthInfo = CardUtility.GetCardGrowth(m_cardID);
		m_cardLevel = args["cardLevel"];
		if (m_isLocalPlayer)
		{
			m_upgradeGradeLimit = (m_cardLevel >= m_GrowthInfo.MaxLevel || Mathf.Max(LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice, LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief) < m_GrowthInfo.UpgradeLimitGrade[m_cardLevel - 1]);
			m_goldEnough = (m_cardLevel < m_GrowthInfo.MaxLevel && LocalPlayerDatabase.PlayerInfo.gold >= m_GrowthInfo.GoldCostNew[m_cardLevel - 1]);
		}
		m_CardProcessUI.SetInfo(m_cardID);
		if (m_isLocalPlayer && CardUtility.CanDropCardPiece(m_cardID) && m_cardLevel < m_GrowthInfo.MaxLevel)
		{
			m_pieceEnough = m_CardProcessUI.IsFull;
			m_GetCardPieceBtn.gameObject.SetActive(value: true);
		}
		else
		{
			m_GetCardPieceBtn.gameObject.SetActive(value: false);
		}
		ShowUpGrade();
		if (m_isLocalPlayer && m_IsShowUpgradeBtn)
		{
			m_UpgradeButton.gameObject.SetActive(value: false);
			m_GoldNum.gameObject.SetActive(value: false);
			m_ComposeBtn.gameObject.SetActive(value: false);
			m_GainTipsBtn.gameObject.SetActive(value: false);
			m_MaxLevelTips.gameObject.SetActive(value: false);
			m_GradeLimitTips.gameObject.SetActive(value: false);
			if (!CardUtility.CanDropCardPiece(m_cardID))
			{
				GradeMappingInfo mapping;
				string gradeName = LocalResources.GetGradeName(LocalResources.GetGradeInfo(m_GrowthInfo.UnlockGrade, out mapping), mapping);
				m_GradeLimitTips.text = string.Format(m_UnlockGradeLimitFormat, gradeName);
				m_GradeLimitTips.gameObject.SetActive(value: true);
			}
			else if (m_cardLevel >= m_GrowthInfo.MaxLevel)
			{
				m_MaxLevelTips.gameObject.SetActive(value: true);
			}
			else if (CardUtility.IsOwned(m_cardID))
			{
				m_UpgradeButton.gameObject.SetActive(value: true);
				m_GoldNum.gameObject.SetActive(value: true);
				if (m_upgradeGradeLimit)
				{
					m_UpgradeButtonBG.State = 1;
					m_UpgradeButtonText.State = 1;
					GradeMappingInfo mapping2;
					string gradeName2 = LocalResources.GetGradeName(LocalResources.GetGradeInfo(m_GrowthInfo.UpgradeLimitGrade[m_cardLevel - 1], out mapping2), mapping2);
					m_UpgradeGradeLimitTips.text = string.Format(m_UpgradeGradeLimitFormat, gradeName2);
				}
				else
				{
					m_UpgradeButtonBG.State = ((!m_pieceEnough) ? 1 : 0);
					m_UpgradeButtonText.State = 0;
				}
				m_GoldNum.text = m_GrowthInfo.GoldCostNew[m_cardLevel - 1].ToString();
				m_GoldNum.color = (m_goldEnough ? m_DefaultGlodColor : Color.red);
				m_ComposeBtn.gameObject.SetActive(value: false);
				m_GainTipsBtn.gameObject.SetActive(value: false);
			}
			else
			{
				if (m_pieceEnough)
				{
					m_ComposeBtn.gameObject.SetActive(value: true);
					m_GainTipsBtn.gameObject.SetActive(value: false);
				}
				else
				{
					m_ComposeBtn.gameObject.SetActive(value: false);
					m_GainTipsBtn.gameObject.SetActive(value: true);
				}
				m_UpgradeButton.gameObject.SetActive(value: false);
				m_GoldNum.gameObject.SetActive(value: false);
			}
		}
		else
		{
			m_UpgradeButton.gameObject.SetActive(value: false);
			m_GoldNum.gameObject.SetActive(value: false);
			m_ComposeBtn.gameObject.SetActive(value: false);
			m_GainTipsBtn.gameObject.SetActive(value: false);
			m_MaxLevelTips.gameObject.SetActive(value: false);
		}
		m_Host.EventProxy(m_GetCardPieceBtn, "OnClickGetPieceBtn");
		m_Host.EventProxy(m_UpgradeButton, "OnClickUpgrade");
		m_Host.EventProxy(m_GainTipsBtn, "OnClickGainTips");
		m_Host.EventProxy(m_ComposeBtn, "OnClickCompose");
		m_PreviewMaxGradeBtn.onButtonPressed.AddListener(delegate
		{
			ShowPreview();
		});
		m_PreviewMaxGradeBtn.onButtonReleased.AddListener(delegate
		{
			ShowUpGrade();
		});
		m_PreviewMaxGradeBtn.gameObject.SetActive(m_cardLevel < m_GrowthInfo.MaxLevel);
	}

	public void OnClickUpgrade()
	{
		if (m_upgradeGradeLimit)
		{
			UILobby.Current.ShowTips(m_UpgradeGradeLimitTips.text);
			return;
		}
		if (!m_pieceEnough)
		{
			UILobby.Current.ShowMessageBoxYesNo(Localization.PieceNotEnoughGotoBuyCardBox, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
			}, null);
			return;
		}
		if (!m_goldEnough)
		{
			UILobby.Current.ShowMessageBoxYesNo(Localization.TipsNoEnoughGold, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, LobbyScene_Money.BuyGold, null);
			return;
		}
		HttpRequestUpgradeCard httpRequestUpgradeCard = new HttpRequestUpgradeCard();
		httpRequestUpgradeCard.cardID = m_cardID;
		GameHttpManager.Inst.Send(httpRequestUpgradeCard, delegate
		{
			CommonDataCollection args = new CommonDataCollection
			{
				["cardId"] = m_cardID,
				["cardLevel"] = m_cardLevel
			};
			UILobby.Current.ShowUI(m_CardUpgradeUI, args);
			LocalPlayerDatabase.RefreshAssetsInfo();
		});
	}

	public void OnClickGetPieceBtn()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
	}

	public void OnClickGainTips()
	{
		if (LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Team)
		{
			JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
		}
		else
		{
			UILobby.Current.Popup(m_GainCardTipsUI);
		}
	}

	public void OnClickCompose()
	{
		CardUtility.ComposeCard(m_cardID, delegate
		{
			UILobby.Current.ShowUI(m_CardComposeUI, null).GetComponent<CardNewGainUI>().ShowCard(m_cardID);
			LocalPlayerDatabase.RefreshAssetsInfo();
		});
	}

	public void ShowPreview()
	{
		float num = CardUtility.GetCardLevelGrowthResult(m_cardID, m_GrowthInfo.MaxLevel);
		if (m_GrowthInfo.Type == CardGrowthType.SpeedRatio)
		{
			num = num * m_GrowthInfo.DefaultValue / 2.8f - 1f;
			num *= 100f;
		}
		string arg = (m_GrowthInfo.Type != CardGrowthType.Discount) ? StringUtility.RemoveUselessZeroInDecimal(num.ToString("F2")) : CardConfigEditPage_DetailPage.GetCardPrice(m_cardID, num).ToString();
		m_ArrtArgs.Clear();
		m_ArrtArgs[0]["IsPreview"] = true;
		m_ArrtArgs[0]["IsHighlight"] = (m_cardLevel < m_GrowthInfo.MaxLevel);
		m_ArrtArgs[0]["AttrDesc"] = m_GrowthInfo.AttrDesc[0];
		m_ArrtArgs[0]["AttrIcon"] = m_GrowthInfo.AttrIcon[0];
		m_ArrtArgs[0]["PreviewValue"] = string.Format(m_GrowthInfo.AttrValue[0], arg);
		for (int i = 1; i < m_GrowthInfo.AttrDesc.Length; i++)
		{
			m_ArrtArgs[i]["IsPreview"] = true;
			m_ArrtArgs[i]["IsHighlight"] = false;
			m_ArrtArgs[i]["AttrDesc"] = m_GrowthInfo.AttrDesc[i];
			m_ArrtArgs[i]["AttrIcon"] = m_GrowthInfo.AttrIcon[i];
			m_ArrtArgs[i]["PreviewValue"] = m_GrowthInfo.AttrValue[i];
		}
		m_AttributeContent.Args = m_ArrtArgs;
	}

	public void ShowUpGrade()
	{
		float num = CardUtility.GetCardLevelGrowthResult(m_cardID, m_cardLevel);
		if (m_GrowthInfo.Type == CardGrowthType.SpeedRatio)
		{
			num = num * m_GrowthInfo.DefaultValue / 2.8f - 1f;
			num *= 100f;
		}
		string arg;
		string x;
		if (m_GrowthInfo.Type == CardGrowthType.Discount)
		{
			int cardPrice = CardConfigEditPage_DetailPage.GetCardPrice(m_cardID, num);
			float cardLevelGrowthResult = CardUtility.GetCardLevelGrowthResult(m_cardID, m_cardLevel + 1);
			int cardPrice2 = CardConfigEditPage_DetailPage.GetCardPrice(m_cardID, cardLevelGrowthResult);
			arg = cardPrice.ToString();
			x = string.Format(m_GrowthInfo.ChangeFormat, cardPrice - cardPrice2);
		}
		else
		{
			arg = StringUtility.RemoveUselessZeroInDecimal(num.ToString("F2"));
			if (m_GrowthInfo.Type == CardGrowthType.SpeedRatio)
			{
				float num2 = Mathf.Abs(m_GrowthInfo.Rate) * m_GrowthInfo.DefaultValue / 2.8f;
				x = string.Format(m_GrowthInfo.ChangeFormat, num2);
			}
			else
			{
				x = string.Format(m_GrowthInfo.ChangeFormat, Mathf.Abs(m_GrowthInfo.Rate));
			}
		}
		m_ArrtArgs.Clear();
		m_ArrtArgs[0]["IsPreview"] = false;
		m_ArrtArgs[0]["AttrDesc"] = m_GrowthInfo.AttrDesc[0];
		m_ArrtArgs[0]["AttrIcon"] = m_GrowthInfo.AttrIcon[0];
		m_ArrtArgs[0]["AttrValue"] = string.Format(m_GrowthInfo.AttrValue[0], arg);
		if (m_isLocalPlayer && m_IsShowUpgradeBtn && m_cardLevel < m_GrowthInfo.MaxLevel && CardUtility.CanDropCardPiece(m_cardID))
		{
			m_ArrtArgs[0]["AttrChange"] = x;
			m_ArrtArgs[0]["AssetEnough"] = (!m_upgradeGradeLimit && m_pieceEnough && m_goldEnough);
		}
		for (int i = 1; i < m_GrowthInfo.AttrDesc.Length; i++)
		{
			m_ArrtArgs[i]["IsPreview"] = false;
			m_ArrtArgs[i]["AttrDesc"] = m_GrowthInfo.AttrDesc[i];
			m_ArrtArgs[i]["AttrIcon"] = m_GrowthInfo.AttrIcon[i];
			m_ArrtArgs[i]["AttrValue"] = m_GrowthInfo.AttrValue[i];
		}
		m_AttributeContent.Args = m_ArrtArgs;
	}
}
