using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class CharacterLotteryController : MonoBehaviour
{
	public List<GameObject> m_WishObjs;

	public GameObject m_WishItemPref;

	private List<CharacterLotteryItem> items = new List<CharacterLotteryItem>();

	private int turningIndex;

	private int curItemIndex;

	private int itemCount = 12;

	public float turningSpeedForOne = 0.2f;

	public float turningSpeedForFive = 0.1f;

	public float flashingItemDelay = 0.3f;

	public int fakeTurningCount = 2;

	public Transform iconRoot;

	public AudioItem turningSound;

	public AudioItem getRewardSound;

	private UnityAction OnEnd;

	public void StartTurning(int[] gridIds, ItemInfo[] resItems, UnityAction OnEnd, UnityAction<int, int> OnGetWishItem = null)
	{
		this.OnEnd = OnEnd;
		StartCoroutine(Turning(gridIds, resItems, OnEnd, OnGetWishItem));
	}

	public void EndTurning()
	{
		StopAllCoroutines();
		StartCoroutine(DelayToEnd(flashingItemDelay));
	}

	private void OnEnable()
	{
		if (iconRoot != null && iconRoot.GetComponent<UIEffectController>() != null)
		{
			iconRoot.GetComponent<UIEffectController>().OnEnterUI();
		}
	}

	private IEnumerator DelayToEnd(float delay)
	{
		foreach (CharacterLotteryItem item in items)
		{
			item.Show(isHightLight: false);
		}
		yield return new WaitForSeconds(delay);
		if (OnEnd != null)
		{
			OnEnd();
		}
	}

	public void Init(List<CharacterLotteryItemInfo> info, bool dirty)
	{
		if ((items.Count <= 0) | dirty)
		{
			Clear();
			Dictionary<int, List<CharacterLotteryItemInfo>> dictionary = new Dictionary<int, List<CharacterLotteryItemInfo>>();
			foreach (CharacterLotteryItemInfo item in info)
			{
				int key = (item.MultiId == 0) ? item.GridId : item.MultiId;
				if (dictionary.ContainsKey(key))
				{
					dictionary[key].Add(item);
				}
				else
				{
					dictionary.Add(key, new List<CharacterLotteryItemInfo>
					{
						item
					});
				}
			}
			int num = 0;
			foreach (KeyValuePair<int, List<CharacterLotteryItemInfo>> item2 in dictionary)
			{
				List<CharacterLotteryItemInfo> value = item2.Value;
				GameObject gameObject = UnityEngine.Object.Instantiate(m_WishItemPref);
				gameObject.transform.SetParent(m_WishObjs[num++].transform, worldPositionStays: false);
				gameObject.transform.localPosition = Vector3.zero;
				CharacterLotteryItem component = gameObject.GetComponent<CharacterLotteryItem>();
				component.Init(value, iconRoot);
				items.Add(component);
			}
		}
		itemCount = items.Count;
	}

	private void Clear()
	{
		foreach (CharacterLotteryItem item in items)
		{
			UnityEngine.Object.Destroy(item.gameObject);
		}
		for (int i = 0; i < iconRoot.childCount; i++)
		{
			UnityEngine.Object.Destroy(iconRoot.GetChild(i).gameObject);
		}
		items.Clear();
	}

	public void Refresh()
	{
		for (int i = 0; i < items.Count; i++)
		{
			items[i].Refresh();
		}
	}

	private IEnumerator Turning(int[] gridIds, ItemInfo[] resItems, UnityAction OnEnd, UnityAction<int, int> OnGetWishItem)
	{
		turningIndex = 0;
		curItemIndex = 0;
		int showResIndex = 0;
		int gridCount = gridIds.Length;
		items[curItemIndex].Show(isHightLight: true);
		float turningDelay = (gridCount > 1) ? turningSpeedForFive : turningSpeedForOne;
		while (showResIndex < gridCount)
		{
			yield return new WaitForSeconds(turningDelay);
			curItemIndex++;
			if (curItemIndex >= itemCount)
			{
				curItemIndex = 0;
				turningIndex++;
			}
			SoundManager.PlayOnce(turningSound);
			items[curItemIndex].Show(isHightLight: true);
			if (turningIndex < fakeTurningCount)
			{
				yield return null;
			}
			else if (items[curItemIndex].gridId.Contains(gridIds[showResIndex]))
			{
				OnGetWishItem?.Invoke(resItems[showResIndex].itemID, resItems[showResIndex].itemCount);
				showResIndex++;
				yield return new WaitForSeconds(flashingItemDelay);
				SoundManager.PlayOnce(getRewardSound);
				items[curItemIndex].Show(isHightLight: true);
				yield return new WaitForSeconds(flashingItemDelay);
				items[curItemIndex].Show(isHightLight: true);
				yield return new WaitForSeconds(flashingItemDelay);
				items[curItemIndex].Show(isHightLight: true);
			}
		}
		yield return new WaitForSeconds(flashingItemDelay);
		items[curItemIndex].Show(isHightLight: false);
		OnEnd();
	}
}
