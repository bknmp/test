using DG.Tweening;
using LightUI;
using LightUtility;
using SimpleJson;
using System.Collections.Generic;
using UnityEngine;

public class BlockBarObject : PlaceableObject
{
	public RoleType m_RoleType;

	public GameObject m_UI;

	public UIProgressBar m_BloodBar;

	public GameObject m_StartEffect;

	public float m_MaxLife = 80f;

	public float m_LifeReducePerSecond = 10f;

	public float m_WakeupExtent = 0.5f;

	public LayerMask m_WakeupMask;

	private PlayerController m_Controller;

	private List<string> m_BlockHitName = new List<string>();

	private bool m_IsDestroyed;

	private float m_CurrentLife;

	public static List<BlockBarObject> AllBlockBarObjects = new List<BlockBarObject>();

	protected override void OnDestroy()
	{
		base.OnDestroy();
		AllBlockBarObjects.Remove(this);
	}

	private new void Start()
	{
		m_Controller = PlayerController.FindPlayer(base.UserId);
		if (m_Controller != null)
		{
			AllBlockBarObjects.Add(this);
			m_RoleType = m_Controller.PlayingRole;
			m_CurrentLife = m_MaxLife;
			m_PreviewArea.SetActive(value: false);
			m_BloodBar.SetProgress(m_CurrentLife, m_MaxLife);
			base.transform.SetParent(InGameScene.Inst.transform, worldPositionStays: true);
			if (!InGameScene.Inst.IsHighTile(base.PreviewPosition))
			{
				base.transform.position = base.PreviewPosition.FlattenY();
			}
			else
			{
				base.transform.position = base.PreviewPosition;
			}
			base.transform.rotation = Quaternion.identity;
			m_Root.transform.localScale = new Vector3(1f, 0.1f, 1f);
			m_Root.transform.DOScaleY(Random.Range(0.999f, 1.001f), 0.8f).SetEase(Ease.OutBack);
			PoolSpawner.Spawn(m_StartEffect).transform.position = base.transform.position + m_StartEffect.transform.position;
			WakeupNearbyRigibodys();
		}
		base.Start();
	}

	private void WakeupNearbyRigibodys()
	{
		m_BlockHitName.Clear();
		int num = Physics.OverlapBoxNonAlloc(base.transform.position + Vector3.up / 2f, Vector3.one * m_WakeupExtent, GameObjectUtility.CacheColliders, base.transform.rotation, m_WakeupMask.value);
		for (int i = 0; i < num; i++)
		{
			Collider collider = GameObjectUtility.CacheColliders[i];
			Rigidbody attachedRigidbody = collider.attachedRigidbody;
			if (!(attachedRigidbody != null))
			{
				continue;
			}
			attachedRigidbody.WakeUp();
			if (GameUtility.IsPlayer(collider) && !m_BlockHitName.Contains(attachedRigidbody.name))
			{
				PlayerController playerController = PlayerController.FindPlayer(attachedRigidbody.name);
				if (playerController != null)
				{
					m_BlockHitName.Add(playerController.name);
					GameTaskUtility.UpdateEvent(EventHow.Hit, 1, m_Controller, playerController, EventObject.CardParam, 107);
				}
			}
		}
	}

	public override void BatchUpdate()
	{
		if (!string.IsNullOrEmpty(base.UserId) && m_CurrentLife > 0f)
		{
			UpdateLife();
		}
		base.BatchUpdate();
	}

	public override void BatchLateUpdate()
	{
		if (string.IsNullOrEmpty(base.UserId))
		{
			base.transform.rotation = Quaternion.identity;
		}
		base.BatchLateUpdate();
	}

	private void UpdateLife()
	{
		if (InGameScene.Inst.Map.IsWorldPositionOutOfBorder(base.transform.position, 0f))
		{
			m_CurrentLife = 0f;
		}
		else
		{
			m_CurrentLife -= Time.deltaTime * m_LifeReducePerSecond;
		}
		OnLifeChanged();
	}

	private void OnLifeChanged()
	{
		m_BloodBar.SetProgress(m_CurrentLife, m_MaxLife);
		if (!m_IsDestroyed && m_CurrentLife <= 0f)
		{
			m_Root.transform.DOScale(Vector3.zero, 0.4f).SetEase(Ease.InBack).OnComplete(delegate
			{
				if (m_PhotonView.isMine)
				{
					PhotonNetwork.Destroy(m_PhotonView);
				}
			});
			m_IsDestroyed = true;
		}
	}

	public void RpcApplyDamage(float damage, int numID)
	{
		m_PhotonView.RPC("LocalApplyDamage", PhotonTargets.AllViaServer, damage, numID);
	}

	[PunRPC]
	private void LocalApplyDamage(float damage, int numID)
	{
		m_CurrentLife -= damage;
		OnLifeChanged();
	}

	public override void StartPreview()
	{
		m_UI.SetActive(value: false);
		m_Root.SetActive(value: false);
		m_PreviewArea.SetActive(value: true);
		base.transform.rotation = Quaternion.identity;
		base.StartPreview();
	}

	private void OnReSyncWrite(object data)
	{
		(data as JsonObject)["life"] = m_CurrentLife;
	}

	private void OnReSyncRead(object data)
	{
		JsonObject jsonObject = data as JsonObject;
		m_CurrentLife = jsonObject.AsFloat("life");
		OnLifeChanged();
	}
}
