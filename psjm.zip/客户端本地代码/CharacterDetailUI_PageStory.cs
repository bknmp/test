using LightUI;
using UnityEngine.UI;

internal class CharacterDetailUI_PageStory
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_AttributeContent;

	public Text m_Story;

	private CommonDataCollection m_AttrArg = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		m_Story.text = characterInfo.Story;
		m_AttrArg.Clear();
		for (int i = 0; i < characterInfo.AttrDesc.Length; i++)
		{
			m_AttrArg[i]["key"] = characterInfo.AttrDesc[i];
			m_AttrArg[i]["value"] = characterInfo.AttrValue[i];
		}
		m_AttributeContent.Args = m_AttrArg;
	}
}
