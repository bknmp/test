using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CancellationPopupResultUI
{
	public UIDataBinder m_Host;

	public Button m_Next;

	public UIStateItem m_State;

	public Button m_CloseButton;

	public Button m_Close1;

	public Button m_Close2;

	public void Bind(CommonDataCollection args)
	{
		m_State.State = args["state"];
		m_Host.EventProxy(m_Next, "OnQuitBtnClick");
		m_Host.EventProxy(m_CloseButton, "OnQuitBtnClick");
		m_Host.EventProxy(m_Close1, "GoToSetting");
		m_Host.EventProxy(m_Close2, "GoToSetting");
	}

	public void OnQuitBtnClick()
	{
		UnityEngine.Debug.Log("DoLogout");
		LoginManager.SDKAutoLoginType = 0;
		AndroidSDKAdapter.OnLoginEvent = null;
		AndroidSDKAdapter.Instance.Logout();
		Application.Quit();
	}

	public void GoToSetting()
	{
		UILobby.Current.GoHome();
	}
}
