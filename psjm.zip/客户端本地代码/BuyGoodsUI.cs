using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class BuyGoodsUI : BuyUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TicketTemplateInitiator;

	public Button m_ButtonBuy;

	public Image m_Icon;

	public Text m_ItemName;

	public UITemplateInitiator m_DiamondTemplateInitiator;

	public GameObject m_TicketButton;

	public GameObject m_DiamondButton;

	public UITabPage m_Page;

	public CommonRewardPopupUI m_StoreRewardPopupUI;

	public UIStateRawImage m_quality;

	public Text m_SelectedTime;

	public UITemplateInitiator m_GoldTemplateInitiator;

	public GameObject m_GoldButton;

	public CommonRewardPopupUI m_NewCardRewardPopupUI;

	public UIPage m_BoxOpenUI;

	public GameObject m_shadow;

	public GameObject m_Sale;

	public Text m_SaleText;

	private List<int> m_ShopIDs = new List<int>();

	private bool m_IsFromRecommend;

	private bool m_IsRole;

	public void Bind(CommonDataCollection args)
	{
		m_SelectedTime.text = "";
		m_Host.EventProxy(m_ButtonBuy, "OnClickBuy");
		m_Host.EventProxy(m_Page, "ChangeCurrency");
		m_globalSelectID = -1;
		m_ShopIDs.Clear();
		for (int i = 0; i < args.ArraySize; i++)
		{
			m_ShopIDs.Add(args[i]["Id"]);
		}
		string text = args["name"];
		if (string.IsNullOrEmpty(text))
		{
			text = LocalResources.DropItemTable.Get(LocalResources.ShopTable.Get(m_ShopIDs[0]).DropItemID).Name;
		}
		m_ItemName.text = text;
		if (args["IsFromRecommend"] != null && (bool)args["IsFromRecommend"])
		{
			m_IsFromRecommend = true;
			if (args["IsRole"] != null && (bool)args["IsRole"])
			{
				m_IsRole = true;
			}
		}
		ShopInfo shopInfo = LocalResources.ShopTable.Get(m_ShopIDs[0]);
		DropItem dropItem = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
		if (shopInfo.OriginalCost > 0f)
		{
			if ((bool)m_Sale && (bool)m_SaleText)
			{
				m_Sale.SetActive(value: true);
				m_SaleText.text = Mathf.RoundToInt(shopInfo.CostDiamond / shopInfo.OriginalCost * 1000f).ToString() + "折";
			}
		}
		else if ((bool)m_Sale && (bool)m_SaleText)
		{
			m_Sale.SetActive(value: false);
		}
		if (dropItem.Type == DropItemType.PropCardBox)
		{
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
			m_shadow.SetActive(value: true);
		}
		else
		{
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
			m_shadow.SetActive(value: false);
		}
		m_quality.State = dropItem.Quality;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		CommonDataCollection commonDataCollection3 = new CommonDataCollection();
		for (int j = 0; j < m_ShopIDs.Count; j++)
		{
			shopInfo = LocalResources.ShopTable.Get(m_ShopIDs[j]);
			dropItem = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
			if (shopInfo.CostGold != 0f)
			{
				int arraySize = commonDataCollection.ArraySize;
				commonDataCollection[arraySize]["id"] = m_ShopIDs[j];
				commonDataCollection[arraySize]["currency"] = 1;
				float num = shopInfo.CostGold * (float)shopInfo.Amount;
				commonDataCollection[arraySize]["price"] = (int)num;
				commonDataCollection[arraySize]["index"] = arraySize;
				commonDataCollection[arraySize]["amount"] = shopInfo.Amount;
				commonDataCollection[arraySize]["exp"] = dropItem.ExpValue;
				commonDataCollection[arraySize]["BuyGoodsUI"].val = this;
			}
			if (shopInfo.CostTicket != 0f)
			{
				int arraySize2 = commonDataCollection2.ArraySize;
				commonDataCollection2[arraySize2]["id"] = m_ShopIDs[j];
				commonDataCollection2[arraySize2]["currency"] = 4;
				float num2 = shopInfo.CostTicket * (float)shopInfo.Amount;
				commonDataCollection2[arraySize2]["price"] = (int)num2;
				commonDataCollection2[arraySize2]["index"] = arraySize2;
				commonDataCollection2[arraySize2]["amount"] = shopInfo.Amount;
				commonDataCollection2[arraySize2]["exp"] = dropItem.ExpValue;
				commonDataCollection2[arraySize2]["BuyGoodsUI"].val = this;
			}
			if (shopInfo.CostDiamond != 0f)
			{
				int arraySize3 = commonDataCollection3.ArraySize;
				commonDataCollection3[arraySize3]["id"] = m_ShopIDs[j];
				commonDataCollection3[arraySize3]["currency"] = 2;
				float num3 = shopInfo.CostDiamond * (float)shopInfo.Amount;
				commonDataCollection3[arraySize3]["price"] = (int)num3;
				commonDataCollection3[arraySize3]["index"] = arraySize3;
				commonDataCollection3[arraySize3]["amount"] = shopInfo.Amount;
				commonDataCollection3[arraySize3]["exp"] = dropItem.ExpValue;
				commonDataCollection3[arraySize3]["BuyGoodsUI"].val = this;
			}
			if (shopInfo.CostDiamond == 0f && shopInfo.CostTicket == 0f && shopInfo.CostGold == 0f)
			{
				int arraySize4 = commonDataCollection.ArraySize;
				commonDataCollection[arraySize4]["id"] = m_ShopIDs[j];
				commonDataCollection[arraySize4]["currency"] = 1;
				float num4 = shopInfo.CostGold * (float)shopInfo.Amount;
				commonDataCollection[arraySize4]["price"] = (int)num4;
				commonDataCollection[arraySize4]["index"] = arraySize4;
				commonDataCollection[arraySize4]["amount"] = shopInfo.Amount;
				commonDataCollection[arraySize4]["exp"] = dropItem.ExpValue;
				commonDataCollection[arraySize4]["BuyGoodsUI"].val = this;
			}
		}
		m_globalIndex = 0;
		if (args.ContainsKey("defaultSelectIdx"))
		{
			m_globalIndex = args["defaultSelectIdx"];
			if (m_globalIndex == -1)
			{
				m_globalIndex = Mathf.Max(commonDataCollection3.ArraySize, commonDataCollection2.ArraySize, commonDataCollection.ArraySize) - 1;
			}
		}
		m_TicketButton.SetActive(commonDataCollection2.ArraySize > 0);
		m_DiamondButton.SetActive(commonDataCollection3.ArraySize > 0);
		m_GoldButton.SetActive(commonDataCollection.ArraySize > 0);
		if (commonDataCollection2.ArraySize <= 0 && commonDataCollection3.ArraySize <= 0 && commonDataCollection.ArraySize <= 0)
		{
			m_GoldButton.SetActive(value: true);
		}
		m_TicketTemplateInitiator.Args = commonDataCollection2;
		m_DiamondTemplateInitiator.Args = commonDataCollection3;
		m_GoldTemplateInitiator.Args = commonDataCollection;
		int num5 = 0;
		while (true)
		{
			if (num5 < m_Page.m_Buttons.Count)
			{
				if (m_Page.m_Buttons[num5].IsActive())
				{
					break;
				}
				num5++;
				continue;
			}
			return;
		}
		m_Page.SetSelectedTabIndex(num5);
	}

	public void OnClickBuy()
	{
		if (m_globalSelectID > 0)
		{
			ShopInfo shopInfo = LocalResources.ShopTable.Get(m_globalSelectID);
			int price = 0;
			if (m_selectedType == CurrencyType.Diamonds)
			{
				price = (int)(shopInfo.CostDiamond * (float)shopInfo.Amount);
			}
			else if (m_selectedType == CurrencyType.Tickets)
			{
				price = (int)(shopInfo.CostTicket * (float)shopInfo.Amount);
			}
			else if (m_selectedType == CurrencyType.Gold)
			{
				price = (int)(shopInfo.CostGold * (float)shopInfo.Amount);
			}
			ShopUtility.CheckMoneyEnough(m_selectedType, price, Buy, shopInfo.DropItemID);
		}
	}

	private void Buy()
	{
		ShopInfo shopInfo = LocalResources.ShopTable.Get(m_globalSelectID);
		DropItem dropInfo = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
		if (dropInfo.Type == DropItemType.PropCardBox)
		{
			HttpRequestBuyItemNew httpRequestBuyItemNew = new HttpRequestBuyItemNew();
			httpRequestBuyItemNew.shopID = m_globalSelectID;
			if (shopInfo.CostGold == 0f && shopInfo.CostTicket == 0f && shopInfo.CostDiamond == 0f)
			{
				httpRequestBuyItemNew.type = CurrencyType.Free;
			}
			else
			{
				httpRequestBuyItemNew.type = m_selectedType;
			}
			GameHttpManager.Inst.Send(httpRequestBuyItemNew, delegate(HttpResponseBuyItemNew onResponse)
			{
				m_Host.GetComponent<UIPopup>().GoBack();
				if (ShopUtility.BuyTimeList.ContainsKey(dropInfo.Id))
				{
					Dictionary<int, int> buyTimeList = ShopUtility.BuyTimeList;
					int id = dropInfo.Id;
					buyTimeList[id]++;
				}
				UILobby.Current.ShowUI(m_BoxOpenUI, BoxUtility.BoxOpenUIArgsWraper(dropInfo.Id, onResponse.itemList));
				UIDataEvents.Inst.InvokeEvent("OnBuySomething");
			});
		}
		else
		{
			HttpRequestBuyItem msg = new HttpRequestBuyItem();
			msg.type = m_selectedType;
			msg.shopID = m_globalSelectID;
			msg.amount = shopInfo.Amount;
			GameHttpManager.Inst.Send(msg, delegate
			{
				m_Host.GetComponent<UIPopup>().GoBack();
				if (dropInfo.Type == DropItemType.PropCard)
				{
					CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_NewCardRewardPopupUI);
					commonRewardPopupUI.SetTitleAndTips(null, string.Format(Localization.NewCardTips, LocalPlayerDatabase.PlayerInfo.cardIDs.Length + 1));
					commonRewardPopupUI.AddItem(shopInfo.DropItemID, msg.amount);
				}
				else if (dropInfo.Type == DropItemType.Character)
				{
					CharacterFeatureUI.Inst.TryShowNewCharacter(dropInfo.TypeParam);
					if (m_IsFromRecommend && m_IsRole)
					{
						LocalPlayerDatabase.ReportClickEvent(ClickEventParam.RECOMM_ROLE_SUCCESS_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString(), dropInfo.Id.ToString());
					}
				}
				else
				{
					bool showExpAdd = dropInfo.Type == DropItemType.SkinPart;
					CommonRewardPopupUI commonRewardPopupUI2 = CommonRewardPopupUI.Show(m_StoreRewardPopupUI, null, showExpAdd);
					commonRewardPopupUI2.SetTitleAndTips(null, null);
					commonRewardPopupUI2.AddItem(shopInfo.DropItemID, msg.amount);
				}
				UIDataEvents.Inst.InvokeEvent("OnBuySomething");
				StoreUI_Binder.SetTabStaticParams(flag: true);
			});
		}
	}

	public void ChangeCurrency()
	{
		m_globalSelectID = -1;
		foreach (UIDataBinder item in m_TicketTemplateInitiator.Items)
		{
			item.UpdateBinding();
		}
		foreach (UIDataBinder item2 in m_DiamondTemplateInitiator.Items)
		{
			item2.UpdateBinding();
		}
	}
}
