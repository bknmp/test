using BehaviorDesigner.Runtime.Tasks;

[TaskName("有队友是倒地状态的")]
[TaskCategory("躲猫猫AI/条件")]
[TaskDescription("有队友是倒地状态的（但不一定是需要我去救的，有可能又别的人去救了）")]
public class AnyTeammateIsDying : Conditional
{
	public SharedAIController ai;

	public override TaskStatus OnUpdate()
	{
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer != ai.Value.PlayerController && allPlayer.PlayingRole == ai.Value.PlayerController.PlayingRole && allPlayer.IsDying)
			{
				return TaskStatus.Success;
			}
		}
		return TaskStatus.Failure;
	}
}
