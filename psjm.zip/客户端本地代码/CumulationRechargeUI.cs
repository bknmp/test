using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine.UI;

internal class CumulationRechargeUI
{
	public UIDataBinder m_Host;

	public Text m_Desc;

	public Text m_TimeText;

	public UITemplateInitiator m_Content;

	public ActivityLobbyPage m_ActivityPage;

	private static bool m_RedPointFlag;

	private static HttpResponseCumulationRechargeInfos m_cumulationRechargeInfos;

	private string m_TimeFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_TimeText.text;
		}
		Activity activity = args["Activity"].val as Activity;
		m_ActivityPage.SetTime(activity);
		LocalPlayerDatabase.SetPrefValue("CumulationRecharge", activity.startTime);
		m_Desc.text = LocalResources.ActivityLobbyInfos.Get(activity.activityId).Desc;
		m_TimeText.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		HttpRequestCumulationRechargeInfos httpRequestCumulationRechargeInfos = new HttpRequestCumulationRechargeInfos();
		httpRequestCumulationRechargeInfos.activityId = activity.activityId;
		GameHttpManager.Inst.Send(httpRequestCumulationRechargeInfos, delegate(HttpResponseCumulationRechargeInfos onResponse)
		{
			m_RedPointFlag = false;
			m_cumulationRechargeInfos = onResponse;
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			List<CumulationRechargeInfo> list = new List<CumulationRechargeInfo>();
			List<CumulationRechargeInfo> list2 = new List<CumulationRechargeInfo>();
			for (int i = 0; i < onResponse.info.Length; i++)
			{
				if (onResponse.info[i].received)
				{
					list2.Add(onResponse.info[i]);
				}
				else
				{
					list.Add(onResponse.info[i]);
				}
			}
			foreach (CumulationRechargeInfo item in list)
			{
				int arraySize = commonDataCollection.ArraySize;
				commonDataCollection[arraySize]["CumulationRechargeInfo"].val = item;
				commonDataCollection[arraySize]["rechargeNum"] = onResponse.rechargeNum;
				commonDataCollection[arraySize]["Activity"].val = activity;
			}
			foreach (CumulationRechargeInfo item2 in list2)
			{
				int arraySize2 = commonDataCollection.ArraySize;
				commonDataCollection[arraySize2]["CumulationRechargeInfo"].val = item2;
				commonDataCollection[arraySize2]["rechargeNum"] = onResponse.rechargeNum;
				commonDataCollection[arraySize2]["Activity"].val = activity;
			}
			m_Content.Args = commonDataCollection;
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	public static void OnRefreshCumulationRechargeRedPoint()
	{
		m_RedPointFlag = true;
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	public static bool CumulationRechargeRedPoint()
	{
		if (IsFirstCheck() || m_RedPointFlag)
		{
			return true;
		}
		if (m_cumulationRechargeInfos == null)
		{
			return false;
		}
		CumulationRechargeInfo[] info = m_cumulationRechargeInfos.info;
		foreach (CumulationRechargeInfo cumulationRechargeInfo in info)
		{
			if (!cumulationRechargeInfo.received && m_cumulationRechargeInfos.rechargeNum >= cumulationRechargeInfo.targetNum)
			{
				return true;
			}
		}
		return false;
	}

	public static bool IsFirstCheck()
	{
		if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.activitys == null)
		{
			return false;
		}
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.CUMULATION_RECHARGE, ActivityCollectionType.ACTIVITY_LOBBY);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (activityByActivityTypeAndCollectionType.startTime == LocalPlayerDatabase.GetPrefValueInt("CumulationRecharge"))
		{
			return false;
		}
		return true;
	}
}
