using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CardUpgradeRewardNew_RewardTemplate
{
	public UIDataBinder m_Host;

	public Text m_Text;

	public UITemplateInitiator m_Reward;

	public Button m_ButtonClaim;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public Button m_Button_CantClaim;

	public GameObject m_Claimed;

	public RectTransform m_Self;

	public Text m_Desc;

	private int m_Index;

	private bool m_HadClaimed;

	private bool m_CanClaim;

	private CardUpgradeRewardNew m_cardUpgradeRewardUI;

	private int m_CardID;

	private string m_DescFormat;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["Id"];
		m_Text.text = args["Desc"];
		m_CardID = args["CardID"];
		int[] array = args["itemIds"].val as int[];
		int[] array2 = args["itemCounts"].val as int[];
		m_HadClaimed = args["claimed"];
		m_cardUpgradeRewardUI = (args["CardUpgradeRewardUI"].val as CardUpgradeRewardNew);
		if (m_Desc != null)
		{
			if (string.IsNullOrEmpty(m_DescFormat))
			{
				m_DescFormat = m_Desc.text;
			}
			m_Desc.text = string.Format(m_DescFormat, LocalResources.InGameStoreTable.Get(m_CardID).FullName);
		}
		int num = CardUtility.IsOwned(m_CardID) ? CardUtility.GetCardLevel(m_CardID) : 0;
		m_CanClaim = (num >= m_Index);
		m_ButtonClaim.gameObject.SetActive(m_CanClaim && !m_HadClaimed);
		m_Button_CantClaim.gameObject.SetActive(!m_CanClaim);
		m_Claimed.SetActive(m_HadClaimed);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < array.Length; i++)
		{
			ItemInfo val = new ItemInfo(array[i], array2[i]);
			CommonDataCollection commonDataCollection2 = new CommonDataCollection();
			commonDataCollection2["dropItemInfo"].val = val;
			commonDataCollection[commonDataCollection.ArraySize] = commonDataCollection2;
		}
		m_Reward.Args = commonDataCollection;
		m_Host.EventProxy(m_ButtonClaim, "OnClickClaim");
		m_Host.EventProxy(m_Button_CantClaim, "OnClickCantClaim");
		if (m_HadClaimed)
		{
			m_Self.SetAsLastSibling();
		}
	}

	public void OnClickCantClaim()
	{
		UILobby.Current.ShowTips(Localization.CantClaim);
	}

	public void OnClickClaim()
	{
		HttpRequestClaimCardUpgradeRewardActivity httpRequestClaimCardUpgradeRewardActivity = new HttpRequestClaimCardUpgradeRewardActivity();
		httpRequestClaimCardUpgradeRewardActivity.cardId = m_CardID;
		httpRequestClaimCardUpgradeRewardActivity.level = m_Index;
		GameHttpManager.Inst.Send(httpRequestClaimCardUpgradeRewardActivity, delegate(HttpResponseClaimCardUpgradeRewardActivity onResponse)
		{
			m_cardUpgradeRewardUI.m_Host.UpdateBinding();
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.AddItems(onResponse.items);
			commonRewardPopupUI.SetTitleAndTips("", "");
		});
	}
}
