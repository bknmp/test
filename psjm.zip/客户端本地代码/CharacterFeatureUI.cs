using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterFeatureUI : MonoBehaviour
{
	private struct SeqParams
	{
		public int characterID;

		public int levelFrom;

		public int levelTo;
	}

	public UIStateItem m_Root;

	public RawImage m_Preview;

	public Button m_Button;

	public Text m_LevelFrom;

	public Text m_LevelTo;

	public Text m_talentPoint;

	public AudioItem m_Sound;

	public Button m_SetActiveButton;

	public Button m_ClickOK;

	public Text m_Tips;

	public GameObject m_SetActiveEffect;

	public Text m_CharacterName;

	private string m_tipsFormat;

	private int m_newCharacterID;

	public ShareButtonSettingPrefab m_ShareButtonSettingPrefab;

	private string m_LevelFormat;

	private string m_TalentPointFormat;

	private float m_StartShowTime;

	private bool m_IsFirstLevelUp;

	private Queue<SeqParams> m_ShowSequences = new Queue<SeqParams>();

	private static Dictionary<int, int> m_LastCharacterLevels = new Dictionary<int, int>();

	private static uint m_LastRoleID;

	public static CharacterFeatureUI Inst;

	private Delegates.VoidCallback OnCloseNewCharacter;

	public static bool IsShowing
	{
		get
		{
			if (!(Inst != null))
			{
				return false;
			}
			return Inst.m_Root.gameObject.activeSelf;
		}
	}

	private void Awake()
	{
		Inst = this;
		m_LevelFormat = m_LevelFrom.text;
		m_TalentPointFormat = m_talentPoint.text;
		m_Button.onClick.AddListener(OnContinueClicked);
		m_SetActiveButton.onClick.AddListener(SetActive);
		m_ClickOK.onClick.AddListener(OK);
		m_tipsFormat = m_Tips.text;
	}

	private void OnDestroy()
	{
		if (Inst == this)
		{
			Inst = null;
		}
	}

	public void TryShowLevelUp(bool initialize = false)
	{
		if (m_LastRoleID != LocalPlayerDatabase.LoginInfo.roleID)
		{
			m_LastCharacterLevels.Clear();
			m_LastRoleID = LocalPlayerDatabase.LoginInfo.roleID;
		}
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (!m_LastCharacterLevels.ContainsKey(playerCharacterInfo.characterID))
			{
				m_LastCharacterLevels[playerCharacterInfo.characterID] = ((!initialize) ? 1 : playerCharacterInfo.ExpLevel);
			}
			if (m_LastCharacterLevels[playerCharacterInfo.characterID] < playerCharacterInfo.ExpLevel)
			{
				m_ShowSequences.Enqueue(new SeqParams
				{
					characterID = playerCharacterInfo.characterID,
					levelTo = playerCharacterInfo.ExpLevel,
					levelFrom = m_LastCharacterLevels[playerCharacterInfo.characterID]
				});
				m_LastCharacterLevels[playerCharacterInfo.characterID] = playerCharacterInfo.ExpLevel;
			}
		}
		if (m_ShowSequences.Count > 0)
		{
			PassRewardsPage_Preview.Dirty = true;
			OnContinueClicked();
		}
	}

	private void DoShowLevelUp(int characterID, int levelFrom, int levelTo)
	{
		SoundManager.PlayOnce(m_Sound);
		UILobby.Current.m_PageContainer.gameObject.SetActive(value: false);
		m_Root.gameObject.SetActive(value: true);
		m_Root.State = 0;
		m_IsFirstLevelUp = (levelFrom == 1);
		m_LevelFrom.text = string.Format(m_LevelFormat, levelFrom);
		m_LevelTo.text = string.Format(m_LevelFormat, levelTo);
		m_talentPoint.text = string.Format(m_TalentPointFormat, levelTo - levelFrom);
		m_StartShowTime = Time.time;
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(characterID);
		PlayerCharacterInfo ownedCharacterInfo = CharacterUtility.GetOwnedCharacterInfo(characterID);
		LobbyPlayerController component = LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.LevelUp, characterInfo.LobbyPrefab, m_Preview).GetComponent<LobbyPlayerController>();
		component.CharacterID = characterID;
		component.m_SkinPartController.UpdateParts(ownedCharacterInfo.currentSkinInfo);
		component.Cards = CardUtility.DefaultCards;
		component.CardSkins = CardUtility.DefaultCardsSkin;
		component.PhysicsBody.isKinematic = true;
		StartCoroutine(DelayDoLevelUp(component, 0.1f));
	}

	private IEnumerator DelayDoLevelUp(LobbyPlayerController player, float delay)
	{
		yield return Yielders.GetWaitForSeconds(delay);
		if (player.ProjectileLauncher != null)
		{
			GameObject currentWeapontInst = player.ProjectileLauncher.CurrentWeapontInst;
			if (currentWeapontInst != null)
			{
				currentWeapontInst.transform.localScale = Vector3.zero;
			}
		}
		if (player.m_Animator != null)
		{
			player.m_Animator.SetTrigger("levelup");
		}
	}

	private void OnContinueClicked()
	{
		if (Time.time - m_StartShowTime > 1f)
		{
			Close();
			if (m_ShowSequences.Count > 0)
			{
				SeqParams seqParams = m_ShowSequences.Dequeue();
				DoShowLevelUp(seqParams.characterID, seqParams.levelFrom, seqParams.levelTo);
			}
			else if (m_IsFirstLevelUp)
			{
				LobbyNewbieDirector.Inst.TryStartTalentGuide();
			}
		}
	}

	public void TryShowNewCharacter(int characterID, Delegates.VoidCallback onSuccess = null)
	{
		LocalPlayerDatabase.RefreshAssetsInfo(delegate
		{
			CardUtility.RequestCardConfigs(force: true);
			DoShowNewCharacter(characterID);
			OnCloseNewCharacter = onSuccess;
		});
	}

	private void DoShowNewCharacter(int characterID)
	{
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(characterID);
		if (characterInfo != null)
		{
			SoundManager.PlayOnce(m_Sound);
			UILobby.Current.m_PageContainer.gameObject.SetActive(value: false);
			m_Root.gameObject.SetActive(value: true);
			m_Root.State = 1;
			m_Tips.text = string.Format(m_tipsFormat, CharacterUtility.OwnCharacterNum());
			m_CharacterName.text = characterInfo.Name;
			m_newCharacterID = characterID;
			ShareImageContent shareImageContent = new ShareImageContent();
			shareImageContent.message = CharacterUtility.OwnCharacterNum().ToString();
			m_ShareButtonSettingPrefab.InitConditionShareButton(2, m_newCharacterID, null, shareImageContent);
			PlayerCharacterInfo ownedCharacterInfo = CharacterUtility.GetOwnedCharacterInfo(characterID);
			LobbyPlayerController component = LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.LevelUp, characterInfo.LobbyPrefab, m_Preview).GetComponent<LobbyPlayerController>();
			component.CharacterID = characterID;
			component.m_SkinPartController.UpdateParts(ownedCharacterInfo.currentSkinInfo);
			component.Cards = CardUtility.DefaultCards;
			component.CardSkins = CardUtility.DefaultCardsSkin;
			component.PhysicsBody.isKinematic = true;
			StartCoroutine(DelayDoLevelUp(component, 0.1f));
		}
	}

	private void SetActive()
	{
		CharacterUtility.SetActiveCharacter(m_newCharacterID);
		PreviewUtility.RevertAllPreview();
		PoolSpawner.Spawn(m_SetActiveEffect, LobbyScene.Inst.CurrentCharacter.transform);
		OK();
	}

	private void OK()
	{
		Close();
		if (OnCloseNewCharacter != null)
		{
			OnCloseNewCharacter();
		}
	}

	private void Close()
	{
		UILobby.Current.m_PageContainer.gameObject.SetActive(value: true);
		m_Root.gameObject.SetActive(value: false);
		LobbyScene.Inst.ClosePreviewPanels();
		if (m_ShowSequences.Count == 0)
		{
			UIDataEvents.Inst.InvokeEvent("OnCharacterFeatureUIDisable");
		}
		UIDataEvents.Inst.InvokeEvent("OnCharacterFeatureUIClosed");
	}
}
