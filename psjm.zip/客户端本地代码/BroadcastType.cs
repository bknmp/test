using System;

[Serializable]
public enum BroadcastType
{
	Gift = 1,
	PassLottery,
	Max
}
