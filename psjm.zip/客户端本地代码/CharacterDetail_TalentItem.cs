using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CharacterDetail_TalentItem
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Image m_Icon;

	public UITipsDialogController m_Tips;

	public UIStateImage m_Frame;

	public UIStateItem m_Type;

	public TalentDetailUI m_TalentDetailUI;

	public Button m_Button;

	private int m_TalentID;

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["id"];
		m_TalentID = item;
		TalentInfo talentInfo = LocalResources.TalentTable.Get(item);
		m_Name.text = talentInfo.Name;
		m_Icon.sprite = SpriteSource.Inst.Find(talentInfo.Icon);
		m_Frame.State = (int)talentInfo.Type;
		m_Type.State = (int)talentInfo.Type;
		if (m_Button != null)
		{
			m_Host.EventProxy(m_Button, "OnButtonClicked");
		}
	}

	public void OnButtonClicked()
	{
		m_TalentDetailUI.ShowTalentInfo(m_TalentID);
	}
}
