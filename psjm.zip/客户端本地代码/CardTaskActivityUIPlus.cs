using LightUI;
using System;
using UnityEngine;

internal class CardTaskActivityUIPlus : CardTaskActivityUI
{
	public RectTransform m_PreviewAnchor;

	public UIDataBinder m_CommonPreview;

	private UIDataBinder m_PreviewUIInst;

	private CommonDataCollection m_Args = new CommonDataCollection();

	public new void Bind(CommonDataCollection args)
	{
		args["OnPreviewCallBack"].val = new Action<int>(OnPreviewCallBack);
		base.Bind(args);
		if (m_PreviewUIInst == null)
		{
			m_PreviewUIInst = UnityEngine.Object.Instantiate(m_CommonPreview, m_PreviewAnchor);
		}
		args["TaskClaimActionWithEffect"].val = new Action<GameObject, int>(DoTaskTaskClaim);
		m_Args = args;
	}

	private void OnPreviewCallBack(int itemID)
	{
		DropItem val = LocalResources.DropItemTable.Get(itemID);
		m_Args["dropItem"].val = val;
		m_PreviewUIInst.Args = m_Args;
	}

	private void DoTaskTaskClaim(GameObject fromGO, int count)
	{
		m_Args["FlyEffectStartGo"].val = fromGO;
		m_Args["addScoresCount"] = count;
		m_ProcessUIInst.Args = m_Args;
	}
}
