using LightUtility;

public class CardGrowthInfo : IdBased
{
	public CardGrowthType Type;

	public string ChangeFormat;

	public string UnitText;

	public float Start;

	public float Rate;

	public int MaxLevel;

	public int[] GoldCostNew;

	public int[] PieceCostNew;

	public int ComposePiece;

	public int UnlockGrade;

	public int[] UpgradeLimitGrade;

	public string[] AttrIcon;

	public string[] AttrDesc;

	public string[] AttrValue;

	public float DefaultValue;

	public int StartTimePC;

	public int StartTimePhone;

	public int StartTime => StartTimePC + StartTimePhone;
}
