using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class ActiveCardConfigView
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_ItemView;

	public Text m_CurrentConfigName;

	public UITemplateInitiator m_ConfigView;

	public Button m_ReplacingDimmer;

	public Button m_ChangeCardConfigBtn;

	public UIPage m_CardConfigEditPage;

	public static int CardConfigIndex;

	public static bool Replacing;

	public void Bind(CommonDataCollection args)
	{
		CardConfigIndex = CardUtility.CurrentCharacterCardConfigs.activeIndex;
		bool num = m_Host.GetComponentInParent<CardConfigEditPage>() != null;
		if (m_ReplacingDimmer != null)
		{
			m_Host.EventProxy(m_ReplacingDimmer, "OnCancelReplacing");
		}
		args = new CommonDataCollection();
		CardConfig activeCardConfig = CardUtility.ActiveCardConfig;
		if (num)
		{
			for (int i = 0; i < 6; i++)
			{
				int arraySize = args.ArraySize;
				args[arraySize]["idx"] = arraySize;
				args[arraySize]["id"] = ((i < activeCardConfig.config.Length) ? activeCardConfig.config[i] : 0);
				args[arraySize]["lock"] = activeCardConfig.LockIndex.Contains(i);
				args[arraySize]["lockEnable"] = activeCardConfig.LockEnable;
				args[arraySize]["lockNum"] = activeCardConfig.LockIndex.Length;
			}
		}
		else
		{
			for (int j = 0; j < activeCardConfig.config.Length; j++)
			{
				int num2 = activeCardConfig.config[j];
				if (num2 > 0)
				{
					int arraySize2 = args.ArraySize;
					args[arraySize2]["idx"] = arraySize2;
					args[arraySize2]["id"] = num2;
					args[arraySize2]["lock"] = activeCardConfig.LockIndex.Contains(j);
					args[arraySize2]["lockEnable"] = activeCardConfig.LockEnable;
					args[arraySize2]["lockNum"] = activeCardConfig.LockIndex.Length;
				}
			}
		}
		m_ItemView.Args = args;
		if (m_ConfigView != null)
		{
			args = new CommonDataCollection();
			CardConfig[] currentCardConfigs = CardUtility.CurrentCardConfigs;
			for (int k = 0; k < currentCardConfigs.Length; k++)
			{
				CardConfig cardConfig = currentCardConfigs[k];
				int arraySize3 = args.ArraySize;
				args[arraySize3]["idx"] = arraySize3;
			}
			m_ConfigView.Args = args;
		}
		if (m_CurrentConfigName != null)
		{
			m_CurrentConfigName.text = activeCardConfig.name;
		}
		if (m_ChangeCardConfigBtn != null)
		{
			m_Host.EventProxy(m_ChangeCardConfigBtn, "GotoChangeCardConfigPage");
		}
	}

	public void OnCancelReplacing()
	{
		Replacing = false;
		UIDataEvents.Inst.InvokeEvent("ActiveCardConfigReplacing");
	}

	public void GotoChangeCardConfigPage()
	{
		UILobby.Current.GoToPage(m_CardConfigEditPage);
		LocalPlayerDatabase.SetPrefValue("HadShowTipsChangeCard", value: true);
	}
}
