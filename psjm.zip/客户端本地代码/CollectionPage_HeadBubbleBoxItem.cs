using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CollectionPage_HeadBubbleBoxItem
{
	public UIDataBinder m_Host;

	public UIStateItem m_State;

	public Text m_Personality;

	public Image m_Image;

	public Text m_ChatText;

	public UITipsDialogController m_Tips;

	public Image m_Extra;

	public void Bind(CommonDataCollection args)
	{
		int id = args["id"];
		bool num = args["owned"];
		HeadBubbleBoxInfo headBubbleBoxInfo = LocalResources.HeadBubbleBoxInfos.Get(id);
		DropItem dropItem = LocalResources.DropItemTable.Get(headBubbleBoxInfo.TypeParam);
		m_Tips.m_Tips = headBubbleBoxInfo.GainTips;
		if (num)
		{
			m_State.State = 0;
			m_Personality.text = dropItem.Personality.ToString();
		}
		else
		{
			m_State.State = 1;
		}
		if (m_ChatText != null)
		{
			m_ChatText.color = GameChatColors.HexToColor(headBubbleBoxInfo.TextColor);
			m_ChatText.text = headBubbleBoxInfo.Name;
		}
		if (string.IsNullOrEmpty(headBubbleBoxInfo.Icon))
		{
			m_Image.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		}
		else
		{
			m_Image.sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon);
		}
		if (dropItem.Type == DropItemType.BubbleBox && m_Extra != null)
		{
			Sprite sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon + "_extra");
			if (sprite != null)
			{
				m_Extra.gameObject.SetActive(value: true);
				m_Extra.sprite = sprite;
				m_Extra.SetNativeSize();
			}
			else
			{
				m_Extra.gameObject.SetActive(value: false);
			}
		}
	}
}
