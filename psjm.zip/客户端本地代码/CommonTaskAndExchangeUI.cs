using GameMessages;
using LightUI;
using UnityEngine;

internal class CommonTaskAndExchangeUI : TaskActivityUI
{
	public UIDataBinder m_CommonTaskUI;

	public GameObject m_RedPointOne;

	public UIDataBinder m_CommonExchangeUI;

	public UIDataBinder m_CommonTaskAndExchangeUI;

	public GameObject m_RedPointTwo;

	public new void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		if (activity == null)
		{
			return;
		}
		if (m_CommonTaskUI != null)
		{
			m_CommonTaskUI.Args = args;
			m_CommonExchangeUI.Args = args;
			m_CommonTaskAndExchangeUI.Args = args;
			if (LocalPlayerDatabase.GetPrefValueInt("CommonTask_" + activity.activityId) != activity.startTime)
			{
				LocalPlayerDatabase.SetPrefValue("CommonTask_" + activity.activityId, activity.startTime);
			}
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}
		if (m_RedPointOne != null)
		{
			m_RedPointOne.SetActive(CommonExchangeUI.GetRedPoint(activity.activityId));
			m_RedPointTwo.SetActive(CommonTaskUI.GetRedPoint(activity.activityId));
		}
	}
}
