public class BoxInfo : QualityBased
{
	public string Name;

	public string Icon;

	public int[] GradesRange;

	public int NeedPoint;

	public int AwardColoringAgent;

	public int[] AwardTicketRange;

	public int[] AwardCoinRange;

	public int[] AwardCardCountArray;

	public int[] AwardCardType;

	public float OpenCostDiamond;

	public float OpenCostTime;

	public int Type;

	public int LotteryMoneyType;

	public int LotteryMoneyCost;

	public int AwardCardPiece
	{
		get
		{
			int num = 0;
			int[] awardCardCountArray = AwardCardCountArray;
			foreach (int num2 in awardCardCountArray)
			{
				num += num2;
			}
			return num;
		}
	}
}
