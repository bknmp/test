using LightUtility;
using System.Collections;
using UnityEngine;

public class BlinkController : MonoBehaviour
{
	public string m_OpenEyesMatName = "Police_05_head_OpenEyes_01_height";

	public string mCloseEyesMatName = "Police_05_head_CloseEyes_01_height";

	public float m_DelayTime = 4f;

	public float m_BlinkTime = 0.2f;

	private Material m_OpenEyesMat;

	private Material m_CloseEyesMat;

	private void OnEnable()
	{
		if (m_OpenEyesMat == null)
		{
			m_OpenEyesMat = GetMaterial(m_OpenEyesMatName);
		}
		if (m_CloseEyesMat == null)
		{
			m_CloseEyesMat = GetMaterial(mCloseEyesMatName);
		}
		StartCoroutine(DoBlink());
	}

	private void OnDestroy()
	{
		if (m_OpenEyesMat != null)
		{
			ResManager.Unload(m_OpenEyesMat);
			m_OpenEyesMat = null;
		}
		if (m_CloseEyesMat != null)
		{
			ResManager.Unload(m_CloseEyesMat);
			m_CloseEyesMat = null;
		}
	}

	private Material GetMaterial(string name)
	{
		return ResManager.Load<Material>(name);
	}

	private IEnumerator DoBlink()
	{
		while (base.gameObject.activeSelf)
		{
			base.transform.GetComponent<SkinnedMeshRenderer>().material = m_CloseEyesMat;
			yield return Yielders.GetWaitForSeconds(m_BlinkTime);
			base.transform.GetComponent<SkinnedMeshRenderer>().material = m_OpenEyesMat;
			yield return Yielders.GetWaitForSeconds(m_DelayTime);
		}
	}
}
