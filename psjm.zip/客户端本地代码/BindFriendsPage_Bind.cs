using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class BindFriendsPage_Bind
{
	public UIDataBinder m_Host;

	public InputField m_InputField;

	public Button m_Search;

	public PlayerIcon m_PlayerIcon;

	public Text m_PlayerName;

	public UIStateImage m_Sex;

	public Text m_Age;

	public Text m_Area;

	public Text m_Description;

	public UIStateItem m_State;

	public GradeItem m_ThiefGrade;

	public GradeItem m_PoliceGrade;

	public UnionBadgeItem m_UnionItem;

	public Text m_PassLevel;

	public UIStateItem m_Top;

	public UIStateItem m_PlayerInfo;

	public Button m_BindButton;

	public UIStateItem m_BindState;

	public Button m_UnBind;

	public GameObject m_BindSucc;

	public static bool m_RefreshPage;

	public static bool m_RefreshBindInfo;

	public static Delegates.VoidCallback OnUpBindChanged;

	private int m_PlayerID;

	public void Bind(CommonDataCollection args)
	{
		if (m_RefreshPage)
		{
			m_InputField.text = "";
			SetBindInfo();
			m_RefreshPage = false;
		}
		OnUpBindChanged = (Delegates.VoidCallback)Delegate.Combine(OnUpBindChanged, new Delegates.VoidCallback(SetBindInfo));
		m_Host.EventProxy(m_Search, "OnSearchButtonClicked");
		m_Host.EventProxy(m_BindButton, "OnBindButtonClicked");
		m_Host.EventProxy(m_UnBind, "OnUnbindButtonClick");
	}

	public void OnDisable()
	{
		OnUpBindChanged = (Delegates.VoidCallback)Delegate.Remove(OnUpBindChanged, new Delegates.VoidCallback(SetBindInfo));
	}

	private void SetBindInfo()
	{
		if (BindFriendsUtility.MyBindFriendsInfo.beBindFriend == 0)
		{
			m_Top.State = 0;
			m_PlayerID = 0;
			m_PlayerInfo.State = 0;
			m_BindState.gameObject.SetActive(value: false);
			m_BindSucc.SetActive(value: false);
			return;
		}
		m_Top.State = 1;
		if (m_PlayerID != BindFriendsUtility.MyBindFriendsInfo.beBindFriend)
		{
			m_PlayerID = BindFriendsUtility.MyBindFriendsInfo.beBindFriend;
			RequestPlayerInfo();
		}
		else
		{
			m_BindState.State = 2;
		}
		m_BindSucc.SetActive(value: true);
	}

	private void RequestPlayerInfo()
	{
		LocalPlayerDatabase.RefreshPlayerInfo((uint)m_PlayerID, delegate(HttpResponsePlayerInfo response)
		{
			SetSearchPlayerInfo(response);
		}, null, null, blocking: true);
	}

	private void SetSearchPlayerInfo(HttpResponsePlayerInfo response)
	{
		m_PlayerIcon.GetComponent<PlayerSpaceButton>().SetPlayerID((uint)m_PlayerID, 0, response);
		m_PlayerIcon.SetTexture(response.publicInfo.icon, response.publicInfo.activeHeadBoxID);
		m_PlayerName.text = response.publicInfo.name;
		m_Sex.State = response.publicInfo.sex;
		m_Age.text = response.publicInfo.age.ToString();
		m_Area.text = LocalResources.ProvinceTable.Find(response.publicInfo.province).Province;
		m_Description.text = ((!string.IsNullOrEmpty(response.description)) ? response.description : Localization.DescriptionEmpty);
		m_State.gameObject.SetActive(m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID);
		m_State.State = response.onlineState;
		m_ThiefGrade.SetGradeItem(response.publicInfo.gradeThief);
		m_PoliceGrade.SetGradeItem(response.publicInfo.gradePolice);
		if (response.publicInfo.unionID > 0)
		{
			m_UnionItem.transform.parent.gameObject.SetActive(value: true);
			m_UnionItem.SetBadge(response.publicInfo.unionBadge, response.publicInfo.unionID, response.publicInfo.unionName);
		}
		else
		{
			m_UnionItem.transform.parent.gameObject.SetActive(value: false);
		}
		if (m_PassLevel != null)
		{
			bool passUnlocked = PassUtility.GetPassUnlocked(response.publicInfo.higherGrade);
			m_PassLevel.transform.parent.gameObject.SetActive(passUnlocked);
			if (passUnlocked)
			{
				m_PassLevel.text = response.passLevel.ToString();
			}
		}
		m_PlayerInfo.State = 1;
		m_BindState.State = ((BindFriendsUtility.MyBindFriendsInfo.beBindFriend != 0) ? 2 : 0);
		m_BindState.gameObject.SetActive(value: true);
	}

	public void OnSearchButtonClicked()
	{
		if (!int.TryParse(m_InputField.text.Trim().Replace(" ", "\u00a0").Replace("\r", "")
			.Replace("\n", ""), out m_PlayerID))
		{
			UILobby.Current.ShowTips(Localization.TipsInvalidInviteNum);
		}
		else
		{
			RequestPlayerInfo();
		}
	}

	public void OnBindButtonClicked()
	{
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
		{
			UILobby.Current.ShowTips(Localization.TipsNotBindSelf);
		}
		else if (BindFriendsUtility.MyBindFriendsInfo.playerState == 0 || BindFriendsUtility.MyBindFriendsInfo.playerState == 3)
		{
			UILobby.Current.ShowTips(Localization.TipsBindFriendRule);
		}
		else
		{
			BindFriendsUtility.ApplyBindFriend((uint)m_PlayerID, delegate
			{
				UILobby.Current.ShowTips(Localization.TipsApplySendOut);
				m_BindState.State = 1;
			});
		}
	}

	public void OnUnbindButtonClick()
	{
		UILobby.Current.ShowMessageBoxYesNo(string.Format(Localization.TipsUnBindFriend, m_PlayerName.text), Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
		{
			BindFriendsUtility.SetReviewStatus((uint)m_PlayerID, 2);
		}, null, showCloseButton: false);
	}
}
