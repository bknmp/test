using DG.Tweening;
using LightUtility;
using UnityEngine;

public class AddMaxLifeBuff : BuffManager.Buff
{
	private GameObject m_AddMaxLifeEffectInst;

	private GameObject addMaxLifeEffect;

	protected BuffManager m_BuffManager;

	protected PlayerController m_PlayerController;

	private GameObject AddMaxLifeEffect
	{
		get
		{
			if (addMaxLifeEffect == null)
			{
				addMaxLifeEffect = PrefabSource.Inst.Find(m_PlayerController.GetBaseCardSkinInfo(106).Prefabs);
			}
			return addMaxLifeEffect;
		}
	}

	public override bool BuffStart(BuffManager buffManager, PlayerController playerController)
	{
		m_BuffManager = buffManager;
		m_PlayerController = playerController;
		m_BuffManager.LocalClearAllDeBuffs();
		UpdateMaxLifeEffect(show: true, broke: false);
		return true;
	}

	public override void BuffUpdate()
	{
		UpdateMaxLifeEffect(shield > 0f, shield <= 0f);
	}

	public override void BuffEnd(bool reconnect = false)
	{
		UpdateMaxLifeEffect(show: false, shield <= 0f);
		if (reconnect)
		{
			m_PlayerController.UpdateBloodBar(tween: false);
		}
		else if (m_BuffManager.m_PhotonView.isMine && shield > 0f)
		{
			m_PlayerController.m_PhotonView.RPC("AddMaxLife", PhotonTargets.AllViaServer, shield * 0.3f);
		}
	}

	private void UpdateMaxLifeEffect(bool show, bool broke)
	{
		if (show && m_AddMaxLifeEffectInst == null)
		{
			Transform parent = (m_BuffManager.m_EffectRoot != null) ? m_BuffManager.m_EffectRoot : m_BuffManager.transform;
			m_AddMaxLifeEffectInst = PoolSpawner.Spawn(AddMaxLifeEffect, parent);
			m_AddMaxLifeEffectInst.transform.localPosition = AddMaxLifeEffect.transform.localPosition;
			m_AddMaxLifeEffectInst.transform.localRotation = AddMaxLifeEffect.transform.localRotation;
		}
		else
		{
			if (show || !(m_AddMaxLifeEffectInst != null))
			{
				return;
			}
			Animator componentInChildren = m_AddMaxLifeEffectInst.GetComponentInChildren<Animator>();
			if (componentInChildren != null)
			{
				if (broke)
				{
					componentInChildren.SetTrigger("Break");
				}
				else
				{
					componentInChildren.SetTrigger("Heal");
				}
			}
			GameObject tmp = m_AddMaxLifeEffectInst;
			m_AddMaxLifeEffectInst.transform.DOScale(1f, 1f).SetEase(Ease.InBack).OnComplete(delegate
			{
				PoolSpawner.DeSpawn(tmp);
			});
			m_AddMaxLifeEffectInst = null;
		}
	}
}
