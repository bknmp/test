using BehaviorDesigner.Runtime.Tasks;

[TaskName("是否有监狱门被破坏了")]
[TaskCategory("躲猫猫AI/条件")]
public class AnyJailDoorBroken : Conditional
{
	public override TaskStatus OnUpdate()
	{
		foreach (JailDoor allAutoOpenJailDoor in JailDoor.AllAutoOpenJailDoors)
		{
			if (allAutoOpenJailDoor.IsBroken)
			{
				return TaskStatus.Success;
			}
		}
		return TaskStatus.Failure;
	}
}
