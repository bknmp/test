using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

internal class AnniversaryPreview_Item
{
	public UIDataBinder m_Host;

	public MultiTargetGraphicButton m_Button;

	public Text m_Name1;

	public Text m_Name2;

	public Text m_Name3;

	public RawImage m_NameImage1;

	public RawImage m_NameImage2;

	public RawImage m_NameImage3;

	public Text m_Time1;

	public Text m_Time2;

	public Text m_Time3;

	public UIStateItem m_State;

	private ActivityLobbyInfo m_info;

	private Activity m_Activity;

	public void Bind(CommonDataCollection args)
	{
		m_info = (args["activityInfo"].val as ActivityLobbyInfo);
		m_Activity = (args["activity"].val as Activity);
		if (m_info != null && m_Activity != null)
		{
			SetInfo();
			StateHandle();
		}
		m_Host.EventProxy(m_Button, "Jump");
	}

	private void SetInfo()
	{
		string text;
		string text4;
		if (m_Name1 != null && m_Name2 != null && m_Name3 != null)
		{
			Text name = m_Name1;
			Text name2 = m_Name2;
			text = (m_Name3.text = m_info.TabName);
			text4 = (name.text = (name2.text = text));
		}
		else
		{
			m_NameImage1.texture = ResManager.Load<Texture>(m_info.TabName + "_close_jump");
			m_NameImage2.texture = ResManager.Load<Texture>(m_info.TabName + "_jump");
			m_NameImage3.texture = ResManager.Load<Texture>(m_info.TabName + "_close_jump");
		}
		string text5 = m_info.TimeDesc;
		if (string.IsNullOrEmpty(text5))
		{
			DateTime date = UtcTimeStamp.GetDate(m_Activity.startTime);
			DateTime date2 = UtcTimeStamp.GetDate(m_Activity.endTime);
			text5 = $"{date:MM.dd}-{date2:MM.dd}";
		}
		Text time = m_Time1;
		Text time2 = m_Time2;
		text = (m_Time3.text = text5);
		text4 = (time.text = (time2.text = text));
	}

	private void StateHandle()
	{
		if (UtcTimeStamp.Now < m_Activity.startTime)
		{
			m_State.State = 0;
		}
		else if (UtcTimeStamp.Now > m_Activity.endTime)
		{
			m_State.State = 2;
		}
		else
		{
			m_State.State = 1;
		}
	}

	public void Jump()
	{
		if (m_info.gradeLimit > 0 && LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < m_Activity.gradeLimit)
		{
			UILobby.Current.ShowTips(string.Format(Localization.EnableWhenGrade, LocalResources.GetGradeName(m_info.gradeLimit)));
		}
		else if (UtcTimeStamp.Now < m_Activity.startTime)
		{
			UILobby.Current.ShowTips(Localization.ActivityNotOpen);
		}
		else if (UtcTimeStamp.Now > m_Activity.endTime)
		{
			UILobby.Current.ShowTips(Localization.ActivityOver);
		}
		else if (m_info.CollectionType == ActivityCollectionType.ANNIVERSART_ACTIVITY || m_info.CollectionType == ActivityCollectionType.LOVER_ACTIVITY)
		{
			AnniversaryActivityUI componentInParent = m_Host.GetComponentInParent<AnniversaryActivityUI>();
			componentInParent.JumpTabByActivityType(m_info.Type);
			componentInParent.GoBackIndex = 0;
		}
		else if (m_info.CollectionType == ActivityCollectionType.NEW_CARD_ACTIVITY)
		{
			NewCardActivity.enterActivityID = m_Activity.activityId;
			JumpModuleManager.Inst.DoJump(JumpModule.NewCardActivity);
		}
		else if (m_info.CollectionType == ActivityCollectionType.CHARACTER_ACTIVITY)
		{
			NewCardActivity.enterActivityID = m_Activity.activityId;
			JumpModuleManager.Inst.DoJump(JumpModule.CharacterActivity).GetComponent<CharacterActivityUI>().JumpTabByActivityType(m_info.Type);
		}
		else if (m_info.CollectionType == ActivityCollectionType.LOTTERY_ACTIVITY)
		{
			NewCardActivity.enterActivityID = m_Activity.activityId;
			JumpModuleManager.Inst.DoJump(JumpModule.CharacterActivity).GetComponent<LotteryActivityUI>().JumpTabByActivityType(m_info.Type);
		}
		else if (m_info.Type == ActivityType.WHEEL)
		{
			JumpModuleManager.Inst.DoJump(JumpModule.WheelActivity);
		}
		else
		{
			UILobby.Current.ShowTips("暂未支持跳转至 " + m_info.TabName + m_info.Id);
		}
	}
}
