using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;

public class CardConfigEditPage : UIEventListener
{
	public enum SelectTabType
	{
		Upgrade,
		Skin,
		Detail
	}

	public Canvas m_ActiveCardConfigCanvas;

	public GameObject m_ReplacingDimmer;

	public UIScrollRect m_ScrollRect;

	public GameObject m_NewKeyMapButton;

	private static CardConfig[] m_BackupCardConfigs;

	public static bool IsShowing;

	private int m_lastActiveCardConfigIndex;

	public static bool HadEnteyCardPage;

	private new void Awake()
	{
		UIDataEvents.Inst.AddEventListener("ActiveCardConfigReplacing", this, OnActiveCardConfigReplacing);
		base.Awake();
	}

	private void OnDestroy()
	{
		IsShowing = false;
	}

	private void OnActiveCardConfigReplacing()
	{
		m_ActiveCardConfigCanvas.overrideSorting = ActiveCardConfigView.Replacing;
		m_ActiveCardConfigCanvas.sortingOrder = 1;
		m_ReplacingDimmer.SetActive(ActiveCardConfigView.Replacing);
	}

	public override void OnEnterUI()
	{
		if (ActiveCardConfigView.Replacing)
		{
			ActiveCardConfigView.Replacing = false;
			UIDataEvents.Inst.InvokeEvent("ActiveCardConfigReplacing");
		}
		TryShowScrollToItemAnimation();
		HadEnteyCardPage = true;
		m_lastActiveCardConfigIndex = CardUtility.CurrentCharacterCardConfigs.activeIndex;
		IsShowing = true;
		UpdateBackupCardConfigs();
		CardConfigEditPage_ItemTemplate.SelectedID = -1;
		UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
		m_ScrollRect.ContentPos = 0f;
		m_NewKeyMapButton.SetActive(GameSettings.Inst.NewIngameKeyMap);
	}

	public override void OnExitUI()
	{
		if (CardUtility.ContainsMultiWeaponCard())
		{
			CardUtility.UnLoadExtraWeaponCard();
			CardUtility.SubmitCurrentCardConfigs(null);
		}
		else if (GameRuntime.PlayingRole == RoleType.Police && !CardUtility.ContainsWeaponCard())
		{
			CardUtility.LoadDefaultWeaponCard();
			CardUtility.SubmitCurrentCardConfigs(null);
		}
		if (m_lastActiveCardConfigIndex != CardUtility.CurrentCharacterCardConfigs.activeIndex)
		{
			CardUtility.ChangeActiveCardConfigIndex(null);
		}
		IsShowing = false;
		if (ActiveCardConfigView.Replacing)
		{
			ActiveCardConfigView.Replacing = false;
			UIDataEvents.Inst.InvokeEvent("ActiveCardConfigReplacing");
		}
		ResourceSource.UnloadUnusedAssets();
	}

	public void OnCloseClicked()
	{
		if (ArrayUtility.Equal(CardUtility.CurrentCardConfigs, m_BackupCardConfigs))
		{
			GoBack();
		}
		else
		{
			SaveCardConfigs();
		}
		int[] activeCardSkins = CardUtility.ActiveCardSkins;
		if (!ArrayUtility.Equal(LobbyScene.Inst.CurrentCharacter.CardSkins, activeCardSkins))
		{
			LobbyScene.Inst.CurrentCharacter.CardSkins = activeCardSkins;
		}
	}

	private void SaveCardConfigs()
	{
		if (CardUtility.ContainsMultiWeaponCard())
		{
			UILobby.Current.ShowMessageBoxOK(Localization.TipsMultiWeaponCard, Localization.MsgBoxOK, Localization.MsgBoxTitle, null);
		}
		else if (GameRuntime.PlayingRole == RoleType.Police && !CardUtility.ContainsWeaponCard())
		{
			UILobby.Current.ShowMessageBoxOK(Localization.TipsOneWeaponCard, Localization.MsgBoxOK, Localization.MsgBoxTitle, null);
		}
		else
		{
			CardUtility.SubmitCurrentCardConfigs(GoBack);
		}
	}

	private void GoBack()
	{
		GetComponent<UILobbyElement>().GoBack();
	}

	private void TryShowScrollToItemAnimation()
	{
		if (LobbyScene.Inst.CurrentMode != LobbyScene.Mode.Team)
		{
			if (CardConfigEditPage_ItemTemplate.ScrollItemID > 0)
			{
				UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
				return;
			}
			foreach (InGameStoreInfo item in LocalResources.InGameStoreTable)
			{
				if (CardUtility.NewUnlockCardIDs.Contains(item.Id))
				{
					CardConfigEditPage_ItemTemplate.ScrollItemID = item.Id;
					UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
					return;
				}
			}
			foreach (InGameStoreInfo item2 in LocalResources.InGameStoreTable)
			{
				if (!CardUtility.IsOwned(item2.Id) && CardUtility.CanComposeCard(item2.Id))
				{
					CardConfigEditPage_ItemTemplate.ScrollItemID = item2.Id;
					UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
					break;
				}
			}
		}
	}

	public static void UpdateBackupCardConfigs()
	{
		m_BackupCardConfigs = CardUtility.CopyCardConfigs();
	}
}
