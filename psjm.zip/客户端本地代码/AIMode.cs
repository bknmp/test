public enum AIMode
{
	Wander,
	Guard,
	Patrol,
	Navigate,
	LockTarget
}
