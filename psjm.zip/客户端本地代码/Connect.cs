using DG.Tweening;
using LightUtility;
using SimpleJson;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Connect : SelectableSkill
{
	private enum ProxyEnum
	{
		Connected = 1,
		EndSkill
	}

	public GameObject m_LinePrefab;

	public Transform m_LineAnchor;

	public float m_Time = 45f;

	public float m_MaxDistance = 12f;

	public GameObject m_MaxLenTips;

	public float m_ShowTipsDistance = 8f;

	public GameObject m_GhostFX;

	public float m_DashSpeed = 10f;

	public int m_DashBuffID = 505;

	public GameObject m_CastFX;

	public GameObject m_ShotPrefab;

	public GameObject m_DashEndFX;

	private ConnectLine m_Line;

	private CanvasGroup m_Alpha;

	private float m_LastDist;

	private Vector3 m_Speed;

	private GameObject m_GhostFXInst;

	private ConnectShot m_Shot;

	private PlayerController m_TargetPlayer;

	private bool m_Connecting;

	private float m_ConnectedTime;

	private int m_DefaultCoinCost;

	private float m_TalentCostCoin;

	private float m_DamageMinTime;

	private Tweener m_TipsTweener;

	public static SafeGameDictionary<string, ConnectState> ConnectStates = new SafeGameDictionary<string, ConnectState>();

	private static bool m_Registed;

	public bool Ghosting => m_GhostFXInst != null;

	public override bool ForcingControl => Ghosting;

	private void Awake()
	{
		m_Alpha = m_MaxLenTips.GetComponent<CanvasGroup>();
	}

	private void OnDestroy()
	{
		if (ConnectStates.ContainsKey(m_PlayerController.UserId))
		{
			ConnectStates.Remove(m_PlayerController.UserId);
		}
	}

	public static bool CheckConnectState(PlayerController player)
	{
		foreach (ConnectState value in ConnectStates.Values)
		{
			if (value.master == player || value.guest == player)
			{
				return true;
			}
		}
		return false;
	}

	private static ConnectState IsConnectMaster(PlayerController player)
	{
		foreach (ConnectState value in ConnectStates.Values)
		{
			if (value.master == player)
			{
				return value;
			}
		}
		return default(ConnectState);
	}

	private static ConnectState IsConnectGuest(PlayerController player)
	{
		foreach (ConnectState value in ConnectStates.Values)
		{
			if (value.guest == player)
			{
				return value;
			}
		}
		return default(ConnectState);
	}

	public override void Initialize(PlayerController player, SkillInfo skillInfo)
	{
		base.Initialize(player, skillInfo);
		m_DefaultCoinCost = LocalResources.SkillTable.Find(base.ID).CoinCost;
		m_Cooldown = m_PlayerController.TalentManager.GetTalent(base.TalentID).Param;
		TalentManager.Talent talent = m_PlayerController.TalentManager.GetTalent(129);
		if (talent != null)
		{
			m_TalentCostCoin = talent.Param;
		}
		m_DamageMinTime = 0.01f;
	}

	public override bool CanClickSkill(bool active, object[] parameters = null)
	{
		if (!base.Activating && !active && parameters != null && !m_PlayerController.IsDying)
		{
			return true;
		}
		if (active && m_State == 1 && base.Activating && m_Connecting && !Ghosting && !m_PlayerController.IsDying)
		{
			return true;
		}
		return false;
	}

	public override void LocalSkill(bool active, object[] parameters = null)
	{
		base.LocalSkill(active, parameters);
		m_TargetPlayer = PlayerController.FindPlayer(NumId2UserId.Get(m_NumID), m_LocalNum);
		if (!base.Activating && !active && parameters != null && !m_PlayerController.IsDying)
		{
			StartSkill(m_Time, 99f);
			SetPreCooldownTime();
			if (m_TalentCostCoin > 0f)
			{
				ChangeCoinCost((int)m_TalentCostCoin);
				m_State = 1;
			}
			else
			{
				m_State = 0;
				ChangeCoinCost(0);
			}
		}
		else if (active && m_State == 1 && base.Activating && m_Connecting && !Ghosting && !m_PlayerController.IsDying)
		{
			StartCoroutine(PrincessDash());
		}
	}

	public override void StartSkill(float duration, float delay = 0f)
	{
		m_StartTime = InGameScene.Inst.GameTime;
		m_Duration = duration;
		m_Delay = delay;
		m_PreCooldownTime = 0f;
		m_SkillEndTime = 0f;
		HideWeapon();
		if (!(m_PlayerController.OnVehichle != null) && !ShapeShifter.IsShapeShiftingVehicle(m_PlayerController.gameObject) && !ShapeShifter.IsShapeShiftingSkateBoard(m_PlayerController.gameObject))
		{
			Vector3 normalized = (m_TargetPlayer.transform.position - m_PlayerController.transform.position).normalized;
			m_PlayerController.SetTargetDirection(normalized, immediately: true);
		}
		m_PlayerController.m_Animator.SetTrigger((m_PlayerController.SpeedForAnimator > 0.1f) ? "cast" : "skill_all");
		if (m_PlayerController.IsVisible)
		{
			PoolSpawner.Spawn(m_CastFX, m_PlayerController.transform).transform.localPosition = new Vector3(0f, 0.5f, 0f);
		}
		SpawnConnectShot();
	}

	private void LocalConnected()
	{
		FinishShot();
		Connected();
	}

	public override void SkillProxy(object parameter)
	{
		ProxyEnum proxyEnum = (ProxyEnum)parameter;
		UnityEngine.Debug.Log("proxy : " + proxyEnum);
		switch (proxyEnum)
		{
		case ProxyEnum.Connected:
			LocalConnected();
			break;
		case ProxyEnum.EndSkill:
			EndSkill();
			break;
		}
	}

	public void RpcShotFinish()
	{
		m_PlayerController.m_PhotonView.RPC("SkillProxy", PhotonTargets.All, ProxyEnum.Connected);
	}

	private void RpcEndSkill()
	{
		m_PlayerController.m_PhotonView.RPC("SkillProxy", PhotonTargets.All, ProxyEnum.EndSkill);
	}

	private void InitLine()
	{
		if (m_Line == null)
		{
			m_Line = PoolSpawner.Spawn(m_LinePrefab, m_LineAnchor).GetComponent<ConnectLine>();
			m_Line.Init();
		}
	}

	private void SpawnConnectShot()
	{
		m_Shot = PoolSpawner.Spawn(m_ShotPrefab).GetComponent<ConnectShot>();
		m_Shot.SetTarget(m_PlayerController, m_TargetPlayer);
		if (m_PlayerController.SpeedForAnimator > 0.1f)
		{
			m_PlayerController.m_Animator.SetTrigger("revive");
		}
		Invoke("ShowWeapon", 0.5f);
	}

	private void FinishShot()
	{
		if (m_Shot != null)
		{
			m_Shot.Finish();
			m_Shot = null;
		}
	}

	private void SpawnConnectLine()
	{
		InitLine();
		m_Line.Connect(GerConnectAnchor(m_PlayerController), GerConnectAnchor(m_TargetPlayer), m_MaxDistance, m_PlayerController.IsLocalPlayer, connected: true);
	}

	private void Connected()
	{
		SpawnConnectLine();
		m_ConnectedTime = InGameScene.Inst.GameTime;
		m_Delay = Mathf.Max(0f, m_ConnectedTime - m_StartTime);
		ConnectStates[m_PlayerController.UserId] = new ConnectState
		{
			master = m_PlayerController,
			guest = m_TargetPlayer
		};
		m_Connecting = true;
		m_PlayerController.BuffManager.OnBuffCreated += OnMasterBuffCreated;
	}

	private void Disconnected()
	{
		if (m_Line != null)
		{
			m_Line.Disconnect();
			m_Line = null;
		}
		m_Connecting = false;
	}

	private Transform GerConnectAnchor(PlayerController player)
	{
		return player.m_Animator.transform.Find("Bip001");
	}

	private void ShowWeapon()
	{
		m_PlayerController.ProjectileLauncher.ShowWeapon(show: true);
	}

	private void HideWeapon()
	{
		m_PlayerController.ProjectileLauncher.ShowWeapon(show: false);
	}

	protected new void Update()
	{
		base.Update();
		UpdateBuffManager();
		if (!(m_TargetPlayer != null))
		{
			return;
		}
		if (m_Connecting)
		{
			if (CheckOutMaxRange())
			{
				if (!IsInvoking("Disconnecting"))
				{
					m_TipsTweener = m_Alpha.DOFade(0f, 0.3f).SetLoops(-1, LoopType.Yoyo);
					Invoke("Disconnecting", 2f);
				}
			}
			else
			{
				CancelInvoke("Disconnecting");
				m_TipsTweener.Kill();
				m_TipsTweener = null;
			}
			if (m_PlayerController.IsMine && (m_TargetPlayer.FinalDeadOrEscaped || m_PlayerController.FinalDeadOrEscaped || (base.Activating && m_PlayerController.IsDying)))
			{
				RpcEndSkill();
			}
		}
		UpdateVisible();
	}

	private void LateUpdate()
	{
		UpdateMaxLenTips();
	}

	private bool CheckOutMaxRange()
	{
		if (m_TargetPlayer == null)
		{
			return true;
		}
		return Vector3.Distance(m_TargetPlayer.transform.position, m_PlayerController.transform.position) > m_MaxDistance;
	}

	private void Disconnecting()
	{
		m_TipsTweener.Kill();
		m_TipsTweener = null;
		if (m_PlayerController.IsMine && m_Connecting && !Ghosting && CheckOutMaxRange())
		{
			RpcEndSkill();
		}
	}

	private void UpdateMaxLenTips()
	{
		if (base.Activating && m_Connecting && !Ghosting)
		{
			if (m_PlayerController.IsCurrentPlayer)
			{
				UpdateMaxLenTipsPRA(m_PlayerController.transform.position, m_TargetPlayer.transform.position);
			}
			else if (m_TargetPlayer.IsCurrentPlayer)
			{
				UpdateMaxLenTipsPRA(m_TargetPlayer.transform.position, m_PlayerController.transform.position);
			}
			else
			{
				m_Alpha.alpha = 0f;
			}
		}
		else
		{
			m_Alpha.alpha = 0f;
		}
	}

	private void UpdateMaxLenTipsPRA(Vector3 near, Vector3 far)
	{
		Vector3 vector = (near - far).FlattenY();
		Vector3 normalized = vector.normalized;
		m_MaxLenTips.transform.position = far.FlattenY(0.1f) + normalized * (m_MaxDistance - 0.5f);
		m_MaxLenTips.transform.rotation = Quaternion.LookRotation(normalized);
		if (m_TipsTweener == null || !m_TipsTweener.IsPlaying())
		{
			m_Alpha.alpha = Mathf.Clamp01((vector.magnitude - m_ShowTipsDistance) / (m_MaxDistance - m_ShowTipsDistance));
		}
	}

	private void UpdateVisible()
	{
		bool flag = m_PlayerController.IsVisible || m_TargetPlayer.IsVisible;
		if (flag != m_LineAnchor.gameObject.activeSelf)
		{
			m_LineAnchor.gameObject.SetActive(flag);
		}
		if (m_GhostFXInst != null && m_GhostFXInst.activeSelf != m_PlayerController.IsVisible)
		{
			m_GhostFXInst.SetActive(m_PlayerController.IsVisible);
		}
	}

	private IEnumerator PrincessDash()
	{
		PlayerController target = m_TargetPlayer;
		float timeout = 5f;
		float time = 0f;
		yield return Ghost(enter: true, target);
		while (base.Activating && time < timeout)
		{
			Dashing(target);
			yield return null;
			time += Time.deltaTime;
			if (m_PlayerController.IsMine && (m_LastDist <= 1f || m_PlayerController.IsHookForwarding || m_PlayerController.PortalAdapter.IsPortaling))
			{
				RpcEndSkill();
			}
		}
		if (time >= timeout)
		{
			EndSkill();
		}
		yield return Ghost(enter: false, target);
	}

	private IEnumerator Ghost(bool enter, PlayerController target)
	{
		UnityEngine.Debug.Log(m_PlayerController.UserId + " Ghost " + enter.ToString());
		if (enter)
		{
			m_PlayerController.LocalExitVehicle();
			m_PlayerController.Shifter.EndShapeShift();
			if (m_PlayerController.IsLocalPlayer)
			{
				InGameStore.Inst.Disabled = true;
				InGameSkillUI.Inst.DisableAll = true;
			}
			m_Line.HideOnLineFx();
			base.HideBody = true;
			base.HideUI = true;
			m_PlayerController.AlphaDuration = 0f;
			AddBuff(m_PlayerController, m_DashBuffID);
			if (m_GhostFXInst != null)
			{
				PoolSpawner.DeSpawn(m_GhostFXInst);
				UnityEngine.Debug.LogError("it is impossible !!!");
			}
			m_GhostFXInst = PoolSpawner.Spawn(m_GhostFX, m_PlayerController.transform);
			m_GhostFXInst.transform.localPosition = new Vector3(0f, 0.5f, 0f);
		}
		else
		{
			if (m_PlayerController.IsVisible)
			{
				PoolSpawner.Spawn(m_DashEndFX, m_PlayerController.transform).transform.localPosition = new Vector3(0f, 0.5f, 0f);
			}
			RemoveBuff(m_PlayerController, m_DashBuffID);
			Vector3 pos = m_PlayerController.m_PhysicsBody.position;
			if (InGameScene.Inst.FindEmptySpace(ref pos, 0.5f))
			{
				m_PlayerController.m_PhysicsBody.position = pos;
				m_PlayerController.m_PhotonTransformView.Warp(pos);
			}
			AutoEnterVehicle(target);
			yield return null;
		}
	}

	private void AutoEnterVehicle(PlayerController target)
	{
		if (m_PlayerController.IsLocalPlayer && m_PlayerController.OnVehichle == null && (ShapeShifter.IsShapeShiftingVehicle(target.gameObject) || ShapeShifter.IsShapeShiftingSkateBoard(target.gameObject)) && Vector3.Distance(m_PlayerController.transform.position, target.transform.position) < 1.5f)
		{
			m_PlayerController.RpcEnterVehicle(target.gameObject);
		}
	}

	private void Dashing(PlayerController target)
	{
		Vector3 position = m_PlayerController.m_PhysicsBody.position;
		Vector3 vector = target.transform.localPosition - position;
		Vector3 a = vector.normalized * Mathf.Clamp01(m_LastDist - target.Radius);
		Vector3 vector2 = (Mathf.Max(target.LinearVelocity.magnitude, m_DashSpeed) * a - m_Speed) * Mathf.Min(Time.deltaTime * 20f, 1f);
		m_Speed += vector2;
		m_LastDist = vector.magnitude;
		position = Vector3.Lerp(position, position + m_Speed, Time.deltaTime);
		m_PlayerController.m_PhysicsBody.position = position;
		m_PlayerController.m_PhotonTransformView.Warp(position);
	}

	private void CheckBuff(PlayerController player)
	{
		if (CheckAutoRecover(player))
		{
			AddBuff(player, 504);
		}
		else
		{
			RemoveBuff(player, 504);
		}
	}

	private void UpdateBuffManager()
	{
		if (m_Connecting)
		{
			CheckBuff(m_PlayerController);
			CheckBuff(m_TargetPlayer);
		}
	}

	private bool CheckAutoRecover(PlayerController player)
	{
		if (player.IsDying)
		{
			return false;
		}
		if (m_DamageMinTime > 0f && InGameScene.Inst.GameTime - player.LastDamageTime > m_DamageMinTime)
		{
			return true;
		}
		return false;
	}

	private void AddBuff(PlayerController player, int buffID)
	{
		if (player != null && !player.BuffManager.ContainsBuff(buffID))
		{
			player.BuffManager.CreateCorrelatedBuff(m_PlayerController, buffID, BuffCorrelation.Connect);
		}
	}

	private void RemoveBuff(PlayerController player, int buffID)
	{
		if (player != null && player.BuffManager != null && player.BuffManager.ContainsBuff(buffID))
		{
			player.BuffManager.RemoveCorrelatedBuff(buffID);
		}
	}

	private void RpcGiveBuff(PlayerController giver, PlayerController getter, int id)
	{
		if (getter.IsMine && getter.BuffManager != null && !getter.IsDying)
		{
			getter.BuffManager.RpcCreateCorrelatedBuff(giver, id, BuffCorrelation.Connect);
		}
	}

	private void OnMasterBuffCreated(int id, BuffCorrelation correlation)
	{
		if (LocalResources.BuffTable.Find(id).Shareable && correlation != BuffCorrelation.Connect)
		{
			RpcGiveBuff(m_PlayerController, m_TargetPlayer, id);
		}
	}

	public override void EndSkill()
	{
		base.EndSkill();
		Reset();
	}

	private void Reset()
	{
		UnityEngine.Debug.Log("reset");
		CancelInvoke("Disconnecting");
		ChangeCoinCost(m_DefaultCoinCost);
		m_ConnectedTime = 0f;
		m_Delay = 0f;
		if (m_PlayerController.IsLocalPlayer)
		{
			InGameStore.Inst.Disabled = false;
			InGameSkillUI.Inst.DisableAll = false;
		}
		base.HideBody = false;
		base.HideUI = false;
		m_PlayerController.AlphaDuration = 0f;
		RemoveBuff(m_PlayerController, m_DashBuffID);
		RemoveBuff(m_TargetPlayer, 504);
		RemoveBuff(m_PlayerController, 504);
		if (m_PlayerController.m_Animator.isActiveAndEnabled)
		{
			m_PlayerController.m_Animator.SetBool("cast", value: false);
		}
		FinishShot();
		Disconnected();
		m_PlayerController.BuffManager.OnBuffCreated -= OnMasterBuffCreated;
		m_TargetPlayer = null;
		ConnectStates.Remove(m_PlayerController.UserId);
		if (m_GhostFXInst != null)
		{
			PoolSpawner.DeSpawn(m_GhostFXInst);
			m_GhostFXInst = null;
		}
	}

	public override void OnReSyncWrite(object data)
	{
		base.OnReSyncWrite(data);
		JsonObject jsonObject = data as JsonObject;
		JsonObject jsonObject2 = new JsonObject();
		foreach (KeyValuePair<string, ConnectState> connectState in ConnectStates)
		{
			if (!connectState.Value.IsNull)
			{
				jsonObject2[connectState.Key] = connectState.Value.master.UserId + "," + connectState.Value.guest.UserId;
			}
		}
		jsonObject["skillConnectStates"] = jsonObject2;
		jsonObject["skillConnecting"] = m_Connecting;
		jsonObject["skillConnectedTime"] = m_ConnectedTime;
	}

	public override void OnReSyncRead(object data)
	{
		CancelInvoke("SpawnConnectShot");
		base.OnReSyncRead(data);
		JsonObject jsonObject = data as JsonObject;
		ConnectStates.Clear();
		foreach (KeyValuePair<string, object> item in jsonObject["skillConnectStates"] as JsonObject)
		{
			string[] array = item.Value.ToString().Split(',');
			ConnectState value = default(ConnectState);
			value.master = PlayerController.FindPlayer(array[0]);
			value.guest = PlayerController.FindPlayer(array[1]);
			ConnectStates[item.Key] = value;
		}
		m_Connecting = jsonObject.AsBool("skillConnecting");
		m_ConnectedTime = jsonObject.AsFloat("skillConnectedTime");
		if (!base.Activating)
		{
			Reset();
			return;
		}
		if (m_NumID > 0)
		{
			m_TargetPlayer = PlayerController.FindPlayer(NumId2UserId.Get(m_NumID), m_LocalNum);
		}
		if (m_Connecting)
		{
			FinishShot();
			SpawnConnectLine();
		}
	}
}
