using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardLotteryUI_CardItem
{
	public UIDataBinder m_Host;

	public UIStateImage m_bgState;

	public Image m_Icon;

	public GameObject m_Mask;

	public Text m_GradeLimit;

	public Button m_Button;

	public Material m_MatDefaultOptimized;

	public Material m_MatDefaultGray;

	public UIStateImage m_TitleStatusBG;

	private string m_GradeLimitFormat;

	private bool m_Init;

	private int m_CardID;

	public void Bind(CommonDataCollection args)
	{
		if (!m_Init)
		{
			m_Init = true;
			m_GradeLimitFormat = m_GradeLimit.text;
		}
		int cardID = m_CardID = args["cardID"];
		DropItem dropItem = CardUtility.GetDropItem(cardID);
		CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(cardID);
		m_bgState.State = dropItem.Quality;
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_Mask.SetActive(cardGrowth.UnlockGrade > LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade);
		m_TitleStatusBG.gameObject.SetActive(m_Mask.activeSelf);
		m_Icon.material = (m_Mask.activeSelf ? m_MatDefaultGray : m_MatDefaultOptimized);
		if (m_Mask.activeSelf)
		{
			GradeMappingInfo mapping;
			GradeInfo gradeInfo = LocalResources.GetGradeInfo(cardGrowth.UnlockGrade, out mapping);
			m_GradeLimit.text = string.Format(m_GradeLimitFormat, gradeInfo.Name);
			m_Icon.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, 20f);
			m_TitleStatusBG.State = dropItem.Quality;
		}
		else
		{
			m_Icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
		}
		m_Host.EventProxy(m_Button, "OnClicked");
	}

	public void OnClicked()
	{
		if (!UILobby.Current.HasPageInStack<CardDetailUI>())
		{
			int cardLevel = CardUtility.GetCardLevel(m_CardID);
			JumpModuleManager.Inst.DoJump(JumpModule.CardDetail, CardUtility.CardDetailUIArgsWraper(m_CardID, cardLevel, showUpgradeBtn: false, isLocalPlayer: false));
		}
	}
}
