using LightUI;
using LightUtility;
using UnityEngine;

internal class ChangeTextureByPfID
{
	public UIDataBinder m_Host;

	public SpriteRenderer m_AngelSprite;

	public MeshRenderer m_Billboard;

	public void Bind(CommonDataCollection args)
	{
		if (m_AngelSprite != null && !string.IsNullOrEmpty(LocalPlayerDatabase.Settings.angleTextureUrl))
		{
			RemoteTextureManager.Inst.Acquire(LocalPlayerDatabase.Settings.angleTextureUrl, useAlphaMask: false, delegate(Texture2D onComplete)
			{
				Sprite sprite = Sprite.Create(onComplete, new Rect(0f, 0f, onComplete.width, onComplete.height), new Vector2(0.5f, 0.5f));
				m_AngelSprite.sprite = sprite;
			});
		}
		if (m_Billboard != null && !string.IsNullOrEmpty(LocalPlayerDatabase.Settings.billboardUrl))
		{
			RemoteTextureManager.Inst.Acquire(LocalPlayerDatabase.Settings.billboardUrl, useAlphaMask: false, delegate(Texture2D onComplete)
			{
				m_Billboard.material.SetTexture("_MainTex", onComplete);
			});
		}
	}
}
