using LightUI;
using UnityEngine;

internal class CardItem_Binder
{
	public UIDataBinder m_Host;

	public CardItemUI m_CardItemUI;

	public GameObject m_Lock;

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["cardId"];
		DataItem item2 = args["cardSkinOrStyleID"];
		DataItem item3 = args["level"];
		m_CardItemUI.SetInfo(item, item2, item3);
		m_Lock.gameObject.SetActive(args["lock"]);
	}
}
