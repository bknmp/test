using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class ActivityLobbyButton : LobbyBaseButton
{
	public UILobbyElement m_UI;

	public GameObject m_RedPoint;

	private int m_ShowAmount;

	private List<ModuleStatus> m_activityRedPointList = new List<ModuleStatus>();

	private void Start()
	{
		Init();
		UIDataEvents.Inst.AddEventListener("OverDayEvent", this, Init);
		UIDataEvents.Inst.AddEventListener("OnActivityLobbyRedPointChange", this, UpdateRedPointState);
	}

	private void UpdateRedPointState()
	{
		foreach (ModuleStatus activityRedPoint in m_activityRedPointList)
		{
			if (ActivityLobby.RedPointState((ActivityType)activityRedPoint.value, activityRedPoint.key))
			{
				m_RedPoint.gameObject.SetActive(value: true);
				return;
			}
		}
		m_RedPoint.gameObject.SetActive(value: false);
	}

	public void OnClick()
	{
		UILobby.Current.ShowUI(m_UI, null);
	}

	private void Init()
	{
		bool flag = false;
		m_activityRedPointList.Clear();
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit && (UtcTimeStamp.Now > activity.startTime || UtcTimeStamp.Now > activity.exchangeStartTime) && (UtcTimeStamp.Now < activity.endTime || UtcTimeStamp.Now < activity.exchangeEndTime) && LocalResources.ActivityLobbyInfos.Get(activity.activityId).CollectionType == ActivityCollectionType.ACTIVITY_LOBBY)
			{
				m_activityRedPointList.Add(new ModuleStatus
				{
					key = activity.activityId,
					value = (int)LocalResources.ActivityLobbyInfos.Get(activity.activityId).Type
				});
				flag = true;
			}
		}
		UpdateRedPointState();
		if (flag)
		{
			Show();
		}
		else
		{
			Hide();
		}
	}
}
