using LightUtility;
using System;
using UnityEngine;

public class AlienScreenAdapter : MonoBehaviour
{
	[Serializable]
	public enum AlienWidthAnchor
	{
		DontAdaptWidth,
		Left,
		Middle,
		Right,
		OffsetY,
		OffsetX
	}

	public static bool EnableAlien;

	public static int MaxAlienHeight = 140;

	public static int DefaultAlienHeight = 90;

	private const int AlienNativeHeight = 90;

	[Tooltip("改变宽度的方向")]
	public AlienWidthAnchor m_AlienWidthAnchor;

	[Tooltip("正表示右移或者宽度增大，负表示左移或者宽度减小")]
	public int m_AlienOffset = 90;

	public bool m_EveryFrame;

	private int m_CurAlienHeight;

	private Vector2 defaultOffsetMin;

	private Vector2 defaultOffsetMax;

	private Vector2 defaultAnchoredPosition;

	private Vector2 defaultSizeDelta;

	private int AlienOffset => (int)((float)(m_AlienOffset * AlienHeight) * 1f / 90f);

	private int AlienHeight
	{
		get
		{
			if (!(GameSettings.Inst == null) && m_AlienWidthAnchor != AlienWidthAnchor.OffsetY)
			{
				return GameSettings.Inst.AlienValue;
			}
			return 90;
		}
	}

	public static void Initialize(int alienScreenLenth)
	{
		UnityEngine.Debug.Log("AlienScreenAdapter Initialize :" + alienScreenLenth);
		DefaultAlienHeight = alienScreenLenth;
		EnableAlien = (ScreenResolution.Aspect >= 2f);
	}

	public void Awake()
	{
		if (EnableAlien)
		{
			RectTransform component = GetComponent<RectTransform>();
			defaultOffsetMin = component.offsetMin;
			defaultOffsetMax = component.offsetMax;
			defaultAnchoredPosition = component.anchoredPosition;
			defaultSizeDelta = component.sizeDelta;
		}
	}

	private void OnEnable()
	{
		Refresh(-1f);
		m_CurAlienHeight = AlienHeight;
	}

	private void OnDisable()
	{
		if (EnableAlien)
		{
			RectTransform component = GetComponent<RectTransform>();
			component.anchoredPosition = defaultAnchoredPosition;
			component.offsetMax = defaultOffsetMax;
			component.offsetMin = defaultOffsetMin;
			component.sizeDelta = defaultSizeDelta;
		}
	}

	private void Refresh(float forceHeight)
	{
		if (EnableAlien)
		{
			RectTransform component = GetComponent<RectTransform>();
			OnDisable();
			int num = (!(forceHeight >= 0f)) ? AlienOffset : ((int)((float)m_AlienOffset * forceHeight / 90f));
			if (m_AlienWidthAnchor == AlienWidthAnchor.Left)
			{
				Vector2 offsetMin = defaultOffsetMin;
				offsetMin.x -= num;
				component.offsetMin = offsetMin;
			}
			else if (m_AlienWidthAnchor == AlienWidthAnchor.Right)
			{
				Vector2 offsetMax = defaultOffsetMax;
				offsetMax.x += num;
				component.offsetMax = offsetMax;
			}
			else if (m_AlienWidthAnchor == AlienWidthAnchor.Middle)
			{
				Vector2 sizeDelta = defaultSizeDelta;
				sizeDelta.x += num;
				component.sizeDelta = sizeDelta;
			}
			else if (m_AlienWidthAnchor == AlienWidthAnchor.OffsetY)
			{
				Vector2 vector = defaultAnchoredPosition;
				vector.y += (float)num;
				component.anchoredPosition = vector;
			}
			else if (m_AlienWidthAnchor == AlienWidthAnchor.OffsetX)
			{
				Vector2 vector2 = defaultAnchoredPosition;
				vector2.x += (float)num;
				component.anchoredPosition = vector2;
			}
			else
			{
				Vector2 vector3 = defaultAnchoredPosition;
				vector3.x += (float)num;
				component.anchoredPosition = vector3;
			}
		}
	}

	private void Update()
	{
		if (m_EveryFrame || m_CurAlienHeight != AlienHeight)
		{
			Refresh(-1f);
			m_CurAlienHeight = AlienHeight;
		}
	}

	public void ForceRefresh(float forceHeight)
	{
		Refresh(forceHeight);
	}
}
