using LightUtility;
using UnityEngine;

public class AdrenalineObject : FloatingObject
{
	public int m_BuffID;

	public float m_LifeAmount = 10f;

	protected override void CheckDevourd()
	{
		if (!m_Devoured && PhotonNetwork.isMasterClient)
		{
			Vector3 position = m_Root.transform.position;
			float r = m_ExposionRadius * m_ExposionRadius;
			int numID = UserId2NumId.Get(base.UserId);
			PlayerController playerController = PlayerController.FindPlayer(base.UserId);
			foreach (PlayerController allPlayer in PlayerController.AllPlayers)
			{
				if (playerController.InSameTeam(allPlayer) && TryDevouredBy(allPlayer, position, r, numID))
				{
					return;
				}
			}
			foreach (DogObject allDogObject in DogObject.AllDogObjects)
			{
				if (playerController.InSameTeam(allDogObject.PlayerController) && TryDevouredBy(allDogObject, position, r, numID))
				{
					return;
				}
			}
			foreach (PlayerController allPlayer2 in PlayerController.AllPlayers)
			{
				if (!playerController.InSameTeam(allPlayer2) && TryDevouredBy(allPlayer2, position, r, numID))
				{
					return;
				}
			}
			foreach (DogObject allDogObject2 in DogObject.AllDogObjects)
			{
				if (!playerController.InSameTeam(allDogObject2.PlayerController) && TryDevouredBy(allDogObject2, position, r, numID))
				{
					break;
				}
			}
		}
	}

	private bool TryDevouredBy(PlayerController player, Vector3 pos, float r2, int numID)
	{
		if (!player.FinalDeadOrEscaped)
		{
			Vector3 vector = pos - player.transform.position;
			if (vector.FlattenY().sqrMagnitude < r2 && -0.8f < vector.y && vector.y < 1.2f)
			{
				player.RpcApplyDamage(0f - m_LifeAmount, numID, DamageSourceType.Adrenaline, m_BuffID);
				m_PhotonView.RPC("MarkAsDevoured", PhotonTargets.All, player.m_PhotonView.viewID);
				return true;
			}
		}
		return false;
	}

	private bool TryDevouredBy(DogObject dog, Vector3 pos, float r2, int numID)
	{
		if (!dog.IsDead)
		{
			Vector3 vector = pos - dog.transform.position;
			if (vector.FlattenY().sqrMagnitude < r2 && -0.8f < vector.y && vector.y < 1.2f)
			{
				dog.RpcApplyDamage(0f - m_LifeAmount, numID, DamageSourceType.Adrenaline, m_BuffID);
				m_PhotonView.RPC("MarkAsDevoured", PhotonTargets.All, dog.PhotonView.viewID);
				return true;
			}
		}
		return false;
	}

	[PunRPC]
	private void MarkAsDevoured(int photonViewID)
	{
		MarkDevoured(photonViewID);
	}
}
