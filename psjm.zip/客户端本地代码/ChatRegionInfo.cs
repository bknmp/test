using LightUtility;

public class ChatRegionInfo : IdBased
{
	public string Name;
}
