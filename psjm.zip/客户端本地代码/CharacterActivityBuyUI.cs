using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterActivityBuyUI
{
	public UIDataBinder m_Host;

	public Text m_CharaterCost;

	public Text m_CharaterPrice;

	public Text m_BagCost;

	public Text m_BagPrice;

	public Text m_LeftText;

	public Text m_RightText;

	public Button m_BuyCharacter;

	public Button m_BuyBag;

	public UIPage m_CharacterGiftBagPreviewUI;

	public UIStateItem m_CharacterStateItem;

	public UIStateItem m_PackageStateItem;

	public UIStateImage m_CharacterPriceID;

	public UIStateImage m_PackagePriceID;

	public RawImage m_CharacterPreview;

	public RawImage m_CollectionPreview;

	public Button m_PreviewBtn;

	public Button m_CloseButton;

	public static bool m_BuyCharacterBag;

	private DropItem m_CharacterItem;

	private string m_BagNameFormat;

	private int m_CharacterID;

	private int m_SuitItemID;

	private int m_CollectionID;

	private int m_PackageID;

	private int m_ActivityID;

	private int m_PriceID;

	private CommonDataCollection m_args;

	private CharacterActivityGoodsInfo m_CharacterActivityInfo => CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo;

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		if ((int)m_args["type"] == 1)
		{
			m_CharacterID = args["characterID"];
			m_SuitItemID = args["suitItemId"];
			SetInfo();
			m_CharacterStateItem.State = 0;
			m_CharacterPriceID.State = 1;
			m_PackageStateItem.State = 1;
			m_Host.EventProxy(m_BuyCharacter, "BuyActivityCharacter");
		}
		else
		{
			m_ActivityID = m_args["activityID"];
			m_CharacterID = args["characterID"];
			m_SuitItemID = args["suitItemId"];
			m_CollectionID = args["collectionID"];
			m_PackageID = args["packageID"];
			m_PriceID = args["priceID"];
			SetDiscountInfo();
			CurrencyHandle();
			m_Host.EventProxy(m_BuyCharacter, "BuyCharacter");
		}
		m_Host.EventProxy(m_CloseButton, "UpdateStoreUI");
	}

	private void SetInfo()
	{
		m_Host.EventProxy(m_BuyBag, "JumpToBagPage");
		m_CollectionPreview.texture = ResManager.Load<Texture>($"PackageImage_{m_SuitItemID}");
		m_CharacterPreview.texture = ResManager.Load<Texture>($"CharacterImage_{m_CharacterID}");
		m_CharaterCost.text = m_CharacterActivityInfo.characterCost.ToString();
		m_CharaterPrice.text = m_CharacterActivityInfo.characterPrice.ToString();
		m_BagPrice.text = m_CharacterActivityInfo.bagPrice / 10 + Localization.RMB;
		m_BagCost.text = m_CharacterActivityInfo.bagCost / 10 + Localization.RMB;
		m_CharacterItem = LocalResources.DropItemTable.Get(m_CharacterID);
		string name = LocalResources.DropItemTable.Get(m_SuitItemID).Name;
		if (m_BagNameFormat == null)
		{
			m_BagNameFormat = m_RightText.text;
		}
		m_LeftText.text = m_CharacterItem.Name;
		m_RightText.text = string.Format(m_BagNameFormat, m_CharacterItem.Name, name);
		m_PreviewBtn.gameObject.SetActive(value: false);
	}

	private void SetDiscountInfo()
	{
		m_CollectionPreview.texture = ResManager.Load<Texture>($"PackageImage_{m_SuitItemID}");
		m_CharacterPreview.texture = ResManager.Load<Texture>($"CharacterImage_{m_CharacterID}");
		m_CharacterItem = LocalResources.DropItemTable.Get(m_CharacterID);
		m_LeftText.text = CharacterDiscountUtility.GetCharacterOnlyPackageName(m_ActivityID, m_CollectionID);
		m_RightText.text = CharacterDiscountUtility.GetCharacterAndSuitPackageName(m_ActivityID, m_CollectionID);
		m_CharaterCost.text = CharacterDiscountUtility.GetCharacterOnlyPackageCurrentPrice(m_ActivityID, m_CharacterID).ToString();
		m_CharaterPrice.text = CharacterDiscountUtility.GetCharacterOnlyPackageOriginalPrice(m_ActivityID, m_CharacterID).ToString();
		if (CharacterDiscountUtility.IsOwnItem(m_CharacterID))
		{
			m_BagPrice.text = CharacterDiscountUtility.GetSuitOnlyPackageOriginalPrice(m_ActivityID, m_CollectionID).ToString();
			m_BagCost.text = CharacterDiscountUtility.GetSuitOnlyPackageCurrentPrice(m_ActivityID, m_CollectionID).ToString();
		}
		else
		{
			m_BagPrice.text = CharacterDiscountUtility.GetCharacterAndSuitOriginalPrice(m_ActivityID, m_CollectionID).ToString();
			m_BagCost.text = CharacterDiscountUtility.GetCharacterAndSuitCurrentPrice(m_ActivityID, m_CollectionID).ToString();
		}
		m_Host.EventProxy(m_BuyCharacter, "BuyCharacter");
		m_Host.EventProxy(m_BuyBag, "BuyCollection");
		m_Host.EventProxy(m_PreviewBtn, "JumpToBagPage");
	}

	private void CurrencyHandle()
	{
		m_CharacterStateItem.State = 0;
		m_PackageStateItem.State = ((m_PriceID == 99) ? 1 : 0);
		switch (CharacterDiscountUtility.GetCharacterPriceID(m_ActivityID, m_CollectionID))
		{
		case 2:
			m_CharacterPriceID.State = 2;
			break;
		case 4:
			m_CharacterPriceID.State = 1;
			break;
		}
		switch (m_PriceID)
		{
		case 2:
			m_PackagePriceID.State = 2;
			break;
		case 4:
			m_PackagePriceID.State = 1;
			break;
		}
	}

	public void BuyActivityCharacter()
	{
		Activity activity = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.CHARACTER_PREVIEW, ActivityCollectionType.CHARACTER_ACTIVITY);
		if (activity == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityOver);
			m_Host.GetComponent<UIPopup>().GoBack();
		}
		else
		{
			ShopUtility.CheckMoneyEnough(CurrencyType.Tickets, m_CharacterActivityInfo.characterCost, delegate
			{
				HttpRequestBuyActivityCharacter requset = new HttpRequestBuyActivityCharacter
				{
					activityId = activity.activityId
				};
				GameHttpManager.Inst.Send(requset, delegate
				{
					m_Host.GetComponent<UIPopup>().GoBack();
					CharacterFeatureUI.Inst.TryShowNewCharacter(m_CharacterItem.TypeParam);
				});
			}, m_CharacterActivityInfo.characterId, currentUIGoBack: false);
		}
	}

	public void BuyCharacter()
	{
		CharacterDiscountUtility.TryBuyCharacter(m_ActivityID, m_CharacterID, null);
	}

	public void BuyCollection()
	{
		if (CharacterDiscountUtility.IsOwnItem(m_CharacterID))
		{
			CharacterDiscountUtility.TryBuy(m_ActivityID, CharacterDiscountUtility.GetSuitOnlyPackageID(m_ActivityID, m_CollectionID), null);
		}
		else
		{
			CharacterDiscountUtility.TryBuy(m_ActivityID, m_PackageID, null);
		}
	}

	public void JumpToBagPage()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["index"] = 1;
		commonDataCollection["type"] = 1;
		commonDataCollection["characterID"] = m_CharacterID;
		commonDataCollection["suitItemId"] = m_SuitItemID;
		commonDataCollection["discountPrice"] = CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.bagCost / 10;
		commonDataCollection["orgPrice"] = CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.bagPrice / 10;
		commonDataCollection["priceID"] = 99;
		UILobby.Current.ShowUI(m_CharacterGiftBagPreviewUI, commonDataCollection);
	}

	public void UpdateStoreUI()
	{
		UIDataEvents.Inst.InvokeEvent("OnSelectSkinPartChanged");
		UIDataEvents.Inst.InvokeEvent("OnCharacterSelectedChange");
		m_Host.GetComponent<UIPopup>().GoBack();
	}
}
