using UnityEngine;

public class CardPreviewConfig : MonoBehaviour
{
	public bool m_ShowNewCard;
}
