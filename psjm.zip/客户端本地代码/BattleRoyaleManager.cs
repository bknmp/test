using LightUtility;
using SimpleJson;
using System;
using System.Collections.Generic;
using TiledMapBuilder;
using UnityEngine;

public class BattleRoyaleManager : MonoBehaviour
{
	[Serializable]
	public class PropcardLimit
	{
		public int cardId;

		public int limit;
	}

	public static BattleRoyaleManager Inst;

	public TiledMap m_Map;

	public List<PropcardLimit> m_CardLimits;

	public int m_MagazineLimit = 10;

	public DeadStageConfig[] m_DeadStageConfig;

	private static int[] m_PropcardSlots;

	private PhotonView m_PhotonView;

	private void Awake()
	{
		Inst = this;
		m_PropcardSlots = new int[m_Map.Width * m_Map.Height];
		m_PhotonView = GetComponent<PhotonView>();
		if (GameRuntime.IsMapBattleRoyale)
		{
			InvokeRepeating("CheckGameOver", GameRuntime.ResumeGame ? 0.5f : 10f, 0.1f);
		}
	}

	public void PlaceProcardInMap(Vector3 orgPos, int cardId, int num, bool snapToMesh = false)
	{
		m_PhotonView.RPC("PlaceProcard", PhotonTargets.MasterClient, orgPos, cardId, num, snapToMesh);
	}

	[PunRPC]
	private void PlaceProcard(Vector3 pos, int cardId, int num, bool snapToMesh)
	{
		Vector3 a = snapToMesh ? Inst.GetPropSpawnPos(pos).FlattenY() : pos.FlattenY();
		a += new Vector3(0f, 0.35f, 0f);
		PhotonNetwork.InstantiateSceneObject(LocalResources.InGameStoreTable.Find(cardId).Model, pos, Quaternion.Euler(46f, -160f, 4f), 0, new object[4]
		{
			cardId,
			num,
			pos,
			a
		});
	}

	public void PlaceProcardArrayInMap(Vector3 orgPos, int[] cardIds, int[] nums, bool snapToMesh = false)
	{
		m_PhotonView.RPC("PlaceProcardArray", PhotonTargets.MasterClient, orgPos, cardIds, nums, snapToMesh);
	}

	[PunRPC]
	private void PlaceProcardArray(Vector3 pos, int[] cardIds, int[] nums, bool snapToMesh)
	{
		int num = cardIds.Length;
		if (cardIds.Length != nums.Length)
		{
			UnityEngine.Debug.LogError("array szie is mismatching ! " + cardIds.Length + " " + nums.Length);
			num = Mathf.Min(cardIds.Length, nums.Length);
		}
		for (int i = 0; i < num; i++)
		{
			PlaceProcard(pos, cardIds[i], nums[i], snapToMesh);
		}
	}

	private void OnDestroy()
	{
		PropcardsSpawner.hasSpawnedObjs.Clear();
		SupplementBoxSpawner_BR.hasSpawnedObjs.Clear();
		Inst = null;
	}

	public void RemovePropInSlot(Vector3 pos)
	{
		m_Map.WorldPositionToIndices(pos, out int x, out int y);
		if (InMap(x, y))
		{
			m_PropcardSlots[GetIndex(x, y)] = 0;
		}
	}

	public Vector3 GetPropSpawnPos(Vector3 requirePos)
	{
		if (m_Map == null)
		{
			UnityEngine.Debug.LogError("地图没准备好");
			return requirePos;
		}
		int num = 1;
		m_Map.WorldPositionToIndices(requirePos, out int x, out int y);
		int findSlotX;
		int findSlotY;
		while (!GetUsableSlot(x, y, num, out findSlotX, out findSlotY))
		{
			num += 2;
			x--;
			y--;
			if (num > 10)
			{
				UnityEngine.Debug.LogError("没有合适的卡位放道具");
				return requirePos;
			}
		}
		m_PropcardSlots[GetIndex(findSlotX, findSlotY)] = 1;
		return m_Map.IndicesToWorldPosition(findSlotX, findSlotY);
	}

	private bool GetUsableSlot(int leftBottomX, int leftBottomY, int size, out int findSlotX, out int findSlotY)
	{
		int i;
		for (i = leftBottomY; i < leftBottomY + size; i++)
		{
			if (InMap(leftBottomX, i) && m_PropcardSlots[GetIndex(leftBottomX, i)] != 1 && !IsCollidable(leftBottomX, i))
			{
				findSlotX = leftBottomX;
				findSlotY = i;
				return true;
			}
		}
		i = leftBottomY + size - 1;
		int j;
		for (j = leftBottomX; j < leftBottomX + size; j++)
		{
			if (InMap(j, i) && m_PropcardSlots[GetIndex(j, i)] != 1 && !IsCollidable(j, i))
			{
				findSlotX = j;
				findSlotY = i;
				return true;
			}
		}
		j = leftBottomX + size - 1;
		for (i = leftBottomY + size - 1; i >= leftBottomY; i--)
		{
			if (InMap(j, i) && m_PropcardSlots[GetIndex(j, i)] != 1 && !IsCollidable(j, i))
			{
				findSlotX = j;
				findSlotY = i;
				return true;
			}
		}
		for (j = leftBottomX + size - 1; j >= leftBottomX; j--)
		{
			if (InMap(j, leftBottomY) && m_PropcardSlots[GetIndex(j, leftBottomY)] != 1 && !IsCollidable(j, leftBottomY))
			{
				findSlotX = j;
				findSlotY = leftBottomY;
				return true;
			}
		}
		findSlotX = leftBottomX;
		findSlotY = leftBottomY;
		return false;
	}

	private bool IsCollidable(int x, int y)
	{
		Vector3 pos = m_Map.IndicesToWorldPosition(x, y);
		if (!InGameScene.Inst.IsCollidable(pos))
		{
			return false;
		}
		TiledMap.RuntimeElementInstance runtimeTileInstance = m_Map.GetRuntimeTileInstance(pos);
		if (runtimeTileInstance.inst != null && runtimeTileInstance.GetComponent<Collider>() != null)
		{
			return runtimeTileInstance.GetComponent<Collider>().enabled;
		}
		return true;
	}

	private bool InMap(int x, int y)
	{
		if (x >= 0 && x < m_Map.Width && y >= 0 && y < m_Map.Height)
		{
			return true;
		}
		return false;
	}

	private int GetIndex(int x, int y)
	{
		return x + y * m_Map.Width;
	}

	public static void SyncProcardManagerData()
	{
		if (PhotonNetwork.isMasterClient)
		{
			m_PropcardSlots = SimpleJson.SimpleJson.DeserializeObject<int[]>(PhotonNetwork.room.CustomProperties["PropcardManager"] as string);
		}
	}

	public int GetCardLimit(int cardId, int defLimit = 10)
	{
		foreach (PropcardLimit cardLimit in m_CardLimits)
		{
			if (cardLimit.cardId == cardId)
			{
				return cardLimit.limit;
			}
		}
		if (LocalResources.InGameStoreTable.Get(cardId).Type == InGameStoreType.Magazine)
		{
			return m_MagazineLimit;
		}
		return defLimit;
	}

	private void CheckGameOver()
	{
		if (GameRuntime.IsNormalGameOver || PlayerController.Inst == null || GameRuntime.WitnessMode)
		{
			return;
		}
		if (GameRuntime.MapType == MapType.TypeBattleRoyale)
		{
			if (PlayerController.Inst.FinalDead)
			{
				InGameScene.Inst.InvokeGameOver();
			}
			if (!IsInvoking("DoBattleRoyaleOver") && CheckBattleRoyaleOver())
			{
				Invoke("DoBattleRoyaleOver", 1f);
			}
		}
		else
		{
			if (PlayerController.Inst.FinalDead)
			{
				InGameScene.Inst.InvokeGameOver();
			}
			if (!IsInvoking("DoBattleRoyaleTeamOver") && CheckBattleRoyaleTeamOver())
			{
				Invoke("DoBattleRoyaleTeamOver", 0f);
			}
		}
	}

	private bool CheckBattleRoyaleOver()
	{
		if (GameRuntime.RemainedThiefCount <= 1 && PlayerController.AllPlayers.Count > 1)
		{
			return true;
		}
		return false;
	}

	private void DoBattleRoyaleOver()
	{
		if (CheckBattleRoyaleOver())
		{
			InGameScene.Inst.InvokeGameOver();
		}
	}

	private bool CheckBattleRoyaleTeamOver()
	{
		if (BattleRoyaleUtility.RemainedGroupCount <= 1 && BattleRoyaleUtility.GroupCount > 1)
		{
			return true;
		}
		return false;
	}

	private void DoBattleRoyaleTeamOver()
	{
		if (CheckBattleRoyaleTeamOver())
		{
			InGameScene.Inst.InvokeGameOver();
		}
	}

	public int GetPersonalCurrentRank()
	{
		int num = 1;
		if ((GameRuntime.MapType == MapType.TypeBattleRoyale && !PlayerController.Inst.IsDying) || (GameRuntime.MapType == MapType.TypeBattleRoyaleTeam && BattleRoyaleUtility.RemainedGroupCount <= 1 && BattleRoyaleUtility.GetRemainedPlayerCount(BattleRoyaleUtility.MyGroupID) >= 1))
		{
			return 1;
		}
		float finalDeadTime = ((ThiefController)PlayerController.Inst).FinalDeadTime;
		if (GameRuntime.MapType == MapType.TypeBattleRoyale)
		{
			foreach (PlayerController allPlayer in PlayerController.AllPlayers)
			{
				if (!allPlayer.FinalDead || ((ThiefController)allPlayer).FinalDeadTime > finalDeadTime)
				{
					num++;
				}
			}
			return num;
		}
		foreach (PlayerController allPlayer2 in PlayerController.AllPlayers)
		{
			if (!(allPlayer2 == PlayerController.Inst) && ((!allPlayer2.FinalDead && BattleRoyaleUtility.GetRemainedPlayerCount(IngameGroupUtility.GetGroupID(allPlayer2.UserId)) > 0) || ((ThiefController)allPlayer2).FinalDeadTime > finalDeadTime))
			{
				num++;
			}
		}
		return num;
	}

	public int GetTeamCurrentRank()
	{
		int num = 1;
		int remainedGroupCount = BattleRoyaleUtility.RemainedGroupCount;
		bool flag = BattleRoyaleUtility.GetRemainedPlayerCount(BattleRoyaleUtility.MyGroupID) > 0;
		if (remainedGroupCount <= 1 && flag)
		{
			return 1;
		}
		return Mathf.Min(BattleRoyaleUtility.GroupCount, remainedGroupCount + ((!flag) ? 1 : 0));
	}
}
