using GameMessages;
using LightUtility;
using UnityEngine;

public class CardLotteryItem : MonoBehaviour
{
	public Animator m_Animator;

	public GameObject m_IdleEffect;

	public GameObject m_OpenEffect;

	public GameObject m_OpenAgainEffect;

	public GameObject m_ExplosionEffectPrefab;

	public AudioItem m_AudioItem;

	public CardLotteryType m_CardLotteryType;

	public CardLotteryType Type => m_CardLotteryType;

	private void Awake()
	{
		SetState(0);
	}

	public void PlayOpenAnimation()
	{
		m_Animator.SetTrigger("open");
		SetState(1);
		SoundManager.PlayOnce(m_AudioItem);
	}

	public void PlayAgainAnimation()
	{
		m_Animator.SetTrigger("openAgain");
		SetState(2);
		SoundManager.PlayOnce(m_AudioItem);
	}

	private void SetState(int state)
	{
		m_IdleEffect.SetActive(state == 0);
		m_OpenEffect.SetActive(state == 1);
		m_OpenAgainEffect.SetActive(state == 2);
		EnableIdleTween(state == 0);
		EnableMoveAnimation(state == 1);
	}

	public void ResetToStart()
	{
		GameObject gameObject = PrefabSource.Inst.Load(base.name);
		base.transform.localPosition = gameObject.transform.position;
		base.transform.localRotation = gameObject.transform.localRotation;
		base.transform.localScale = gameObject.transform.localScale;
		SetState(0);
		base.gameObject.SetActive(value: false);
		base.gameObject.SetActive(value: true);
	}

	private void EnableMoveAnimation(bool enable = true)
	{
		GetComponent<Animator>().enabled = enable;
	}

	private void EnableIdleTween(bool enable = true)
	{
		TweenPosition component = GetComponent<TweenPosition>();
		if (component != null)
		{
			component.enabled = enable;
		}
		TweenRotation component2 = GetComponent<TweenRotation>();
		if (component2 != null)
		{
			component2.enabled = enable;
		}
	}

	public void PlayExplosionEffect()
	{
		if (m_ExplosionEffectPrefab != null)
		{
			PoolSpawner.Spawn(m_ExplosionEffectPrefab, base.transform.parent.parent);
		}
	}
}
