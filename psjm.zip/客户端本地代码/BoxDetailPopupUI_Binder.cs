using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class BoxDetailPopupUI_Binder
{
	public UIDataBinder m_Host;

	public Text m_Description;

	public UITemplateInitiator m_Initiator;

	public Text m_TitleText;

	private string m_TitleFormat;

	public void Bind(CommonDataCollection args)
	{
		int id = args["activityId"];
		ItemInfo[] obj = (ItemInfo[])args["itemInfos"].val;
		int num = args["curCount"];
		int num2 = args["needCount"];
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		ItemInfo[] array = obj;
		foreach (ItemInfo val in array)
		{
			commonDataCollection[commonDataCollection.ArraySize]["dropItemInfo"].val = val;
		}
		m_Initiator.Args = commonDataCollection;
		ActivityType type = LocalResources.ActivityLobbyInfos.Get(id).Type;
		string arg = (type != ActivityType.LIMITLOTTERY_ACTIVITY) ? Localization.Wish : Localization.Pray;
		if (m_TitleFormat == null)
		{
			m_TitleFormat = m_TitleText.text;
		}
		m_TitleText.text = string.Format(m_TitleFormat, arg);
		m_Description.text = string.Format(Localization.CharacterLotteryFormat, arg, num, num2);
	}

	public static CommonDataCollection ArgsWraper(int activityId, int curCount, int needCount, ItemInfo[] itemInfos)
	{
		return new CommonDataCollection
		{
			["activityId"] = activityId,
			["curCount"] = curCount,
			["needCount"] = needCount,
			["itemInfos"] = 
			{
				val = itemInfos
			}
		};
	}
}
