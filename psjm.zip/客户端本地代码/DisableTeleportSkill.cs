using BehaviorDesigner.Runtime.Tasks;

[TaskName("隐藏页面上的传送技能")]
[TaskCategory("考驾照功能")]
public class DisableTeleportSkill : Action
{
	public override TaskStatus OnUpdate()
	{
		InGameSkillUI.Inst.DisableTeleport = true;
		return TaskStatus.Success;
	}
}
