using DG.Tweening;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class CoinDrawingManager : MonoBehaviour
{
	public class CoinInst
	{
		public Material material;

		public Vector3 position;

		public float size = 1f;

		public float scaleFactor = 1f;

		private float scale = 1f;

		public Matrix4x4 TRS => Matrix4x4.TRS(position, Quaternion.identity, size * scale * scaleFactor * Vector3.one);

		public Tweener DOBlendableMoveBy(Vector3 byValue, float duration)
		{
			Vector3 to = Vector3.zero;
			return DOTween.To(() => to, delegate(Vector3 x)
			{
				Vector3 b = x - to;
				to = x;
				position += b;
			}, byValue, duration);
		}

		public Tweener DOMove(Vector3 endValue, float duration)
		{
			return DOTween.To(() => position, delegate(Vector3 x)
			{
				position = x;
			}, endValue, duration);
		}

		public Tweener DOScale(float endValue, float duration)
		{
			return DOTween.To(() => scale, delegate(float x)
			{
				scale = x;
			}, endValue, duration);
		}
	}

	private class MatrixArray
	{
		public Matrix4x4[] matrix = new Matrix4x4[100];

		public int count;
	}

	private List<CoinInst> m_ActiveCoins = new List<CoinInst>();

	private List<Material> m_MaterialList = new List<Material>();

	private Dictionary<Material, MatrixArray> m_InstancingMatrix = new Dictionary<Material, MatrixArray>();

	private Dictionary<Material, Queue<CoinInst>> m_PoolCoins = new Dictionary<Material, Queue<CoinInst>>();

	private CommandBuffer m_CommandBuffer;

	private Mesh m_Quad;

	private Camera m_Camera;

	private float m_ScaleFactor;

	private static CoinDrawingManager _inst;

	public static CoinDrawingManager Inst
	{
		get
		{
			if (_inst == null)
			{
				_inst = new GameObject("CoinDrawingManager").AddComponent<CoinDrawingManager>();
			}
			return _inst;
		}
	}

	public void Initialize(Camera bindCamera)
	{
		m_CommandBuffer = new CommandBuffer();
		m_CommandBuffer.name = "CoinDrawingManager";
		m_Quad = Resources.GetBuiltinResource<Mesh>("Quad.fbx");
		m_Camera = bindCamera;
		m_Camera.AddCommandBuffer(CameraEvent.AfterForwardAlpha, m_CommandBuffer);
		m_ScaleFactor = (float)Screen.width / (1.7778f * (float)Screen.height);
	}

	private void OnDestroy()
	{
		if (_inst == this)
		{
			_inst = null;
		}
		if (m_Camera != null)
		{
			m_Camera.RemoveCommandBuffer(CameraEvent.AfterForwardAlpha, m_CommandBuffer);
		}
		m_CommandBuffer?.Dispose();
	}

	public CoinInst AcquireCoinInst(Material material)
	{
		if (!m_PoolCoins.TryGetValue(material, out Queue<CoinInst> value))
		{
			value = new Queue<CoinInst>();
			m_PoolCoins.Add(material, value);
			m_MaterialList.Add(material);
		}
		CoinInst coinInst = null;
		if (value.Count > 0)
		{
			coinInst = value.Dequeue();
		}
		else
		{
			coinInst = new CoinInst();
			coinInst.material = material;
			coinInst.scaleFactor = m_ScaleFactor;
		}
		m_ActiveCoins.Add(coinInst);
		return coinInst;
	}

	public void ReleaseCoinInst(CoinInst inst)
	{
		if (m_PoolCoins.TryGetValue(inst.material, out Queue<CoinInst> value))
		{
			value.Enqueue(inst);
		}
		m_ActiveCoins.Remove(inst);
	}

	private void Update()
	{
		if (m_Quad == null)
		{
			return;
		}
		m_CommandBuffer.Clear();
		int count = m_ActiveCoins.Count;
		if (SystemInfo.supportsInstancing)
		{
			foreach (Material material in m_MaterialList)
			{
				if (m_InstancingMatrix.TryGetValue(material, out MatrixArray value))
				{
					value.count = 0;
				}
			}
			for (int i = 0; i < count; i++)
			{
				CoinInst coinInst = m_ActiveCoins[i];
				if (!m_InstancingMatrix.TryGetValue(coinInst.material, out MatrixArray value2))
				{
					value2 = new MatrixArray();
					m_InstancingMatrix.Add(coinInst.material, value2);
				}
				if (value2.count < value2.matrix.Length)
				{
					value2.matrix[value2.count] = coinInst.TRS;
					value2.count++;
				}
			}
			foreach (Material material2 in m_MaterialList)
			{
				if (m_InstancingMatrix.TryGetValue(material2, out MatrixArray value3))
				{
					m_CommandBuffer.DrawMeshInstanced(m_Quad, 0, material2, 0, value3.matrix, value3.count);
				}
			}
		}
		else
		{
			for (int j = 0; j < count; j++)
			{
				CoinInst coinInst2 = m_ActiveCoins[j];
				m_CommandBuffer.DrawMesh(m_Quad, coinInst2.TRS, coinInst2.material);
			}
		}
	}
}
