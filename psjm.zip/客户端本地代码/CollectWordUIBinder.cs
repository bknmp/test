using GameMessages;
using LightUI;

internal class CollectWordUIBinder : CommonExchangeUI
{
	public ActivityLobbyPage m_ActivityPage;

	public new void Bind(CommonDataCollection args)
	{
		base.Bind(args);
		Activity activityById = ActivityLobby.GetActivityById(m_activityId);
		m_ActivityPage.SetTime(activityById);
	}

	protected new void OnDisable()
	{
		base.OnDisable();
	}
}
