using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CardSkinUIBinder
{
	public static DropItem DefaultSelectCardItem;

	public UIDataBinder m_Host;

	public UIDataScrollView m_CardScrollView;

	public RawImage m_Preview;

	public UIPointerBehaviour m_Input;

	public GameObject m_BuyPanel;

	public InfoPanelController m_RolePanel;

	private List<DropItem> m_DropItemList = new List<DropItem>();

	private bool m_Init;

	private UIDataBinder m_ButtonPanel;

	public void Bind(CommonDataCollection args)
	{
		if (!m_Init)
		{
			m_Init = true;
			UIDataEvents.Inst.AddEventListener("OnSelectCardSkinItemChanged", m_Host, SetSelectInfo);
			UIDataEvents.Inst.AddEventListener("OnPlayerInfoChanged", m_Host, SetSelectInfo);
		}
		SetCardSkinList();
		SetScrollview();
		Preview();
	}

	private void SetScrollview()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int num = 0;
		foreach (DropItem dropInfo in m_DropItemList)
		{
			ShopInfo shopInfo = LocalResources.ShopTable.Find((ShopInfo x) => x.DropItemID == dropInfo.Id);
			foreach (KeyValuePair<int, List<ShopInfo>> item in ShopUtility.StoreCardSkinDict)
			{
				bool flag = false;
				foreach (ShopInfo item2 in item.Value)
				{
					if (item2.Id == shopInfo.Id)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					commonDataCollection[num]["DropInfo"].val = dropInfo;
					commonDataCollection[num]["ShopInfo"].val = shopInfo;
					commonDataCollection[num]["Index"] = num;
					commonDataCollection[num]["Page"].val = this;
					if (num == 0)
					{
						DefaultSelectCardItem = dropInfo;
					}
					num++;
				}
			}
		}
		m_CardScrollView.SetItems(commonDataCollection.Array);
	}

	private void SetCardSkinList()
	{
		m_DropItemList.Clear();
		foreach (KeyValuePair<int, List<ShopInfo>> item2 in ShopUtility.StoreCardSkinDict)
		{
			if (!ShopUtility.ShopInfoCannotSell(item2.Value[0]))
			{
				DropItem item = LocalResources.DropItemTable.Get(item2.Value[0].DropItemID);
				m_DropItemList.Add(item);
			}
		}
		m_DropItemList.Sort((DropItem x, DropItem y) => ShopUtility.CompareShopInfo(x.Id, y.Id));
	}

	public void Preview()
	{
		CardSkinInfo cardSkinInfo = (StoreCardSkinUI_ItemTemplate.Selected != null) ? LocalResources.CardSkinTable.Get(StoreCardSkinUI_ItemTemplate.Selected.DropInfo.TypeParam) : LocalResources.CardSkinTable.Get(DefaultSelectCardItem.TypeParam);
		if (ResourceSource.Load(cardSkinInfo.Prefabs + "_Lobby") != null)
		{
			LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, cardSkinInfo.Prefabs + "_Lobby", m_Preview, m_Input);
		}
		m_Preview.gameObject.SetActive(value: true);
	}

	private double CalcWeight(DropItem card)
	{
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(card.TypeParam);
		return (double)(((LocalResources.ShopTable.Find((ShopInfo y) => y.DropItemID == card.Id).GainType == ShopGainType.Buy) ? 1000 : 0) * 1000 + card.Quality * 10) + (double)cardSkinInfo.Rank * 0.001;
	}

	private void SetSelectInfo()
	{
		if (m_Host.gameObject.activeInHierarchy)
		{
			CommonDataCollection buttonInfo;
			int itemPanel;
			if (StoreCardSkinUI_ItemTemplate.Selected != null)
			{
				List<int> list = (from x in ShopUtility.StoreCardSkinDict[StoreCardSkinUI_ItemTemplate.Selected.DropInfo.TypeParam]
					select x.Id).ToList();
				buttonInfo = StoreUI_BuyButton.WrapperData(StoreCardSkinUI_ItemTemplate.Selected.m_PermanentTips.gameObject.activeSelf, list, StoreCardSkinUI_ItemTemplate.Selected.ShopInfo.GainType, StoreCardSkinUI_ItemTemplate.Selected.m_PriceType.State, StoreCardSkinUI_ItemTemplate.Selected.m_Price.text, StoreCardSkinUI_ItemTemplate.Selected.ShopInfo.SellStartTime, StoreCardSkinUI_ItemTemplate.Selected.m_GainTips.text, isSuit: false);
				itemPanel = list.Max();
			}
			else
			{
				buttonInfo = null;
				itemPanel = 0;
			}
			SetButtonInfo(buttonInfo);
			SetItemPanel(itemPanel);
		}
	}

	private void SetButtonInfo(CommonDataCollection args)
	{
		m_BuyPanel.SetActive(args != null);
		if (m_BuyPanel.activeSelf)
		{
			if (m_ButtonPanel == null)
			{
				m_ButtonPanel = m_BuyPanel.GetComponentInChildren<UIDataBinder>();
			}
			m_ButtonPanel.Args = args;
		}
	}

	private void SetItemPanel(int itemId)
	{
		m_RolePanel.gameObject.SetActive(itemId != 0);
		if (m_RolePanel.gameObject.activeSelf)
		{
			m_RolePanel.SetItemId(itemId);
		}
	}
}
