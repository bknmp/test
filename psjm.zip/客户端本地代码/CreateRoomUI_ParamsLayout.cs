using LightUI;
using UnityEngine.UI;

internal class CreateRoomUI_ParamsLayout
{
	public UIDataBinder m_Host;

	public Text m_NameText;

	public Slider m_Slider;

	public Text m_ValueText;

	private RoomCustomConfigInfo m_ParamConfig;

	private RoleType m_RoleType;

	public void Bind(CommonDataCollection args)
	{
		CustomParamID paramID = (CustomParamID)(int)args["paramID"];
		int num = args["level"];
		m_RoleType = (RoleType)(int)args["roleType"];
		m_ParamConfig = LocalResources.GetRoomCustomConfig(paramID, m_RoleType);
		m_NameText.text = m_ParamConfig.Name;
		m_Slider.maxValue = m_ParamConfig.Levels.Length - 1;
		m_Slider.minValue = 0f;
		m_Slider.wholeNumbers = true;
		m_Slider.value = num;
		OnValueChanged();
		m_Slider.onValueChanged.RemoveAllListeners();
		m_Slider.onValueChanged.AddListener(OnValueChanged);
	}

	private void OnValueChanged(float val = 0f)
	{
		int num = (int)m_Slider.value;
		m_ValueText.text = m_ParamConfig.ShowLevels[num];
		CreateRoomUI.SetParams(m_RoleType, m_ParamConfig.ParamID, num);
	}
}
