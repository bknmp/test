using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CommonLoginActivityDayUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Collection;

	public Text m_Title;

	public Button m_GetRewardBtn;

	public Button m_NextDayGetRewardBtn;

	public GameObject m_CantGetRewardBtn;

	public Button m_Mask;

	public Text m_AvailabText;

	public GameObject m_AvailabFX;

	public UIStateImage m_BG;

	public UIStateItem m_DayTitle;

	public UIStateItem m_BtnState;

	public UIStateRawImage m_BGState;

	private int m_ActivityId;

	private int m_Index;

	private string m_DayIndexText;

	private CommonDataCollection m_args;

	private int m_Type;

	public Text m_Title2;

	public Text m_Title3;

	private int m_CanClaim = 1;

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		m_ActivityId = m_args["activityId"];
		m_Index = m_args["index"];
		m_Type = m_args["type"];
		SetInfo();
		AvailableHandle();
		ClaimHandle();
		if (m_Type == 1)
		{
			StyleHandle();
		}
		m_Collection.Args = WrapData();
		if (m_Mask.gameObject.activeSelf)
		{
			if ((bool)m_BtnState)
			{
				m_BtnState.gameObject.SetActive(value: false);
			}
			m_Host.EventProxy(m_Mask, "OnMaskClick");
		}
	}

	private void SetInfo()
	{
		if (m_Title != null)
		{
			if (string.IsNullOrEmpty(m_DayIndexText))
			{
				m_DayIndexText = m_Title.text;
			}
			m_Title.text = string.Format(m_DayIndexText, m_Index);
			if (m_AvailabText != null)
			{
				m_AvailabText.text = m_Title.text;
			}
		}
	}

	private void AvailableHandle()
	{
		bool num = CommonLoginActivityUtility.isNextDayRewardAvailable(m_ActivityId, m_Index);
		m_CanClaim = ((!CommonLoginActivityUtility.isRewardAvailable(m_ActivityId, m_Index)) ? 1 : 0);
		if (num)
		{
			if ((bool)m_BtnState)
			{
				m_BtnState.State = 2;
			}
			if ((bool)m_BGState)
			{
				m_BGState.State = 0;
			}
			m_Host.EventProxy(m_NextDayGetRewardBtn, "OnGetRewardNextDayBtnClick");
		}
		else
		{
			m_AvailabFX.gameObject.SetActive(m_CanClaim == 0);
			if ((bool)m_BGState)
			{
				m_BGState.State = 1;
			}
			m_BtnState.State = (m_AvailabFX.gameObject.activeSelf ? 1 : 0);
			if (m_BtnState.State == 1)
			{
				m_Host.EventProxy(m_GetRewardBtn, "OnGetRewardBtnClick");
			}
		}
		if (m_CantGetRewardBtn != null)
		{
			m_CantGetRewardBtn.SetActive(!m_AvailabFX.gameObject.activeSelf);
		}
	}

	private void ClaimHandle()
	{
		if (CommonLoginActivityUtility.isRewardReceive(m_ActivityId, m_Index))
		{
			m_Mask.gameObject.SetActive(value: true);
			m_GetRewardBtn.gameObject.SetActive(value: false);
			m_AvailabFX.SetActive(value: false);
			if (m_CantGetRewardBtn != null)
			{
				m_CantGetRewardBtn.SetActive(value: false);
			}
			if ((bool)m_BGState)
			{
				m_BGState.State = 0;
			}
			m_CanClaim = 1;
		}
	}

	public void StyleHandle()
	{
		m_Title2 = m_DayTitle.transform.GetChild(1).GetComponent<Text>();
		m_Title3 = m_DayTitle.transform.GetChild(2).GetComponent<Text>();
		if (m_BG != null)
		{
			m_BG.State = m_Index - 1;
		}
		m_DayTitle.State = m_Index - 1;
		if (m_Title != null && m_Title2 != null && m_Title3 != null)
		{
			m_Title2.text = m_Title.text;
			m_Title3.text = m_Title.text;
		}
	}

	public void OnMaskClick()
	{
		UILobby.Current.ShowTips(Localization.hadClaim);
	}

	public void OnGetRewardBtnClick()
	{
		CommonLoginActivityUtility.GetReward(m_ActivityId, m_Index, null);
	}

	public void OnGetRewardNextDayBtnClick()
	{
		UILobby.Current.ShowTips(Localization.NextDayAvailableHint);
	}

	protected CommonDataCollection WrapData()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int rewardCountWithDayIndex = CommonLoginActivityUtility.GetRewardCountWithDayIndex(m_ActivityId, m_Index);
		for (int i = 0; i < rewardCountWithDayIndex; i++)
		{
			commonDataCollection[i]["activityId"] = m_ActivityId;
			commonDataCollection[i]["index"] = m_Index;
			commonDataCollection[i]["rewardIndex"] = i;
			commonDataCollection[i]["canClaim"] = m_CanClaim;
		}
		return commonDataCollection;
	}
}
