using DG.Tweening;
using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_SkinPartItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Button m_SelectBtn;

	public GameObject m_Selected;

	public MultiTargetGraphicButton m_BuyBtn;

	public UIPopup m_BuySkinPartUI;

	public UIDataBinder m_Time;

	public Image m_Use;

	public Image m_Color;

	public MultiTargetGraphicButton m_LotteryBtn;

	public UIPage m_StoreUI;

	public Image m_Icon;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public GameObject m_NotOwn;

	public GameObject m_RedPoint;

	public UIScrollRect m_ScrollView;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeasonText;

	public static int globalSelected = -1;

	private int skinPartID;

	private List<int> m_dropIDs;

	private bool own;

	private bool isUsing;

	private int color;

	private bool m_selectedFlag;

	private Tween m_tween;

	private int expiredTime;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SelectBtn, "OnClickSelect");
		m_Host.EventProxy(m_BuyBtn, "OnClickBuy");
		m_Host.EventProxy(m_LotteryBtn, "OnClickLottery");
		skinPartID = args["skinPartID"];
		ShopUtility.ShopGoodsData shopGoodsData = JsonUtility.FromJson<ShopUtility.ShopGoodsData>(args["goodsData"]);
		m_dropIDs = shopGoodsData.shopID;
		if (m_dropIDs.Count > 0)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(m_dropIDs[0]);
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
			m_QualityBG.State = dropItem.Quality;
			m_Effect.State = dropItem.Quality;
		}
		else
		{
			DropItem dropItem2 = LocalResources.DropItemTable.Find((DropItem x) => x.TypeParam == skinPartID);
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem2.Icon);
			m_QualityBG.State = dropItem2.Quality;
			m_Effect.State = dropItem2.Quality;
		}
		SkinInfo skinInfo = CharacterUtility.GetSkinInfo(skinPartID);
		int limitedEdition = skinInfo.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeasonText.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		m_Name.text = skinInfo.Name;
		isUsing = CharacterUtility.IsUsingSkin(skinPartID);
		own = CharacterUtility.OwnSkinPart(skinPartID, out expiredTime, out color);
		bool flag = CharacterUtility.IsDefaultColor(skinPartID, color);
		if (own)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection[0]["time"] = expiredTime;
			m_Time.Args = commonDataCollection;
		}
		if (m_NotOwn != null)
		{
			m_NotOwn.gameObject.SetActive(!own);
		}
		if (m_Use != null)
		{
			m_Use.gameObject.SetActive(isUsing);
		}
		if (m_Color != null)
		{
			m_Color.transform.parent.gameObject.SetActive(!flag);
			m_Color.color = LocalResources.ColorPaletteTable.Get(color).Color;
		}
		if (m_BuyBtn != null)
		{
			m_BuyBtn.gameObject.SetActive(!own && shopGoodsData.gainType == ShopGainType.Buy);
		}
		if (m_LotteryBtn != null)
		{
			m_LotteryBtn.gameObject.SetActive(!own && shopGoodsData.gainType == ShopGainType.Lottery);
		}
		m_RedPoint.gameObject.SetActive(NewSkinPartTips.Inst.IsNew(skinPartID));
		UpdateSelectState();
	}

	public void OnClickSelect()
	{
		if (expiredTime > 0 && UtcTimeStamp.Now >= expiredTime)
		{
			UILobby.Current.ShowTips(Localization.OutOfDate);
			return;
		}
		NewSkinPartTips.Inst.TryToClear(skinPartID);
		m_RedPoint.gameObject.SetActive(value: false);
		SkinPartController skinPartController = LobbyScene.Inst.CurrentCharacter.m_SkinPartController;
		CharacterUtility.SkinPartArray realChangedParts = CharacterUtility.GetRealChangedParts(skinPartID, skinPartController.PartIDs);
		if (CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			if (!isUsing)
			{
				UILobby.Current.ShowTips(Localization.SetSkinPartSuccess);
			}
			PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
			foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
			{
				if (playerCharacterInfo.characterID == realChangedParts.characterID)
				{
					CharacterUtility.LocalChangePlayerPartsData(realChangedParts, playerCharacterInfo.currentSkinInfo, playerCharacterInfo.characterID);
				}
			}
		}
		globalSelected = skinPartID;
		CharacterUtility.DoChangeParts(realChangedParts);
		UIDataEvents.Inst.InvokeEvent("OnSelectSkinPartChanged");
	}

	public void OnClickBuy()
	{
		UILobby.Current.Popup(m_BuySkinPartUI);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		foreach (int dropID in m_dropIDs)
		{
			commonDataCollection[commonDataCollection.ArraySize]["Id"] = dropID;
		}
		commonDataCollection["name"] = LocalResources.SkinPartTable.Get(skinPartID).Name;
		UILobby.Current.CurrentPopup().GetComponent<UIDataBinder>().Args = commonDataCollection;
	}

	public void OnClickLottery()
	{
		UILobby.Current.GoToPage(m_StoreUI);
		UILobby.Current.CurrentPage().GetComponent<UITabPage>().SetSelectedTabIndex(1);
	}

	private void UpdateSelectState()
	{
		bool flag = skinPartID == globalSelected;
		m_Selected.gameObject.SetActive(skinPartID == globalSelected);
		if (!WardrobeUIRedPointJunction.SkinPartRedPointFlag && flag)
		{
			m_ScrollView.ScrollToItem(m_Host.gameObject.transform, tween: true);
		}
		if (m_selectedFlag == flag)
		{
			return;
		}
		if (flag)
		{
			if (m_tween != null)
			{
				m_tween.Kill();
			}
			m_tween = m_Host.transform.DOScale(1.05f, 0.2f).SetEase(Ease.OutBack);
		}
		else
		{
			if (m_tween != null)
			{
				m_tween.Kill();
			}
			m_Host.transform.localScale = Vector3.one;
		}
		m_selectedFlag = flag;
	}
}
