using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class ActivationCodeUI : MonoBehaviour
{
	public InputField m_Input;

	public CommonRewardPopupUI m_RewardPopupUI;

	public void OnClickExchange()
	{
		string text = m_Input.text.Trim();
		if (string.IsNullOrEmpty(text))
		{
			UILobby.Current.ShowTips(Localization.InputActivationCodeFirst);
		}
		else if (text.StartsWith("CA|"))
		{
			int platformID = WindowsSDKAdapter.Adapter.PlatformID;
			if (platformID == 2)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.CloneAccountTips, Localization.Yes, Localization.No, Localization.MsgBoxTitle, CloneAccount, null);
			}
			else if (LocalPlayerDatabase.LoginPlatformID == PlatformID.Official)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.CloneAccountTips, Localization.Yes, Localization.No, Localization.MsgBoxTitle, CloneAccount, null);
			}
			else
			{
				UILobby.Current.ShowTips(Localization.InvalidActivationCode);
			}
		}
		else
		{
			ExchangeRewards();
		}
	}

	private void CloneAccount()
	{
		HttpRequestCloneAccount httpRequestCloneAccount = new HttpRequestCloneAccount();
		httpRequestCloneAccount.token = m_Input.text.Trim();
		GameHttpManager.Inst.Send(httpRequestCloneAccount, delegate
		{
			ResManager.LoadScene("Loading");
		});
	}

	private void ExchangeRewards()
	{
		HttpRequestExchangeRewards httpRequestExchangeRewards = new HttpRequestExchangeRewards();
		httpRequestExchangeRewards.exchangeCode = m_Input.text.Trim();
		GameHttpManager.Inst.Send(httpRequestExchangeRewards, delegate(HttpResponseExchangeRewards onResponse)
		{
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_RewardPopupUI);
			commonRewardPopupUI.AddItems(onResponse.rewards);
			commonRewardPopupUI.SetTitleAndTips("", "");
		});
	}
}
