using GameMessages;

public class BuyUI
{
	protected int m_globalSelectID;

	protected int m_globalIndex;

	protected CurrencyType m_selectedType;

	public int GlobalSelectID
	{
		get
		{
			return m_globalSelectID;
		}
		set
		{
			m_globalSelectID = value;
		}
	}

	public int GlobalIndex
	{
		get
		{
			return m_globalIndex;
		}
		set
		{
			m_globalIndex = value;
		}
	}

	public CurrencyType SelectedType
	{
		get
		{
			return m_selectedType;
		}
		set
		{
			m_selectedType = value;
		}
	}
}
