using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class AdTryCharacterButton_TalentItem
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public UIStateItem m_Frame;

	public UIStateItem m_Type;

	public Image m_LevelImg;

	public UITipsDialogController m_TipsDialog;

	public void Bind(CommonDataCollection args)
	{
		int num = args["talentID"];
		int num2 = args["talentLevel"];
		TalentInfo talentInfo = LocalResources.TalentTable.Get(num);
		m_Icon.sprite = SpriteSource.Inst.Find(talentInfo.Icon);
		m_LevelImg.fillAmount = TalentUtility.GetTalentLevelImageFillAmount(num, num2);
		SetStyle(talentInfo.Type);
		SetTipsDialog(talentInfo, num2);
	}

	private void SetStyle(TalentType type)
	{
		if (type == TalentType.Default)
		{
			m_Frame.transform.parent.localScale = Vector3.one;
		}
		else
		{
			m_Frame.transform.parent.localScale = new Vector3(1.25f, 1.25f, 1.25f);
		}
		m_Type.State = (int)type;
		m_Frame.State = (int)type;
	}

	private void SetTipsDialog(TalentInfo talentInfo, int talentLevel)
	{
		List<object> list = new List<object>();
		for (int i = 1; i <= talentInfo.MaxLevel; i++)
		{
			string colorBonus = GetColorBonus(TalentUtility.GetTalentShowBonus(talentInfo.Id, i), talentLevel == i, i == 1 && talentLevel <= 0);
			list.Add(colorBonus);
		}
		string tips = string.Format(talentInfo.TakeEffectTips, list.ToArray());
		m_TipsDialog.SetTips(tips, talentInfo.Name);
	}

	private string GetColorBonus(string bonus, bool activated, bool preview)
	{
		if (preview)
		{
			return $"<color=#00FFFF>{bonus}</color>";
		}
		return string.Format(activated ? "<color=#008BFFFF>{0}</color>" : "<color=#423636FF>{0}</color>", bonus);
	}
}
