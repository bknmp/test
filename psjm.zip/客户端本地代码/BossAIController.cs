using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;

public class BossAIController : MonoBehaviour
{
	[Serializable]
	public class SkillFireProbability
	{
		public SkillKind kind;

		public int weight;

		public int cooldown;

		[HideInInspector]
		public int lastTime;
	}

	public SkillFireProbability[] m_SkillInfos;

	private List<SkillFireProbability> m_ActiveSkillInfos = new List<SkillFireProbability>();

	private SkillLauncher m_SkillLauncher;

	private void Start()
	{
		m_SkillLauncher = GetComponent<SkillLauncher>();
		SkillFireProbability[] skillInfos = m_SkillInfos;
		for (int i = 0; i < skillInfos.Length; i++)
		{
			skillInfos[i].lastTime = (int)Time.time;
		}
	}

	public void TryAttack(Transform target)
	{
		if (m_SkillLauncher == null)
		{
			m_SkillLauncher = GetComponent<SkillLauncher>();
			return;
		}
		int num = 0;
		m_ActiveSkillInfos.Clear();
		SkillFireProbability[] skillInfos = m_SkillInfos;
		foreach (SkillFireProbability skillFireProbability in skillInfos)
		{
			Skill skill = m_SkillLauncher.GetSkill(skillFireProbability.kind);
			if (skill != null && !skill.IsPlaying && !(skill.CooldownRatio > 0f) && !IsCoolingDown(skillFireProbability) && InRange(skill, target))
			{
				m_ActiveSkillInfos.Add(skillFireProbability);
				num += skillFireProbability.weight;
			}
		}
		if (m_ActiveSkillInfos.Count > 0)
		{
			int num2 = UnityEngine.Random.Range(0, 100);
			float num3 = 0f;
			foreach (SkillFireProbability activeSkillInfo in m_ActiveSkillInfos)
			{
				Skill skill2 = m_SkillLauncher.GetSkill(activeSkillInfo.kind);
				int num4 = (activeSkillInfo.weight <= 0) ? (-1) : (activeSkillInfo.weight * 100 / num);
				num3 += (float)num4;
				if ((float)num2 <= num3)
				{
					activeSkillInfo.lastTime = (int)Time.time;
					DoAttack(m_SkillLauncher, skill2, target);
					break;
				}
			}
		}
	}

	private void DoAttack(SkillLauncher skillLauncher, Skill skill, Transform target)
	{
		object param = null;
		object param2;
		if (skill.Kind == SkillKind.Prison || skill.Kind == SkillKind.TigerJump)
		{
			param2 = base.transform.localPosition;
			param = target.position;
		}
		else if (skill.Kind == SkillKind.Snipe)
		{
			param2 = base.transform.localPosition;
			param = target.localPosition - base.transform.localPosition;
			GetComponent<PlayerController>().AI.CurrentAttackPosition = target.localPosition;
		}
		else if (skill.Kind == SkillKind.Normal)
		{
			skill.InitializeStartParams(out param2, out param);
			param2 = (target.position - base.transform.position).normalized * skill.Properties.attackRadius + base.transform.localPosition;
		}
		else
		{
			skill.InitializeStartParams(out param2, out param);
		}
		skillLauncher.RpcStartSkill(skill, param2, param);
	}

	private bool InRange(Skill skill, Transform target)
	{
		float num = Mathf.Max(skill.MaxPlaceDistance, skill.Properties.attackRadius);
		return Vector3.Distance(base.transform.localPosition.FlattenY(), target.localPosition.FlattenY()) < num;
	}

	private bool IsCoolingDown(SkillFireProbability info)
	{
		return Time.time - (float)info.lastTime < (float)info.cooldown;
	}
}
