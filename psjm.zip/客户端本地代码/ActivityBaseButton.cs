using GameMessages;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class ActivityBaseButton : LobbyBaseButton
{
	public Text m_RemainTime;

	private Coroutine m_Coroutine;

	private int m_EndTime;

	public void SetInfo(Activity activity)
	{
		if (activity == null)
		{
			Hide();
		}
		else
		{
			SetInfo(activity.gradeLimit, Mathf.Min(activity.startTime, activity.exchangeStartTime), Mathf.Max(activity.endTime, activity.exchangeEndTime));
		}
	}

	public void SetInfo(int unlockGrade, int startTime, int endTime)
	{
		if (m_RemainTime != null)
		{
			m_RemainTime.transform.parent.gameObject.SetActive(value: false);
		}
		m_EndTime = endTime;
		if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < unlockGrade)
		{
			Hide();
		}
		else if (UtcTimeStamp.Now < startTime)
		{
			Hide();
			Invoke("Show", Mathf.Max(0, startTime - UtcTimeStamp.Now));
			Invoke("Hide", Mathf.Max(0.1f, endTime - UtcTimeStamp.Now));
		}
		else if (UtcTimeStamp.Now <= endTime)
		{
			Show();
			Invoke("Hide", Mathf.Max(0.1f, endTime - UtcTimeStamp.Now));
		}
		else
		{
			Hide();
		}
	}

	public void ShowCooldown(int startTimestamp, int endTime = 0)
	{
		if (endTime > 0)
		{
			m_EndTime = endTime;
		}
		if (m_RemainTime != null)
		{
			m_RemainTime.transform.parent.gameObject.SetActive(value: false);
			InvokeRepeating("UpdateTime", Mathf.Max(0, startTimestamp - UtcTimeStamp.Now), 1f);
		}
	}

	private void UpdateTime()
	{
		if (m_RemainTime == null || base.gameObject == null)
		{
			return;
		}
		if (!m_RemainTime.gameObject.activeInHierarchy)
		{
			m_RemainTime.transform.parent.gameObject.SetActive(value: true);
		}
		int seconds = m_EndTime - UtcTimeStamp.Now;
		TimeSpan timeSpan = new TimeSpan(0, 0, seconds);
		if (timeSpan.TotalHours >= 24.0)
		{
			if (timeSpan.Hours > 0)
			{
				m_RemainTime.text = $"{timeSpan.Days:0}{Localization.Day}";
			}
			else
			{
				m_RemainTime.text = $"{timeSpan.Days:0}{Localization.Day}";
			}
		}
		else if (timeSpan.Hours > 0)
		{
			m_RemainTime.text = $"{timeSpan.Hours}{Localization.Hour}";
		}
		else
		{
			m_RemainTime.text = $"{timeSpan.Minutes + 1}{Localization.Minute}";
		}
	}
}
