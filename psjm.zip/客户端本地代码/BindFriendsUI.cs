using LightUI;
using LightUtility;
using System;
using UnityEngine;

public class BindFriendsUI : MonoBehaviour
{
	public UITabPage m_TabPage;

	public static Delegates.VoidCallback OnUpBindChanged;

	public static int m_EnterPageIndex = -1;

	private void Start()
	{
		m_TabPage.OnTabChanged.AddListener(OnTabChanged);
	}

	private void OnEnable()
	{
		if (m_EnterPageIndex != -1)
		{
			m_TabPage.SetSelectedTabIndex(m_EnterPageIndex);
			m_EnterPageIndex = -1;
		}
		Invoke("TryShowPointAdd", 0.3f);
		OnUpBindChanged = (Delegates.VoidCallback)Delegate.Combine(OnUpBindChanged, new Delegates.VoidCallback(ChangedUpBind));
	}

	private void OnDisable()
	{
		OnUpBindChanged = (Delegates.VoidCallback)Delegate.Remove(OnUpBindChanged, new Delegates.VoidCallback(ChangedUpBind));
	}

	private void TryShowPointAdd()
	{
		BindFriendsUtility.TryShowPointAdd();
	}

	public void OnTabChanged()
	{
		switch (m_TabPage.GetSelectedTabIndex())
		{
		case 1:
			PassStorePage_Item.wantSelectIdx = 0;
			break;
		case 2:
			BindFriendsPage_Bind.m_RefreshPage = true;
			break;
		}
	}

	public void ChangedUpBind()
	{
		BindFriendsUtility.RefreshMyBindFriendsInfo(clearPointAdd: false, delegate
		{
			if (BindFriendsPage_Bind.OnUpBindChanged != null)
			{
				BindFriendsPage_Bind.OnUpBindChanged();
			}
		});
	}
}
