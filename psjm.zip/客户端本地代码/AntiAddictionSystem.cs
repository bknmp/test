using LightUtility;
using System;
using UnityEngine;

public class AntiAddictionSystem : MonoBehaviour
{
	public float[] m_NoticeMins;

	private string AnTiPlayedTimeKey = "ANTI_PLAYED_TIME";

	private string AnTiSaveTimeKey = "ANTI_SAVE_TIME";

	private int m_MinHour;

	private int m_MaxHour;

	private int m_TotalTime;

	private float m_PlayedTime;

	private bool m_Started;

	private bool m_ShowingPopup;

	public static AntiAddictionSystem Inst;

	public int PlayedTime => (int)m_PlayedTime;

	public bool ShowingPopup => m_ShowingPopup;

	public bool Filled
	{
		get
		{
			if (LocalPlayerDatabase.LoginInfo.audit != 0)
			{
				return LocalPlayerDatabase.LoginInfo.audit == 1;
			}
			return true;
		}
	}

	public static bool CanPlay
	{
		get
		{
			if (Inst != null && Inst.m_Started)
			{
				if (Inst.IsInCanPlayTime())
				{
					return !Inst.IsPlayedTimeTooLong();
				}
				return false;
			}
			return true;
		}
	}

	public int ProceedsPercent => 100;

	private void Awake()
	{
		if (LocalPlayerDatabase.LoginInfo == null || Inst != null)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			return;
		}
		Inst = this;
		ResManager.DontDestroyOnLoad(base.gameObject);
		LocalPlayerDatabase.OnLoginInfoChanged = (Delegates.VoidCallback)Delegate.Combine(LocalPlayerDatabase.OnLoginInfoChanged, new Delegates.VoidCallback(Restart));
	}

	private void OnDestroy()
	{
		LocalPlayerDatabase.OnLoginInfoChanged = (Delegates.VoidCallback)Delegate.Remove(LocalPlayerDatabase.OnLoginInfoChanged, new Delegates.VoidCallback(Restart));
		if (Inst == this)
		{
			Inst = null;
		}
	}

	private void Update()
	{
		if (m_Started)
		{
			m_PlayedTime += Time.deltaTime;
		}
	}

	private void OnDisable()
	{
		Save();
	}

	private void OnApplicationPause(bool pause)
	{
		if (pause)
		{
			Save();
		}
	}

	private void Save()
	{
		if (m_Started)
		{
			LocalPlayerDatabase.SetPrefValue(AnTiPlayedTimeKey, PlayedTime);
			LocalPlayerDatabase.SetPrefValue(AnTiSaveTimeKey, UtcTimeStamp.Now);
			PlayerPrefs.Save();
		}
	}

	private void Restart()
	{
		CancelInvoke();
		m_Started = false;
		TryStartMonitoring();
	}

	private void SetParams()
	{
		m_TotalTime = LocalPlayerDatabase.PrivatePlayerInfo.totalCanPlayTime;
		m_MinHour = LocalPlayerDatabase.Settings.underAgePlayTimeMin;
		m_MaxHour = LocalPlayerDatabase.Settings.underAgePlayTimeMax;
		float a = UtcTimeStamp.IsCrossDay(LocalPlayerDatabase.GetPrefValueInt(AnTiSaveTimeKey), UtcTimeStamp.Now) ? m_PlayedTime : Mathf.Max(m_PlayedTime, LocalPlayerDatabase.GetPrefValueInt(AnTiPlayedTimeKey));
		m_PlayedTime = Mathf.Max(a, LocalPlayerDatabase.PrivatePlayerInfo.totalPlayedTime);
		if (AndroidSDKAdapter.Adapter.UseSDKAddictionTime)
		{
			m_PlayedTime = AndroidSDKAdapter.Adapter.PlayedTime;
			AndroidSDKAdapter.AddictionTimeEvent = SetPlayedTime;
		}
	}

	private void SetPlayedTime(int time)
	{
		UnityEngine.Debug.Log("SetPlayedTime___" + time);
		m_PlayedTime = Mathf.Max(time, m_PlayedTime);
	}

	public void ResetPlayedTime()
	{
		m_PlayedTime = 0f;
		LocalPlayerDatabase.SetPrefValue(AnTiPlayedTimeKey, 0);
	}

	public void DestroySelf()
	{
		if (Inst == this)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			Inst = null;
		}
	}

	public void TryStartMonitoring()
	{
		if (m_Started)
		{
			Check();
		}
		else
		{
			if (TouristSystem.IsTourist() || TouristSystem.BindedAccountCanOpen)
			{
				return;
			}
			if (!AntiAddictionUtility.Verified)
			{
				if (LocalPlayerDatabase.Settings.RNSRealNameFlag == 2)
				{
					if (!(GameRuntime.ActiveSceneName != "Lobby") || LocalPlayerDatabase.Settings.RNSEnableInGameLimit)
					{
						ShowRealNameLimitUI();
						m_Started = true;
					}
					return;
				}
				if (LocalPlayerDatabase.Settings.RNSRealNameFlag == 0)
				{
					return;
				}
			}
			if (LocalPlayerDatabase.Settings.RNSAntiAdditionFlag != 0 && !AntiAddictionUtility.IsAudlt)
			{
				m_Started = true;
				SetParams();
				InvokeRepeating("Check", 10f, 10f);
				Check();
				TimeSpanSender.Inst.StartSendNotice();
				UnityEngine.Debug.Log("Start AntiAddiction");
			}
		}
	}

	private void Check()
	{
		if (m_ShowingPopup || CharacterFeatureUI.IsShowing || (GameRuntime.ActiveSceneName != "Lobby" && (!LocalPlayerDatabase.Settings.RNSEnableInGameLimit || !(InGameScene.Inst != null) || (IsInCanPlayTime() && !IsPlayedTimeTooLong()))))
		{
			return;
		}
		if (!IsInCanPlayTime())
		{
			string arg = (!AntiAddictionUtility.Verified) ? Localization.TipsUnVerfiedEqualsChild : "";
			AntiAddictionUtility.ShowWarningPopup(string.Format(Localization.TipsGameTooLate, arg), canGoBack: false, SetShowingPopup);
			return;
		}
		if (IsPlayedTimeTooLong())
		{
			string arg2 = (!AntiAddictionUtility.Verified) ? Localization.TipsUnVerfiedEqualsChild : "";
			AntiAddictionUtility.ShowWarningPopup(string.Format(Localization.TipsGameTooMuch, arg2), canGoBack: false, SetShowingPopup);
			return;
		}
		int num = m_TotalTime - (int)m_PlayedTime;
		int num2 = 0;
		while (true)
		{
			if (num2 < m_NoticeMins.Length)
			{
				float num3 = m_NoticeMins[num2] * 60f;
				if (num3 > 0f && (float)num < num3)
				{
					break;
				}
				num2++;
				continue;
			}
			return;
		}
		int num4 = Mathf.CeilToInt((float)num / 60f);
		string arg3 = $"{num4}{Localization.Minute}";
		string arg4 = (!AntiAddictionUtility.Verified) ? Localization.TipsUnVerfiedEqualsChild : "";
		AntiAddictionUtility.ShowWarningPopup(string.Format(Localization.TipsGameTimeLeft, arg4, arg3), canGoBack: true, SetShowingPopup);
		for (int i = num2; i < m_NoticeMins.Length; i++)
		{
			m_NoticeMins[i] = 0f;
		}
	}

	public void SetShowingPopup(bool val)
	{
		m_ShowingPopup = val;
	}

	private bool IsInCanPlayTime()
	{
		int hour = UtcTimeStamp.NowDateTime.Hour;
		if (hour >= m_MinHour)
		{
			return hour < m_MaxHour;
		}
		return false;
	}

	private bool IsPlayedTimeTooLong()
	{
		return m_TotalTime - (int)m_PlayedTime <= 0;
	}

	private void ShowRealNameLimitUI()
	{
		AntiAddictionUtility.ShowWarningPopup(Localization.TipsGoCertification, canGoBack: false, SetShowingPopup);
	}
}
