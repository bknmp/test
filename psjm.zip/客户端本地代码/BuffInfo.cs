using LightUtility;

public class BuffInfo : IdBased
{
	public string Name;

	public string Icon;

	public float Duration;

	public float SpeedGain;

	public float CooldownGain;

	public float JumpGain;

	public float CriticalGain;

	public bool SkillDisabled;

	public bool Invincible;

	public float BloodSucking;

	public bool DeBuff;

	public bool Tilable;

	public bool LoseControl;

	public bool Clearable;

	public bool IgnoreDebuff;

	public int InGameStoreItemID;

	public BuffCorrelation Correlation;

	public int CorrelationCardID;

	public int Visible;

	public bool ProgressHided;

	public bool Interrupt;

	public bool Silence;

	public float Damage;

	public float DamageInterval;

	public bool ShowEnemy;

	public float Shield;

	public BuffManager.BuffType BuffType;

	public BuffManager.EndType EndType;

	public bool DyingUseable;

	public bool Shareable;

	public bool Caged;

	public bool Avoidable;

	public bool Deceleration;

	public bool Multiple;
}
