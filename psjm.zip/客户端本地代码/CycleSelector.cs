using LightUtility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class CycleSelector : MonoBehaviour
{
	public Button m_PreButton;

	public Button m_NextButton;

	public Text m_CurText;

	public UnityEvent OnPageChanged;

	public AudioItem m_PreClicked;

	public AudioItem m_NextClicked;

	private int m_Index;

	private int m_Count;

	public int Index => m_Index;

	public int Count => m_Count;

	private void Awake()
	{
		m_PreButton.onClick.AddListener(PrevPage);
		m_NextButton.onClick.AddListener(NextPage);
	}

	public bool SetIndex(int index, int count)
	{
		if (m_Index != index || m_Count != count)
		{
			m_Index = Mathf.Clamp(index, 0, count - 1);
			m_Count = count;
			InvokePageChanged();
			return true;
		}
		return false;
	}

	private void NextPage()
	{
		SoundManager.PlayOnce(m_NextClicked);
		m_Index = (m_Index + 1) % m_Count;
		InvokePageChanged();
	}

	private void PrevPage()
	{
		SoundManager.PlayOnce(m_PreClicked);
		m_Index = (m_Index - 1) % m_Count;
		if (m_Index < 0)
		{
			m_Index = m_Count - 1;
		}
		InvokePageChanged();
	}

	private void InvokePageChanged()
	{
		m_CurText.text = $"{m_Index}/{m_Count - 1}";
		OnPageChanged.Invoke();
	}

	public void UpdateText(string msg)
	{
		m_CurText.text = msg;
	}
}
