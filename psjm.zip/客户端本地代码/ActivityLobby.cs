using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActivityLobby : UIEventListener
{
	public Text m_TitleText;

	public UIDataTabPage m_DataTabPage;

	private List<Activity> m_ActivityList = new List<Activity>();

	public static int enterActivityID = -1;

	private void Start()
	{
		m_DataTabPage.TabPage.OnTabChanged.AddListener(UpdateTitleName);
	}

	public override void OnEnterUI()
	{
		m_ActivityList.Clear();
		int num = 0;
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < activity.gradeLimit || (UtcTimeStamp.Now < activity.startTime && UtcTimeStamp.Now < activity.exchangeStartTime) || (UtcTimeStamp.Now > activity.endTime && UtcTimeStamp.Now > activity.exchangeEndTime))
			{
				continue;
			}
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
			if (activityLobbyInfo != null)
			{
				if (activityLobbyInfo.CollectionType == ActivityCollectionType.ACTIVITY_LOBBY)
				{
					m_ActivityList.Add(activity);
				}
				if (!string.IsNullOrEmpty(activity.previewPictureUrl))
				{
					num++;
				}
			}
		}
		if (num >= 2)
		{
			m_ActivityList.Add(new Activity
			{
				activityId = 0
			});
		}
		m_ActivityList.Sort((Activity a, Activity b) => LocalResources.ActivityLobbyInfos.Get(a.activityId).Rank.CompareTo(LocalResources.ActivityLobbyInfos.Get(b.activityId).Rank));
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		foreach (Activity activity2 in m_ActivityList)
		{
			commonDataCollection[commonDataCollection.ArraySize]["Activity"].val = activity2;
		}
		m_DataTabPage.SetItems(commonDataCollection.Array, commonDataCollection.Array);
		SetEnterTabPage();
		UpdateTitleName();
	}

	private void UpdateTitleName()
	{
		if (m_ActivityList.Count > 0)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(m_ActivityList[Mathf.Max(0, m_DataTabPage.TabPage.GetSelectedTabIndex())].activityId);
			m_TitleText.text = activityLobbyInfo.TitleName;
		}
	}

	public void SetEnterTabPage()
	{
		if (m_ActivityList.Count > 0)
		{
			for (int i = 0; i < m_ActivityList.Count; i++)
			{
				if (enterActivityID == m_ActivityList[i].activityId)
				{
					m_DataTabPage.TabPage.m_DefaultTabIndex = i;
					break;
				}
			}
		}
		if (enterActivityID == -1)
		{
			m_DataTabPage.TabPage.m_DefaultTabIndex = 0;
		}
		enterActivityID = -1;
	}

	public int ActivityLobbyTabPageIndex(string previewPictureUrl)
	{
		for (int i = 0; i < m_ActivityList.Count; i++)
		{
			if (m_ActivityList[i].previewPictureUrl == previewPictureUrl)
			{
				return i;
			}
		}
		return 0;
	}

	public static Activity GetActivityByActivityTypeAndCollectionType(ActivityType type, ActivityCollectionType collectionType, out ActivityLobbyInfo activityInfo, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (LocalPlayerDatabase.Settings == null)
		{
			activityInfo = null;
			return null;
		}
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (!ignoreGrade && LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < activity.gradeLimit)
			{
				continue;
			}
			int num = ignoreExchangeTime ? activity.startTime : Mathf.Min(activity.startTime, activity.exchangeStartTime);
			int num2 = ignoreExchangeTime ? activity.endTime : Mathf.Max(activity.endTime, activity.exchangeEndTime);
			if (ignoreTime || (UtcTimeStamp.Now > num && UtcTimeStamp.Now < num2))
			{
				activityInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
				if (activityInfo.Type == type && (activityInfo.CollectionType == ActivityCollectionType.NONE || activityInfo.CollectionType == collectionType))
				{
					return activity;
				}
			}
		}
		activityInfo = null;
		return null;
	}

	public static Activity GetActivityByActivityTypeAndCollectionType(ActivityType type, ActivityCollectionType collectionType, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (LocalPlayerDatabase.Settings == null)
		{
			return null;
		}
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (!ignoreGrade && LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < activity.gradeLimit)
			{
				continue;
			}
			int num = ignoreExchangeTime ? activity.startTime : Mathf.Min(activity.startTime, activity.exchangeStartTime);
			int num2 = ignoreExchangeTime ? activity.endTime : Mathf.Max(activity.endTime, activity.exchangeEndTime);
			if (ignoreTime || (UtcTimeStamp.Now > num && UtcTimeStamp.Now < num2))
			{
				ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
				if (activityLobbyInfo.Type == type && (activityLobbyInfo.CollectionType == ActivityCollectionType.NONE || activityLobbyInfo.CollectionType == collectionType))
				{
					return activity;
				}
			}
		}
		return null;
	}

	public static List<Activity> GetActivitysByType(ActivityType type, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (LocalPlayerDatabase.Settings == null)
		{
			return null;
		}
		List<Activity> list = new List<Activity>();
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (ignoreGrade || LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit)
			{
				int num = ignoreExchangeTime ? activity.startTime : Mathf.Min(activity.startTime, activity.exchangeStartTime);
				int num2 = ignoreExchangeTime ? activity.endTime : Mathf.Max(activity.endTime, activity.exchangeEndTime);
				if ((ignoreTime || (UtcTimeStamp.Now > num && UtcTimeStamp.Now < num2)) && LocalResources.ActivityLobbyInfos.Get(activity.activityId).Type == type)
				{
					list.Add(activity);
				}
			}
		}
		return list;
	}

	public static Activity GetActivityById(int activityId, out ActivityLobbyInfo activityInfo, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (LocalPlayerDatabase.Settings == null)
		{
			activityInfo = null;
			return null;
		}
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (ignoreGrade || LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit)
			{
				int num = ignoreExchangeTime ? activity.startTime : Mathf.Min(activity.startTime, activity.exchangeStartTime);
				int num2 = ignoreExchangeTime ? activity.endTime : Mathf.Max(activity.endTime, activity.exchangeEndTime);
				if ((ignoreTime || (UtcTimeStamp.Now > num && UtcTimeStamp.Now < num2)) && activity.activityId == activityId)
				{
					activityInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
					return activity;
				}
			}
		}
		activityInfo = null;
		return null;
	}

	public static Activity GetActivityById(int activityId, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (LocalPlayerDatabase.Settings == null)
		{
			return null;
		}
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (ignoreGrade || LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit)
			{
				int num = ignoreExchangeTime ? activity.startTime : Mathf.Min(activity.startTime, activity.exchangeStartTime);
				int num2 = ignoreExchangeTime ? activity.endTime : Mathf.Max(activity.endTime, activity.exchangeEndTime);
				if ((ignoreTime || (UtcTimeStamp.Now > num && UtcTimeStamp.Now < num2)) && activity.activityId == activityId)
				{
					return activity;
				}
			}
		}
		return null;
	}

	public static bool IsActicityAvailable(ActivityType type, ActivityCollectionType collectionType, out int activityId, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		Activity activityByActivityTypeAndCollectionType = GetActivityByActivityTypeAndCollectionType(type, collectionType, ignoreTime, ignoreGrade, ignoreExchangeTime);
		if (activityByActivityTypeAndCollectionType == null)
		{
			activityId = 0;
			return false;
		}
		activityId = activityByActivityTypeAndCollectionType.activityId;
		return true;
	}

	public static bool IsActicityAvailable(ActivityType type, ActivityCollectionType collectionType, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (GetActivityByActivityTypeAndCollectionType(type, collectionType, ignoreTime, ignoreGrade, ignoreExchangeTime) == null)
		{
			return false;
		}
		return true;
	}

	public static bool IsActicityAvailable(int activityId, bool ignoreTime = false, bool ignoreGrade = false, bool ignoreExchangeTime = false)
	{
		if (GetActivityById(activityId, ignoreTime, ignoreGrade, ignoreExchangeTime) == null)
		{
			return false;
		}
		return true;
	}

	public static bool RedPointState(ActivityType type, int activityId = 0)
	{
		bool result = false;
		switch (type)
		{
		case ActivityType.COLLECT_WORD:
			result = CommonExchangeUI.GetRedPoint(activityId);
			break;
		case ActivityType.MICRO_PAYMENT:
			result = MicroPaymentActivityUI.MicroPaymentRedPoint();
			break;
		case ActivityType.CUMULATION_RECHARGE:
			result = CumulationRechargeUI.CumulationRechargeRedPoint();
			break;
		case ActivityType.LOGIN_ACTIVITY:
			result = LoginActivityUI.LoginActivityRedPoint();
			break;
		case ActivityType.BUY_NEW_CARD_DIRECT:
		case ActivityType.GIVE_OLD_CARD:
		case ActivityType.GIVE_OLD_CARD_UP:
			result = BuyCardDirectActivity.RedPoint(type);
			break;
		case ActivityType.NEW_CARD_UPGRADE_REWARD:
			result = CardUpgradeRewardNew.GetRedPointState();
			break;
		case ActivityType.NEW_CARD_ACTIVITY_REWARD:
		case ActivityType.OLD_CARD_ACTIVITY_REWARD:
		case ActivityType.OLD_CARD_COLLECTION_REWARD:
			result = CardTaskActivityUI.GetRedPoint(type);
			break;
		case ActivityType.NEW_CARD_GIFT:
		case ActivityType.CHARACTER_BUY_DIRECT:
		case ActivityType.CHARACTER_GIFT:
			result = ActivityGiftUI.ActivityGiftRedPoint(type);
			break;
		case ActivityType.CHARACTER_TASK_ACTIVITY:
			result = CharacterTaskActivityUI.GetRedPoint();
			break;
		case ActivityType.SHARE_ACTIVITY:
			result = ShareActivityUI.GetRedPoint();
			break;
		case ActivityType.COMMON_TASK:
		{
			Activity activityById = GetActivityById(activityId);
			if (activityById != null && activityById.startTime != LocalPlayerDatabase.GetPrefValueInt("CommonTask_" + activityId))
			{
				return true;
			}
			result = (CommonTaskUI.GetRedPoint(activityId) || CommonExchangeUI.GetRedPoint(activityId));
			break;
		}
		case ActivityType.CHARACTER_LOTTERY:
		case ActivityType.CHARACTER_SUITE_LOTTERY:
			result = CharacterLotteryUI.GetRedPoint(activityId);
			break;
		case ActivityType.WEEKEND_DOUBLE:
			result = WeekendDoubleUI.GetRedPoint();
			break;
		case ActivityType.LIMITLOTTERY_ACTIVITY:
			result = (CharacterLotteryUI.GetRedPoint(activityId) || LimitLotteryStoreUI.GetRedPoint(activityId));
			break;
		case ActivityType.PINK_LOTTERY_ACTIVITY:
			result = PinkLotteryPage_Bind.PinkLotteryModel.IsFreeDrawAvailable;
			break;
		case ActivityType.CHARACTER_UPGRADE_ACTIVITY:
			result = CharacterUpgradeActivity.GetRedPointState(activityId);
			break;
		case ActivityType.CHARACTER_DISCOUNT_PACKAGE:
			result = CharacterDiscountUtility.GetRedPointState(activityId);
			break;
		case ActivityType.COMMON_LOGIN_ACTIVITY:
			result = CommonLoginActivityUtility.GetRedPointState(activityId);
			break;
		case ActivityType.PASS_LOTTERY_ACTIVITY:
			result = PassLotteryUtility.GetRedPointState(activityId);
			break;
		}
		return result;
	}

	public static bool BubbleState(ActivityType type, int activityId = 0)
	{
		bool result = false;
		if (type == ActivityType.PASS_LOTTERY_ACTIVITY)
		{
			result = PassLotteryUtility.GetBubbleState(activityId);
		}
		return result;
	}

	public static bool TabRedPointState(ActivityType type, int activityId = 0)
	{
		bool result = RedPointState(type, activityId);
		if (type == ActivityType.SHARE_ACTIVITY)
		{
			result = ShareActivityUI.GetTabRedPoint();
		}
		return result;
	}

	public static void InvokeActivityLobbyRedPointChange()
	{
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	public static void ActivityOverDayHandle(ref int lastRefreshTime, Delegates.VoidCallback OnOverday)
	{
		if (UtcTimeStamp.IsOverDay(lastRefreshTime, UtcTimeStamp.Now))
		{
			OnOverday();
		}
		lastRefreshTime = UtcTimeStamp.Now;
	}

	public static void ShowInfoPopupUI(string title, string desc, int activityId = 0)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["activityId"] = activityId;
		commonDataCollection["title"] = title;
		commonDataCollection["desc"] = desc;
		UIPopup ui = PrefabSource.Inst.Load<UIPopup>("CommonActivityInfoUI");
		UILobby.Current.ShowUI(ui, commonDataCollection);
	}
}
