using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class AccountBindMailUI : MonoBehaviour
{
	public AccountInfoController m_AccountInfo;

	public Button m_CloseBtn;

	public InputField m_Mail;

	public Button m_SendCode;

	public Text m_CountDown;

	public InputField m_Code;

	public Button m_OK;

	public UIStateItem m_TitleState;

	public UIStateItem m_BtnState;

	private static Delegates.VoidCallback OnMailSuccess;

	private MailCodeType m_MailCodeType;

	private int m_LastSendTime;

	private void Awake()
	{
		m_SendCode.onClick.AddListener(OnSendCodeClick);
		m_OK.onClick.AddListener(OnOkClick);
		m_CloseBtn.onClick.AddListener(CloseUI);
	}

	private void OnEnable()
	{
		if (UtcTimeStamp.Now - m_LastSendTime <= 60)
		{
			m_CountDown.transform.parent.gameObject.SetActive(value: true);
			StartCoroutine(ButtonCountDown(60 - UtcTimeStamp.Now + m_LastSendTime));
		}
		else
		{
			m_CountDown.transform.parent.gameObject.SetActive(value: false);
		}
	}

	private void OnDisable()
	{
		StopAllCoroutines();
	}

	public void Init(bool isBind, Delegates.VoidCallback onSuccess)
	{
		OnMailSuccess = onSuccess;
		m_AccountInfo.SetAccountInfo((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName);
		m_Code.text = "";
		m_CountDown.transform.parent.gameObject.SetActive(value: false);
		m_TitleState.State = ((!isBind) ? 1 : 0);
		m_BtnState.State = ((!isBind) ? 1 : 0);
		m_MailCodeType = (isBind ? MailCodeType.Bind : MailCodeType.UnBind);
		m_Mail.text = AccountUtility.LoginAccountInfo.mail;
		m_Mail.interactable = isBind;
		if (isBind)
		{
			AccountUtility.ShowMailRedPoint = true;
			AccountUtility.OnChangeRedPoint?.Invoke();
		}
	}

	private void OnSendCodeClick()
	{
		if (CheckMailFormat())
		{
			AccountUtility.SendMailCode(m_MailCodeType, m_Mail.text, delegate
			{
				m_LastSendTime = UtcTimeStamp.Now;
				StopAllCoroutines();
				StartCoroutine(ButtonCountDown(60));
				m_CountDown.transform.parent.gameObject.SetActive(value: true);
			});
		}
	}

	private bool CheckMailFormat(bool checkCode = false)
	{
		if (m_Mail.text.Length < 5 || !m_Mail.text.Contains("@"))
		{
			UILobby.Current.ShowTips(Localization.TipsMailError);
			return false;
		}
		string[] array = m_Mail.text.Split('@');
		if (array[0].Length <= 0 || !array[1].Contains("."))
		{
			UILobby.Current.ShowTips(Localization.TipsMailError);
			return false;
		}
		if (checkCode && m_Code.text.Length <= 0)
		{
			UILobby.Current.ShowTips(Localization.TipsInvalidCode);
			return false;
		}
		return true;
	}

	private IEnumerator ButtonCountDown(int time)
	{
		while (time > 0)
		{
			m_CountDown.text = time.ToString();
			yield return new WaitForSeconds(1f);
			time--;
		}
		m_CountDown.transform.parent.gameObject.SetActive(value: false);
	}

	private void OnOkClick()
	{
		if (CheckMailFormat(checkCode: true))
		{
			AccountUtility.CheckMailCode(m_MailCodeType, m_Mail.text, int.Parse(m_Code.text), OnSuccess);
		}
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	private void OnSuccess()
	{
		if (m_MailCodeType == MailCodeType.Bind)
		{
			UILobby.Current.ShowTips(Localization.MailBindSuccess);
			AccountUtility.LoginAccountInfo.mail = EncryptMail(m_Mail.text);
			if (LocalPlayerDatabase.LoginInfo != null)
			{
				LocalPlayerDatabase.LoginInfo.mail = AccountUtility.LoginAccountInfo.mail;
			}
		}
		else if (m_MailCodeType == MailCodeType.UnBind)
		{
			UILobby.Current.ShowTips(Localization.MailUnbindSuccess);
			AccountUtility.LoginAccountInfo.mail = "";
			AccountUtility.LoginAccountInfo.accountSafe = false;
			if (LocalPlayerDatabase.LoginInfo != null)
			{
				LocalPlayerDatabase.LoginInfo.mail = "";
				LocalPlayerDatabase.LoginInfo.accountSafe = false;
			}
		}
		m_LastSendTime = 0;
		CloseUI();
		if (OnMailSuccess != null)
		{
			OnMailSuccess();
		}
	}

	private string EncryptMail(string mail)
	{
		string[] array = mail.Split('@');
		if (array.Length > 1)
		{
			mail = "";
			mail += array[0][0].ToString();
			int num = Mathf.Max(array[0].Length - 2, 0);
			for (int i = 0; i < num; i++)
			{
				mail += "*";
			}
			mail = mail + array[0][array[0].Length - 1].ToString() + "@";
			mail += array[1];
		}
		return mail;
	}

	public static void ShowUI(bool isBind, Delegates.VoidCallback onSuccess = null)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountBindMailUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountBindMailUI>().Init(isBind, onSuccess);
	}
}
