using GameMessages;
using System.Collections.Generic;
using UnityEngine;

public class BuyCardDirectActivityPanel : MonoBehaviour
{
	public List<GameObject> m_SubElements = new List<GameObject>();

	private float m_EnterTime;

	private void OnEnable()
	{
		Invoke("ActivieSubElements", 0.1f);
		m_EnterTime = Time.time;
	}

	private void ActivieSubElements()
	{
		foreach (GameObject subElement in m_SubElements)
		{
			subElement.SetActive(value: true);
		}
	}

	private void OnDisable()
	{
		foreach (GameObject subElement in m_SubElements)
		{
			subElement.SetActive(value: false);
		}
		if (m_EnterTime > 0f)
		{
			int num = Mathf.Max(0, (int)(Time.time - m_EnterTime));
			if (num > 0)
			{
				LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CARDACTIVITY_STAY_VIDEO_PAGE, num.ToString());
			}
			m_EnterTime = 0f;
		}
	}
}
