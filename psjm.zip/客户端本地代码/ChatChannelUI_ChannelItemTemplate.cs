using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class ChatChannelUI_ChannelItemTemplate
{
	public UIDataBinder m_Host;

	public GameObject m_Selected;

	public UIStateImage m_State;

	public Text m_ChannelName;

	public Button m_Button;

	private string m_ChannelFormat;

	public static int Selected;

	private int m_ChannelID;

	public void Bind(CommonDataCollection args)
	{
		if (m_ChannelFormat == null)
		{
			m_ChannelFormat = m_ChannelName.text;
		}
		m_ChannelID = args["channelID"];
		ChatChannelInfo chatChannelInfo = ChatUtility.GetChatChannelInfo(m_ChannelID);
		if (chatChannelInfo != null)
		{
			ChatRegionInfo chatRegionInfo = LocalResources.ChatRegionTable.Find(chatChannelInfo.regionID);
			m_ChannelName.text = string.Format(m_ChannelFormat, chatRegionInfo.Name, chatChannelInfo.number);
			m_State.State = chatChannelInfo.state;
		}
		m_Host.EventProxy(m_Button, "OnSelectButtonClick");
		if (m_ChannelID == PublicChatManager.ChannelID)
		{
			Selected = m_ChannelID;
		}
		UpdateSelectState();
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_ChannelID)
		{
			Selected = m_ChannelID;
			ChangeChannel();
			UIDataEvents.Inst.InvokeEvent("OnSelectChannelItemChanged");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_ChannelID == Selected;
			m_Selected.SetActive(active);
		}
	}

	private void ChangeChannel()
	{
		PublicChatManager.Inst.ChangeChannelID(m_ChannelID);
		LobbyScene.Inst.ChatPanel.HideChatChannelUI();
		UILobby.Current.ShowTips(Localization.TipsChangeChannel);
	}
}
