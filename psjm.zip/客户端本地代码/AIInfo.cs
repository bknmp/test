using LightUtility;
using System;

[Serializable]
public class AIInfo : IdBased
{
	public string Name;

	public int CharacterID;

	public RoleType Camp;

	public string Behavior;

	public int SuiteID;

	public int[] TalentLevels;

	public int[] Cards;

	public int[] CardLevels;
}
