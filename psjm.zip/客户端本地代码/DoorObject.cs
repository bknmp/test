using DG.Tweening;
using SimpleJson;
using System;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

public class DoorObject : UsableObject
{
	[Serializable]
	public class Door
	{
		public Transform m_Root;

		public Vector3 m_RotationClosed;

		public Vector3 m_RotationOpened;

		public Tween m_Tween;

		public Animator m_Animator;
	}

	public Collider m_Collider;

	public OffMeshLink m_NavOffMeshLink;

	public bool m_InitialOpened;

	public float m_RotationDuration = 0.3f;

	public AudioClip m_SoundOpen;

	public AudioClip m_SoundClose;

	public Door[] m_Doors;

	public UnityAction<bool> OnToggled;

	public NavMeshObstacle m_NavMeshObstacle;

	private bool m_Opened;

	public override ViewBlockType CanBlockView
	{
		get
		{
			if (!m_Opened)
			{
				return ViewBlockType.Block;
			}
			return ViewBlockType.UnBlock;
		}
	}

	public bool IsOpend => m_Opened;

	public override UsableType UsableType => UsableType.Door;

	protected new void Awake()
	{
		m_Opened = m_InitialOpened;
		Door[] doors = m_Doors;
		foreach (Door door in doors)
		{
			door.m_Root.localRotation = Quaternion.Euler(m_Opened ? door.m_RotationOpened : door.m_RotationClosed);
		}
		m_Collider.enabled = !m_Opened;
		base.Awake();
		if (m_NavMeshObstacle != null)
		{
			m_NavMeshObstacle.enabled = m_Collider.enabled;
		}
	}

	protected new void Start()
	{
		UpdateNavMesh();
		base.Start();
	}

	private void UpdateDoorState(bool tween)
	{
		Door[] doors = m_Doors;
		foreach (Door door in doors)
		{
			if (door.m_Tween != null)
			{
				door.m_Tween.Kill();
			}
			if (m_Opened)
			{
				SetCollider(active: false);
				if (door.m_Animator != null)
				{
					if (door.m_Animator.isActiveAndEnabled)
					{
						door.m_Animator.SetTrigger("open");
						PlayAudio(open: true);
					}
				}
				else if (tween)
				{
					door.m_Tween = door.m_Root.DOLocalRotate(door.m_RotationOpened, m_RotationDuration);
					PlayAudio(open: true);
				}
				else
				{
					door.m_Root.localRotation = Quaternion.Euler(door.m_RotationOpened);
				}
			}
			else if (door.m_Animator != null)
			{
				if (door.m_Animator.isActiveAndEnabled)
				{
					door.m_Animator.SetTrigger("close");
					PlayAudio(open: false);
				}
				SetCollider(active: true);
			}
			else if (tween)
			{
				door.m_Tween = door.m_Root.DOLocalRotate(door.m_RotationClosed, m_RotationDuration).OnComplete(delegate
				{
					SetCollider(active: true);
				});
				PlayAudio(open: false);
			}
			else
			{
				SetCollider(active: true);
				door.m_Root.localRotation = Quaternion.Euler(door.m_RotationClosed);
			}
		}
		UpdateNavMesh();
		if (base.Block != null)
		{
			InGameFogOfWar.Inst.NotifiyMapChanged(base.Block.x, base.Block.y);
		}
	}

	private void PlayAudio(bool open)
	{
		if (m_AudioSources.Complete != null)
		{
			m_AudioSources.Complete.PlayOneShot(open ? m_SoundOpen : m_SoundClose);
		}
	}

	private void SetCollider(bool active)
	{
		m_Collider.enabled = active;
		if (m_NavMeshObstacle != null)
		{
			m_NavMeshObstacle.enabled = active;
		}
	}

	protected virtual void UpdateNavMesh()
	{
		m_NavOffMeshLink.gameObject.SetActive(m_Opened);
	}

	protected override void OnUseComplete(string userID)
	{
		base.OnUseComplete(userID);
		ToggleState();
	}

	public void ToggleState(bool tween = true)
	{
		m_Opened = !m_Opened;
		UpdateDoorState(tween);
		if (OnToggled != null)
		{
			OnToggled(IsOpend);
		}
	}

	public override float GetSpeedUpRatio(string userID)
	{
		PlayerController playerController = PlayerController.FindPlayer(userID);
		if (playerController != null)
		{
			return playerController.m_TalentProperties.doorSpeedUp;
		}
		return 0f;
	}

	public override void OnReSyncWrite(object data)
	{
		base.OnReSyncWrite(data);
		(data as JsonObject)["opened"] = m_Opened;
	}

	public override void OnReSyncRead(object data)
	{
		base.OnReSyncRead(data);
		bool flag = (data as JsonObject).AsBool("opened");
		if (m_Irreversible && m_Opened)
		{
			UpdateDoorState(tween: false);
		}
		else if (flag != m_Opened)
		{
			m_Opened = flag;
			UpdateDoorState(tween: false);
		}
	}
}
