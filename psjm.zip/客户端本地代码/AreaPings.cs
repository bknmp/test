using GameMessages;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class AreaPings : MonoBehaviour
{
	private struct Item
	{
		public int areaID;

		public Ping ping;

		public float startTime;
	}

	private const float m_MaxTimeLimit = 1f;

	private static Dictionary<int, int> m_AreaPings = new Dictionary<int, int>();

	private List<Item> m_PingList = new List<Item>();

	private IEnumerator Start()
	{
		if (LocalPlayerDatabase.Settings.areaIPs != null)
		{
			AreaIP[] areaIPs = LocalPlayerDatabase.Settings.areaIPs;
			foreach (AreaIP areaIP in areaIPs)
			{
				Item item = default(Item);
				item.areaID = areaIP.areaID;
				item.ping = new Ping(areaIP.ip);
				item.startTime = Time.time;
				m_PingList.Add(item);
				yield return new WaitForSeconds(0.1f);
			}
		}
	}

	private void Update()
	{
		int num = 0;
		while (num < m_PingList.Count)
		{
			Item item = m_PingList[num];
			if (Time.time - item.startTime > 1f)
			{
				int num2 = 1000;
				m_AreaPings[item.areaID] = num2;
				UnityEngine.Debug.Log($"Area Ping {item.ping.ip}({item.areaID}):{num2}ms");
				m_PingList.RemoveAt(num);
			}
			else if (item.ping.isDone)
			{
				m_AreaPings[item.areaID] = item.ping.time;
				UnityEngine.Debug.Log($"Area Ping {item.ping.ip}({item.areaID}):{item.ping.time}ms");
				m_PingList.RemoveAt(num);
			}
			else
			{
				num++;
			}
		}
	}

	public static int FindBestAreaID()
	{
		AreaIP areaIP = null;
		AreaIP[] areaIPs = LocalPlayerDatabase.Settings.areaIPs;
		int num = 1000;
		for (int i = 0; i < areaIPs.Length; i++)
		{
			int areaID = areaIPs[i].areaID;
			int value = 0;
			if (!m_AreaPings.TryGetValue(areaID, out value))
			{
				value = 1000;
			}
			if (value < num)
			{
				num = value;
				areaIP = areaIPs[i];
			}
		}
		if (areaIP == null)
		{
			int mostUsedAreaID = GetMostUsedAreaID();
			UnityEngine.Debug.Log($"GetMostUsedAreaID {mostUsedAreaID}");
			return mostUsedAreaID;
		}
		UnityEngine.Debug.Log($"FindBestAreaIP {areaIP.ip}({areaIP.areaID}):{num}ms");
		return areaIP.areaID;
	}

	public static AreaIP FindAreaIP(int areaID)
	{
		AreaIP[] areaIPs = LocalPlayerDatabase.Settings.areaIPs;
		for (int i = 0; i < areaIPs.Length; i++)
		{
			if (areaIPs[i].areaID == areaID)
			{
				return areaIPs[i];
			}
		}
		return null;
	}

	public static void SaveLastUsedAreaID(int areaID)
	{
		try
		{
			string path = Application.persistentDataPath + "/LastUseAreaID.txt";
			List<string> list = new List<string>();
			if (File.Exists(path))
			{
				list.AddRange(File.ReadAllLines(path));
			}
			if (list.Count > 100)
			{
				list.RemoveRange(0, list.Count - 100);
			}
			list.Add(areaID.ToString());
			File.WriteAllLines(path, list.ToArray());
		}
		catch (Exception)
		{
		}
	}

	public static int GetMostUsedAreaID()
	{
		string path = Application.persistentDataPath + "/LastUseAreaID.txt";
		List<string> list = new List<string>();
		if (File.Exists(path))
		{
			list.AddRange(File.ReadAllLines(path));
		}
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		for (int i = 0; i < list.Count; i++)
		{
			if (int.TryParse(list[i], out int result))
			{
				if (!dictionary.ContainsKey(result))
				{
					dictionary[result] = 0;
				}
				Dictionary<int, int> dictionary2 = dictionary;
				int key = result;
				dictionary2[key]++;
			}
		}
		int result2 = 1;
		int num = 0;
		foreach (KeyValuePair<int, int> item in dictionary)
		{
			if (item.Value > num)
			{
				num = item.Value;
				result2 = item.Key;
			}
		}
		return result2;
	}
}
