using DG.Tweening;
using LightUI;
using LightUtility;
using SimpleJson;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class BubbleObject : BouncingObject
{
	private enum TargetState
	{
		None,
		Caging,
		Killing
	}

	public int m_CagedDebuffID = 520;

	public int m_SpeedBuffID = 521;

	public GameObject m_UI;

	public UIProgressBar m_ProgressBar;

	public float m_LifeReducePerSecond = 1f;

	public Vector3 m_FloatOffset = new Vector3(0f, 0.2f, 0f);

	public Vector3 m_PlayerDyingOffset = new Vector3(0f, 0.7f, -0.15f);

	public Animator m_BubbleAnimator;

	public GameObject m_CageEffect;

	public AudioSource m_RunAudio;

	public static List<BubbleObject> AllBubbleObjects = new List<BubbleObject>();

	private bool m_Following;

	private bool m_IsNetworkDestroyed;

	private float m_MaxLife;

	private float m_CurrentLife;

	private float m_CagingDuration;

	private float m_KillingDuration;

	private TargetState m_TargetState;

	private bool m_BubbleMoveEnd;

	private BubbleViewObject m_BubbleViewObject;

	private PlayerController m_Target;

	public PlayerController PlayerController => m_PlayerController;

	public PlayerController Target => m_Target;

	public bool Fixing => Target != null;

	public bool IsNetworkDestroyed => m_IsNetworkDestroyed;

	private new void Awake()
	{
		base.Awake();
		m_UI.SetActive(value: false);
		m_TargetState = TargetState.None;
		m_BubbleMoveEnd = false;
		m_IsNetworkDestroyed = false;
		if (!string.IsNullOrEmpty(base.UserId))
		{
			m_CagingDuration = LocalResources.BuffTable.Find(520).Duration;
			m_KillingDuration = 9999f;
			m_BubbleViewObject = GetComponent<BubbleViewObject>();
		}
	}

	private new void Start()
	{
		base.Start();
		if (!string.IsNullOrEmpty(base.UserId))
		{
			m_MaxLife = float.MaxValue;
			AllBubbleObjects.Add(this);
			UpdateSpeedBuff();
			m_BubbleViewObject.Initialized(m_PlayerController);
		}
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		if (!string.IsNullOrEmpty(base.UserId))
		{
			AllBubbleObjects.Remove(this);
			try
			{
				m_IsNetworkDestroyed = true;
				Unfixing();
			}
			catch
			{
				UnityEngine.Debug.Log("Scene Destroyed");
			}
		}
	}

	protected override bool CanTriggerTarget(DamagableTarget target, ref int numID, ref int viewID, ref int localNum)
	{
		if (target.m_TargetType == DamagableTarget.TargetType.Player)
		{
			PlayerController playerController = (PlayerController)target.Target;
			if (!m_PlayerController.InSameTeam(playerController) && !InBubble(playerController) && !playerController.BuffManager.IsCaged)
			{
				ThiefController thiefController = playerController as ThiefController;
				if (thiefController != null && thiefController.IsCaptured)
				{
					return false;
				}
				if (playerController.Leaping || playerController.Launching || playerController.WaterEscaping)
				{
					return false;
				}
				if (playerController.PortalAdapter != null && playerController.PortalAdapter.IsPortaling)
				{
					return false;
				}
				if (playerController.Shifter.IsMissile)
				{
					return false;
				}
				numID = UserId2NumId.Get(playerController.UserId);
				localNum = playerController.LocalNum;
				return true;
			}
			return false;
		}
		return false;
	}

	[PunRPC]
	public override void OnFinishHit(Vector3 hitPos, int numID, int viewID, int localNum)
	{
		m_Hit = true;
		m_Launched = false;
		PlayerController player = PlayerController.FindPlayer(numID, localNum);
		if (player != null)
		{
			m_Target = player;
			m_Target.BuffManager.LocalClearBuffs(401);
			if (!player.IsDying)
			{
				m_Target.BuffManager.CreateCorrelatedBuff(PlayerController.FindPlayer(base.UserId), m_CagedDebuffID, BuffCorrelation.Talent, 131);
			}
			PlayerController playerController = player;
			playerController.OnDamageAppliedWithSource = (UnityAction<float, DamageSourceType, BasePlayerController, float>)Delegate.Combine(playerController.OnDamageAppliedWithSource, new UnityAction<float, DamageSourceType, BasePlayerController, float>(OnDamageAppliedWithSource));
			try
			{
				if (this != null)
				{
					StartCoroutine(FixingPlayer(player, delegate
					{
						FixedPlayer(player);
					}));
				}
			}
			catch
			{
			}
		}
		else
		{
			UnityEngine.Debug.LogWarning("player == null");
			LocalBurst();
		}
	}

	private void ShowFixedFX()
	{
		m_RunAudio.Stop();
		m_BubbleAnimator.SetTrigger("hit");
		PoolSpawner.Spawn(m_CageEffect, base.transform).transform.localPosition = Vector3.zero;
	}

	private IEnumerator FixingPlayer(PlayerController player, Action callback = null)
	{
		float dist = 1f;
		while (dist > 0.1f)
		{
			UpdateMoving(player.transform.localPosition);
			dist = Vector3.Distance(base.transform.position.FlattenY(), player.transform.localPosition.FlattenY());
			if (player.OnHookJoint || player.IsHookForwarding || player.ProjectileLauncher.IsSabering)
			{
				break;
			}
			yield return null;
		}
		callback?.Invoke();
	}

	private IEnumerator FollowPlayer(PlayerController player)
	{
		if (!m_Following)
		{
			m_Following = true;
			while (m_Following && base.WaitRpcTrigger)
			{
				UpdateMoving(player.transform.localPosition);
				yield return null;
			}
			m_Trigger = false;
			m_Following = false;
		}
	}

	private IEnumerator DoShowHighlight(PlayerController target)
	{
		InGameMinimap.Inst.ShowHighlight(target, show: true);
		yield return Yielders.GetWaitForSeconds(3f);
		InGameMinimap.Inst.ShowHighlight(target, show: false);
	}

	private void FixedPlayer(PlayerController player)
	{
		if (m_IsNetworkDestroyed)
		{
			return;
		}
		ShowFixedFX();
		m_Following = false;
		if (player == null)
		{
			UnityEngine.Debug.LogWarning("FixedPlayer is null !");
			return;
		}
		base.transform.SetParent(player.transform, worldPositionStays: false);
		base.transform.localPosition = Vector3.zero;
		base.transform.DOLocalMove(m_FloatOffset, 0.2f).OnComplete(delegate
		{
			m_BubbleMoveEnd = true;
		});
		m_Root.AddComponent<FixedRotation>();
		Vector3 endValue = (!player.IsDying) ? m_FloatOffset : m_PlayerDyingOffset;
		player.m_Animator.transform.DOLocalMove(endValue, 0.2f);
		player.ProjectileLauncher.ShowWeapon(show: false);
		if (player.IsMine)
		{
			if (!player.Shifter.IsVehicle && !player.Shifter.IsSkateBoard && !player.Shifter.IsRabbit)
			{
				player.Shifter.RpcEndShapeShift();
			}
			player.RpcExitVehicle();
		}
		if (m_PlayerController.PlayingRole == RoleType.Police)
		{
			StartCoroutine(DoShowHighlight(player));
		}
	}

	private void Unfixing()
	{
		if (m_Target != null)
		{
			if (m_Target.OnDamageAppliedWithSource != null)
			{
				PlayerController target = m_Target;
				target.OnDamageAppliedWithSource = (UnityAction<float, DamageSourceType, BasePlayerController, float>)Delegate.Remove(target.OnDamageAppliedWithSource, new UnityAction<float, DamageSourceType, BasePlayerController, float>(OnDamageAppliedWithSource));
			}
			m_Target.m_Animator.transform.transform.DOLocalMove(Vector3.zero, 0.2f);
			m_Target.ProjectileLauncher.ShowWeapon(show: true);
			if (m_Target.BuffManager.ContainsBuff(m_CagedDebuffID))
			{
				m_Target.BuffManager.RemoveCorrelatedBuff(m_CagedDebuffID);
			}
			PlayerController playerController = m_PlayerController;
			if (playerController == null)
			{
				playerController = PlayerController.FindPlayer(base.UserId);
			}
			if (playerController != null && playerController.PlayingRole == RoleType.Police)
			{
				InGameMinimap.Inst.ShowHighlight(m_Target, show: false);
			}
			m_Target = null;
		}
	}

	protected override void OnTrigger(Vector3 hitPos = default(Vector3), int numID = 0, int viewID = 0, int localNum = 0)
	{
		PlayerController playerController = PlayerController.FindPlayer(numID, localNum);
		if (playerController != null && IsArbiter)
		{
			StartCoroutine(FollowPlayer(playerController));
			if (playerController.Shifter.IsBall)
			{
				playerController.Shifter.RpcEndShapeShift();
				RpcBurst();
			}
			else
			{
				RpcFinishHit(hitPos, numID, viewID, localNum);
			}
		}
	}

	private void DoDestroy()
	{
		if (!m_IsNetworkDestroyed)
		{
			m_IsNetworkDestroyed = true;
			Invoke("SafeDestroy", 1.5f);
			if (m_BubbleViewObject != null)
			{
				UnityEngine.Object.Destroy(m_BubbleViewObject);
			}
		}
	}

	private void OnDamageAppliedWithSource(float damage, DamageSourceType source, BasePlayerController killer, float damageExcludeShield)
	{
		switch (source)
		{
		case DamageSourceType.Medkit:
		case DamageSourceType.Revive:
		case DamageSourceType.Adrenaline:
		case DamageSourceType.Genius:
		case DamageSourceType.BrokeCage:
			LocalBurst();
			break;
		}
	}

	public override void BatchUpdate()
	{
		if (!IsNetworkDestroyed)
		{
			if (!Fixing)
			{
				base.BatchUpdate();
				return;
			}
			CheckTargetState();
			UpdateLife();
		}
	}

	public override void BatchLateUpdate()
	{
		base.BatchLateUpdate();
		if (Fixing && m_BubbleMoveEnd)
		{
			base.transform.localPosition = m_FloatOffset;
		}
		if (!string.IsNullOrEmpty(base.UserId) && !m_IsNetworkDestroyed && m_Root.activeSelf != !base.IsReconnect)
		{
			m_Root.SetActive(!base.IsReconnect);
		}
	}

	private void CheckTargetState()
	{
		if (!(m_Target != null) || m_IsNetworkDestroyed)
		{
			return;
		}
		if (m_Target.FinalDeadOrEscaped || (m_Target.IsPuppet && m_Target.IsDying))
		{
			LocalBurst();
			return;
		}
		if (m_TargetState == TargetState.Caging && !m_Target.IsDying && !m_Target.BuffManager.ContainsBuff(m_CagedDebuffID))
		{
			LocalBurst();
			return;
		}
		if (!m_Target.IsDying && m_TargetState != TargetState.Caging)
		{
			m_TargetState = TargetState.Caging;
			m_Target.BuffManager.LocalClearBuffs(401);
			m_Target.BuffManager.CreateCorrelatedBuff(m_PlayerController, m_CagedDebuffID, BuffCorrelation.Talent, 131);
			m_UI.gameObject.SetActive(value: true);
			m_MaxLife = m_CagingDuration;
			m_CurrentLife = m_MaxLife;
			m_ProgressBar.SetProgress(m_CurrentLife, m_MaxLife);
		}
		else if (m_Target.IsDying && m_TargetState != TargetState.Killing)
		{
			m_TargetState = TargetState.Killing;
			m_UI.gameObject.SetActive(value: false);
			m_MaxLife = m_KillingDuration;
			m_CurrentLife = m_MaxLife;
			m_ProgressBar.SetProgress(m_CurrentLife, m_MaxLife);
		}
		if (!m_Target.Shifter.IsVehicle && !m_Target.Shifter.IsSkateBoard && !m_Target.Shifter.IsRabbit && !m_Target.Shifter.IsMissile)
		{
			m_Target.Shifter.EndShapeShift();
		}
		if (m_Target.OnVehichle != null)
		{
			m_Target.LocalExitVehicle();
		}
	}

	private void UpdateLife()
	{
		if (m_CurrentLife > 0f)
		{
			m_CurrentLife -= Time.deltaTime * m_LifeReducePerSecond;
		}
		OnLifeChanged();
	}

	private void OnLifeChanged()
	{
		m_ProgressBar.SetProgress(m_CurrentLife, m_MaxLife);
		if (!m_IsNetworkDestroyed && m_CurrentLife <= 0f && !IsInvoking("SafeDestroy") && IsArbiter)
		{
			RpcBurst();
		}
	}

	private void UpdateSpeedBuff()
	{
		m_PlayerController.BuffManager.CreateCorrelatedBuff(m_PlayerController, m_SpeedBuffID, BuffCorrelation.Talent, 133);
	}

	[PunRPC]
	protected override void LocalSetTargetPos(Vector3 targetPos, Vector3 nextTargetPos, Vector3 currentPos)
	{
		if (!Fixing)
		{
			base.LocalSetTargetPos(targetPos, nextTargetPos, currentPos);
		}
	}

	protected override void UpdateTime()
	{
		if (IsArbiter)
		{
			base.UpdateTime();
		}
	}

	protected override void OnTimeOut()
	{
		if (IsArbiter)
		{
			RpcBurst();
		}
	}

	private void RpcBurst()
	{
		m_PhotonView.RPC("LocalBurst", PhotonTargets.AllViaServer);
	}

	[PunRPC]
	private void LocalBurst()
	{
		if (this != null && !m_IsNetworkDestroyed)
		{
			Unfixing();
			m_Root.SetActive(value: false);
			m_UI.gameObject.SetActive(value: false);
			ShowHitEffect();
			DoDestroy();
		}
	}

	private void OnReSyncWrite(object data)
	{
		JsonObject obj = data as JsonObject;
		obj["pos"] = base.transform.position;
		obj["targetPos"] = m_TargetPos;
		obj["nextPos"] = m_NextTargetPos;
		obj["life"] = m_CurrentLife;
		obj["targetNumID"] = ((m_Target != null) ? UserId2NumId.Get(m_Target.UserId) : 0);
		obj["targetLocalNum"] = ((m_Target != null) ? m_Target.LocalNum : 0);
	}

	private void OnReSyncRead(object data)
	{
		JsonObject jsonObject = data as JsonObject;
		base.transform.position = jsonObject.As<Vector3>("pos");
		if (m_CurrentPos == Vector3.zero)
		{
			m_CurrentPos = base.transform.position;
			m_TargetPos = jsonObject.As<Vector3>("targetPos");
			m_NextTargetPos = jsonObject.As<Vector3>("nextPos");
		}
		int numID = jsonObject.AsInt("targetNumID");
		int localNum = jsonObject.AsInt("targetLocalNum");
		PlayerController playerController = PlayerController.FindPlayer(numID, localNum);
		if (playerController != null)
		{
			PlayerController playerController2 = playerController;
			playerController2.OnDamageAppliedWithSource = (UnityAction<float, DamageSourceType, BasePlayerController, float>)Delegate.Combine(playerController2.OnDamageAppliedWithSource, new UnityAction<float, DamageSourceType, BasePlayerController, float>(OnDamageAppliedWithSource));
			m_Target = playerController;
			FixedPlayer(playerController);
			m_CurrentLife = jsonObject.AsFloat("life");
			m_TargetState = ((!playerController.IsDying) ? TargetState.Caging : TargetState.Killing);
			m_MaxLife = (playerController.IsDying ? m_KillingDuration : m_CagingDuration);
			m_UI.gameObject.SetActive(m_TargetState == TargetState.Caging);
			m_ProgressBar.SetProgress(m_CurrentLife, m_MaxLife);
		}
		OnLifeChanged();
	}

	public static bool InBubble(PlayerController player)
	{
		if (player == null)
		{
			return false;
		}
		foreach (BubbleObject allBubbleObject in AllBubbleObjects)
		{
			if (allBubbleObject.Target != null && allBubbleObject.Target.UserId == player.UserId && allBubbleObject.Target.LocalNum == player.LocalNum)
			{
				return true;
			}
		}
		return false;
	}
}
