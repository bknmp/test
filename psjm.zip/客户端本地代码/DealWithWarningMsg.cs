using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;

[TaskName("处理预警消息")]
[TaskCategory("躲猫猫AI/条件")]
public class DealWithWarningMsg : Conditional
{
	public SharedGameObject warningTarget;

	public WarningDef warningDef;

	public override TaskStatus OnUpdate()
	{
		if (warningTarget.Value != null)
		{
			switch (warningDef)
			{
			case WarningDef.EscapeDoor:
				if (!(warningTarget.Value.GetComponent<EscapeDoor>() != null))
				{
					return TaskStatus.Failure;
				}
				return TaskStatus.Success;
			case WarningDef.Trap:
				if (!(warningTarget.Value.GetComponent<TrapObject>() != null) || IsDraggingEnemy())
				{
					return TaskStatus.Failure;
				}
				return TaskStatus.Success;
			case WarningDef.Vault:
				if (!(warningTarget.Value.GetComponent<VaultObject>() != null) || IsDraggingEnemy())
				{
					return TaskStatus.Failure;
				}
				return TaskStatus.Success;
			default:
				return TaskStatus.Success;
			}
		}
		return TaskStatus.Failure;
	}

	private bool IsDraggingEnemy()
	{
		return GetComponent<PoliceController>().IsDragging;
	}
}
