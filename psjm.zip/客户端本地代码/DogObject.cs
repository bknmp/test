using DG.Tweening;
using LightUI;
using LightUtility;
using SimpleJson;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class DogObject : PlaceableObject
{
	[Serializable]
	public class LevelProperties
	{
		public float m_ExtraMaxLife = 100f;

		public float m_PerceptionRange = 20f;

		public float m_PatrolRange = 2.5f;

		public float m_Attack = 18f;

		public float m_Scale = 1f;

		private float m_SqrPerceptionRange = -1f;

		public float SqrPerceptionRange
		{
			get
			{
				if (m_SqrPerceptionRange < 0f)
				{
					m_SqrPerceptionRange = m_PerceptionRange * m_PerceptionRange;
				}
				return m_SqrPerceptionRange;
			}
		}
	}

	private class AnimatorIDs
	{
		public readonly int speed = Animator.StringToHash("speed");

		public readonly int attack = Animator.StringToHash("attack");

		public readonly int die = Animator.StringToHash("die");
	}

	public enum TipStatus
	{
		None,
		Confused,
		Dispatch,
		Die,
		Chasing
	}

	private enum State
	{
		Dispatching,
		Patroling,
		Chasing,
		Attacking,
		Confusing
	}

	private struct AttackTarget
	{
		public PlayerController player;

		public DogObject dog;

		private float sqrDistance;

		public Vector3 position
		{
			get
			{
				if (dog != null)
				{
					return dog.transform.localPosition - dog.transform.forward * 0.5f;
				}
				if (player != null)
				{
					return player.transform.localPosition;
				}
				return Vector3.zero;
			}
		}

		public bool IsDead
		{
			get
			{
				if (dog != null)
				{
					return dog.IsDead;
				}
				if (player != null)
				{
					if (player.InStealth)
					{
						return false;
					}
					return !player.CanBeAttacked;
				}
				return true;
			}
		}

		public float SqrDistance
		{
			get
			{
				if (IsDead)
				{
					return float.MaxValue;
				}
				return sqrDistance;
			}
			set
			{
				sqrDistance = value;
			}
		}

		public float Radius
		{
			get
			{
				if (dog != null)
				{
					return dog.m_Radius;
				}
				if (player != null)
				{
					return player.Radius;
				}
				return 0f;
			}
		}

		public void ApplyDamage(DogObject attacker, int debuffId)
		{
			int numID = (attacker.m_PlayerController != null) ? UserId2NumId.Get(attacker.m_PlayerController.UserId) : 0;
			if (dog != null)
			{
				dog.RpcApplyDamage(attacker.m_LevelProperties[attacker.Level].m_Attack, numID, DamageSourceType.Dog, debuffId, attacker.m_PhotonView.viewID);
			}
			else if (player != null)
			{
				player.RpcApplyDamage(attacker.m_LevelProperties[attacker.Level].m_Attack, numID, DamageSourceType.Dog, debuffId);
			}
		}
	}

	public GameObject m_UI;

	public UIStateItem m_StatusTips;

	public Animator m_Animator;

	public UIProgressBar m_BloodBar;

	public GameObject m_AttackEffect;

	public GameObject m_SpawnEffect;

	public GameObject m_GainSpeedEffect;

	public float m_SpawnDistance = 1f;

	public float m_MaxLife = 100f;

	public float m_LifeReducePerSecond = 3f;

	public float m_AttackRange = 1f;

	public float m_AttackInterval = 1f;

	public float m_AttackDelay = 0.2f;

	public float m_RunSpeed = 4f;

	public float m_PatrolSpeed = 2f;

	public float m_MaxConfusingTime = 3f;

	public float m_SmoothSpeedFactor = 0.2f;

	public int m_DebuffID = 205;

	public float m_Radius = 0.3f;

	public float m_LockTargetTime = 2f;

	public float m_SqrMaxConfuseDistance = 6.25f;

	public LevelProperties[] m_LevelProperties;

	private int m_level;

	private float m_DefaultMaxLife;

	private AnimatorIDs m_AnimatorIDs = new AnimatorIDs();

	private State m_State;

	private Vector3 m_SpawnPosition;

	private Vector3 m_PatrolCenter;

	private Vector3 m_TargetDirection;

	private Vector3 m_GuardingOffset;

	private AttackTarget m_AttackTarget;

	private PlayerController m_PlayerController;

	private NavMeshAgent m_NavAgent;

	private float m_CurrentLife;

	private float m_LastAttackTime;

	private float m_LastConfusingTime;

	private float m_LastDamageTime;

	private float m_LastRequestOwnershipTime;

	private float m_SmoothSpeed;

	private bool m_LastVisible;

	private bool m_Hiding;

	private PhysicsVelocityCaculator m_PhysicsVelocityCaculator;

	private BuffManager m_BuffManager;

	private Coroutine m_CurrentTipsCoroutine;

	private RoleType m_RoleType;

	private DamagableTarget m_DamagableTarget;

	private float m_LastLockTargetTime;

	private NavMeshPath m_Path;

	private Vector3 m_LastPos;

	public static List<DogObject> AllDogObjects = new List<DogObject>();

	private bool m_Attracting;

	public bool IsDead => m_CurrentLife <= 0f;

	public float CurrentLife => m_CurrentLife;

	public RoleType PlayingRole => m_RoleType;

	public PlayerController PlayerController => m_PlayerController;

	public int Level => m_level;

	public bool IsLockTarget => InGameScene.Inst.GameTime - m_LastLockTargetTime < m_LockTargetTime;

	public bool OnHooking
	{
		get;
		set;
	}

	public BuffManager BuffManager => m_BuffManager;

	public bool Attracting
	{
		get
		{
			if (m_Attracting)
			{
				return GravityFieldObject.AllGravityFieldObjects.Count > 0;
			}
			return false;
		}
		set
		{
			m_Attracting = value;
		}
	}

	public DamagableTarget DamagableTarget => m_DamagableTarget;

	public Vector3 LinearVelocity => m_PhysicsVelocityCaculator.LinearVelocity;

	public bool IsHurt => m_CurrentLife < m_MaxLife;

	protected override void OnDestroy()
	{
		base.OnDestroy();
		AllDogObjects.Remove(this);
	}

	private new void Start()
	{
		m_PlayerController = PlayerController.FindPlayer(base.UserId);
		if (m_PlayerController != null)
		{
			m_level = 0;
			AllDogObjects.Add(this);
			m_RoleType = m_PlayerController.PlayingRole;
			m_NavAgent = GetComponent<NavMeshAgent>();
			m_PhysicsVelocityCaculator = GetComponent<PhysicsVelocityCaculator>();
			m_BuffManager = GetComponent<BuffManager>();
			m_DamagableTarget = GetComponent<DamagableTarget>();
			m_PreviewArea.SetActive(value: false);
			m_BuffManager.PlayingRole = PlayingRole;
			m_MaxLife = m_PlayerController.GetCardLevelGrowthResult(LocalResources.PlaceableTable.Get(base.ItemID).InGameStoreItemID);
			m_DefaultMaxLife = m_MaxLife;
			m_TargetDirection = (base.PreviewPosition - m_PlayerController.transform.localPosition).FlattenY().normalized;
			m_SpawnPosition = m_PlayerController.transform.localPosition.FlattenY() + m_SpawnDistance * m_TargetDirection;
			if (InGameScene.Inst.IsHighTile(base.PreviewPosition))
			{
				m_SpawnPosition = m_PlayerController.transform.localPosition;
			}
			m_PatrolCenter = base.PreviewPosition;
			m_CurrentLife = m_MaxLife;
			m_BloodBar.SetProgress(m_CurrentLife, m_MaxLife);
			UpdateScale();
			base.transform.SetParent(InGameScene.Inst.transform, worldPositionStays: true);
			base.transform.localPosition = m_SpawnPosition;
			LocalShowStatusTips(TipStatus.Dispatch, 1f);
			SpawnStartEffect();
			UpdateVisibility(force: true);
			GetComponent<FogViewObject>().Initialized(m_PlayerController);
		}
		base.Start();
	}

	public override void StartPreview()
	{
		m_UI.SetActive(value: false);
		m_Root.SetActive(value: false);
		m_PreviewArea.SetActive(value: true);
		base.transform.rotation = Quaternion.identity;
		base.StartPreview();
	}

	protected override bool CheckCardSkin()
	{
		bool num = base.CheckCardSkin();
		if (num)
		{
			m_Animator = m_Root.GetComponentInChildren<Animator>();
			m_GainSpeedEffect = m_Root.transform.Find("GainSpeedFX").gameObject;
		}
		return num;
	}

	public void SetPatrolPos(Vector3 pos)
	{
		m_PatrolCenter = pos;
	}

	private void UpdateScale()
	{
		m_Root.transform.DOScale(Vector3.one * m_LevelProperties[m_level].m_Scale, 0.2f);
	}

	private void InitNavigation()
	{
		if (!m_NavAgent.enabled)
		{
			if (NavMesh.SamplePosition(base.transform.localPosition, out NavMeshHit hit, 100f, m_NavAgent.areaMask) || NavMesh.FindClosestEdge(base.transform.localPosition, out hit, m_NavAgent.areaMask))
			{
				base.transform.localPosition = hit.position;
			}
			else
			{
				UnityEngine.Debug.LogWarning("Invalid NavMesh Position");
			}
			m_NavAgent.enabled = true;
			m_NavAgent.updateRotation = false;
			m_Path = new NavMeshPath();
		}
	}

	private void ReturnToDefaultState()
	{
		if (!IsLockTarget)
		{
			m_AttackTarget.dog = null;
			m_AttackTarget.player = null;
		}
		RpcShowStatusTips(TipStatus.None);
		m_State = State.Patroling;
		NewPatrolDestination();
		if (IsInvoking("ReturnToDefaultState"))
		{
			CancelInvoke("ReturnToDefaultState");
		}
	}

	private void NewPatrolDestination()
	{
		if (!IsDead && m_State == State.Patroling && m_NavAgent.enabled)
		{
			SetDestination(m_PatrolCenter + UnityEngine.Random.insideUnitCircle.ExpandZ().SwapYZ() * m_LevelProperties[m_level].m_PatrolRange);
		}
	}

	private void NewConfusingDestination()
	{
		if (!IsDead && !m_AttackTarget.IsDead && m_State == State.Confusing && m_NavAgent.enabled)
		{
			SetDestination(m_AttackTarget.position + UnityEngine.Random.insideUnitCircle.ExpandZ().SwapYZ() * m_LevelProperties[m_level].m_PatrolRange);
		}
	}

	public override void BatchUpdate()
	{
		if (!string.IsNullOrEmpty(base.UserId))
		{
			if (!OnHooking && PhotonNetwork.isMasterClient)
			{
				RequestOwnership();
			}
			UpdateVisibility();
			UpdateAI();
			UpdateLife();
			float magnitude = m_PhysicsVelocityCaculator.LinearVelocity.FlattenY().magnitude;
			m_SmoothSpeed = Mathf.Lerp(m_SmoothSpeed, magnitude, m_SmoothSpeedFactor);
			if (m_Animator.isActiveAndEnabled)
			{
				m_Animator.SetFloat(m_AnimatorIDs.speed, m_SmoothSpeed);
			}
			if (m_GainSpeedEffect != null)
			{
				m_GainSpeedEffect.SetActive(m_BuffManager.SpeedGain > 0.001f);
			}
			SlimeObject.CheckSlimeDamage(m_DamagableTarget);
			m_LastPos = base.transform.position;
		}
		base.BatchUpdate();
	}

	public void RequestOwnership()
	{
		if (!GameRuntime.WitnessMode && !m_PhotonView.isMine && InGameScene.Inst.GameTime - m_LastRequestOwnershipTime > 0.5f)
		{
			m_LastRequestOwnershipTime = InGameScene.Inst.GameTime;
			m_PhotonView.RequestOwnership();
		}
	}

	private void UpdateLife()
	{
		m_CurrentLife -= Time.deltaTime * m_LifeReducePerSecond;
		m_CurrentLife = Mathf.Max(m_CurrentLife, 0f);
		OnLifeChanged();
	}

	private void UpdateAI()
	{
		if (!PhotonNetwork.isMasterClient)
		{
			m_NavAgent.enabled = false;
			return;
		}
		if (OnHooking)
		{
			m_NavAgent.enabled = false;
			return;
		}
		InitNavigation();
		if (IsDead)
		{
			m_NavAgent.enabled = false;
			return;
		}
		float num = m_NavAgent.speed;
		switch (m_State)
		{
		case State.Dispatching:
			SetDestination(m_PatrolCenter);
			num = m_RunSpeed;
			if (!CheckChasingTarget(3f) && (IsTargetReached() || (base.transform.position - m_LastPos).sqrMagnitude < m_NavAgent.stoppingDistance))
			{
				m_State = State.Patroling;
			}
			break;
		case State.Patroling:
			num = m_PatrolSpeed;
			if (!CheckChasingTarget() && IsTargetReached() && !IsInvoking("NewPatrolDestination"))
			{
				Invoke("NewPatrolDestination", UnityEngine.Random.Range(0.5f, 2f));
			}
			break;
		case State.Chasing:
		{
			num = m_RunSpeed;
			UpdateChasingTarget();
			float num2 = (m_AttackTarget.player != null && m_AttackTarget.player.PlayingRole == RoleType.Boss) ? 4f : 1f;
			if (m_AttackTarget.SqrDistance < m_LevelProperties[m_level].SqrPerceptionRange * num2)
			{
				SetDestination(m_AttackTarget.position.FlattenY());
				bool flag = IsConfusing(m_AttackTarget);
				RpcShowStatusTips(flag ? TipStatus.Confused : TipStatus.Chasing);
				if (flag)
				{
					m_State = State.Confusing;
					m_LastConfusingTime = InGameScene.Inst.GameTime;
					break;
				}
				float num3 = m_AttackRange + m_AttackTarget.Radius;
				if (m_AttackTarget.SqrDistance < num3 * num3)
				{
					m_State = State.Attacking;
				}
			}
			else
			{
				m_PatrolCenter = base.transform.localPosition;
				ReturnToDefaultState();
			}
			break;
		}
		case State.Attacking:
		{
			num = m_RunSpeed;
			UpdateDistanceToChasingTarget();
			float num4 = m_AttackRange + m_AttackTarget.Radius;
			if (m_AttackTarget.SqrDistance < num4 * num4)
			{
				if (IsInvoking("ReturnToDefaultState"))
				{
					CancelInvoke("ReturnToDefaultState");
				}
				float num5 = (m_BuffManager.CooldownGain > 1.001f) ? (m_AttackInterval / (1f + m_BuffManager.CooldownGain)) : m_AttackInterval;
				if (IsConfusing(m_AttackTarget))
				{
					m_State = State.Confusing;
					m_LastConfusingTime = InGameScene.Inst.GameTime;
				}
				else if (InGameScene.Inst.GameTime - m_LastAttackTime > num5 && !m_BuffManager.IsSkillDisabled)
				{
					m_PhotonView.RPC("LocalAttack", PhotonTargets.All, m_AttackTarget.position);
					m_AttackTarget.ApplyDamage(this, m_DebuffID);
					m_LastAttackTime = InGameScene.Inst.GameTime;
				}
			}
			else if (!IsInvoking("ReturnToDefaultState"))
			{
				m_PatrolCenter = base.transform.localPosition;
				Invoke("ReturnToDefaultState", m_AttackDelay);
			}
			break;
		}
		case State.Confusing:
			num = m_PatrolSpeed;
			if (!m_AttackTarget.IsDead && InGameScene.Inst.GameTime - m_LastConfusingTime < m_MaxConfusingTime && IsConfusing(m_AttackTarget))
			{
				RpcShowStatusTips(TipStatus.Confused);
				if (InGameScene.Inst.GameTime - m_LastConfusingTime > 0.5f)
				{
					num = 0f;
				}
				if (!IsInvoking("NewConfusingDestination"))
				{
					Invoke("NewConfusingDestination", UnityEngine.Random.Range(0.5f, 1f));
				}
			}
			else
			{
				ReturnToDefaultState();
			}
			break;
		}
		num *= 1f + m_BuffManager.SpeedGain;
		m_NavAgent.speed = num;
		if (!m_AttackTarget.IsDead && m_State == State.Attacking)
		{
			m_TargetDirection = (m_AttackTarget.position - base.transform.localPosition).FlattenY().normalized;
		}
		else
		{
			Vector3 a = m_NavAgent.velocity.FlattenY();
			float magnitude = a.magnitude;
			if (magnitude > 0.1f)
			{
				m_TargetDirection = Vector3.Slerp(m_TargetDirection, a / magnitude, m_SmoothSpeedFactor);
			}
		}
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, Quaternion.LookRotation(m_TargetDirection), m_NavAgent.angularSpeed * Time.deltaTime);
	}

	private bool IsTargetReached()
	{
		if (!m_NavAgent.pathPending)
		{
			return m_NavAgent.remainingDistance < m_NavAgent.stoppingDistance;
		}
		return false;
	}

	private void UpdateDistanceToChasingTarget()
	{
		if (m_AttackTarget.player != null && !m_AttackTarget.player.CanBeAttacked)
		{
			m_AttackTarget.SqrDistance = float.MaxValue;
		}
		else
		{
			m_AttackTarget.SqrDistance = GetSqrDistanceToThisDog(m_AttackTarget.position);
		}
	}

	private bool CheckChasingTarget(float overrideRange = -1f)
	{
		if (m_AttackTarget.IsDead || !IsLockTarget)
		{
			m_AttackTarget = FindEnemyInRange(overrideRange);
		}
		if (!m_AttackTarget.IsDead && m_NavAgent.enabled)
		{
			SetDestination(m_AttackTarget.position.FlattenY());
			m_State = State.Chasing;
			return true;
		}
		return false;
	}

	private void UpdateChasingTarget(float overrideRange = -1f)
	{
		if (m_AttackTarget.IsDead || !IsLockTarget)
		{
			AttackTarget attackTarget = FindEnemyInRange(overrideRange);
			if (m_AttackTarget.IsDead || !IsConfusing(m_AttackTarget) || !(m_AttackTarget.SqrDistance < m_SqrMaxConfuseDistance) || !(attackTarget.SqrDistance > m_SqrMaxConfuseDistance))
			{
				m_AttackTarget = attackTarget;
			}
		}
	}

	private bool IsConfusing(AttackTarget target)
	{
		if (target.dog != null || target.player == null)
		{
			return false;
		}
		return IsConfusing(target.player);
	}

	private bool IsConfusing(PlayerController player)
	{
		if (player.PlayingRole == RoleType.Boss)
		{
			return false;
		}
		if (player.Hiding && !m_Hiding)
		{
			return true;
		}
		if (player.Flying)
		{
			return false;
		}
		if (player.LinearVelocity.magnitude > 2f)
		{
			return false;
		}
		if (ShapeShifter.IsShapeShiftingDefault(player.gameObject))
		{
			return true;
		}
		if (player.InStealth)
		{
			return true;
		}
		return false;
	}

	private AttackTarget FindEnemyInRange(float overrideRange = -1f)
	{
		float num = (overrideRange < 0f) ? m_LevelProperties[m_level].SqrPerceptionRange : (overrideRange * overrideRange);
		AttackTarget attackTarget = default(AttackTarget);
		float num2 = 0f;
		foreach (PlayerController allPlayersAndPuppet in PlayerController.AllPlayersAndPuppets)
		{
			if (!allPlayersAndPuppet.InSameTeam(PlayerController) && allPlayersAndPuppet.CanBeAttacked && !IsConfusing(allPlayersAndPuppet))
			{
				float num3 = (allPlayersAndPuppet.PlayingRole == RoleType.Boss) ? 4f : 1f;
				float sqrDistanceToThisDog = GetSqrDistanceToThisDog(allPlayersAndPuppet.transform.localPosition);
				if (sqrDistanceToThisDog < num * num3 && (num2 <= 0f || sqrDistanceToThisDog < num2))
				{
					num2 = sqrDistanceToThisDog;
					attackTarget.player = allPlayersAndPuppet;
				}
			}
		}
		foreach (DogObject allDogObject in AllDogObjects)
		{
			if (!allDogObject.PlayerController.InSameTeam(PlayerController) && !allDogObject.IsDead)
			{
				float sqrDistanceToThisDog2 = GetSqrDistanceToThisDog(allDogObject.transform.localPosition);
				if (sqrDistanceToThisDog2 < num && (num2 <= 0f || sqrDistanceToThisDog2 < num2))
				{
					num2 = sqrDistanceToThisDog2;
					attackTarget.dog = allDogObject;
				}
			}
		}
		if (attackTarget.dog != null)
		{
			attackTarget.player = null;
		}
		attackTarget.SqrDistance = num2;
		return attackTarget;
	}

	private float GetSqrDistanceToThisDog(Vector3 pos)
	{
		Vector3 vector = pos - base.transform.localPosition;
		float num = vector.FlattenY().sqrMagnitude;
		if (Mathf.Abs(vector.y) > 1.5f)
		{
			num = Mathf.Max(25f, num);
		}
		return num;
	}

	private void UpdateVisibility(bool force = false)
	{
		m_Hiding = InGameScene.Inst.IsHidable(base.transform.localPosition);
		bool flag = false;
		flag = (PlayerController.Inst.InSameTeam(PlayerController) || InGameScene.Inst.GameTime - m_LastDamageTime < 1f || InGameFogOfWar.Inst.GetPositionVisibility(base.transform.localPosition) > 0.1f);
		if ((flag != m_LastVisible) | force)
		{
			m_UI.GetComponent<CanvasGroup>().DOFade(flag ? 1f : 0f, 0.2f);
			m_BuffManager.m_BuffDisplay.gameObject.SetActive(flag);
			m_LastVisible = flag;
		}
	}

	private void LockTheTarget(DogObject dog, PlayerController player)
	{
		if ((!(dog == null) || !(player == null)) && !IsLockTarget)
		{
			m_AttackTarget.dog = dog;
			m_AttackTarget.player = player;
			m_LastLockTargetTime = InGameScene.Inst.GameTime;
		}
	}

	public void RpcApplyDamage(float damage, int numID, DamageSourceType source, int param = 0, int attackerDogPhotonViewID = 0)
	{
		m_PhotonView.RPC("LocalApplyDamage", PhotonTargets.AllViaServer, damage, numID, source, param, attackerDogPhotonViewID);
	}

	public void RpcShowStatusTips(TipStatus status, float duration = -1f)
	{
		if (m_StatusTips.State != (int)status)
		{
			m_PhotonView.RPC("LocalShowStatusTips", PhotonTargets.All, status, duration);
		}
	}

	private void OnLifeChanged()
	{
		m_BloodBar.SetProgress(m_CurrentLife, m_MaxLife);
		if (m_CurrentLife <= 0f && !IsInvoking("DestroySelf"))
		{
			if (PhotonNetwork.isMasterClient)
			{
				m_PhotonView.RPC("LocalDie", PhotonTargets.All);
			}
			Invoke("DestroySelf", 1.5f);
		}
	}

	private void TryLevelUp()
	{
		if (m_level < m_LevelProperties.Length - 1)
		{
			m_level++;
			m_MaxLife = m_DefaultMaxLife + m_LevelProperties[m_level].m_ExtraMaxLife;
			UpdateScale();
		}
	}

	[PunRPC]
	private void LocalApplyDamage(float damage, int numID, DamageSourceType source, int param = 0, int attackerDogPhotonViewID = 0)
	{
		if (this == null || m_BuffManager == null)
		{
			return;
		}
		PlayerController playerController = PlayerController.FindPlayer(NumId2UserId.Get(numID));
		switch (source)
		{
		case DamageSourceType.Medkit:
			return;
		case DamageSourceType.Projectile:
		case DamageSourceType.ProjectileCritical:
		case DamageSourceType.Saber:
		case DamageSourceType.ThrownBullet:
		case DamageSourceType.Missile:
			LockTheTarget(null, playerController);
			break;
		case DamageSourceType.Grenade:
			m_BuffManager.CreateCorrelatedBuff(playerController, param, BuffCorrelation.Grenade);
			LockTheTarget(null, playerController);
			break;
		case DamageSourceType.Adrenaline:
			m_BuffManager.LocalClearAllDeBuffs();
			m_BuffManager.CreateCorrelatedBuff(playerController, param, BuffCorrelation.Adrenaline);
			TryLevelUp();
			break;
		case DamageSourceType.Leap:
			m_BuffManager.CreateCorrelatedBuff(playerController, param, BuffCorrelation.Talent, 122);
			LockTheTarget(null, playerController);
			break;
		case DamageSourceType.Dog:
		{
			PhotonView photonView = PhotonView.Find(attackerDogPhotonViewID);
			if (photonView != null)
			{
				DogObject component = photonView.GetComponent<DogObject>();
				if (component != null)
				{
					LockTheTarget(component, null);
				}
			}
			break;
		}
		}
		if (playerController.IsLocalPlayer && !playerController.IsDying && playerController.BuffManager.BloodSucking > 0f && playerController.m_BattleProperties.life < playerController.m_BattleProperties.maxLife)
		{
			float damage2 = (0f - damage) * playerController.BuffManager.BloodSucking;
			playerController.RpcApplyDamage(damage2, numID, DamageSourceType.BloodSucking);
		}
		m_LastDamageTime = InGameScene.Inst.GameTime;
		m_CurrentLife -= damage;
		m_CurrentLife = Mathf.Clamp(m_CurrentLife, 0f, m_MaxLife);
		OnLifeChanged();
	}

	[PunRPC]
	private void LocalAttack(Vector3 pos)
	{
		PoolSpawner.Spawn(m_AttackEffect).transform.localPosition = pos + m_AttackEffect.transform.localPosition;
		m_Animator.SetTrigger(m_AnimatorIDs.attack);
		if (PlayerController.Inst != null && PlayerController != null && PlayerController.Inst.InSameTeam(PlayerController))
		{
			InGameTipsUI.Inst.ShowNoticeWarning(this, 0.5f);
		}
	}

	[PunRPC]
	private void LocalDie()
	{
		LocalShowStatusTips(TipStatus.Die, 1f);
		m_BuffManager.LocalClearAllBuffs();
		m_UI.SetActiveFading(active: false, 0.2f, 1f);
		m_Root.SetActiveFading(active: false, 0.5f, 1f);
		m_Animator.SetTrigger(m_AnimatorIDs.die);
	}

	[PunRPC]
	private void LocalShowStatusTips(TipStatus status, float duration = -1f)
	{
		if (m_CurrentTipsCoroutine != null)
		{
			StopCoroutine(m_CurrentTipsCoroutine);
		}
		if (duration > 0f)
		{
			m_CurrentTipsCoroutine = StartCoroutine(DoShowStatusTips(status, duration));
		}
		else
		{
			m_StatusTips.State = (int)status;
		}
		if (status == TipStatus.Confused && PlayerController.Inst.InSameTeam(PlayerController) && m_AttackTarget.player != null && m_AttackTarget.player.InStealth)
		{
			InGameTipsUI.Inst.ShowNoticeWarning(this, 0.5f);
		}
	}

	private IEnumerator DoShowStatusTips(TipStatus status, float duration)
	{
		m_StatusTips.State = (int)status;
		yield return Yielders.GetWaitForSeconds(duration);
		m_StatusTips.State = 0;
	}

	private void SpawnStartEffect()
	{
		PoolSpawner.Spawn(m_SpawnEffect).transform.localPosition = base.transform.localPosition + m_SpawnEffect.transform.localPosition;
	}

	private void DestroySelf()
	{
		if (PhotonNetwork.isMasterClient)
		{
			PhotonNetwork.Destroy(m_PhotonView);
		}
	}

	private void SetDestination(Vector3 targetPosition)
	{
		m_NavAgent.destination = targetPosition;
		if (!m_NavAgent.pathEndPosition.Equals(m_NavAgent.destination) && NavMesh.CalculatePath(base.transform.position, targetPosition, -1, m_Path))
		{
			m_NavAgent.SetPath(m_Path);
		}
	}

	private void OnReSyncWrite(object data)
	{
		JsonObject obj = data as JsonObject;
		obj["pos"] = base.transform.position;
		obj["rot"] = base.transform.rotation.eulerAngles;
		obj["life"] = m_CurrentLife;
		obj["maxLife"] = m_MaxLife;
		obj["level"] = m_level;
	}

	private void OnReSyncRead(object data)
	{
		JsonObject jsonObject = data as JsonObject;
		base.transform.position = jsonObject.As<Vector3>("pos");
		base.transform.rotation = Quaternion.Euler(jsonObject.As<Vector3>("rot"));
		m_CurrentLife = jsonObject.AsFloat("life");
		m_MaxLife = jsonObject.AsFloat("maxLife");
		m_level = jsonObject.AsInt("level");
		OnLifeChanged();
		UpdateScale();
	}
}
