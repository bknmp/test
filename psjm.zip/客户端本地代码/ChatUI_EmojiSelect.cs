using LightUI;
using UnityEngine;

internal class ChatUI_EmojiSelect
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiatorGrid;

	private TextAsset m_TextAsset;

	public void Bind(CommonDataCollection args)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (m_TextAsset == null)
		{
			m_TextAsset = ResManager.Load<TextAsset>("emojiNames");
		}
		string[] array = m_TextAsset.text.Split('\n');
		for (int i = 1; i < array.Length; i++)
		{
			if (!string.IsNullOrEmpty(array[i]))
			{
				string[] array2 = array[i].Split('\t');
				commonDataCollection[commonDataCollection.ArraySize]["emoji"] = array2[0];
			}
		}
		m_TemplateInitiatorGrid.Args = commonDataCollection;
	}

	private void OnDestroy()
	{
		if (m_TextAsset != null)
		{
			ResManager.Unload(m_TextAsset);
			m_TextAsset = null;
		}
	}
}
