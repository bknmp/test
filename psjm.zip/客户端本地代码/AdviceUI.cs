using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AdviceUI : MonoBehaviour
{
	public InputField m_Advice;

	public void SubmitAdvice()
	{
		string text = m_Advice.text.Trim();
		if (!string.IsNullOrEmpty(text))
		{
			LocalPlayerDatabase.SubmitAdvice(text, delegate
			{
				m_Advice.text = "";
				UILobby.Current.ShowTips(Localization.TipsAdviceSent);
				GetComponent<UIPopup>().GoBack();
			});
		}
		else
		{
			UILobby.Current.ShowTips(Localization.TipsAdviceEmpty);
		}
	}
}
