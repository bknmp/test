using DG.Tweening;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBomb : Skill
{
	private float m_ExplosionRadius;

	private Queue<Vector3> m_Positions = new Queue<Vector3>();

	private float m_LastTime;

	private List<Vector3> m_LastPositions = new List<Vector3>();

	private bool m_cancel;

	private float ExplosionRadius
	{
		get
		{
			if (m_ExplosionRadius == 0f)
			{
				m_ExplosionRadius = base.Properties.prefabs[0].GetComponent<GrenadeObject>().m_ExposionRadius;
			}
			return m_ExplosionRadius;
		}
	}

	public override float CooldownRatio
	{
		get
		{
			if (!base.IsPlaying || m_cancel)
			{
				return base.CooldownRatio;
			}
			return 1f - (Time.time - m_StartTime);
		}
	}

	public override float Duration => base.Properties.duration;

	public override void InitializeStartParams(out object param1, out object param2)
	{
		Vector3 vector = m_Owner.transform.localPosition.FlattenY();
		Vector3[] array = GenerateRandomPostions(vector, base.Properties.attackRadius);
		param1 = vector;
		param2 = array;
	}

	public override void Update()
	{
		m_Owner.GetComponent<BossObject>().m_ProgressBar.SetProgress(base.PlayingProgress, 1f);
		base.Update();
	}

	public override void OnStart(object param1, object param2)
	{
		if (base.IsPlaying)
		{
			m_StartTime = Time.time - Duration + 0.4f;
			m_cancel = true;
			return;
		}
		m_cancel = false;
		base.Center = (Vector3)param1;
		Vector3[] positions = (Vector3[])param2;
		base.OnStart(param1, param2);
		m_Positions.Clear();
		AddBombs(positions);
		m_Owner.SkillLauncher.ShowSkillBorder(show: true, base.Center, base.Properties.attackRadius);
		m_Owner.GetComponent<BossObject>().m_ProgressBar.gameObject.SetActiveFading(active: true, 0f);
		m_Owner.StartCoroutine(StartJet());
	}

	protected override void PlayAnimation()
	{
		if (!string.IsNullOrEmpty(base.Properties.animationName))
		{
			m_Owner.m_Animator.SetTrigger(base.Properties.animationName);
		}
	}

	public override void OnHit()
	{
	}

	protected override void OnEnd()
	{
		base.OnEnd();
		m_Owner.SkillLauncher.ShowSkillBorder(show: false, base.Center, base.Properties.attackRadius);
		m_Owner.GetComponent<BossObject>().m_ProgressBar.gameObject.SetActive(value: false);
	}

	public void AddBombs(Vector3[] positions)
	{
		foreach (Vector3 item in positions)
		{
			m_Positions.Enqueue(item);
		}
		m_LastPositions.Clear();
		m_LastPositions.AddRange(positions);
	}

	private IEnumerator StartJet()
	{
		float interval = 0.177f;
		yield return Yielders.GetWaitForSeconds(1f);
		m_LastTime = Time.time;
		while (Duration - Time.time + m_StartTime > 1f && !m_cancel && !m_Owner.IsDying)
		{
			if (m_Positions.Count > 0)
			{
				Vector3 pos = m_Positions.Dequeue();
				SpawnBomb(pos);
				yield return Yielders.GetWaitForSeconds(interval);
			}
			else if (m_Owner.m_PhotonView.isMine)
			{
				if (Time.time - m_LastTime > Random.Range(0.8f, 1.2f))
				{
					m_LastTime = Time.time;
					m_Owner.SkillLauncher.RpcOnAddBombs(this, GenerateRandomPostions(base.Center, base.Properties.attackRadius));
				}
				else
				{
					yield return Yielders.EndOfFrame;
				}
			}
			else
			{
				yield return Yielders.EndOfFrame;
			}
		}
		m_Owner.m_Animator.SetTrigger(base.Properties.animationName + "_end");
	}

	private void SpawnBomb(Vector3 pos)
	{
		Vector3 forward = m_Owner.transform.forward;
		PlaceableObject component = PoolSpawner.Spawn(base.Properties.prefabs[0].gameObject).GetComponent<PlaceableObject>();
		component.transform.position = base.Center;
		component.transform.rotation = Quaternion.LookRotation(forward);
		component.UserId = m_Owner.UserId;
		component.PreviewPosition = pos;
		component.ItemID = 0;
		component.PreviewDirection = forward;
	}

	public void PlayJet(int type)
	{
		Vector3 forward = m_Owner.transform.forward;
		GameObject gameObject = PoolSpawner.Spawn(base.Properties.prefabs[1].gameObject);
		Vector3 position = m_Owner.SkillLauncher.m_Muzzles[type].position;
		gameObject.transform.position = position;
		gameObject.transform.rotation = Quaternion.LookRotation(forward);
		gameObject.transform.DOLocalMoveY(8f, 0.9f).SetEase(Ease.OutCubic);
		if (base.Properties.effect != null)
		{
			PoolSpawner.Spawn(base.Properties.effect).transform.position = position;
		}
	}

	private Vector3[] GenerateRandomPostions(Vector3 center, float radius)
	{
		List<Vector3> list = new List<Vector3>();
		float radius2 = radius + 0.5f - ExplosionRadius;
		float num = 2f;
		int num2 = 3;
		float extraParam = base.Properties.extraParam1;
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer != null && allPlayer.PlayingRole != m_Owner.PlayingRole && allPlayer.CanBeAttacked && Vector3.Distance(allPlayer.transform.position.FlattenY(), m_Owner.transform.position.FlattenY()) < radius)
			{
				Vector3 vector = allPlayer.transform.position.FlattenY();
				vector += allPlayer.LinearVelocity.FlattenY() * extraParam;
				vector.x += Random.Range(0f - num, num);
				vector.z += Random.Range(0f - num, num);
				vector = FixPosition(vector, center, radius2);
				TryAddNewNoOverLapPos(list, vector, ExplosionRadius);
			}
		}
		int num3 = 100;
		while (num3-- > 0 && list.Count < num2)
		{
			Vector3 randomPositon = GetRandomPositon(center, radius2);
			TryAddNewNoOverLapPos(list, randomPositon, ExplosionRadius);
		}
		while (list.Count < num2)
		{
			list.Add(GetRandomPositon(center, radius2));
		}
		return list.ToArray();
	}

	private bool TryAddNewNoOverLapPos(List<Vector3> list, Vector3 pos, float radius)
	{
		float num = radius * base.Properties.extraParam2;
		bool flag = true;
		foreach (Vector3 item in list)
		{
			if (Vector3.Distance(item, pos) < num)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			foreach (Vector3 lastPosition in m_LastPositions)
			{
				if (Vector3.Distance(lastPosition, pos) < num)
				{
					flag = false;
					break;
				}
			}
		}
		if (flag)
		{
			list.Add(pos);
		}
		return flag;
	}

	private Vector3 FixPosition(Vector3 pos, Vector3 center, float radius)
	{
		if (Vector3.Distance(pos, center) > radius)
		{
			pos = center + (pos - center).normalized * radius;
		}
		return pos;
	}

	private Vector3 GetRandomPositon(Vector3 center, float radius)
	{
		float f = Random.Range(0f, 360f);
		float num = Mathf.Sqrt(Random.Range(0f, 1f)) * radius;
		return new Vector3(num * Mathf.Sin(f), 0f, num * Mathf.Cos(f)) + center;
	}
}
