using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class CommonRewardItem : MonoBehaviour
{
	public UIStateItem m_SkinEffect;

	public CardPieceProcessBar m_CardPieceProcessBar;

	public Text m_Tips;
}
