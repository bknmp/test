using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Broadcast : MonoBehaviour
{
	public UITemplateInitiator m_BroadcastDisplay;

	private const int OnceCount = 10;

	private const int MaxShowCount = 1;

	private const int ArraySize = 2;

	private const float ReqInterval = 1f;

	private List<BroadcastInfo> m_Broadcasts;

	private List<BroadcastInfo> m_ShowBroadcasts;

	private bool[] m_News;

	private int[] m_LastIDs;

	private float[] m_LastTimes;

	private GameObject m_Root;

	public static Broadcast Inst;

	private void Awake()
	{
		Inst = this;
		BroadcastUtility.onNewBroadcast = (Delegates.ObjectCallback<BroadcastType>)Delegate.Combine(BroadcastUtility.onNewBroadcast, new Delegates.ObjectCallback<BroadcastType>(OnNewBroadcast));
		m_Broadcasts = new List<BroadcastInfo>();
		m_ShowBroadcasts = new List<BroadcastInfo>();
		m_News = new bool[2];
		m_LastIDs = new int[2];
		m_LastTimes = new float[2];
		m_Root = m_BroadcastDisplay.gameObject;
	}

	private void OnDestroy()
	{
		if (Inst == this)
		{
			Inst = null;
		}
		m_Broadcasts.Clear();
		m_ShowBroadcasts.Clear();
		m_News = null;
		m_LastIDs = null;
		m_LastTimes = null;
		BroadcastUtility.onNewBroadcast = (Delegates.ObjectCallback<BroadcastType>)Delegate.Remove(BroadcastUtility.onNewBroadcast, new Delegates.ObjectCallback<BroadcastType>(OnNewBroadcast));
	}

	private int TypeToIndex(BroadcastType type)
	{
		return (int)(type - 1);
	}

	private BroadcastType IndexToType(int index)
	{
		return (BroadcastType)(index + 1);
	}

	private void OnNewBroadcast(BroadcastType type)
	{
		m_News[TypeToIndex(type)] = true;
	}

	private void UpdateBroadcastDisplay()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < m_ShowBroadcasts.Count; i++)
		{
			commonDataCollection[i]["broadcast"].val = m_ShowBroadcasts[i];
		}
		m_BroadcastDisplay.Args = commonDataCollection;
	}

	private void ShowBroadcast(BroadcastInfo broadcast)
	{
		broadcast.endTime = UtcTimeStamp.Now + Mathf.Max(5, broadcast.endTime - UtcTimeStamp.Now);
		m_ShowBroadcasts.Add(broadcast);
		UpdateBroadcastDisplay();
	}

	public void RemoveBroadcast(int id)
	{
		int num = m_ShowBroadcasts.FindIndex((BroadcastInfo a) => a.id == id);
		if (num != -1)
		{
			m_ShowBroadcasts.RemoveAt(num);
			UpdateBroadcastDisplay();
		}
	}

	private void SetRootActive(bool active)
	{
		if (m_Root.activeSelf != active)
		{
			m_Root.SetActive(active);
		}
	}

	private void Update()
	{
		if (!SendGiftUI.IsShowing && (UILobby.Current.CurrentPopup() != null || BoxOpenUI.IsShowing || NewbiePage.IsShowing || HideBroadcastUI.m_HideCount > 0 || VideoUI.IsShowing || CardLotteryUI.PlayingAnimiation || SupplyPage_SupplyBoxItem.Opening || LobbyNewbieDirector.IsGuiding || PassLotteryBoardcastHandler.IsShow || LimitLotteryStoreUI.IsShowing))
		{
			SetRootActive(active: false);
			return;
		}
		SetRootActive(active: true);
		for (int i = 0; i < 2; i++)
		{
			if (m_News[i] && Time.time - m_LastTimes[i] >= 1f)
			{
				m_News[i] = false;
				m_LastTimes[i] = Time.time;
				BroadcastUtility.RefreshBroadcast(IndexToType(i), m_LastIDs[i], 10, delegate(HttpResponseBroadcast res)
				{
					if (res.broadcasts.Length != 0)
					{
						m_Broadcasts.AddRange(res.broadcasts);
						m_Broadcasts = (from a in m_Broadcasts
							orderby a.priority descending
							select a).ToList();
						int num2 = TypeToIndex((BroadcastType)res.broadcasts[0].channel);
						int id = res.broadcasts[res.broadcasts.Length - 1].id;
						m_LastIDs[num2] = id;
						if (res.broadcasts.Length >= 10)
						{
							m_News[num2] = true;
						}
						if (m_Broadcasts.Exists((BroadcastInfo a) => a.priority > 9999))
						{
							m_Broadcasts = (from a in m_Broadcasts
								orderby a.startTime descending
								select a).ToList();
							m_ShowBroadcasts.Clear();
							m_BroadcastDisplay.Args.Clear();
						}
					}
				});
			}
		}
		for (int j = 0; j < m_Broadcasts.Count; j++)
		{
			if (m_ShowBroadcasts.Count >= 1)
			{
				break;
			}
			BroadcastInfo broadcast = m_Broadcasts[j];
			m_Broadcasts.RemoveAt(j);
			ShowBroadcast(broadcast);
		}
		int num = 0;
		while (num < m_ShowBroadcasts.Count)
		{
			if (m_ShowBroadcasts[num].endTime <= UtcTimeStamp.Now)
			{
				m_ShowBroadcasts.RemoveAt(num);
				UpdateBroadcastDisplay();
			}
			else
			{
				num++;
			}
		}
	}
}
