using LightUtility;
using UnityEngine;

public class AudioItemData : MonoBehaviour
{
	public AudioItem Item;
}
