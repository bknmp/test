using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChangeCharacterUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_ThiefTemplateInitiator;

	public UITemplateInitiator m_PoliceTemplateInitiator;

	public GameObject m_Tips;

	public UIStateItem m_PoliceTitle;

	public GameObject m_WeekendDoubleTips;

	public UIStateItem m_BGState;

	public Text m_WeekendDoubleTipsText;

	public void Bind(CommonDataCollection args)
	{
		bool flag = (GameRuntime.IsMapBoss || GameRuntime.IsMapBattleRoyale) && GameRuntime.PlayingRole == RoleType.Police && GameModePage.IsShowing;
		List<CharacterInfo> list = new List<CharacterInfo>();
		List<CharacterInfo> list2 = new List<CharacterInfo>();
		List<CharacterInfo> list3 = new List<CharacterInfo>();
		List<CharacterInfo> list4 = new List<CharacterInfo>();
		bool flag2 = LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Normal;
		bool flag3 = LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Team && GameRuntime.IsCustomRoom && GameRuntime.IsMapBoss;
		foreach (CharacterInfo item in LocalResources.CharacterTable)
		{
			if (flag3 && GameRuntime.CurrentRoom.config.Mode() != RoomMode.Classic && item.Role == RoleType.Boss)
			{
				list3.Add(item);
			}
			if (item.IsVisibleInUI && (((LobbyScene.Inst.CurrentMode == LobbyScene.Mode.None || LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Normal || GameRuntime.PlayingRole == item.Role) | flag) || (LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Team && (GameRuntime.IsCustomRoom || GameRuntime.IsUnionBattle)) || GameRuntime.IsTrainingMode))
			{
				if (CharacterUtility.IsOwnCharacter(item.Id))
				{
					if (item.Role == RoleType.Thief)
					{
						list.Add(item);
					}
					else if (!flag3)
					{
						list3.Add(item);
					}
				}
				else if (flag2 || CharacterFreeUtility.IsCharacterFree)
				{
					if (item.Role == RoleType.Thief)
					{
						list2.Add(item);
					}
					else if (!flag3)
					{
						list4.Add(item);
					}
				}
			}
		}
		list.Sort((CharacterInfo a, CharacterInfo b) => a.Rank.CompareTo(b.Rank));
		list2.Sort((CharacterInfo a, CharacterInfo b) => a.Rank.CompareTo(b.Rank));
		list3.Sort((CharacterInfo a, CharacterInfo b) => a.Rank.CompareTo(b.Rank));
		list4.Sort((CharacterInfo a, CharacterInfo b) => a.Rank.CompareTo(b.Rank));
		m_PoliceTitle.State = ((GameRuntime.IsCustomRoom && GameRuntime.IsMapBoss) ? 1 : 0);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		foreach (CharacterInfo item2 in list)
		{
			CommonDataCollection commonDataCollection2 = new CommonDataCollection();
			commonDataCollection2["Id"] = item2.Id;
			commonDataCollection2["Icon"] = item2.Icon;
			commonDataCollection2["Name"] = item2.Name;
			commonDataCollection2["Own"] = true;
			commonDataCollection.Array.Add(commonDataCollection2);
		}
		foreach (CharacterInfo item3 in list2)
		{
			CommonDataCollection commonDataCollection3 = new CommonDataCollection();
			commonDataCollection3["Id"] = item3.Id;
			commonDataCollection3["Icon"] = item3.Icon;
			commonDataCollection3["Name"] = item3.Name;
			commonDataCollection3["Own"] = false;
			commonDataCollection.Array.Add(commonDataCollection3);
		}
		CommonDataCollection commonDataCollection4 = new CommonDataCollection();
		foreach (CharacterInfo item4 in list3)
		{
			CommonDataCollection commonDataCollection5 = new CommonDataCollection();
			commonDataCollection5["Id"] = item4.Id;
			commonDataCollection5["Icon"] = item4.Icon;
			commonDataCollection5["Name"] = item4.Name;
			commonDataCollection5["Own"] = true;
			commonDataCollection4.Array.Add(commonDataCollection5);
		}
		foreach (CharacterInfo item5 in list4)
		{
			CommonDataCollection commonDataCollection6 = new CommonDataCollection();
			commonDataCollection6["Id"] = item5.Id;
			commonDataCollection6["Icon"] = item5.Icon;
			commonDataCollection6["Name"] = item5.Name;
			commonDataCollection6["Own"] = false;
			commonDataCollection4.Array.Add(commonDataCollection6);
		}
		m_ThiefTemplateInitiator.Args = commonDataCollection;
		m_ThiefTemplateInitiator.gameObject.SetActive(commonDataCollection.ArraySize > 0);
		m_PoliceTemplateInitiator.Args = commonDataCollection4;
		m_PoliceTemplateInitiator.gameObject.SetActive(commonDataCollection4.ArraySize > 0 && !flag);
		if (m_ThiefTemplateInitiator.gameObject.activeSelf && m_PoliceTemplateInitiator.gameObject.activeSelf)
		{
			m_BGState.State = 0;
		}
		else
		{
			m_BGState.State = 1;
		}
		if (m_Tips != null)
		{
			m_Tips.SetActive(flag);
			if (flag)
			{
				switch (GameRuntime.MapType)
				{
				case MapType.TypeBoss:
					m_Tips.GetComponent<Text>().text = Localization.TipsBossNeedThief;
					break;
				case MapType.TypeBattleRoyale:
				case MapType.TypeBattleRoyaleTeam:
					m_Tips.GetComponent<Text>().text = Localization.TipsBattleRoyaleNeedThief;
					break;
				}
			}
		}
		if (m_WeekendDoubleTips != null)
		{
			bool flag4 = !GameRuntime.IsCustomRoom && !GameRuntime.IsMapBattleRoyale && !GameRuntime.IsMapBoss;
			ActivityLobbyInfo activityInfo = new ActivityLobbyInfo();
			Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.WEEKEND_DOUBLE, ActivityCollectionType.ANNIVERSART_ACTIVITY, out activityInfo);
			m_WeekendDoubleTips.SetActive(flag4 && activityByActivityTypeAndCollectionType != null);
			if (m_WeekendDoubleTipsText != null && activityByActivityTypeAndCollectionType != null)
			{
				m_WeekendDoubleTipsText.text = activityInfo.Desc;
			}
		}
	}
}
