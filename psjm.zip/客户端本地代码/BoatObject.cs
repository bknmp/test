using UnityEngine;

public class BoatObject : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
