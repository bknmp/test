using LightUI;
using LightUtility;
using UnityEngine.UI;

public class DailyBoxUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Image m_Frame;

	public Image m_Icon;

	public Text m_Amount;

	public UITipsDialogController m_Tips;

	private DropItem m_ItemInfo;

	public void Bind(CommonDataCollection args)
	{
		m_ItemInfo = (args["DropItem"].val as DropItem);
		m_Frame.sprite = SpriteSource.Inst.Find(m_ItemInfo.Frame);
		m_Icon.sprite = SpriteSource.Inst.Find(m_ItemInfo.Icon);
		string str = args["Amount"].val as string;
		m_Amount.text = "x" + str;
		if (!string.IsNullOrEmpty(m_ItemInfo.BubbleTips))
		{
			m_Tips.m_Tips = m_ItemInfo.BubbleTips;
		}
	}
}
