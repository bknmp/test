using ExitGames.Client.Photon;
using UnityEngine;

internal static class CustomTypes
{
	public static readonly byte[] memVector3 = new byte[12];

	public static readonly byte[] memVector2 = new byte[8];

	public static readonly byte[] memQuarternion = new byte[16];

	public static readonly byte[] memPlayer = new byte[4];

	private const int damageExtraInfoSize = 42;

	public static readonly byte[] memDamageExtraInfo = new byte[42];

	public static readonly byte[] memPropConfig = new byte[8];

	private const int projectileExtraInfoSize = 16;

	public static readonly byte[] memProjectileExtraInfo = new byte[16];

	internal static void Register()
	{
		PhotonPeer.RegisterType(typeof(Vector2), 87, SerializeVector2, DeserializeVector2);
		PhotonPeer.RegisterType(typeof(Vector3), 86, SerializeVector3, DeserializeVector3);
		PhotonPeer.RegisterType(typeof(Quaternion), 81, SerializeQuaternion, DeserializeQuaternion);
		PhotonPeer.RegisterType(typeof(PhotonPlayer), 80, SerializePhotonPlayer, DeserializePhotonPlayer);
		PhotonPeer.RegisterType(typeof(DamageExtraInfo), 68, SerializeDamageExtraInfo, DeserializeDamageExtraInfo);
		PhotonPeer.RegisterType(typeof(SupplementBoxSpawner_BR.PropConfig), 83, SerializePropConfig, DeserializePropConfig);
		PhotonPeer.RegisterType(typeof(ProjectileExtraInfo), 70, SerializeProjectileExtraInfo, DeserializeProjectileExtraInfo);
	}

	private static short SerializeVector3(StreamBuffer outStream, object customobject)
	{
		Vector3 vector = (Vector3)customobject;
		int targetOffset = 0;
		lock (memVector3)
		{
			byte[] array = memVector3;
			Protocol.Serialize(vector.x, array, ref targetOffset);
			Protocol.Serialize(vector.y, array, ref targetOffset);
			Protocol.Serialize(vector.z, array, ref targetOffset);
			outStream.Write(array, 0, 12);
		}
		return 12;
	}

	private static object DeserializeVector3(StreamBuffer inStream, short length)
	{
		Vector3 vector = default(Vector3);
		lock (memVector3)
		{
			inStream.Read(memVector3, 0, 12);
			int offset = 0;
			Protocol.Deserialize(out vector.x, memVector3, ref offset);
			Protocol.Deserialize(out vector.y, memVector3, ref offset);
			Protocol.Deserialize(out vector.z, memVector3, ref offset);
		}
		return vector;
	}

	private static short SerializeVector2(StreamBuffer outStream, object customobject)
	{
		Vector2 vector = (Vector2)customobject;
		lock (memVector2)
		{
			byte[] array = memVector2;
			int targetOffset = 0;
			Protocol.Serialize(vector.x, array, ref targetOffset);
			Protocol.Serialize(vector.y, array, ref targetOffset);
			outStream.Write(array, 0, 8);
		}
		return 8;
	}

	private static object DeserializeVector2(StreamBuffer inStream, short length)
	{
		Vector2 vector = default(Vector2);
		lock (memVector2)
		{
			inStream.Read(memVector2, 0, 8);
			int offset = 0;
			Protocol.Deserialize(out vector.x, memVector2, ref offset);
			Protocol.Deserialize(out vector.y, memVector2, ref offset);
		}
		return vector;
	}

	private static short SerializeQuaternion(StreamBuffer outStream, object customobject)
	{
		Quaternion quaternion = (Quaternion)customobject;
		lock (memQuarternion)
		{
			byte[] array = memQuarternion;
			int targetOffset = 0;
			Protocol.Serialize(quaternion.w, array, ref targetOffset);
			Protocol.Serialize(quaternion.x, array, ref targetOffset);
			Protocol.Serialize(quaternion.y, array, ref targetOffset);
			Protocol.Serialize(quaternion.z, array, ref targetOffset);
			outStream.Write(array, 0, 16);
		}
		return 16;
	}

	private static object DeserializeQuaternion(StreamBuffer inStream, short length)
	{
		Quaternion quaternion = default(Quaternion);
		lock (memQuarternion)
		{
			inStream.Read(memQuarternion, 0, 16);
			int offset = 0;
			Protocol.Deserialize(out quaternion.w, memQuarternion, ref offset);
			Protocol.Deserialize(out quaternion.x, memQuarternion, ref offset);
			Protocol.Deserialize(out quaternion.y, memQuarternion, ref offset);
			Protocol.Deserialize(out quaternion.z, memQuarternion, ref offset);
		}
		return quaternion;
	}

	private static short SerializePhotonPlayer(StreamBuffer outStream, object customobject)
	{
		int iD = ((PhotonPlayer)customobject).ID;
		lock (memPlayer)
		{
			byte[] array = memPlayer;
			int targetOffset = 0;
			Protocol.Serialize(iD, array, ref targetOffset);
			outStream.Write(array, 0, 4);
			return 4;
		}
	}

	private static object DeserializePhotonPlayer(StreamBuffer inStream, short length)
	{
		int value;
		lock (memPlayer)
		{
			inStream.Read(memPlayer, 0, length);
			int offset = 0;
			Protocol.Deserialize(out value, memPlayer, ref offset);
		}
		if (PhotonNetwork.networkingPeer.mActors.ContainsKey(value))
		{
			return PhotonNetwork.networkingPeer.mActors[value];
		}
		return null;
	}

	private static short SerializeDamageExtraInfo(StreamBuffer outStream, object customobject)
	{
		DamageExtraInfo damageExtraInfo = (DamageExtraInfo)customobject;
		int targetOffset = 0;
		lock (memDamageExtraInfo)
		{
			byte[] array = memDamageExtraInfo;
			Protocol.Serialize(damageExtraInfo.explosionPos.x, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.explosionPos.y, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.explosionPos.z, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.explosionRadius, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.playerPos.x, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.playerPos.y, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.playerPos.z, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.rrt, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.cardID, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.critical, array, ref targetOffset);
			Protocol.Serialize(damageExtraInfo.time, array, ref targetOffset);
			outStream.Write(array, 0, 42);
		}
		return 42;
	}

	private static object DeserializeDamageExtraInfo(StreamBuffer inStream, short length)
	{
		DamageExtraInfo damageExtraInfo = default(DamageExtraInfo);
		lock (memDamageExtraInfo)
		{
			inStream.Read(memDamageExtraInfo, 0, 42);
			int offset = 0;
			Vector3 explosionPos = default(Vector3);
			Protocol.Deserialize(out explosionPos.x, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out explosionPos.y, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out explosionPos.z, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out float value, memDamageExtraInfo, ref offset);
			Vector3 playerPos = default(Vector3);
			Protocol.Deserialize(out playerPos.x, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out playerPos.y, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out playerPos.z, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out int value2, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out int value3, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out short value4, memDamageExtraInfo, ref offset);
			Protocol.Deserialize(out float value5, memDamageExtraInfo, ref offset);
			damageExtraInfo.explosionPos = explosionPos;
			damageExtraInfo.explosionRadius = value;
			damageExtraInfo.playerPos = playerPos;
			damageExtraInfo.rrt = value2;
			damageExtraInfo.cardID = value3;
			damageExtraInfo.critical = value4;
			damageExtraInfo.time = value5;
		}
		return damageExtraInfo;
	}

	private static short SerializePropConfig(StreamBuffer outStream, object customobject)
	{
		SupplementBoxSpawner_BR.PropConfig propConfig = (SupplementBoxSpawner_BR.PropConfig)customobject;
		lock (memPropConfig)
		{
			byte[] array = memPropConfig;
			int targetOffset = 0;
			Protocol.Serialize(propConfig.cardId, array, ref targetOffset);
			Protocol.Serialize(propConfig.num, array, ref targetOffset);
			outStream.Write(array, 0, 8);
		}
		return 8;
	}

	private static object DeserializePropConfig(StreamBuffer inStream, short length)
	{
		SupplementBoxSpawner_BR.PropConfig propConfig = new SupplementBoxSpawner_BR.PropConfig();
		lock (memPropConfig)
		{
			inStream.Read(memPropConfig, 0, 8);
			int offset = 0;
			Protocol.Deserialize(out propConfig.cardId, memPropConfig, ref offset);
			Protocol.Deserialize(out propConfig.num, memPropConfig, ref offset);
			return propConfig;
		}
	}

	private static short SerializeProjectileExtraInfo(StreamBuffer outStream, object customobject)
	{
		ProjectileExtraInfo projectileExtraInfo = (ProjectileExtraInfo)customobject;
		int targetOffset = 0;
		lock (memProjectileExtraInfo)
		{
			byte[] array = memProjectileExtraInfo;
			Protocol.Serialize(projectileExtraInfo.weaponID, array, ref targetOffset);
			Protocol.Serialize(projectileExtraInfo.reloadTime, array, ref targetOffset);
			Protocol.Serialize(projectileExtraInfo.fireTime, array, ref targetOffset);
			Protocol.Serialize(projectileExtraInfo.magazineRemained, array, ref targetOffset);
			outStream.Write(array, 0, 16);
		}
		return 16;
	}

	private static object DeserializeProjectileExtraInfo(StreamBuffer inStream, short length)
	{
		ProjectileExtraInfo projectileExtraInfo = default(ProjectileExtraInfo);
		lock (memProjectileExtraInfo)
		{
			inStream.Read(memProjectileExtraInfo, 0, 16);
			int offset = 0;
			Protocol.Deserialize(out int value, memProjectileExtraInfo, ref offset);
			Protocol.Deserialize(out float value2, memProjectileExtraInfo, ref offset);
			Protocol.Deserialize(out float value3, memProjectileExtraInfo, ref offset);
			Protocol.Deserialize(out int value4, memProjectileExtraInfo, ref offset);
			projectileExtraInfo.weaponID = value;
			projectileExtraInfo.reloadTime = value2;
			projectileExtraInfo.fireTime = value3;
			projectileExtraInfo.magazineRemained = value4;
		}
		return projectileExtraInfo;
	}
}
