using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CommentUIBinder
{
	public enum Type
	{
		Card = 1,
		Character = 3
	}

	public UIDataBinder m_Host;

	public Text m_Name;

	public Button m_LeftButton;

	public Button m_RightButton;

	public UIDataScrollView m_DataScrollView;

	public InputField m_InputField;

	public Button m_PublishButton;

	public CommentUI m_CommentUI;

	public GameObject m_Empty;

	public UIStateItem m_Title;

	public MultiTargetGraphicButton m_CoolDown;

	public Text m_CoolDownText;

	public Button m_CloseButton;

	private int m_Id;

	private bool m_Requesting;

	private int m_Start;

	private int m_End;

	private int HOT_ITEM_NUM = 3;

	private int m_type;

	private List<int> m_IdList;

	private string m_CoolDownFormat;

	private Coroutine m_Coroutine;

	private const float PublishCommentCoolDownTime = 180f;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_CoolDownFormat))
		{
			m_CoolDownFormat = m_CoolDownText.text;
		}
		m_InputField.text = "";
		m_Id = args["id"];
		m_type = args["type"];
		m_Title.State = m_type - 1;
		m_CommentUI.SetInfo(m_type, m_Id);
		if (m_type == 1)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_Id);
			m_Name.text = inGameStoreInfo.FullName;
			m_IdList = CardConfigEditPage_CardContentBinder.m_CardIdSortList;
			m_Name.rectTransform.anchoredPosition = new Vector2(0f, -285f);
		}
		else if (m_type == 3)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_Id);
			m_Name.text = characterInfo.Name;
			m_IdList = CharacterUI_PageSelectCharacter.CharacterList;
			m_Name.rectTransform.anchoredPosition = new Vector2(0f, -359f);
		}
		UpdatePublishButtonState();
		m_DataScrollView.ClearItems();
		m_Requesting = false;
		m_Host.EventProxy(m_DataScrollView, "OnRequestData");
		m_Host.EventProxy(m_LeftButton, "OnClickLeftBtn");
		m_Host.EventProxy(m_RightButton, "OnClickRightBtn");
		m_Host.EventProxy(m_PublishButton, "OnClickPublishComment");
		m_Host.EventProxy(m_CoolDown, "OnPublishCoolDown");
		m_Host.EventProxy(m_CloseButton, "OnCloseBtnClick");
	}

	public void OnRequestData(int start, int end)
	{
		if (!m_Requesting)
		{
			m_Requesting = true;
			m_Start = Mathf.Max(start, 0);
			m_Start = ((m_Start > HOT_ITEM_NUM) ? (m_Start - 1) : m_Start);
			m_End = end;
			m_End = ((m_End > HOT_ITEM_NUM) ? (m_End - 1) : m_End);
			if (m_Start < m_End)
			{
				HttpRequestComment httpRequestComment = new HttpRequestComment();
				httpRequestComment.start = m_Start;
				httpRequestComment.end = m_End;
				httpRequestComment.type = m_type;
				httpRequestComment.param = m_Id;
				GameHttpManager.Inst.SendNoWait(httpRequestComment, OnResponse);
			}
		}
	}

	private void OnResponse(HttpResponseComment onResponse)
	{
		if (onResponse.comments.Length + m_Start <= 0)
		{
			m_Empty.SetActive(value: true);
		}
		else
		{
			m_Empty.SetActive(value: false);
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < onResponse.comments.Length; i++)
			{
				int num = commonDataCollection.ArraySize;
				if (i + m_Start == HOT_ITEM_NUM)
				{
					commonDataCollection[num]["state"] = 0;
					num++;
				}
				commonDataCollection[num]["state"] = 1;
				commonDataCollection[num]["hot"] = (i + m_Start < HOT_ITEM_NUM);
				commonDataCollection[num]["roleID"] = onResponse.comments[i].roleID;
				commonDataCollection[num]["name"] = onResponse.comments[i].name;
				commonDataCollection[num]["commentID"] = onResponse.comments[i].commentID;
				commonDataCollection[num]["comment"] = onResponse.comments[i].comment;
				commonDataCollection[num]["likeNum"] = onResponse.comments[i].likeNum;
				commonDataCollection[num]["liked"] = onResponse.comments[i].liked;
				commonDataCollection[num]["cardCommentUI"].val = m_CommentUI;
			}
			m_DataScrollView.AddItems(commonDataCollection.Array);
		}
		m_Requesting = false;
	}

	private void UpdatePublishButtonState()
	{
		if (m_Coroutine != null)
		{
			m_Host.StopCoroutine(m_Coroutine);
		}
		float lastPublishTime = m_CommentUI.GetLastPublishTime(m_type, m_Id);
		if (lastPublishTime > 0f && Time.realtimeSinceStartup - lastPublishTime < 180f)
		{
			m_Coroutine = m_Host.StartCoroutine(UpdateCoolDownState(lastPublishTime));
			return;
		}
		m_CoolDown.gameObject.SetActive(value: false);
		m_PublishButton.gameObject.SetActive(value: true);
	}

	private IEnumerator UpdateCoolDownState(float lastTime)
	{
		m_CoolDown.gameObject.SetActive(value: true);
		m_PublishButton.gameObject.SetActive(value: false);
		bool cooling = true;
		while (cooling)
		{
			float num = Time.realtimeSinceStartup - lastTime;
			cooling = (num < 180f);
			int num2 = Mathf.CeilToInt(Mathf.Max(0f, 180f - num));
			m_CoolDownText.text = string.Format(m_CoolDownFormat, num2);
			yield return new WaitForSeconds(1f);
		}
		m_CoolDown.gameObject.SetActive(value: false);
		m_PublishButton.gameObject.SetActive(value: true);
	}

	public void OnClickLeftBtn()
	{
		m_InputField.text = "";
		m_CommentUI.TrySentCommentLikeData();
		int num = ArrayUtility.IndexOf(m_IdList.ToArray(), m_Id);
		num = ((num != 0) ? (num - 1) : (m_IdList.Count - 1));
		m_Host.Args = WrapperCommentData(m_IdList[num], m_type);
	}

	public void OnClickRightBtn()
	{
		m_InputField.text = "";
		m_CommentUI.TrySentCommentLikeData();
		int num = ArrayUtility.IndexOf(m_IdList.ToArray(), m_Id);
		num = ((num != m_IdList.Count - 1) ? (num + 1) : 0);
		CommonDataCollection commonDataCollection3 = m_Host.Args = (m_Host.Args = WrapperCommentData(m_IdList[num], m_type));
	}

	public void OnClickPublishComment()
	{
		if (string.IsNullOrEmpty(m_InputField.text.Replace(" ", "")))
		{
			UILobby.Current.ShowTips(Localization.CommentEmpty);
			m_InputField.text = "";
		}
		else if (!CanPublishComment())
		{
			UILobby.Current.ShowTips(Localization.CantPublishComment);
			m_InputField.text = "";
		}
		else if (AntiAddictionUtility.CheckCanSendInput())
		{
			HttpRequestPublishComment httpRequestPublishComment = new HttpRequestPublishComment();
			httpRequestPublishComment.comment = m_InputField.text;
			httpRequestPublishComment.type = m_type;
			httpRequestPublishComment.param = m_Id;
			GameHttpManager.Inst.Send(httpRequestPublishComment, delegate
			{
				m_InputField.text = "";
				UILobby.Current.ShowTips(Localization.WaitForVerify);
			});
		}
	}

	private bool CanPublishComment()
	{
		if (m_type == 1)
		{
			return CardUtility.IsOwned(m_Id);
		}
		if (m_type == 3)
		{
			return CharacterUtility.IsOwnCharacter(m_Id);
		}
		return false;
	}

	public void OnPublishCoolDown()
	{
		UILobby.Current.ShowTips(Localization.PublishCommentCoolDown);
	}

	public static CommonDataCollection WrapperCommentData(int id, int type)
	{
		return new CommonDataCollection
		{
			["id"] = id,
			["type"] = type
		};
	}

	public void OnCloseBtnClick()
	{
		LobbyScene.Inst.ShowCampPanels(show: false);
		m_Host.GetComponent<UIPopup>().GoBack();
	}
}
