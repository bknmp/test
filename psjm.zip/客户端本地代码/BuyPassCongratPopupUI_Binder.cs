using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class BuyPassCongratPopupUI_Binder
{
	public UIDataBinder m_Host;

	public Button m_GoGet;

	public Button m_Close;

	public UIDataScrollView m_UnlockItemsScrollView;

	private bool m_FromRecharge;

	private Animation m_Animation;

	public void Bind(CommonDataCollection args)
	{
		m_FromRecharge = args["fromRechargeUI"];
		UnityEngine.Debug.Log(m_FromRecharge);
		m_Host.EventProxy(m_GoGet, "OnGoGetClicked");
		m_Host.EventProxy(m_Close, "OnCloseClicked");
		CommonDataCollection unlockItemList = PassUtility.WrapAllRewards(0, PassUtility.GetMaxLevel(), PassUtility.RewardDataType.Paid);
		SetUnlockItemList(unlockItemList);
		UIDataEvents.Inst.InvokeEvent("OnPassStoreRedPointChanged");
		m_Animation = m_GoGet.gameObject.transform.parent.gameObject.GetComponent<Animation>();
		if ((bool)m_Animation)
		{
			m_Animation.Play();
		}
	}

	public void OnGoGetClicked()
	{
		if (m_FromRecharge)
		{
			UILobby.Current.GoBack();
		}
		UILobby.Current.GoBack();
		UILobbyElement uILobbyElement = JumpModuleManager.Inst.DoJump(JumpModule.PassUI);
		JumpModuleManager.Inst.JumpTabPage(uILobbyElement.transform);
	}

	public void OnCloseClicked()
	{
		if (m_FromRecharge)
		{
			UILobby.Current.GoBack();
		}
		UILobby.Current.GoBack();
	}

	public void SetUnlockItemList(CommonDataCollection args)
	{
		m_UnlockItemsScrollView.SetItems(args.Array);
		m_UnlockItemsScrollView.m_TemplateInitiator.m_Template.GetComponent<TweenScale>().enabled = false;
	}
}
