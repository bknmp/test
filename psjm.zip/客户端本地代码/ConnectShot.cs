using LightUtility;
using UnityEngine;

public class ConnectShot : MonoBehaviour
{
	public float m_ShotSpeed;

	public GameObject m_HitFX;

	public GameObject m_Root;

	private float m_LastDist;

	private Vector3 m_Speed;

	private PlayerController m_PlayerController;

	private PlayerController m_Target;

	private Transform m_TargetAnchor;

	private Connect m_Connect;

	private GameObject m_BoomInst;

	private bool m_Finished;

	private void Start()
	{
		m_Finished = false;
	}

	private void Update()
	{
		if (m_Target != null)
		{
			Moving();
			m_Root.SetActive(m_PlayerController.IsVisible || m_Target.IsVisible);
			if (!m_Finished && m_PlayerController.IsMine && IsHited())
			{
				RpcFinish();
			}
		}
		UpdateBoomFX();
	}

	public void SetTarget(PlayerController master, PlayerController target)
	{
		m_PlayerController = master;
		m_Target = target;
		m_TargetAnchor = GerAnchor(m_Target);
		base.transform.position = GerAnchor(m_PlayerController).position;
		m_Connect = (Connect)m_PlayerController.SkillManager.RoleSkill;
	}

	private Transform GerAnchor(PlayerController player)
	{
		return player.m_Animator.transform.Find("Bip001");
	}

	private void RpcFinish()
	{
		m_Connect.RpcShotFinish();
	}

	public void Finish()
	{
		m_Finished = true;
		Invoke("Hit", 0.5f / m_Speed.magnitude);
		Invoke("DoDestroy", 2f);
	}

	private void Hit()
	{
		if (m_HitFX != null && m_Target != null && m_Target.IsVisible)
		{
			m_BoomInst = PoolSpawner.Spawn(m_HitFX);
		}
		m_Target = null;
		m_Root.SetActive(value: false);
	}

	private void DoDestroy()
	{
		m_TargetAnchor = null;
		m_BoomInst = null;
		PoolSpawner.DeSpawn(base.gameObject);
	}

	private void Moving()
	{
		Vector3 position = base.transform.position;
		Vector3 lhs = m_TargetAnchor.position - position;
		Vector3 vector = lhs.normalized * Mathf.Clamp01(m_LastDist);
		Vector3 vector2 = (Mathf.Max(m_Target.LinearVelocity.magnitude + 2f, m_ShotSpeed) * vector - m_Speed) * Mathf.Min(Time.deltaTime * 20f, 1f);
		m_Speed += vector2;
		m_LastDist = lhs.FlattenY().magnitude;
		position = Vector3.Lerp(position, position + m_Speed, Time.deltaTime);
		base.transform.rotation = Quaternion.Slerp(base.transform.rotation, Quaternion.LookRotation(vector), 900f * Time.deltaTime);
		base.transform.position = position;
	}

	private void UpdateBoomFX()
	{
		if (m_BoomInst != null)
		{
			Vector3 normalized = (m_PlayerController.transform.position - m_TargetAnchor.position).FlattenY().normalized;
			Vector3 position = m_TargetAnchor.position + Mathf.Abs(m_HitFX.transform.position.z) * normalized;
			position.y += m_HitFX.transform.position.y;
			m_BoomInst.transform.position = position;
			m_BoomInst.transform.rotation = Quaternion.LookRotation(normalized);
		}
	}

	public bool IsHited()
	{
		return (m_TargetAnchor.position - base.transform.localPosition).FlattenY().magnitude <= 0.5f;
	}
}
