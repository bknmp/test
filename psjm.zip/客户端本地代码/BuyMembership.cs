using LightUI;
using UnityEngine.UI;

public class BuyMembership
{
	public UIDataBinder m_Host;

	public Button m_ButtonBuy;

	public UIStateItem m_IconAndName;

	public UITemplateInitiator m_TemplateInitiator;

	public Text m_Title;

	public UIPopup m_SubscribeMembership;

	public static int m_MembershipID;

	public void Bind(CommonDataCollection args)
	{
		m_IconAndName.State = m_MembershipID;
		m_Host.EventProxy(m_ButtonBuy, "OnBuyButtonClicked");
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int num = 0;
		foreach (GoodsInfo item in LocalResources.GoodsTable)
		{
			if (item.SpecialParam != null && item.SpecialParam.Length != 0 && item.SpecialParam[0] == m_MembershipID)
			{
				commonDataCollection[num]["goodsID"] = item.Id;
				commonDataCollection[num]["ID"] = num;
				if (num == 0)
				{
					BuyMembershipItem.globalSelected = item.Id;
				}
				num++;
			}
		}
		m_Title.text = $"{(MembershipUtility.IsInTime(m_MembershipID) ? Localization.Renew : Localization.Subscribe)}{LocalResources.MembershipInfos.Get(m_MembershipID).Name}";
		m_TemplateInitiator.Args = commonDataCollection;
	}

	public void OnBuyButtonClicked()
	{
		bool renew = MembershipUtility.IsInTime(m_MembershipID);
		MembershipUtility.SubscribeMembership(BuyMembershipItem.globalSelected, delegate
		{
			UILobby.Current.GoBack();
			SubscribeMembership.membershipID = m_MembershipID;
			SubscribeMembership.renew = renew;
			SubscribeMembership.count = LocalResources.GoodsTable.Get(BuyMembershipItem.globalSelected).SpecialParam[1];
			UILobby.Current.Popup(m_SubscribeMembership);
		});
	}
}
