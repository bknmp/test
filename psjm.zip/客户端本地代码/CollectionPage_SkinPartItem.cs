using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_SkinPartItem
{
	public UIDataBinder m_Host;

	public Text m_Personality;

	public Text m_NameText;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_NotCollected;

	public GameObject m_NotOwnedText;

	public Button m_Button;

	public Button m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeason;

	private string m_PersonalityFormat;

	public void Bind(CommonDataCollection args)
	{
		HttpResponsePlayerInfo assets = (HttpResponsePlayerInfo)args["playerInfo"].val;
		int id = args["itemID"];
		if (m_PersonalityFormat == null)
		{
			m_PersonalityFormat = m_Personality.text;
		}
		DropItem dropItem = LocalResources.DropItemTable.Find(id);
		bool flag = CollectionUtility.OwnedForever(dropItem, assets);
		SkinInfo skinInfo = CharacterUtility.GetSkinInfo(dropItem.TypeParam);
		int limitedEdition = skinInfo.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		m_NameText.text = skinInfo.Name;
		if (flag)
		{
			m_Personality.text = string.Format(m_PersonalityFormat, dropItem.Personality);
			m_Personality.gameObject.SetActive(value: true);
			m_NotCollected.SetActive(value: false);
			m_NotOwnedText.SetActive(value: false);
		}
		else
		{
			m_Personality.gameObject.SetActive(value: false);
			m_NotCollected.SetActive(value: true);
			m_NotOwnedText.SetActive(value: true);
		}
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_QualityBG.State = dropItem.Quality;
		m_Effect.State = dropItem.Quality;
		m_Effect.gameObject.SetActive(flag);
		m_Host.EventProxy(m_Button, "OnButtonClick");
	}

	public void OnButtonClick()
	{
		if (m_ButtonGain.gameObject.activeSelf)
		{
			m_ButtonGain.onClick.Invoke();
		}
	}
}
