using LightUtility;

public class BaseCardSkinInfo : IdBased
{
	public int CardID;

	public string Name;

	public string Prefabs;

	public int TypeParam;

	public string AttachmentName;

	public int DropId;

	public string AnimationClip;

	public string Effect;

	public float PreviewZOffset;

	public string GainTips;

	public int SellStartTimePC;

	public int SellEndTimePC;

	public int MobileTimeOffset;

	public int LimitedEdition;

	public string Description;

	public string[] Tags;

	public int[] TagsQuality;

	public string[] TagsDesc;

	public bool IsSpecialMatInLobby;

	private string m_Icon;

	public int SellStartTime => SellStartTimePC + MobileTimeOffset;

	public int SellEndTime => SellEndTimePC + MobileTimeOffset;

	public string Icon
	{
		get
		{
			if (m_Icon == null)
			{
				if (DropId > 0)
				{
					DropItem dropItem = LocalResources.DropItemTable.Find(DropId);
					if (dropItem != null)
					{
						m_Icon = dropItem.Icon;
					}
				}
				else
				{
					InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(CardID);
					if (inGameStoreInfo != null)
					{
						InGameStoreType type = inGameStoreInfo.Type;
						if (type == InGameStoreType.WeaponUpgrade)
						{
							BaseCardSkinInfo typeParamSkin = GetTypeParamSkin();
							if (typeParamSkin != null)
							{
								int num = CardID - typeParamSkin.CardID + 1;
								string icon = typeParamSkin.Icon;
								m_Icon = icon.Remove(icon.Length - 1, 1) + num;
							}
						}
						else
						{
							DropItem dropItem2 = FindDropItemWithTypeIdAndType();
							if (dropItem2 != null)
							{
								m_Icon = dropItem2.Icon;
							}
						}
					}
				}
			}
			return m_Icon;
		}
	}

	protected virtual BaseCardSkinInfo GetTypeParamSkin()
	{
		return LocalResources.CardSkinTable.Find(TypeParam);
	}

	protected virtual DropItem FindDropItemWithTypeIdAndType()
	{
		return LocalResources.FindDropItemFromTypeIdAndType(Id, DropItemType.CardSkin);
	}
}
