public class ActivityUtility
{
	public static bool IsActivityExist(int activityId)
	{
		return ActivityLobby.GetActivityById(activityId) != null;
	}
}
