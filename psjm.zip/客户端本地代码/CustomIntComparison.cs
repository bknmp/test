using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using BehaviorDesigner.Runtime.Tasks.Basic.Math;

public class CustomIntComparison : Conditional
{
	public IntComparison.Operation operation;

	public SharedInt num;

	protected int CompareValue;

	public override TaskStatus OnUpdate()
	{
		switch (operation)
		{
		case IntComparison.Operation.LessThan:
			if (CompareValue >= num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case IntComparison.Operation.LessThanOrEqualTo:
			if (CompareValue > num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case IntComparison.Operation.EqualTo:
			if (CompareValue != num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case IntComparison.Operation.NotEqualTo:
			if (CompareValue == num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case IntComparison.Operation.GreaterThanOrEqualTo:
			if (CompareValue < num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		case IntComparison.Operation.GreaterThan:
			if (CompareValue <= num.Value)
			{
				return TaskStatus.Failure;
			}
			return TaskStatus.Success;
		default:
			return TaskStatus.Failure;
		}
	}
}
