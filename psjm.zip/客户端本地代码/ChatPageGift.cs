using LightUI;

internal class ChatPageGift
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	private int m_Start;

	private int m_End;

	private bool m_Requesting;

	public void Bind(CommonDataCollection args)
	{
		m_Requesting = false;
		m_Start = 0;
		m_End = 0;
		ChatPageGift_GiftItemTemplate.m_RecordID = 0;
		m_DataScrollView.ClearItems();
		m_Host.EventProxy(m_DataScrollView, "OnRequestData");
	}

	public void OnRequestData(int start, int end)
	{
		if (!m_Requesting)
		{
			m_Requesting = true;
			m_Start = start;
			m_End = end;
			if (m_Start < m_End)
			{
				GiftUtility.GetGiftRecordsByIndex(m_Start, m_End, OnResponseRank);
			}
		}
	}

	private void OnResponseRank(int num)
	{
		m_Requesting = false;
		if (num > 0)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = m_Start; i < m_Start + num; i++)
			{
				commonDataCollection[i - m_Start]["index"] = i;
			}
			m_DataScrollView.AddItems(commonDataCollection.Array);
		}
	}
}
