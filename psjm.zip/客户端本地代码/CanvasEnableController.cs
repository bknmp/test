using LightUI;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Canvas))]
public class CanvasEnableController : UIEventListener
{
	private Canvas m_Canvas;

	private bool m_Stopped;

	private Dictionary<Transform, UIPopup> m_PopupDic = new Dictionary<Transform, UIPopup>();

	private Dictionary<Transform, UIPage> m_PageDic = new Dictionary<Transform, UIPage>();

	public static bool Disable
	{
		get;
		set;
	}

	private new void Awake()
	{
		base.Awake();
		m_Canvas = GetComponent<Canvas>();
	}

	public override void OnEnterUI()
	{
		m_Stopped = true;
	}

	public override void OnExitUI()
	{
		Stop();
	}

	private void LateUpdate()
	{
		Transform parentPage = GetParentPage();
		if (parentPage != null)
		{
			if (Disable || UILobby.Current.CurrentPopup() != null || HasNextActiveSiblingPage(parentPage))
			{
				Stop();
				m_Stopped = true;
			}
			else if (m_Stopped)
			{
				Play();
				m_Stopped = false;
			}
			return;
		}
		Transform parentPopup = GetParentPopup();
		if (parentPopup != null)
		{
			if (Disable || HasNextActiveSiblingPopup(parentPopup) || UILobby.Current.CurrentPopup() == null)
			{
				Stop();
				m_Stopped = true;
			}
			else if (m_Stopped)
			{
				Play();
				m_Stopped = false;
			}
		}
		else if (Disable || HasNonIgnorablePage() || UILobby.Current.CurrentPopup() != null)
		{
			Stop();
			m_Stopped = true;
		}
		else if (m_Stopped)
		{
			Play();
			m_Stopped = false;
		}
	}

	private void Stop()
	{
		if (m_Canvas != null)
		{
			m_Canvas.enabled = false;
		}
	}

	private void Play()
	{
		if (m_Canvas != null)
		{
			m_Canvas.enabled = true;
		}
	}

	private Transform GetParentPage()
	{
		Transform transform = base.transform;
		while (transform != null && UILobby.Current != null && transform.parent != UILobby.Current.m_PageContainer)
		{
			transform = transform.parent;
		}
		return transform;
	}

	private Transform GetParentPopup()
	{
		Transform transform = base.transform;
		while (transform != null && UILobby.Current != null && transform.parent != UILobby.Current.m_PopupContainer)
		{
			transform = transform.parent;
		}
		return transform;
	}

	private bool HasNonIgnorablePage()
	{
		if (UILobby.Current.CurrentPage() == null)
		{
			return false;
		}
		return true;
	}

	private bool HasNextActiveSiblingPopup(Transform node)
	{
		for (int i = node.GetSiblingIndex() + 1; i < node.parent.childCount; i++)
		{
			Transform child = node.parent.GetChild(i);
			if (child.gameObject.activeSelf)
			{
				if (!m_PopupDic.ContainsKey(child))
				{
					m_PopupDic.Add(child, child.GetComponent<UIPopup>());
				}
				if (m_PopupDic[child] != null)
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool HasNextActiveSiblingPage(Transform node)
	{
		for (int i = node.GetSiblingIndex() + 1; i < node.parent.childCount; i++)
		{
			Transform child = node.parent.GetChild(i);
			if (child.gameObject.activeSelf)
			{
				if (!m_PageDic.ContainsKey(child))
				{
					m_PageDic.Add(child, child.GetComponent<UIPage>());
				}
				if (m_PageDic[child] != null)
				{
					return true;
				}
			}
		}
		return false;
	}
}
