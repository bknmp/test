using GameMessages;
using UnityEngine;

public static class BroadcastExtends
{
	public static T ConvertTo<T>(this BroadcastInfo broadcast)
	{
		return JsonUtility.FromJson<T>(broadcast.json);
	}
}
