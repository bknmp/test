using LightUI;
using LightUtility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_PageColoration
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_RandomColors;

	public Button m_RandomButton;

	public Text m_RandomPriceText;

	public UIStateImage m_RandomIcon;

	public GameObject m_RandomColoring;

	public GameObject m_LoadEffect;

	public UIStateItem m_State;

	public AudioItemData m_ButtonClick;

	public CharacterColorationUI m_ColorationUI;

	private int[] m_PartIDs;

	private int m_CurrentPartID;

	private SkinPartInfo m_PartInfo;

	private int m_lastTabIndex;

	public static bool IsRandomColoring;

	public static Dictionary<SkinPartType, int> Selected = new Dictionary<SkinPartType, int>
	{
		{
			SkinPartType.Head,
			-1
		},
		{
			SkinPartType.Hand,
			-1
		},
		{
			SkinPartType.Body,
			-1
		},
		{
			SkinPartType.Trouser,
			-1
		},
		{
			SkinPartType.Shoe,
			-1
		}
	};

	public void Bind(CommonDataCollection args)
	{
		if (args["tabIndex"] != null)
		{
			m_lastTabIndex = args["tabIndex"];
		}
		m_CurrentPartID = LobbyScene.Inst.CurrentCharacter.m_SkinPartController.PartIDs[m_lastTabIndex];
		m_PartIDs = new int[1]
		{
			m_CurrentPartID
		};
		if (ShopUtility.IsInGroup(m_CurrentPartID))
		{
			int groupID = ShopUtility.GetGroupID(m_CurrentPartID);
			m_PartIDs = LocalResources.SkinGroupTable.Get(groupID).SkinPartIds;
		}
		m_ColorationUI.SetDefaultSelectedColor();
		m_PartInfo = LocalResources.SkinPartTable.Get(m_CurrentPartID);
		m_State.State = ((m_PartInfo.DefaultColorID != 0) ? 1 : 0);
		m_RandomColors.Args = CreateColorArgs(m_PartInfo.ColorRandomIDs, m_CurrentPartID);
		m_RandomPriceText.text = $"x{LocalPlayerDatabase.Settings.coloringAgentCost}";
		m_RandomPriceText.color = ((LocalPlayerDatabase.PlayerInfo.coloringAgentNum >= LocalPlayerDatabase.Settings.coloringAgentCost) ? Color.white : Color.red);
		m_RandomIcon.State = (int)m_PartInfo.PartType;
		m_Host.EventProxy(m_RandomButton, "OnRandomClicked");
	}

	private CommonDataCollection CreateColorArgs(int[] colorIDs, int partID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < colorIDs.Length; i++)
		{
			commonDataCollection[i]["colorID"] = colorIDs[i];
			commonDataCollection[i]["colorIndex"] = i;
			commonDataCollection[i]["partID"] = partID;
			commonDataCollection[i]["skinPartType"] = m_lastTabIndex;
		}
		return commonDataCollection;
	}

	public void OnRandomClicked()
	{
		if (!CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
		{
			UILobby.Current.ShowTips(Localization.BuyCharacterFirst);
		}
		else
		{
			CharacterUtility.BuyColor(0, m_PartIDs, delegate(int[] colorIDs)
			{
				m_Host.StopAllCoroutines();
				m_Host.StartCoroutine(PlayRandomAnimation(colorIDs));
			});
		}
	}

	private IEnumerator PlayRandomAnimation(int[] colorIDs)
	{
		IsRandomColoring = true;
		m_RandomColoring.SetActive(value: true);
		UILobby.Current.GetComponent<GraphicRaycaster>().enabled = false;
		int start = ArrayUtility.IndexOf(m_PartInfo.ColorRandomIDs, Selected[(SkinPartType)m_lastTabIndex]);
		if (start == -1)
		{
			start = 0;
		}
		int num = -1;
		int num2 = 0;
		int colorID = 0;
		while (num == -1 && num2 < colorIDs.Length)
		{
			colorID = colorIDs[num2];
			num = ArrayUtility.IndexOf(m_PartInfo.ColorRandomIDs, colorID);
			num2++;
		}
		int j = m_PartInfo.ColorRandomIDs.Length;
		int i;
		for (i = num - start; i < 20; i += j)
		{
		}
		float v = (float)i * 0.5f;
		float damping = 0.94f;
		float p = 0f;
		while (p < (float)i)
		{
			p += Mathf.Clamp(v, 1f, 10f) * Time.deltaTime;
			int num3 = Mathf.FloorToInt((float)start + p) % j;
			int num4 = m_PartInfo.ColorRandomIDs[num3];
			if (Selected[(SkinPartType)m_lastTabIndex] != num4)
			{
				SoundManager.PlayOnce(m_ButtonClick.Item);
				v *= damping;
				Selected[(SkinPartType)m_lastTabIndex] = num4;
				UIDataEvents.Inst.InvokeEvent("OnColorSelectedChanged");
			}
			yield return null;
		}
		if (Selected[(SkinPartType)m_lastTabIndex] != colorID)
		{
			Selected[(SkinPartType)m_lastTabIndex] = colorID;
			UIDataEvents.Inst.InvokeEvent("OnColorSelectedChanged");
		}
		yield return new WaitForSeconds(0.2f);
		for (int k = 0; k < colorIDs.Length; k++)
		{
			CharacterUtility.UpdateSkinPartColor(m_PartIDs[k], colorIDs[k]);
		}
		UILobby.Current.ShowTips(Localization.TipsColoringSuccess);
		CharacterUI_ColorTemplate.SelectedItem.SpawnBuyEffect();
		IsRandomColoring = false;
		m_RandomColoring.SetActive(value: false);
		UILobby.Current.GetComponent<GraphicRaycaster>().enabled = true;
	}
}
