using UnityEngine;
using UnityEngine.UI;

public class CountDownTimeUI : MonoBehaviour
{
	public enum TimeMode
	{
		Time,
		UnscaledTime,
		Realtime
	}

	public Text timeText;

	public TimeMode m_TimeMode;

	private int lastRemainTime = -1;

	private float startTime;

	private float startRemainedTime;

	private float RemainedTime
	{
		get
		{
			float num = GetTime() - startTime;
			return startRemainedTime - num;
		}
	}

	private void Update()
	{
		float remainedTime = RemainedTime;
		UpdateTimeUI(remainedTime);
	}

	public void SetTime(float remainTime)
	{
		startRemainedTime = remainTime;
		startTime = GetTime();
	}

	private void UpdateTimeUI(float remainedTime)
	{
		int num = Mathf.Max(0, Mathf.CeilToInt(remainedTime));
		if (lastRemainTime != num)
		{
			int num2 = num / 86400;
			int num3 = num % 3600;
			int num4 = num3 % 3600;
			if (num2 > 0)
			{
				timeText.text = $"{num2}天{num3 / 3600:D2}:{num4 / 60:D2}:{num4 % 60:D2}";
			}
			else
			{
				timeText.text = $"{num3 / 3600:D2}:{num4 / 60:D2}:{num4 % 60:D2}";
			}
			lastRemainTime = num;
		}
	}

	private float GetTime()
	{
		switch (m_TimeMode)
		{
		case TimeMode.UnscaledTime:
			return Time.unscaledTime;
		case TimeMode.Realtime:
			return Time.realtimeSinceStartup;
		default:
			return Time.time;
		}
	}
}
