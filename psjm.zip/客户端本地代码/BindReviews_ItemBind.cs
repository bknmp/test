using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BindReviews_ItemBind
{
	public UIDataBinder m_Host;

	public PlayerIcon m_Icon;

	public UIStateImage m_Sex;

	public Text m_PlayerName;

	public GradeItem m_ThiefGrade;

	public Text m_Time;

	public PlayerSpaceButton m_SpaceButton;

	public Text m_Status;

	public GradeItem m_PoliceGrade;

	public Button m_AgreeButton;

	public Button m_IgnoreButton;

	public Button m_UnBindButton;

	public UIStateItem m_ReviewState;

	public UIStateItem m_ButtonState;

	public Text m_Binded;

	public GameObject m_Empty;

	private int m_Index;

	private BindFriendsReview m_BindFriendsReview;

	private string m_HadBindFormat;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["index"];
		if (BindFriendsUtility.BindFriendsReviews != null && BindFriendsUtility.BindFriendsReviews.Count > m_Index)
		{
			m_BindFriendsReview = BindFriendsUtility.BindFriendsReviews[m_Index];
			SetNomalInfo();
			SetReviewStateInfo();
		}
	}

	private void SetNomalInfo()
	{
		SocialCacheManager.Inst.AcquireHeadInfo(m_BindFriendsReview.roleID, delegate(HeadInfo headInfo)
		{
			if (headInfo != null)
			{
				m_PlayerName.text = headInfo.name;
				m_Icon.SetTexture(headInfo.icon, headInfo.activeHeadBoxID);
				m_Sex.State = headInfo.sex;
				m_ThiefGrade.SetGradeItem(headInfo.gradeThief);
				m_PoliceGrade.SetGradeItem(headInfo.gradePolice);
			}
		});
		m_SpaceButton.SetPlayerID(m_BindFriendsReview.roleID);
		m_Status.text = UnionUtility.ShowStatus(m_BindFriendsReview.status);
	}

	private void SetReviewStateInfo()
	{
		int reviewState = m_BindFriendsReview.reviewState;
		m_ReviewState.State = reviewState;
		switch (reviewState)
		{
		case 0:
		{
			string formatTimeShort = UITimeText.GetFormatTimeShort(UtcTimeStamp.Now - m_BindFriendsReview.time, withAgo: true);
			m_Time.text = formatTimeShort;
			m_Host.EventProxy(m_AgreeButton, "OnAgreeClicked");
			m_Host.EventProxy(m_IgnoreButton, "OnIgnoreClicked");
			m_ButtonState.State = 0;
			break;
		}
		case 1:
		{
			if (m_HadBindFormat == null)
			{
				m_HadBindFormat = m_Binded.text;
			}
			string arg = UtcTimeStamp.GetDate(m_BindFriendsReview.time).ToString("yyyy/MM/dd");
			m_Binded.text = string.Format(m_HadBindFormat, arg);
			m_Host.EventProxy(m_UnBindButton, "OnUnBindClicked");
			m_ButtonState.State = 1;
			break;
		}
		case 2:
			m_Host.EventProxy(m_UnBindButton, "OnUnBindClicked");
			m_ButtonState.State = 1;
			break;
		default:
			m_ButtonState.State = 2;
			break;
		}
	}

	public void OnIgnoreClicked()
	{
		BindFriendsUtility.SetReviewStatus(m_BindFriendsReview.roleID, 0, ReviewResponse);
	}

	public void OnAgreeClicked()
	{
		BindFriendsUtility.SetReviewStatus(m_BindFriendsReview.roleID, 1, ReviewResponse);
	}

	public void OnUnBindClicked()
	{
		UILobby.Current.ShowMessageBoxYesNo(string.Format(Localization.TipsUnBindFriend, m_PlayerName.text), Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
		{
			BindFriendsUtility.SetReviewStatus(m_BindFriendsReview.roleID, 2, ReviewResponse);
		}, null, showCloseButton: false);
	}

	private void ReviewResponse(HttpResponseBindFriendsReviewsStatus response)
	{
		switch (response.opt)
		{
		case 1:
			m_Host.gameObject.SetActive(value: false);
			BindFriendsUtility.BindFriendsReviews.RemoveAt(m_Index);
			if (BindFriendsUtility.BindFriendsReviews.Count <= 0)
			{
				m_Empty.SetActive(value: true);
			}
			break;
		case 2:
			m_BindFriendsReview.reviewState = 1;
			m_BindFriendsReview.time = UtcTimeStamp.Now;
			SetReviewStateInfo();
			BindReviews_Bind.NeedUpdate = true;
			SocialUtility.IsFollowingDirty = true;
			break;
		}
		UILobby.Current.ShowTips(response.message);
	}
}
