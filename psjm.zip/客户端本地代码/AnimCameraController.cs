using LightUtility;
using UnityEngine;

public class AnimCameraController : MonoBehaviour
{
	public Vector3 m_DefaultPos;

	public Vector3 m_DefaultRot;

	private Camera m_MainCamera;

	private CameraOffCenterProjection m_mainCameraOffCenter;

	private Camera m_Camera;

	private CameraOffCenterProjection m_CameraOffCenter;

	private void Awake()
	{
		m_Camera = GetComponentInChildren<Camera>(includeInactive: true);
		m_CameraOffCenter = m_Camera.GetComponent<CameraOffCenterProjection>();
		if (m_CameraOffCenter == null)
		{
			m_CameraOffCenter = m_Camera.gameObject.AddComponent<CameraOffCenterProjection>();
		}
		m_Camera.enabled = false;
	}

	private void OnEnable()
	{
		m_MainCamera = GetMainCamera();
		if (m_MainCamera == null || !m_MainCamera.gameObject.activeInHierarchy || (LobbyScene.Inst.m_CampPanel.Root.activeSelf && LobbyScene.Inst.m_CampPanel.PoliceCamera.gameObject.activeSelf && LobbyScene.Inst.m_CampPanel.ThiefCamera.gameObject.activeSelf))
		{
			PoolSpawner.DeSpawn(base.gameObject);
			return;
		}
		m_MainCamera.gameObject.GetComponent<CameraOrbit>().ResetView(0.3f);
		base.transform.SetParent(m_MainCamera.transform);
		base.transform.localPosition = m_DefaultPos;
		base.transform.localRotation = Quaternion.Euler(m_DefaultRot);
		CopyParamFormMainCamera();
		m_MainCamera.enabled = false;
		m_Camera.enabled = true;
		m_mainCameraOffCenter = m_MainCamera.gameObject.GetComponent<CameraOffCenterProjection>();
	}

	private Camera GetMainCamera()
	{
		if (LobbyScene.Inst.m_CampPanel.Root.activeSelf)
		{
			return LobbyScene.Inst.m_CampPanel.Root.GetComponentInChildren<Camera>();
		}
		return LobbyScene.Inst.NormalCamera;
	}

	private void CopyParamFormMainCamera()
	{
		if (!(m_Camera == null))
		{
			m_Camera.fieldOfView = m_MainCamera.fieldOfView;
			m_Camera.farClipPlane = m_MainCamera.farClipPlane;
			m_Camera.nearClipPlane = m_MainCamera.nearClipPlane;
			m_Camera.clearFlags = m_MainCamera.clearFlags;
		}
	}

	private void Update()
	{
		if (m_mainCameraOffCenter != null && m_mainCameraOffCenter.enabled)
		{
			m_CameraOffCenter.enabled = true;
			m_CameraOffCenter.offset = m_mainCameraOffCenter.offset;
		}
		else
		{
			m_CameraOffCenter.enabled = false;
		}
	}

	private void OnDisable()
	{
		ResetMainCamera();
	}

	private void ResetMainCamera()
	{
		if (!(LobbyScene.Inst == null))
		{
			SceneCameraBlur component = LobbyScene.Inst.GetComponent<SceneCameraBlur>();
			if (component != null && component.enabled)
			{
				component.TryModifiedCamera(m_MainCamera);
			}
			m_MainCamera.enabled = true;
			m_Camera.enabled = false;
		}
	}
}
