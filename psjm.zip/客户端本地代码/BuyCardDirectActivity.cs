using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class BuyCardDirectActivity
{
	public UIDataBinder m_Host;

	public UIDataBinder m_ItemTemplate;

	public UIDataBinder m_ItemTemplate1;

	public Text m_Time;

	public GameObject m_FirstRechargeTips;

	public RectTransform m_PreviewAnchor;

	private bool restore;

	private string m_TimeFormat;

	private Activity m_Activity;

	private ActivityLobbyInfo m_ActivityInfo;

	private UIDataBinder m_PreviewUIInst;

	[SerializeField]
	private int supportNewCardCount = 1;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		m_Activity = (args["Activity"].val as Activity);
		m_ActivityInfo = LocalResources.ActivityLobbyInfos.Get(m_Activity.activityId);
		m_FirstRechargeTips.gameObject.SetActive(!FirstRechargeUtility.AllRewardsReceived && m_ActivityInfo.Type == ActivityType.BUY_NEW_CARD_DIRECT);
		HttpRequestBuyNewCardDirectActivity httpRequestBuyNewCardDirectActivity = new HttpRequestBuyNewCardDirectActivity();
		httpRequestBuyNewCardDirectActivity.ActivityID = m_Activity.activityId;
		GameHttpManager.Inst.Send(httpRequestBuyNewCardDirectActivity, delegate(HttpResponseBuyNewCardDirectActivity OnHttpResponse)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < OnHttpResponse.infos.Length && i < supportNewCardCount; i++)
			{
				commonDataCollection[i]["BuyCardDirectActivityInfo"].val = OnHttpResponse.infos[i];
				commonDataCollection[i]["BuyCardDirectActivityUI"].val = this;
				commonDataCollection[i]["Activity"].val = m_Activity;
			}
			TrySaveAllBuyData(OnHttpResponse.infos);
			if (m_ItemTemplate != null)
			{
				m_ItemTemplate.Args = commonDataCollection[0];
			}
			if (m_ItemTemplate1 != null)
			{
				m_ItemTemplate1.Args = commonDataCollection[1];
			}
		}, null, null, LocalPlayerDatabase.DummyWait);
		LocalPlayerDatabase.SetPrefValue("BuyCardDirectActivity", m_Activity.startTime);
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(m_Activity.startTime), UITimeText.GetDateTime(m_Activity.endTime));
		if (!restore)
		{
			restore = true;
			PaymentUtility.RestorePay();
		}
		SetPreviewItem();
	}

	public void SetPreviewItem()
	{
		if (m_PreviewUIInst == null)
		{
			m_PreviewUIInst = ResManager.Instantiate<UIDataBinder>("PreviewItem");
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["ShowCardId"] = m_ActivityInfo.Index;
			commonDataCollection["DiffState"] = 0;
			m_PreviewUIInst.Args = commonDataCollection;
		}
	}

	public static bool RedPoint(ActivityType type)
	{
		if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.activitys == null)
		{
			return false;
		}
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(type, ActivityCollectionType.NEW_CARD_ACTIVITY);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (type == ActivityType.GIVE_OLD_CARD || type == ActivityType.GIVE_OLD_CARD_UP)
		{
			if (LocalPlayerDatabase.GetPrefValueInt("BuyNewCardDirectActivityAllBuy") == activityByActivityTypeAndCollectionType.startTime)
			{
				if (type == ActivityType.GIVE_OLD_CARD_UP && LocalPlayerDatabase.GetPrefValueInt("KnowWhyChange") == activityByActivityTypeAndCollectionType.startTime)
				{
					return false;
				}
				return true;
			}
			return true;
		}
		if (activityByActivityTypeAndCollectionType.startTime == LocalPlayerDatabase.GetPrefValueInt("BuyCardDirectActivity"))
		{
			return false;
		}
		return true;
	}

	private void TrySaveAllBuyData(BuyNewCardDirectActivityInfo[] infos)
	{
		bool flag = true;
		for (int i = 0; i < infos.Length; i++)
		{
			if (!infos[i].hadBuy)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			LocalPlayerDatabase.SetPrefValue("BuyNewCardDirectActivityAllBuy", m_Activity.startTime);
		}
	}
}
