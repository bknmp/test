using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CardDetailUI_CardSkinTime
{
	public UIDataBinder m_Host;

	public Text m_Time;

	private string m_format;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_format))
		{
			m_format = m_Time.text;
		}
		DataItem item = args["expiredTime"];
		if ((int)item > UtcTimeStamp.Now)
		{
			m_Time.text = string.Format(m_format, UITimeText.GetFormatTimeShort((int)item - UtcTimeStamp.Now, withAgo: false));
		}
		else
		{
			(args["cardSkinPage"].val as CardConfigEditPage_PageCardSkin).m_Host.UpdateBinding();
		}
	}
}
