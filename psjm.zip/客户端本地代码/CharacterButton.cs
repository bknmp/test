using LightUI;
using UnityEngine;

public class CharacterButton : MonoBehaviour
{
	public GameObject m_RedPoint;

	private void Awake()
	{
		UIDataEvents.Inst.AddEventListener("OnPlayerInfoChanged", this, UpdateRedPoint);
	}

	private void Start()
	{
		UpdateRedPoint();
	}

	private void UpdateRedPoint()
	{
		bool active = false;
		foreach (CharacterInfo item in LocalResources.CharacterTable)
		{
			if (item.IsVisibleInUI && TalentUtility.HasTalentCanUpgrade(CharacterUtility.GetOwnedCharacterInfo(item.Id), item))
			{
				active = true;
				break;
			}
		}
		m_RedPoint.gameObject.SetActive(active);
	}
}
