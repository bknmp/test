using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterDetail_SuiteBtnItem
{
	public UIDataBinder m_Host;

	public Button m_Button;

	public UIStateRawImage m_QualityBG;

	public Text m_Name;

	public Image m_Icon;

	public UIScrollRect m_ScrollView;

	public ScrollviewAnimator m_ScrollViewAnimator;

	public UIStateItem m_CantBuyTipsState;

	public Text m_GainTypeTips;

	public Button m_BuyButton;

	public GameObject m_Mask;

	public UIPopup m_BuySuiteUI;

	public static string SelectedSuite;

	private string m_suiteName;

	private List<int> m_skinPartIds;

	private string m_Current;

	private bool m_CanBuyInCharacterUI;

	public void Bind(CommonDataCollection args)
	{
		int globalSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		m_suiteName = args["suiteName"];
		if (string.IsNullOrEmpty(m_Current))
		{
			m_Current = m_Name.text;
		}
		if (m_suiteName == "current")
		{
			m_QualityBG.State = 0;
			m_Name.text = m_Current;
			m_Icon.sprite = SpriteSource.Inst.Find(LocalResources.CharacterTable.Get(CharacterUI_SelectCharacterItemTemplate.globalSelected).ExpIcon);
			m_CanBuyInCharacterUI = false;
			m_CantBuyTipsState.gameObject.SetActive(value: false);
		}
		else
		{
			if (!ShopSuiteUtility.CharacterSuites[globalSelected].suites.ContainsKey(m_suiteName))
			{
				return;
			}
			int id = ShopSuiteUtility.CharacterSuites[globalSelected].suites[m_suiteName][0];
			ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(id);
			m_skinPartIds = new List<int>();
			if (shopSuiteInfo.GainType == ShopGainType.Default)
			{
				m_skinPartIds = new List<int>(LocalResources.CharacterTable.Get(globalSelected).DefaultParts);
			}
			else
			{
				m_skinPartIds.AddRange(CharacterUtility.GetSuiteParts(shopSuiteInfo));
			}
			m_QualityBG.State = shopSuiteInfo.Quality;
			m_Name.text = shopSuiteInfo.Name;
			m_Icon.sprite = SpriteSource.Inst.Find(shopSuiteInfo.Icon);
			m_CanBuyInCharacterUI = shopSuiteInfo.CanBuyInCharacterUI;
			m_CantBuyTipsState.gameObject.SetActive(value: true);
			if (ShopSuiteUtility.IsOwnPermanentSuite(shopSuiteInfo.Id))
			{
				m_CantBuyTipsState.State = 0;
			}
			else
			{
				m_CantBuyTipsState.State = 1;
				m_GainTypeTips.text = shopSuiteInfo.GainTips;
			}
		}
		UpdateSelecteStatus();
		m_Host.EventProxy(m_BuyButton, "OnClickBuy");
		m_Host.EventProxy(m_Button, "OnClickSelected");
		ScrollviewAnimator scrollViewAnimator = m_ScrollViewAnimator;
		scrollViewAnimator.OnSelectedChange = (Delegates.ObjectCallback<UIDataBinder>)Delegate.Remove(scrollViewAnimator.OnSelectedChange, new Delegates.ObjectCallback<UIDataBinder>(OnSelectedChange));
		ScrollviewAnimator scrollViewAnimator2 = m_ScrollViewAnimator;
		scrollViewAnimator2.OnSelectedChange = (Delegates.ObjectCallback<UIDataBinder>)Delegate.Combine(scrollViewAnimator2.OnSelectedChange, new Delegates.ObjectCallback<UIDataBinder>(OnSelectedChange));
	}

	private void UpdateSelecteStatus()
	{
		bool flag = SelectedSuite == m_suiteName;
		if (flag)
		{
			if (m_suiteName == "current")
			{
				PreviewUtility.RevertAllPreview();
			}
			else
			{
				PreviewUtility.PreviewSkinPart(m_skinPartIds.ToArray());
			}
			m_ScrollView.ScrollToItem(m_Host.transform.GetSiblingIndex(), tween: true);
			m_BuyButton.gameObject.SetActive(m_CanBuyInCharacterUI && m_CantBuyTipsState.State != 0);
		}
		else
		{
			m_BuyButton.gameObject.SetActive(value: false);
		}
		m_Mask.gameObject.SetActive(!flag);
	}

	public void OnClickSelected()
	{
		if (SelectedSuite.Equals(m_suiteName))
		{
			return;
		}
		SelectedSuite = m_suiteName;
		UIDataEvents.Inst.InvokeEvent("OnCharacterDetailSuitePreviewChange");
		if (m_suiteName != "current")
		{
			int id = ShopSuiteUtility.CharacterSuites[CharacterUI_SelectCharacterItemTemplate.globalSelected].suites[m_suiteName][0];
			ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(id);
			if (!shopSuiteInfo.HasChangePartAnim)
			{
				int animation = shopSuiteInfo.Animation;
				LobbyScene.Inst.CurrentCharacter.TryShowAnimation(animation);
			}
		}
	}

	public void OnClickBuy()
	{
		List<int> list = new List<int>();
		foreach (int item in ShopSuiteUtility.CharacterSuites[CharacterUI_SelectCharacterItemTemplate.globalSelected].suites[m_suiteName])
		{
			if (LocalResources.ShopSuiteTable.Get(item).GainType == ShopGainType.Buy)
			{
				list.Add(item);
			}
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["suiteIDs"].val = list;
		commonDataCollection["defaultSelectIdx"] = -1;
		BuySuiteUI.ItemSelected = ArrayUtility.Create(5, initialValue: true);
		BuySuiteUI.Reset = true;
		UILobby.Current.ShowUI(m_BuySuiteUI, commonDataCollection);
	}

	private void OnSelectedChange(UIDataBinder binder)
	{
		if (binder == m_Host)
		{
			OnClickSelected();
		}
	}
}
