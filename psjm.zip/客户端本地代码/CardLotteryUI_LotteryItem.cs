using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CardLotteryUI_LotteryItem
{
	public UIDataBinder m_Host;

	public UIDataBinder m_LotteryButton;

	public Text m_Amount;

	public Image m_MinimumIcon;

	public Text m_MinimumAmount;

	public UIStateRawImage m_LotteryTips;

	public UIStateItem m_NewCardProbability;

	public Text m_LimitTips;

	public UIStateRawImage m_TitleState;

	public Text m_CardName;

	public Text m_DescText;

	public Text m_DescText1;

	private string m_DescTextFormat;

	private string m_DescTextFormat1;

	public void Bind(CommonDataCollection args)
	{
		int id = args["boxID"];
		BoxInfo boxInfo = LocalResources.BoxTable.Get(id);
		CardLotteryInfo lotteryInfo = CardLotteryUtility.GetLotteryInfo(boxInfo.Type);
		m_LotteryButton.Args = args;
		CardLotteryUtility.ExpectAmount expectAmount = CardLotteryUtility.GetExpectAmount(boxInfo);
		m_Amount.text = $"x{expectAmount.totalCount}";
		m_MinimumIcon.transform.parent.gameObject.SetActive(expectAmount.minItemCount > 0);
		if (expectAmount.minItemCount > 0)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(expectAmount.minItemID);
			m_MinimumIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
			m_MinimumAmount.text = $"x{expectAmount.minItemCount}";
		}
		if (lotteryInfo.type == CardLotteryType.Rainbow)
		{
			m_LotteryTips.transform.parent.gameObject.SetActive(value: false);
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(901);
			if (activityLobbyInfo != null && m_NewCardProbability != null)
			{
				int index = activityLobbyInfo.Index;
				bool num = CardUtility.IsOwned(index) || CardUtility.CanComposeCard(index);
				string fullName = LocalResources.InGameStoreTable.Get(index).FullName;
				if (m_CardName != null)
				{
					m_CardName.text = fullName;
				}
				if (m_DescText != null)
				{
					if (m_DescTextFormat == null)
					{
						m_DescTextFormat = m_DescText.text;
					}
					m_DescText.text = string.Format(m_DescTextFormat, fullName);
				}
				if (m_DescText1 != null)
				{
					if (m_DescTextFormat1 == null)
					{
						m_DescTextFormat1 = m_DescText1.text;
					}
					m_DescText1.text = string.Format(m_DescTextFormat1, fullName);
				}
				m_NewCardProbability.gameObject.SetActive(value: true);
				if (num)
				{
					m_NewCardProbability.State = 1;
				}
				else
				{
					m_NewCardProbability.State = 0;
				}
			}
			else
			{
				m_NewCardProbability.gameObject.SetActive(value: false);
			}
		}
		else
		{
			m_LotteryTips.transform.parent.gameObject.SetActive(lotteryInfo.type != CardLotteryType.Normal);
			if (m_LotteryTips.gameObject.activeInHierarchy)
			{
				if (CardLotteryUtility.HasUnlockedNewCard())
				{
					m_LotteryTips.State = ((lotteryInfo.type == CardLotteryType.Advanced) ? 2 : 3);
				}
				else
				{
					m_LotteryTips.State = ((lotteryInfo.type != CardLotteryType.Advanced) ? 1 : 0);
				}
			}
		}
		m_LimitTips.transform.parent.gameObject.SetActive(boxInfo.Type != 7);
		m_LimitTips.text = $"({lotteryInfo.drawCountTdy}/{lotteryInfo.drawCountLimit})";
		if (boxInfo.Type == 19)
		{
			m_TitleState.State = 3;
		}
		else
		{
			m_TitleState.State = boxInfo.Type - 7;
		}
	}
}
