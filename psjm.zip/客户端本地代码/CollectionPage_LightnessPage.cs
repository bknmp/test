using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_LightnessPage
{
	public UIDataBinder m_Host;

	public Text m_CollectProgress;

	public Text m_Personality;

	public UITemplateInitiator m_Content;

	public GameObject m_Empty;

	public GameObject m_Panel;

	public GameObject m_PreviewPort;

	public UIScrollRect m_ScrollView;

	public GameObject m_NotHaveTips;

	public Button m_ButtonGain;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private uint m_PlayerID;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	private string m_LightnessProgressFormat;

	public void Bind(CommonDataCollection args)
	{
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerID = args["roleID"];
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		if (string.IsNullOrEmpty(m_LightnessProgressFormat))
		{
			m_LightnessProgressFormat = m_CollectProgress.text;
		}
		CollectionPage_LightnessItem.Selected = 0;
		DropItem[] array = (from a in LocalResources.DropItemTable
			where a.Type == DropItemType.Lightness && a.expiredTime == 0
			orderby a.Quality descending
			select a).ToArray();
		List<DropItem> list = new List<DropItem>();
		List<int> list2 = new List<int>();
		List<int> list3 = new List<int>();
		DropItem[] array2 = array;
		foreach (DropItem dropItem in array2)
		{
			LightnessInfo lightnessInfo = LocalResources.LightnessInfo.Get(dropItem.TypeParam);
			if (LightnessController.IsOwnForeverLightness(dropItem.TypeParam, m_PlayerInfo))
			{
				list.Add(dropItem);
				list2.Add(dropItem.Id);
			}
			else if ((lightnessInfo.SellStartTime == 0 || lightnessInfo.SellStartTime <= UtcTimeStamp.Now) && (lightnessInfo.SellEndTime == 0 || lightnessInfo.SellEndTime >= UtcTimeStamp.Now))
			{
				list3.Add(dropItem.Id);
			}
		}
		int num = 0;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (list2.Count > 0)
		{
			commonDataCollection[num]["state"] = 0;
			commonDataCollection[num]["items"].val = list2.ToList();
			commonDataCollection[num]["roleID"].val = m_PlayerID;
			commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num++;
		}
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
		{
			if (list3.Count > 0)
			{
				commonDataCollection[num]["state"] = 2;
				commonDataCollection[num]["items"].val = list3.ToList();
				commonDataCollection[num]["roleID"].val = m_PlayerID;
				commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
				commonDataCollection[num]["playerCardConfigs"].val = m_PlayerCardConfigs;
			}
			m_Panel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
			m_Empty.SetActive(value: false);
		}
		else if (list.Count > 0)
		{
			m_Empty.SetActive(value: false);
			m_Panel.SetActive(value: true);
			m_PreviewPort.SetActive(value: true);
		}
		else
		{
			m_Panel.SetActive(value: false);
			m_PreviewPort.SetActive(value: false);
			m_Empty.SetActive(value: true);
		}
		m_Content.Args = commonDataCollection;
		m_CollectProgress.text = string.Format(m_LightnessProgressFormat, LightnessController.GetOwnForeverLightnessCount(m_PlayerInfo), list2.Count + list3.Count);
		m_Personality.text = list.Sum((DropItem a) => a.Personality).ToString();
		m_ScrollView.ScrollToStart(immediately: true);
		m_NotHaveTips.SetActive(value: false);
		m_Host.EventProxy(m_ButtonGain, "OnGainButtonClick");
	}
}
