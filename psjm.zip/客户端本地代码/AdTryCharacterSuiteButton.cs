using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AdTryCharacterSuiteButton : MonoBehaviour
{
	public RawImage m_RawImage;

	public UIPointerBehaviour m_Input;

	public GameObject m_PreviewPort;

	private Delegates.VoidCallback m_OnFinish;

	protected int m_CharacterID;

	protected PlayerCharacterInfo m_PlayerCharacterInfo;

	private AdScene m_AdScene;

	private void PreviewCharacter(int id, PlayerCharacterInfo characterInfo)
	{
		RoleType role = LocalResources.CharacterTable.Get(id).Role;
		MatchPlayerData playerData = CharacterUtility.GetPlayerData();
		LobbyScene.Inst.UpdateCampPanel(role, "", characterInfo, playerData, m_RawImage, notRTMethod: false, m_Input, closeOppositeRole: true);
		m_PreviewPort.SetActive(value: true);
	}

	public virtual void SetInfo(Delegates.VoidCallback onFinish, AdScene adScene)
	{
		m_OnFinish = onFinish;
		m_AdScene = adScene;
		m_CharacterID = 0;
		m_PlayerCharacterInfo = AdUtility.TryPlayerCharacterInfo;
		AdSDKManager.TryReportEvent(adScene, AdStatistics.Show);
		if (m_PlayerCharacterInfo != null)
		{
			m_CharacterID = m_PlayerCharacterInfo.characterID;
			PreviewCharacter(m_CharacterID, m_PlayerCharacterInfo);
		}
		else
		{
			GetComponent<UIPopup>().GoBack();
			UnityEngine.Debug.LogWarning("Error Scene " + adScene);
		}
	}

	public void OnOKCallback()
	{
		AdSDKManager.Inst.ShowAd(m_AdScene, delegate
		{
			AdUtility.RequestRewards(m_AdScene, 0, null, DoFinish);
		});
	}

	public void OnSkipCallback()
	{
		AdUtility.ClearTryCharacter();
		AdUtility.RequestNoRewards(m_AdScene, DoFinish);
	}

	private void DoFinish()
	{
		GetComponent<UIPopup>().GoBack();
		if (m_OnFinish != null)
		{
			m_OnFinish();
		}
	}
}
