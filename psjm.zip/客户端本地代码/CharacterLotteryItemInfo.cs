using LightUtility;
using System;

[Serializable]
public class CharacterLotteryItemInfo : IdBased
{
	public int GridId;

	public int ItemId;

	public int ItemCount;

	public int Type;

	public int PopValue;

	public int ActivityId;

	public int Quality;

	public int Preview;

	public int Prize;

	public int MultiId;

	public int Weight;
}
