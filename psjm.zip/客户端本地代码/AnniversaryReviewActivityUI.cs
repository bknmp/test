using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class AnniversaryReviewActivityUI
{
	public UIDataBinder m_Host;

	public UIStateItem m_State;

	public Button m_NextPageButton;

	public Text m_Desc;

	public HeadItem m_HeadItem;

	public Text m_RoleId;

	public Text m_PoliceGrade;

	public Text m_ThiefGrade;

	public Text m_CreatAccountTime;

	public UITemplateInitiator m_Titles;

	public ShareButtonController m_ShareButtonController;

	public GameObject m_Main;

	public GameObject m_Content;

	public Animation m_Animation;

	public UIStateItem m_ShareButtonState;

	private bool m_Init;

	public static HttpResponseShareActivityInfo m_shareInfo;

	private int m_lastRefreshShareInfoTime;

	private bool m_allowShare;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_NextPageButton, "OnClickNextPageBtn");
		m_HeadItem.SetInfo(LocalPlayerDatabase.LoginInfo.roleID);
		m_PoliceGrade.text = LocalResources.GetGradeName(LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice);
		m_ThiefGrade.text = LocalResources.GetGradeName(LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief);
		m_RoleId.text = LocalPlayerDatabase.LoginInfo.roleID.ToString();
		m_CreatAccountTime.text = UtcTimeStamp.GetDate((int)LocalPlayerDatabase.LoginInfo.createAccountTime).ToString("yyyy.M.d");
		Activity activity = args["Activity"].val as Activity;
		m_allowShare = ShareManager.AllowToShare();
		if (!m_Init)
		{
			ActivityLobbyInfo activityInfo = LocalResources.ActivityLobbyInfos.Find(activity.activityId);
			GameHttpManager.Inst.Send(new HttpRequestAnniversaryReview(), delegate(HttpResponseAnniversaryReview onResponse)
			{
				m_Init = true;
				Text desc = m_Desc;
				string format = string.IsNullOrEmpty(onResponse.desc) ? activityInfo.Desc : onResponse.desc;
				object[] param = onResponse.param;
				desc.text = string.Format(format, param);
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				for (int i = 0; i < onResponse.titles.Length; i++)
				{
					commonDataCollection[i]["id"] = onResponse.titles[i];
				}
				m_Titles.Args = commonDataCollection;
				m_ShareButtonController.SetReportParam(onResponse.descId.ToString());
			});
		}
		if (activity.startTime != LocalPlayerDatabase.GetPrefValueInt("AnniversaryReviewActivity"))
		{
			LocalPlayerDatabase.SetPrefValue("AnniversaryReviewActivity", activity.startTime);
			ActivityLobby.InvokeActivityLobbyRedPointChange();
			m_State.State = 0;
		}
		else
		{
			m_State.State = 1;
		}
		if (m_shareInfo == null || UtcTimeStamp.IsCrossDay(m_lastRefreshShareInfoTime, UtcTimeStamp.Now))
		{
			m_lastRefreshShareInfoTime = UtcTimeStamp.Now;
			HttpRequestShareActivityInfo httpRequestShareActivityInfo = new HttpRequestShareActivityInfo();
			httpRequestShareActivityInfo.activityId = activity.activityId;
			GameHttpManager.Inst.SendNoWait(httpRequestShareActivityInfo, delegate(HttpResponseShareActivityInfo onResponse)
			{
				m_shareInfo = onResponse;
				ShareImageContent shareImageContent = new ShareImageContent
				{
					gameobject = m_Main
				};
				m_ShareButtonController.InitButton(4001, 0, OnShareCallBack, shareImageContent, m_shareInfo);
				UpdateButton();
			});
		}
		m_Main.transform.SetParent(m_Content.transform, worldPositionStays: false);
	}

	public void OnClickNextPageBtn()
	{
		m_State.State = 1;
		m_Animation.Play();
	}

	public static bool GetRedPoint()
	{
		ActivityLobbyInfo activityInfo = new ActivityLobbyInfo();
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.ANNIVERSARY_REVIEW, ActivityCollectionType.ANNIVERSART_ACTIVITY, out activityInfo);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (activityByActivityTypeAndCollectionType.startTime != LocalPlayerDatabase.GetPrefValueInt("AnniversaryReviewActivity"))
		{
			return true;
		}
		return false;
	}

	private void OnShareCallBack(int retCode)
	{
		switch (retCode)
		{
		case 0:
			UILobby.Current.ShowTips(Localization.ShareFailMessage);
			break;
		case 1:
			m_shareInfo.todayShared = true;
			m_shareInfo.hadShareOnce = true;
			UpdateButton();
			if (m_allowShare)
			{
				UILobby.Current.ShowTips(Localization.ShareSuccessMessage);
			}
			break;
		case 2:
			UILobby.Current.ShowTips(Localization.ShareCancelMessage);
			break;
		}
	}

	private void UpdateButton()
	{
		if (ShareManager.AllowToShare())
		{
			m_ShareButtonState.State = 0;
		}
		else if (m_shareInfo.hadShareOnce)
		{
			m_ShareButtonState.State = 2;
		}
		else
		{
			m_ShareButtonState.State = 1;
		}
	}
}
