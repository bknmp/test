using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class CardUtility
{
	public const int MaxLockNum = 3;

	public static List<int> NewUnlockCardIDs = new List<int>();

	private static InGameStoreInfo[] m_allCardInfos;

	public static readonly int[] DefaultCardsA = new int[4]
	{
		100,
		104,
		103,
		200
	};

	public static readonly int[] DefaultCardsBC = new int[6]
	{
		100,
		104,
		103,
		200,
		105,
		108
	};

	public static readonly int[] DefaultCardsSkin = new int[4]
	{
		500005,
		500004,
		500001,
		500010
	};

	private static HttpResponseCardConfigs cacheCardConfigs;

	private static HttpResponseClaimedCardSkinID cacheClaimedCardSkinID;

	public static int[] DefaultCards
	{
		get
		{
			if (LocalPlayerDatabase.Settings.ABTestType != 1 && LocalPlayerDatabase.Settings.ABTestType != 2)
			{
				return DefaultCardsA;
			}
			return DefaultCardsBC;
		}
	}

	public static CardConfig ActiveCardConfig
	{
		get
		{
			CharacterCardConfig currentCharacterCardConfigs = CurrentCharacterCardConfigs;
			CardConfig cardConfig = (currentCharacterCardConfigs == null) ? null : currentCharacterCardConfigs.allConfigs[currentCharacterCardConfigs.activeIndex];
			if (!GameSettings.Inst.NewIngameKeyMap || GameRuntime.PlayingRole != RoleType.Thief)
			{
				return cardConfig;
			}
			for (int i = 0; i < cardConfig.config.Length; i++)
			{
				if (LocalResources.InGameStoreTable.Get(cardConfig.config[i]).Type == InGameStoreType.Weapon)
				{
					int[] array = ArrayUtility.Create(6, 0);
					Array.Copy(cardConfig.config, 0, array, 0, cardConfig.config.Length - 1);
					array[i] = 0;
					array[5] = cardConfig.config[i];
					cardConfig.config = array;
					break;
				}
			}
			return cardConfig;
		}
	}

	public static int[] ActiveCardLevels => GetCardLevels(ActiveCardConfig.config);

	public static int[] ActiveCardSkins => GetCardSkins(ActiveCardConfig.config);

	public static int[] ActiveCardStyles => GetCardStyles(ActiveCardConfig.config);

	public static CharacterCardConfig CurrentCharacterCardConfigs => GetCharacterCardConfigs();

	public static CardConfig[] CurrentCardConfigs => CurrentCharacterCardConfigs.allConfigs;

	public static HttpResponseCardConfigs PlayerCardConfigs => cacheCardConfigs;

	public static InGameStoreInfo[] GetAllCardInfos()
	{
		if (m_allCardInfos == null)
		{
			List<InGameStoreInfo> list = new List<InGameStoreInfo>();
			foreach (InGameStoreInfo item in LocalResources.InGameStoreTable)
			{
				if (item.RoleType != -2 && item.Type != InGameStoreType.Magazine && item.Type != InGameStoreType.WeaponUpgrade)
				{
					list.Add(item);
				}
			}
			list.Sort((InGameStoreInfo a, InGameStoreInfo b) => a.CardPriority.CompareTo(b.CardPriority));
			m_allCardInfos = list.ToArray();
		}
		return m_allCardInfos;
	}

	public static ItemInfo[] GetNewbieLevelCard(int level)
	{
		switch (level)
		{
		default:
			return new ItemInfo[2]
			{
				new ItemInfo
				{
					itemID = 10104,
					itemCount = 1
				},
				new ItemInfo
				{
					itemID = 10103,
					itemCount = 1
				}
			};
		case 2:
			return new ItemInfo[1]
			{
				new ItemInfo
				{
					itemID = 10100,
					itemCount = 1
				}
			};
		case 3:
			return new ItemInfo[1]
			{
				new ItemInfo
				{
					itemID = 10200,
					itemCount = 1
				}
			};
		}
	}

	public static bool IsOwned(int cardID)
	{
		if (LocalPlayerDatabase.PlayerInfo.cardIDs == null)
		{
			return false;
		}
		if (ArrayUtility.IndexOf(LocalPlayerDatabase.PlayerInfo.cardIDs, cardID) == -1)
		{
			return false;
		}
		return true;
	}

	public static bool IsNewCard(int cardID)
	{
		CardGrowthInfo cardGrowth = GetCardGrowth(cardID);
		if (cardGrowth == null)
		{
			return false;
		}
		if (cardGrowth.StartTime != 0)
		{
			return cardGrowth.StartTime > UtcTimeStamp.Now;
		}
		return false;
	}

	public static bool IsCardRoleMatch(InGameStoreInfo item)
	{
		if (item.Type == InGameStoreType.Weapon && GameRuntime.PlayingRole == RoleType.Police)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(item.Id + 1);
			if (inGameStoreInfo != null)
			{
				item = inGameStoreInfo;
			}
		}
		if (item.RoleType != -1)
		{
			return item.RoleType == (int)GameRuntime.PlayingRole;
		}
		return true;
	}

	public static bool IsCardRoleMatch(int cardID)
	{
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		if (inGameStoreInfo != null)
		{
			return IsCardRoleMatch(inGameStoreInfo);
		}
		return false;
	}

	public static bool CanBuyCard(int cardID)
	{
		int gold = LocalPlayerDatabase.PlayerInfo.gold;
		foreach (ShopInfo item in LocalResources.ShopTable)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(item.DropItemID);
			if (dropItem.Type == DropItemType.PropCard && dropItem.TypeParam == cardID && (float)gold >= item.CostGold)
			{
				return true;
			}
		}
		return false;
	}

	public static int GetCardLevel(int cardID)
	{
		if (LocalPlayerDatabase.PlayerInfo.cardLevels == null)
		{
			return 1;
		}
		int num = ArrayUtility.IndexOf(LocalPlayerDatabase.PlayerInfo.cardIDs, cardID);
		if (num == -1)
		{
			return 1;
		}
		return LocalPlayerDatabase.PlayerInfo.cardLevels[num];
	}

	public static CardGrowthInfo GetCardGrowth(int cardID)
	{
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		return LocalResources.CardGrowthTable.Get(inGameStoreInfo.GrowthID);
	}

	public static DropItem GetDropItem(int cardID)
	{
		foreach (DropItem item in LocalResources.DropItemTable)
		{
			if (item.Type == DropItemType.PropCard && item.TypeParam == cardID)
			{
				return item;
			}
		}
		return null;
	}

	public static float GetCardLevelGrowthResult(int cardID, int level)
	{
		CardGrowthInfo cardGrowth = GetCardGrowth(cardID);
		return (float)Mathf.RoundToInt((cardGrowth.Start + (float)(level - 1) * cardGrowth.Rate) * 10000f) / 10000f;
	}

	public static float GetCardLevelGrowthResult(CardGrowthInfo growthInfo, int level)
	{
		return (float)Mathf.RoundToInt((growthInfo.Start + (float)(level - 1) * growthInfo.Rate) * 10000f) / 10000f;
	}

	public static bool InActiveCardConfig(int cardID)
	{
		return ActiveCardConfig.config.Contains(cardID);
	}

	public static CardConfig GetCardConfig(int configIndex)
	{
		return CurrentCardConfigs[configIndex];
	}

	public static void UnloadCard(int cardID)
	{
		ChangeCardLockState(ArrayUtility.IndexOf(ActiveCardConfig.config, cardID), islock: false);
		ArrayUtility.Replace(ActiveCardConfig.config, cardID, 0);
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public static void LoadCard(int cardID, int slotIndex)
	{
		CardConfig activeCardConfig = ActiveCardConfig;
		if (activeCardConfig.config.Length < slotIndex + 1)
		{
			Array.Resize(ref activeCardConfig.config, slotIndex + 1);
		}
		activeCardConfig.config[slotIndex] = cardID;
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public static void ChangeCardLockState(int idx, bool islock)
	{
		CardConfig activeCardConfig = ActiveCardConfig;
		List<int> list = activeCardConfig.LockIndex.ToList();
		if (islock)
		{
			if (!activeCardConfig.LockIndex.Contains(idx))
			{
				list.Add(idx);
			}
		}
		else if (activeCardConfig.LockIndex.Contains(idx))
		{
			list.Remove(idx);
		}
		activeCardConfig.lockIndex = list.ToArray();
	}

	public static void ReplaceCardGroup(int[] targetCardIDs, int CharacterID, int idx, Delegates.VoidCallback onSuccess = null)
	{
		CardConfig cardConfig = GetCharacterCardConfigs(CharacterID).allConfigs[idx];
		if (cardConfig.config.Length != targetCardIDs.Length)
		{
			Array.Resize(ref cardConfig.config, targetCardIDs.Length);
		}
		for (int i = 0; i < cardConfig.config.Length; i++)
		{
			cardConfig.config[i] = targetCardIDs[i];
			cardConfig.lockIndex = new int[0];
		}
		HttpRequestSetCardConfigs httpRequestSetCardConfigs = new HttpRequestSetCardConfigs();
		httpRequestSetCardConfigs.characterID = CharacterID;
		httpRequestSetCardConfigs.allConfigs = GetCharacterCardConfigs(CharacterID).allConfigs;
		GameHttpManager.Inst.Send(httpRequestSetCardConfigs, null, delegate
		{
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
			if (onSuccess != null)
			{
				onSuccess();
			}
		});
	}

	public static CardConfig[] CopyCardConfigs()
	{
		CardConfig[] currentCardConfigs = CurrentCardConfigs;
		CardConfig[] array = new CardConfig[currentCardConfigs.Length];
		for (int i = 0; i < currentCardConfigs.Length; i++)
		{
			array[i] = new CardConfig();
			array[i].name = currentCardConfigs[i].name;
			array[i].config = (currentCardConfigs[i].config.Clone() as int[]);
			array[i].lockIndex = (currentCardConfigs[i].LockIndex.Clone() as int[]);
		}
		return array;
	}

	public static void RestoreCardConfigs(CardConfig[] configs)
	{
		CardConfig[] currentCardConfigs = CurrentCardConfigs;
		int num = Mathf.Min(currentCardConfigs.Length, configs.Length);
		for (int i = 0; i < num; i++)
		{
			currentCardConfigs[i].config = configs[i].config;
		}
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public static int[] GetCardLevels(int[] cardIDs)
	{
		int[] array = new int[cardIDs.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = GetCardLevel(cardIDs[i]);
		}
		return array;
	}

	public static int[] GetCardSkins(int[] cardIDs)
	{
		int[] array = new int[cardIDs.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = CurCardSkin(cardIDs[i]);
		}
		return array;
	}

	public static int[] GetCardStyles(int[] cardIDs)
	{
		int[] array = new int[cardIDs.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = CurCardStyle(CurCardSkin(cardIDs[i]));
		}
		return array;
	}

	public static CharacterCardConfig GetCharacterCardConfigs(int characterID = 0)
	{
		if (characterID == 0)
		{
			characterID = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
		}
		CharacterCardConfig[] allCharacterCardConfigs = cacheCardConfigs.allCharacterCardConfigs;
		foreach (CharacterCardConfig characterCardConfig in allCharacterCardConfigs)
		{
			if (characterID == characterCardConfig.characterID)
			{
				return characterCardConfig;
			}
		}
		return null;
	}

	public static void FixUnlockSlot(ref HttpResponseCardConfigs response)
	{
		int higherGrade = LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade;
		int num = 0;
		int[] unlockCardSlotGrade = LocalPlayerDatabase.Settings.UnlockCardSlotGrade;
		foreach (int num2 in unlockCardSlotGrade)
		{
			if (higherGrade >= num2)
			{
				num++;
			}
		}
		if (num >= 6)
		{
			return;
		}
		CharacterCardConfig[] allCharacterCardConfigs = response.allCharacterCardConfigs;
		for (int i = 0; i < allCharacterCardConfigs.Length; i++)
		{
			CardConfig[] allConfigs = allCharacterCardConfigs[i].allConfigs;
			foreach (CardConfig cardConfig in allConfigs)
			{
				int num3 = -1;
				for (int k = num; k < 6 && cardConfig.config.Length > k; k++)
				{
					if (cardConfig.config[k] != 0)
					{
						if (num3 < 0 && LocalResources.InGameStoreTable.Get(cardConfig.config[k]).Type == InGameStoreType.Weapon)
						{
							num3 = cardConfig.config[k];
						}
						cardConfig.config[k] = 0;
					}
				}
				if (cardConfig.lockIndex != null)
				{
					ArrayUtility.Remove(ref cardConfig.lockIndex, 4);
					ArrayUtility.Remove(ref cardConfig.lockIndex, 5);
				}
				if (num3 > 0)
				{
					cardConfig.config[num - 1] = num3;
				}
			}
		}
	}

	public static GameAsyncCallback RequestCardConfigs(bool force = false, Delegates.VoidCallback onSuccess = null)
	{
		if (!force && cacheCardConfigs != null)
		{
			onSuccess?.Invoke();
			return null;
		}
		HttpRequestCardConfigs requset = new HttpRequestCardConfigs();
		return GameHttpManager.Inst.Send(requset, delegate(HttpResponseCardConfigs response)
		{
			FixUnlockSlot(ref response);
			cacheCardConfigs = response;
			CardConfigEditPage.UpdateBackupCardConfigs();
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
		}, onSuccess);
	}

	public static void SubmitCurrentCardConfigs(Delegates.VoidCallback onSuccess)
	{
		int characterID = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
		HttpRequestSetCardConfigs httpRequestSetCardConfigs = new HttpRequestSetCardConfigs();
		httpRequestSetCardConfigs.characterID = characterID;
		httpRequestSetCardConfigs.allConfigs = CurrentCardConfigs;
		GameHttpManager.Inst.Send(httpRequestSetCardConfigs, null, onSuccess);
		LobbyPlayerController currentCharacter = LobbyScene.Inst.CurrentCharacter;
		currentCharacter.Cards = ActiveCardConfig.config;
		currentCharacter.CardLevels = ActiveCardLevels;
		currentCharacter.CardSkins = ActiveCardSkins;
		currentCharacter.CardStyles = ActiveCardStyles;
	}

	public static void ChangeCardConfigName(int configIndex, string name, Delegates.VoidCallback onSuccess)
	{
		int characterID = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
		HttpRequestChangeCardConfigName httpRequestChangeCardConfigName = new HttpRequestChangeCardConfigName();
		httpRequestChangeCardConfigName.characterID = characterID;
		httpRequestChangeCardConfigName.index = configIndex;
		httpRequestChangeCardConfigName.name = name;
		GameHttpManager.Inst.Send(httpRequestChangeCardConfigName, delegate
		{
			GetCardConfig(configIndex).name = name;
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
		}, onSuccess);
	}

	public static void ChangeActiveCardConfigIndex(Delegates.VoidCallback onSuccess)
	{
		int characterID = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
		HttpRequestChangeCardConfigIndex httpRequestChangeCardConfigIndex = new HttpRequestChangeCardConfigIndex();
		httpRequestChangeCardConfigIndex.characterID = characterID;
		httpRequestChangeCardConfigIndex.index = CurrentCharacterCardConfigs.activeIndex;
		GameHttpManager.Inst.Send(httpRequestChangeCardConfigIndex, null, onSuccess);
	}

	public static void localChangeActiveCardConfigIndex(int configIndex, Delegates.VoidCallback onSuccess)
	{
		CurrentCharacterCardConfigs.activeIndex = configIndex;
		LobbyPlayerController currentCharacter = LobbyScene.Inst.CurrentCharacter;
		currentCharacter.Cards = ActiveCardConfig.config;
		currentCharacter.CardLevels = ActiveCardLevels;
		currentCharacter.CardSkins = ActiveCardSkins;
		currentCharacter.CardStyles = ActiveCardStyles;
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public static void BuyCard(int itemID, CurrencyType type, Delegates.VoidCallback onSuccess)
	{
		HttpRequestBuyItem httpRequestBuyItem = new HttpRequestBuyItem();
		httpRequestBuyItem.shopID = itemID;
		httpRequestBuyItem.type = type;
		GameHttpManager.Inst.Send(httpRequestBuyItem, delegate
		{
			LocalPlayerDatabase.RefreshAssetsInfo(onSuccess);
		});
	}

	public static bool OwnCardSkin(int cardSkinID, out int expiredTime)
	{
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(cardSkinID);
		if (cardSkinInfo != null && cardSkinInfo.UnlockLevel == 0 && cardSkinInfo.GainType == 0)
		{
			expiredTime = 0;
			return true;
		}
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardOwnSkin.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardOwnSkin[i] == cardSkinID && (LocalPlayerDatabase.PlayerInfo.cardSkinExpiredTime[i] == 0 || LocalPlayerDatabase.PlayerInfo.cardSkinExpiredTime[i] > UtcTimeStamp.Now))
			{
				expiredTime = (int)LocalPlayerDatabase.PlayerInfo.cardSkinExpiredTime[i];
				return true;
			}
		}
		expiredTime = -1;
		return false;
	}

	public static bool OwnCardStyle(int cardStyleID, out int expiredTime)
	{
		if (LocalResources.CardStyleTable.Get(cardStyleID) == null)
		{
			expiredTime = -1;
			return false;
		}
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardOwnStyle.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardOwnStyle[i] == cardStyleID && (LocalPlayerDatabase.PlayerInfo.cardStyleExpiredTime[i] == 0 || LocalPlayerDatabase.PlayerInfo.cardStyleExpiredTime[i] > UtcTimeStamp.Now))
			{
				expiredTime = (int)LocalPlayerDatabase.PlayerInfo.cardStyleExpiredTime[i];
				return true;
			}
		}
		expiredTime = -1;
		return false;
	}

	public static bool IsDefaultCardSkin(int cardID, int skinID)
	{
		return LocalResources.InGameStoreTable.Get(cardID).DefaultSkinID == skinID;
	}

	public static bool OwnPermanentCardSkin(int cardSkinID)
	{
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardOwnSkin.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardOwnSkin[i] == cardSkinID)
			{
				if (LocalPlayerDatabase.PlayerInfo.cardSkinExpiredTime[i] != 0)
				{
					break;
				}
				return true;
			}
		}
		return false;
	}

	public static bool OwnPermanentCardStyle(int cardSkinID)
	{
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardOwnStyle.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardOwnStyle[i] == cardSkinID)
			{
				if (LocalPlayerDatabase.PlayerInfo.cardStyleExpiredTime[i] != 0)
				{
					break;
				}
				return true;
			}
		}
		return false;
	}

	public static int CurCardSkin(int cardID)
	{
		return CurCardSkin(cardID, LocalPlayerDatabase.PlayerInfo.cardIDs, LocalPlayerDatabase.PlayerInfo.cardCurSkin);
	}

	public static int CurCardSkin(int cardID, int[] cards, int[] cardSkins)
	{
		if (cardSkins == null)
		{
			return LocalResources.InGameStoreTable.Get(cardID).DefaultSkinID;
		}
		for (int i = 0; i < cards.Length; i++)
		{
			if (cards[i] == cardID)
			{
				return cardSkins[i];
			}
		}
		return LocalResources.InGameStoreTable.Get(cardID).DefaultSkinID;
	}

	public static int CurCardStyle(int skinID)
	{
		return CurCardStyle(skinID, LocalPlayerDatabase.PlayerInfo.cardCurStyle);
	}

	public static int CurCardStyle(int skinID, int[] cardStyles)
	{
		if (cardStyles == null || skinID == 0)
		{
			return 0;
		}
		for (int i = 0; i < cardStyles.Length; i++)
		{
			if (skinID == LocalResources.CardStyleTable.Get(cardStyles[i]).BasicCardSkinId)
			{
				return cardStyles[i];
			}
		}
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Find(skinID);
		if (cardSkinInfo != null)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardSkinInfo.CardID);
			if (inGameStoreInfo != null && inGameStoreInfo.Type == InGameStoreType.WeaponUpgrade && CurCardStyle(cardSkinInfo.TypeParam, cardStyles) > 0)
			{
				return LocalResources.CardStyleTable.Find((CardStyleInfo a) => a.BasicCardSkinId == skinID).Id;
			}
		}
		return 0;
	}

	public static void SetCardSkin(int cardID, int skinID)
	{
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardIDs.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardIDs[i] == cardID)
			{
				LocalPlayerDatabase.PlayerInfo.cardCurSkin[i] = skinID;
			}
		}
	}

	public static void SetCardStyle(int skinID, int styleID)
	{
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.cardOwnSkin.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.cardOwnSkin[i] == skinID)
			{
				LocalPlayerDatabase.PlayerInfo.cardCurStyle[i] = styleID;
			}
		}
		LobbyScene.Inst.CurrentCharacter.CardStyles = ActiveCardStyles;
	}

	public static CardSkinInfo GetSkinInfo(InGameStoreInfo cardInfo)
	{
		if (cardInfo.Type == InGameStoreType.WeaponUpgrade || cardInfo.Type == InGameStoreType.Magazine)
		{
			int num = CurCardSkin((cardInfo.Type == InGameStoreType.WeaponUpgrade) ? LocalResources.WeaponTable.Get(cardInfo.TypeParam).BaseWeaponID : cardInfo.TypeParam);
			foreach (CardSkinInfo item in LocalResources.CardSkinTable)
			{
				if (item.TypeParam == num && item.CardID == cardInfo.Id)
				{
					return item;
				}
			}
			return null;
		}
		return LocalResources.CardSkinTable.Get(CurCardSkin(cardInfo.Id));
	}

	public static CardSkinInfo GetSkinInfo(int cardID)
	{
		return GetSkinInfo(LocalResources.InGameStoreTable.Get(cardID));
	}

	public static CardSkinInfo GetSkinInfo(int cardID, int[] cards, int[] cardSkins)
	{
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		if (inGameStoreInfo.Type == InGameStoreType.WeaponUpgrade || inGameStoreInfo.Type == InGameStoreType.Magazine)
		{
			int num = CurCardSkin((inGameStoreInfo.Type == InGameStoreType.WeaponUpgrade) ? LocalResources.WeaponTable.Get(inGameStoreInfo.TypeParam).BaseWeaponID : inGameStoreInfo.TypeParam, cards, cardSkins);
			foreach (CardSkinInfo item in LocalResources.CardSkinTable)
			{
				if (item.TypeParam == num && item.CardID == inGameStoreInfo.Id)
				{
					return item;
				}
			}
			return null;
		}
		return LocalResources.CardSkinTable.Get(CurCardSkin(inGameStoreInfo.Id, cards, cardSkins));
	}

	public static int[] GetRelatedCardSkin(int[] cardSkins, int[] cardStyles)
	{
		List<int> list = new List<int>();
		if (cardSkins == null)
		{
			return list.ToArray();
		}
		for (int i = 0; i < cardSkins.Length; i++)
		{
			int skinID = (cardStyles != null && cardStyles[i] > 0) ? cardStyles[i] : cardSkins[i];
			BaseCardSkinInfo baseCardSkinInfo = LocalResources.CardStyleTable.Find(skinID);
			if (baseCardSkinInfo != null && baseCardSkinInfo.TypeParam > 0)
			{
				foreach (CardStyleInfo item in LocalResources.CardStyleTable.FindAll((CardStyleInfo x) => x.TypeParam == skinID && x.Id != skinID))
				{
					list.Add(item.Id);
				}
				continue;
			}
			baseCardSkinInfo = LocalResources.CardSkinTable.Find(skinID);
			if (baseCardSkinInfo != null && baseCardSkinInfo.TypeParam > 0)
			{
				foreach (CardSkinInfo item2 in LocalResources.CardSkinTable.FindAll((CardSkinInfo x) => x.TypeParam == skinID && x.Id != skinID))
				{
					list.Add(item2.Id);
				}
			}
		}
		return list.ToArray();
	}

	public static BaseCardSkinInfo GetBaseCardSkinInfo(int cardSkinOrStyleID)
	{
		BaseCardSkinInfo baseCardSkinInfo = LocalResources.CardStyleTable.Get(cardSkinOrStyleID);
		if (baseCardSkinInfo == null || baseCardSkinInfo.CardID == 0)
		{
			baseCardSkinInfo = LocalResources.CardSkinTable.Get(cardSkinOrStyleID);
		}
		if (baseCardSkinInfo == null || baseCardSkinInfo.CardID == 0)
		{
			UnityEngine.Debug.LogError("GetBaseCardSkinInfo Cannot Find:" + cardSkinOrStyleID);
		}
		return baseCardSkinInfo;
	}

	public static CardStyleInfo GetStyleInfo(int cardID, int[] cards, int[] cardSkins, int[] cardStyles, out CardSkinInfo skinInfo)
	{
		skinInfo = GetSkinInfo(cardID, cards, cardSkins);
		if (skinInfo == null)
		{
			return null;
		}
		return LocalResources.CardStyleTable.Get(CurCardStyle(skinInfo.Id, cardStyles));
	}

	public static BaseCardSkinInfo GetMyBaseCardSkinInfo(int cardID)
	{
		CardSkinInfo skinInfo;
		CardStyleInfo styleInfo = GetStyleInfo(cardID, LocalPlayerDatabase.PlayerInfo.cardIDs, LocalPlayerDatabase.PlayerInfo.cardCurSkin, LocalPlayerDatabase.PlayerInfo.cardCurStyle, out skinInfo);
		if (styleInfo != null && styleInfo.CardID > 0)
		{
			return styleInfo;
		}
		return skinInfo;
	}

	public static bool AllCardsCollected()
	{
		InGameStoreInfo[] allCardInfos = GetAllCardInfos();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			if (!IsOwned(inGameStoreInfo.Id) && !CanComposeCard(inGameStoreInfo.Id))
			{
				return false;
			}
		}
		return true;
	}

	public static bool AllCardsCanDropPiece()
	{
		InGameStoreInfo[] allCardInfos = GetAllCardInfos();
		for (int i = 0; i < allCardInfos.Length; i++)
		{
			if (!CanDropCardPiece(allCardInfos[i].Id))
			{
				return false;
			}
		}
		return true;
	}

	public static bool CanDropCardPiece(int cardID)
	{
		return CanDropCardPiece(GetCardGrowth(cardID));
	}

	public static bool CanDropCardPiece(CardGrowthInfo growInfo)
	{
		return LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= growInfo.UnlockGrade;
	}

	public static bool GetUpgradeLimit(int cardID, out int upgradeLimitGrade, out int goldCost, out int pieceCost)
	{
		upgradeLimitGrade = 0;
		goldCost = 0;
		pieceCost = 0;
		int cardLevel = GetCardLevel(cardID);
		CardGrowthInfo cardGrowth = GetCardGrowth(cardID);
		if (cardLevel >= cardGrowth.MaxLevel)
		{
			return false;
		}
		upgradeLimitGrade = cardGrowth.UpgradeLimitGrade[cardLevel - 1];
		goldCost = cardGrowth.GoldCostNew[cardLevel - 1];
		pieceCost = cardGrowth.PieceCostNew[cardLevel - 1];
		return true;
	}

	public static void UnLoadExtraWeaponCard()
	{
		int[] config = ActiveCardConfig.config;
		int num = 0;
		for (int i = 0; i < config.Length; i++)
		{
			int num2 = config[i];
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(num2);
			if (inGameStoreInfo != null && inGameStoreInfo.Type == InGameStoreType.Weapon)
			{
				if (num == 0)
				{
					num = num2;
				}
				else
				{
					config[i] = 0;
				}
			}
		}
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public static void LoadDefaultWeaponCard()
	{
		int num = ArrayUtility.IndexOf(ActiveCardConfig.config, 0);
		if (num == -1)
		{
			num = ActiveCardConfig.config.Length - 1;
		}
		LoadCard(200, num);
	}

	public static bool ContainsWeaponCard()
	{
		return CountActiveWeaponCard() > 0;
	}

	public static bool ContainsMultiWeaponCard()
	{
		return CountActiveWeaponCard() > 1;
	}

	private static int CountActiveWeaponCard()
	{
		int num = 0;
		int[] config = ActiveCardConfig.config;
		foreach (int id in config)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(id);
			if (inGameStoreInfo != null && inGameStoreInfo.Type == InGameStoreType.Weapon)
			{
				num++;
			}
		}
		return num;
	}

	public static int[] GetActiveCardSkins(int[] activeCardIDs, int[] cardIDs, int[] cardCurSkin)
	{
		int[] array = new int[activeCardIDs.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = CurCardSkin(activeCardIDs[i], cardIDs, cardCurSkin);
		}
		return array;
	}

	public static int[] GetActiveCardStyles(int[] activeCardSkins, int[] cardCurStyles)
	{
		int[] array = new int[activeCardSkins.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = CurCardStyle(activeCardSkins[i], cardCurStyles);
		}
		return array;
	}

	public static int GetCardComposePieceNum(int cardID)
	{
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		return LocalResources.CardGrowthTable.Get(inGameStoreInfo.GrowthID).ComposePiece;
	}

	public static int GetOwnCardPieceNum(int cardID)
	{
		if (LocalPlayerDatabase.PlayerInfo.cardPiece != null)
		{
			CardPieceInfo[] cardPiece = LocalPlayerDatabase.PlayerInfo.cardPiece;
			foreach (CardPieceInfo cardPieceInfo in cardPiece)
			{
				if (cardPieceInfo.cardID == cardID)
				{
					return cardPieceInfo.num;
				}
			}
		}
		return 0;
	}

	public static bool CanComposeCard(int cardID)
	{
		return GetOwnCardPieceNum(cardID) >= GetCardComposePieceNum(cardID);
	}

	public static bool AnyCanComposeCard()
	{
		return AnyCanComposeCardID() != 0;
	}

	public static int AnyCanComposeCardID()
	{
		InGameStoreInfo[] allCardInfos = GetAllCardInfos();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			if (!IsOwned(inGameStoreInfo.Id) && CanComposeCard(inGameStoreInfo.Id) && CanDropCardPiece(GetCardGrowth(inGameStoreInfo.Id)))
			{
				return inGameStoreInfo.Id;
			}
		}
		return 0;
	}

	public static bool CanUpgradeCard(int cardID)
	{
		if (IsOwned(cardID))
		{
			int goldCost;
			if (GetUpgradeLimit(cardID, out int upgradeLimitGrade, out goldCost, out int pieceCost) && Mathf.Max(LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice, LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief) >= upgradeLimitGrade && LocalPlayerDatabase.PlayerInfo.gold >= goldCost)
			{
				return GetOwnCardPieceNum(cardID) >= pieceCost;
			}
			return false;
		}
		return false;
	}

	public static bool CanUpgradeCard2(int cardID)
	{
		if (IsOwned(cardID))
		{
			if (GetUpgradeLimit(cardID, out int upgradeLimitGrade, out int _, out int pieceCost) && Mathf.Max(LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice, LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief) >= upgradeLimitGrade)
			{
				return GetOwnCardPieceNum(cardID) >= pieceCost;
			}
			return false;
		}
		return false;
	}

	public static bool IsEnoughCardPiece(int cardID, int pieceNum, out bool Own, out bool maxLevel, out int needPiece)
	{
		CardGrowthInfo cardGrowth = GetCardGrowth(cardID);
		Own = IsOwned(cardID);
		if (Own)
		{
			int cardLevel = GetCardLevel(cardID);
			maxLevel = (cardLevel >= cardGrowth.MaxLevel);
			needPiece = (maxLevel ? 1 : cardGrowth.PieceCostNew[cardLevel - 1]);
		}
		else
		{
			maxLevel = false;
			needPiece = cardGrowth.ComposePiece;
		}
		return pieceNum >= needPiece;
	}

	public static int GetUpgradeToMaxPieceNum(int cardID)
	{
		int cardLevel = GetCardLevel(cardID);
		CardGrowthInfo cardGrowth = GetCardGrowth(cardID);
		if (cardLevel >= cardGrowth.MaxLevel)
		{
			return 0;
		}
		int num = 0;
		for (int i = cardLevel - 1; i < cardGrowth.PieceCostNew.Length; i++)
		{
			num += cardGrowth.PieceCostNew[i];
		}
		if (!IsOwned(cardID))
		{
			num += cardGrowth.ComposePiece;
		}
		return num;
	}

	public static void ComposeCard(int cardID, Delegates.VoidCallback OnSuccess)
	{
		HttpRequestComposeCard httpRequestComposeCard = new HttpRequestComposeCard();
		httpRequestComposeCard.cardID = cardID;
		GameHttpManager.Inst.Send(httpRequestComposeCard, delegate
		{
			OnSuccess();
			LocalPlayerDatabase.SetPrefValue("HadComposeCard", value: true);
		});
	}

	public static DropItem GetCardPieceDropInfo(int cardID)
	{
		return LocalResources.DropItemTable.Get(cardID + 20000);
	}

	public static CommonDataCollection CardDetailUIArgsWraper(int cardID, int cardLevel, bool showUpgradeBtn = true, bool isLocalPlayer = true, bool isFromStore = false)
	{
		return new CommonDataCollection
		{
			["cardID"] = cardID,
			["cardLevel"] = cardLevel,
			["showUpgradeBtn"] = showUpgradeBtn,
			["isLocalPlayer"] = isLocalPlayer,
			["IsFromStore"] = isFromStore,
			["IsFromShowUI"] = true
		};
	}

	public static void RefreshClaimedCardSkinID()
	{
		GameHttpManager.Inst.Send(new HttpRequestClaimedCardSkinID(), delegate(HttpResponseClaimedCardSkinID onResponse)
		{
			cacheClaimedCardSkinID = onResponse;
		});
	}

	public static string GetCardPrefabName(int skinId)
	{
		if (LocalResources.CardSkinTable.Get(skinId).Styles.Contains(StyleItemTemplate.GlobleSelectedStyleId))
		{
			return LocalResources.CardStyleTable.Get(StyleItemTemplate.GlobleSelectedStyleId).Prefabs;
		}
		int[] cardCurStyle = LocalPlayerDatabase.PlayerInfo.cardCurStyle;
		foreach (int num in cardCurStyle)
		{
			if (num != 0)
			{
				CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(num);
				if (cardStyleInfo.BasicCardSkinId == skinId)
				{
					return cardStyleInfo.Prefabs;
				}
			}
		}
		return LocalResources.CardSkinTable.Get(skinId).Prefabs;
	}

	public static string GetCardIconName(int skinId)
	{
		int[] cardCurStyle = LocalPlayerDatabase.PlayerInfo.cardCurStyle;
		foreach (int num in cardCurStyle)
		{
			if (num != 0)
			{
				CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(num);
				if (cardStyleInfo.BasicCardSkinId == skinId)
				{
					return cardStyleInfo.Icon;
				}
			}
		}
		return LocalResources.CardSkinTable.Get(skinId).Icon;
	}

	public static bool CardSkinIsClaimed(int cardSkinId)
	{
		return cacheClaimedCardSkinID.cardSkinID.Contains(cardSkinId);
	}

	public static void OnClaimCardSkin(int cardSkinId)
	{
		List<int> list = new List<int>(cacheClaimedCardSkinID.cardSkinID);
		list.Add(cardSkinId);
		cacheClaimedCardSkinID.cardSkinID = list.ToArray();
	}

	public static List<int> GetCanShowStyleList(int skinId)
	{
		List<int> list = new List<int>();
		int[] styles = LocalResources.CardSkinTable.Get(skinId).Styles;
		for (int i = 0; i < styles.Length; i++)
		{
			CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(styles[i]);
			bool flag = (cardStyleInfo.SellStartTime != 0 && cardStyleInfo.SellStartTime > UtcTimeStamp.Now) || (cardStyleInfo.SellEndTime != 0 && cardStyleInfo.SellEndTime < UtcTimeStamp.Now);
			if (OwnCardStyle(cardStyleInfo.Id, out int _) || !flag)
			{
				list.Add(styles[i]);
			}
		}
		return list;
	}
}
