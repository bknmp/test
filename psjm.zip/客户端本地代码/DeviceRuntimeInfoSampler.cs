using PerformanceSDK;
using PerformanceSDK.Core;
using System;
using System.Collections.Generic;
using UnityEngine;

public class DeviceRuntimeInfoSampler : ISampler
{
	[Serializable]
	public class CpuTimeInState
	{
		public int index;

		public string[] freqs;

		public long[] times;
	}

	public class DeviceRuntimeInfoSampleData
	{
		public float startGameTemperature;

		public float endGameTemperature;

		public float startGamePss;

		public float endGamePss;

		public string startGameMono = "";

		public string endGameMono = "";

		public float beforeGamebatteryLevel = -1f;

		public float afterGamebatteryLevel = -1f;

		public CpuTimeInState cpuTimeInState;

		public int startGameCpuFrequency;

		public int endGameCpuFrequency;
	}

	private DeviceRuntimeInfoSampleData _reportSampleData = new DeviceRuntimeInfoSampleData();

	private bool startGameTemperatureRecorded;

	private float duration;

	private int cpuIndex;

	private string startCpuTimeInfo;

	public string tag
	{
		get;
		private set;
	}

	[SamplerCreator("DeviceRuntimeInfo")]
	public static ISampler Create(SampleSetting setting)
	{
		return new DeviceRuntimeInfoSampler(setting);
	}

	private void Reset()
	{
		_reportSampleData.startGamePss = 0f;
		_reportSampleData.endGamePss = 0f;
		_reportSampleData.startGameTemperature = 0f;
		_reportSampleData.endGameTemperature = 0f;
		_reportSampleData.beforeGamebatteryLevel = -1f;
		_reportSampleData.afterGamebatteryLevel = -1f;
		_reportSampleData.startGameCpuFrequency = 0;
		_reportSampleData.endGameCpuFrequency = 0;
		duration = 0f;
		startGameTemperatureRecorded = false;
	}

	public DeviceRuntimeInfoSampler(SampleSetting setting)
	{
		tag = setting.tag;
	}

	public void OnSample()
	{
		float deltaTimeFromLastFrame = TimeManager.DeltaTimeFromLastFrame;
		duration += deltaTimeFromLastFrame;
		if (duration > 1f && !startGameTemperatureRecorded)
		{
			_reportSampleData.startGameTemperature = PerformanceInfoUtils.GetTemperature();
			startGameTemperatureRecorded = true;
		}
	}

	public void OnBeginSample()
	{
		Reset();
		PerformanceInfoUtils.StartListenTemperature();
		startGameTemperatureRecorded = false;
		_reportSampleData.startGamePss = PerformanceInfoUtils.GetPss();
		_reportSampleData.startGameMono = PerformanceInfoUtils.GetMono();
		_reportSampleData.beforeGamebatteryLevel = SystemInfo.batteryLevel;
		_reportSampleData.startGameCpuFrequency = (int)ClipboardTool.GetCpuFrequency();
		cpuIndex = PerformanceInfoUtils.GetCurCpu();
		startCpuTimeInfo = PerformanceInfoUtils.GetCpuTimeInState(cpuIndex);
	}

	public object OnEndSample()
	{
		PerformanceInfoUtils.StartListenTemperature();
		_reportSampleData.endGamePss = PerformanceInfoUtils.GetPss();
		_reportSampleData.endGameMono = PerformanceInfoUtils.GetMono();
		_reportSampleData.afterGamebatteryLevel = SystemInfo.batteryLevel;
		_reportSampleData.endGameCpuFrequency = (int)ClipboardTool.GetCpuFrequency();
		CpuTimeInState end = String2TimeInState(PerformanceInfoUtils.GetCpuTimeInState(cpuIndex), cpuIndex);
		CpuTimeInState start = String2TimeInState(startCpuTimeInfo, cpuIndex);
		CpuTimeInState cpuTimeInState = CalculateDiffTimeInState(start, end);
		_reportSampleData.cpuTimeInState = cpuTimeInState;
		return _reportSampleData;
	}

	private CpuTimeInState String2TimeInState(string info, int index)
	{
		if (string.IsNullOrEmpty(info))
		{
			return null;
		}
		try
		{
			string[] array = info.Split('\n');
			if (array.Length == 0)
			{
				return null;
			}
			List<string> list = new List<string>();
			List<long> list2 = new List<long>();
			int i = 0;
			for (int num = array.Length; i < num; i++)
			{
				string[] array2 = array[i].Split(' ');
				if (array2.Length > 1 && long.TryParse(array2[1].Trim(), out long result))
				{
					list.Add(array2[0]);
					list2.Add(result);
				}
			}
			return new CpuTimeInState
			{
				freqs = list.ToArray(),
				times = list2.ToArray(),
				index = index
			};
		}
		catch (Exception)
		{
			return null;
		}
	}

	private CpuTimeInState CalculateDiffTimeInState(CpuTimeInState start, CpuTimeInState end)
	{
		if (start == null || end == null || start.freqs.Length != end.freqs.Length)
		{
			return null;
		}
		try
		{
			CpuTimeInState cpuTimeInState = new CpuTimeInState
			{
				freqs = new string[start.freqs.Length],
				times = new long[start.times.Length],
				index = start.index
			};
			int i = 0;
			for (int num = start.freqs.Length; i < num; i++)
			{
				cpuTimeInState.freqs[i] = start.freqs[i];
				cpuTimeInState.times[i] = end.times[i] - start.times[i];
			}
			return cpuTimeInState;
		}
		catch (Exception)
		{
			return null;
		}
	}
}
