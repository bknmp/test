using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using LightUtility;

[TaskName("角色距离比较")]
[TaskCategory("躲猫猫AI/条件")]
[TaskDescription("比较的值是距离的平方")]
public class DistanceComparison : CustomFloatComparison
{
	public SharedPlayerController player1;

	public SharedPlayerController player2;

	public bool ignoreY;

	public bool comparePostion;

	public SharedVector3 targetPostion;

	public SharedFloat storeDistanceResult;

	public override TaskStatus OnUpdate()
	{
		if (player1.Value == null || (!comparePostion && player2.Value == null))
		{
			return TaskStatus.Failure;
		}
		if (!comparePostion)
		{
			if (ignoreY)
			{
				CompareValue = (player1.Value.transform.localPosition - player2.Value.transform.localPosition).FlattenY().sqrMagnitude;
			}
			else
			{
				CompareValue = (player1.Value.transform.localPosition - player2.Value.transform.localPosition).sqrMagnitude;
			}
		}
		else if (ignoreY)
		{
			CompareValue = (player1.Value.transform.localPosition - targetPostion.Value).FlattenY().sqrMagnitude;
		}
		else
		{
			CompareValue = (player1.Value.transform.localPosition - targetPostion.Value).sqrMagnitude;
		}
		if (storeDistanceResult != null)
		{
			storeDistanceResult.Value = CompareValue;
		}
		return base.OnUpdate();
	}
}
