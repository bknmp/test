using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine.UI;

internal class CardUpgradeReward_ItemTemplate
{
	public UIDataBinder m_Host;

	public Image m_Frame;

	public Image m_Icon;

	public UIDataScrollView m_DataScrollViewLeft;

	public Image m_MaxLevelFrame;

	public Image m_MaxLevelIcon;

	public Text m_MaxLevelAmount;

	public Slider m_Process;

	public Text m_Level;

	public Text m_Name;

	public Text m_NotOwn;

	public MultiTargetGraphicButton m_CardButton;

	private string m_LevelFormat;

	private int m_cardId;

	private CommonDataCollection m_rewardArgs = new CommonDataCollection();

	private CardUpgradeRewardActivity m_cardUpgradeRewardUI;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_LevelFormat))
		{
			m_LevelFormat = m_Level.text;
		}
		CardUpgradeRewardActivityInfo cardUpgradeRewardActivityInfo = args["CardUpgradeRewardInfo"].val as CardUpgradeRewardActivityInfo;
		m_cardUpgradeRewardUI = (args["CardUpgradeRewardUI"].val as CardUpgradeRewardActivity);
		m_cardId = cardUpgradeRewardActivityInfo.cardId;
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_cardId);
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_Icon.sprite = SpriteSource.Inst.Find(LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID).Icon);
		m_Name.text = inGameStoreInfo.FullName;
		CardUpgradeReward cardUpgradeReward = LocalResources.CardUpgradeReward.Get(cardUpgradeRewardActivityInfo.cardId);
		DropItem dropItem = LocalResources.DropItemTable.Get(cardUpgradeReward.ItemID[cardUpgradeReward.ItemID.Length - 1]);
		m_MaxLevelFrame.sprite = SpriteSource.Inst.Find(dropItem.Frame);
		m_MaxLevelIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_MaxLevelAmount.text = BuyGoodsUI_ItemTemplate.GetUnitString(dropItem, cardUpgradeReward.ItemCount[cardUpgradeReward.ItemCount.Length - 1]);
		int num = CardUtility.IsOwned(inGameStoreInfo.Id) ? CardUtility.GetCardLevel(inGameStoreInfo.Id) : 0;
		m_Process.value = 1f - (float)num / (float)CardUtility.GetCardGrowth(inGameStoreInfo.Id).MaxLevel;
		m_rewardArgs.Clear();
		for (int i = 0; i < cardUpgradeReward.ItemID.Length; i++)
		{
			m_rewardArgs[i]["cardID"] = cardUpgradeReward.Id;
			m_rewardArgs[i]["itemId"] = cardUpgradeReward.ItemID[i];
			m_rewardArgs[i]["itemCount"] = cardUpgradeReward.ItemCount[i];
			m_rewardArgs[i]["index"] = i;
			m_rewardArgs[i]["claimed"] = cardUpgradeRewardActivityInfo.claimed[i];
			m_rewardArgs[i]["cardLevel"] = num;
			m_rewardArgs[i]["CardUpgradeRewardUI"].val = m_cardUpgradeRewardUI;
		}
		if (num > 0)
		{
			m_NotOwn.gameObject.SetActive(value: false);
			m_Level.gameObject.SetActive(value: true);
			m_Level.text = string.Format(m_LevelFormat, num);
		}
		else
		{
			m_NotOwn.gameObject.SetActive(value: true);
			m_Level.gameObject.SetActive(value: false);
		}
		m_DataScrollViewLeft.m_TemplateInitiator.Args = m_rewardArgs;
		m_DataScrollViewLeft.m_TemplateInitiator.OnItemsChanged.RemoveListener(KeepProcessFirstSibling);
		m_DataScrollViewLeft.m_TemplateInitiator.OnItemsChanged.AddListener(KeepProcessFirstSibling);
		m_DataScrollViewLeft.m_ScrollRect.scrollbar.onValueChanged.AddListener(OnScrollViewValueChange);
		CardUpgradeRewardActivity cardUpgradeRewardUI = m_cardUpgradeRewardUI;
		cardUpgradeRewardUI.OnScrollViewValueChange = (Delegates.ObjectCallback2<int, float>)Delegate.Combine(cardUpgradeRewardUI.OnScrollViewValueChange, new Delegates.ObjectCallback2<int, float>(TryUpdateScrollViewValue));
		m_Host.EventProxy(m_CardButton, "OnClickCardButton");
	}

	private void KeepProcessFirstSibling()
	{
		m_Process.transform.SetAsFirstSibling();
	}

	private void OnScrollViewValueChange(float value)
	{
		m_cardUpgradeRewardUI.OnScrollViewValueChange(m_cardId, value);
	}

	private void TryUpdateScrollViewValue(int id, float value)
	{
		if (id != m_cardId)
		{
			m_DataScrollViewLeft.m_ScrollRect.scrollbar.onValueChanged.RemoveListener(OnScrollViewValueChange);
			m_DataScrollViewLeft.m_ScrollRect.scrollbar.value = value;
			m_DataScrollViewLeft.m_ScrollRect.scrollbar.onValueChanged.AddListener(OnScrollViewValueChange);
		}
	}

	public void OnClickCardButton()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.CardDetail, CardUtility.CardDetailUIArgsWraper(m_cardId, CardUtility.GetCardLevel(m_cardId)));
	}
}
