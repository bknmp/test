using GameMessages;
using LightUI;
using System.Collections.Generic;

public class CollectionPage_SkinPartBlock
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Group;

	public UIStateImage m_Title;

	public void Bind(CommonDataCollection args)
	{
		DataItem value = args["roleID"];
		HttpResponsePlayerInfo val = (HttpResponsePlayerInfo)args["playerInfo"].val;
		HttpResponseCardConfigs val2 = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		int state = args["state"];
		m_Title.State = state;
		List<int> list = (List<int>)args["skinPart"].val;
		args.Clear();
		for (int i = 0; i < list.Count; i++)
		{
			args[i]["itemID"] = list[i];
			args[i]["roleID"] = value;
			args[i]["playerInfo"].val = val;
			args[i]["playerCardConfigs"].val = val2;
		}
		m_Group.Args = args;
		m_Group.UpdateImmediately(withChildren: true);
	}
}
