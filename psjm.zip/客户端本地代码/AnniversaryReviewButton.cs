using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AnniversaryReviewButton : ActivityBaseButton
{
	public Text m_ActivityName;

	public GameObject m_RedPoint;

	private ActivityLobbyInfo m_ActivityInfo;

	private CommonDataCollection m_Arg;

	private void Start()
	{
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.ANNIVERSARY_REVIEW, ActivityCollectionType.ANNIVERSART_ACTIVITY, out m_ActivityInfo, ignoreTime: true);
		if (activityByActivityTypeAndCollectionType != null)
		{
			m_Arg = new CommonDataCollection();
			m_Arg["Activity"].val = activityByActivityTypeAndCollectionType;
			m_ActivityName.text = m_ActivityInfo.TabName;
		}
		SetInfo(activityByActivityTypeAndCollectionType);
		RefreshRedPoint();
		UIDataEvents.Inst.AddEventListener("OnActivityLobbyRedPointChange", this, RefreshRedPoint);
	}

	public void OnClick()
	{
		UILobby.Current.ShowUI(PrefabSource.Inst.Find(m_ActivityInfo.Prefab).GetComponent<UILobbyElement>(), m_Arg);
	}

	private void RefreshRedPoint()
	{
		m_RedPoint.gameObject.SetActive(AnniversaryReviewActivityUI.GetRedPoint());
	}
}
