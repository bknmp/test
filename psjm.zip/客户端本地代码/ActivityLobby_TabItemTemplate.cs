using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class ActivityLobby_TabItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_TabName;

	public GameObject m_RedPoint;

	public Text m_TabName2;

	public RawImage m_TabNameImage;

	public GameObject m_Line;

	public UIStateImage m_TabIcon;

	public void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
		if (m_TabName != null)
		{
			m_TabName.text = ((activityLobbyInfo.Type == ActivityType.PREVIEW) ? activityLobbyInfo.TitleName : activityLobbyInfo.TabName);
		}
		m_RedPoint.gameObject.SetActive(ActivityLobby.TabRedPointState(activityLobbyInfo.Type, activity.activityId));
		if (m_TabName2 != null)
		{
			m_TabName2.text = activityLobbyInfo.TabName;
			m_TabName.text = ((activityLobbyInfo.Type == ActivityType.PREVIEW) ? activityLobbyInfo.TitleName : activityLobbyInfo.TabName);
		}
		if (m_TabNameImage != null)
		{
			m_TabNameImage.texture = ResManager.Load<Texture>(activityLobbyInfo.TabName);
		}
		if (m_Line != null)
		{
			m_Line.gameObject.SetActive(!args.ContainsKey("IsLast"));
		}
		if (m_TabIcon != null)
		{
			m_TabIcon.State = activityLobbyInfo.Rank - 1;
		}
	}
}
