using LightUI;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class AccountBindMessageBoxUI
{
	public UIDataBinder m_Host;

	public Button m_BindButton;

	public Button m_CloseButton;

	public Text m_Message;

	public Button m_CountDown;

	private Text m_CountDownText;

	private string m_CountDownFormat;

	private int m_DelayTime = 15;

	private Coroutine m_CountDownQuit;

	private int m_RemainCountDown;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_BindButton, "OnBind");
		m_Host.EventProxy(m_CountDown, "QuitGame");
		DataItem item = args["IsGobackOrQuit"];
		m_Message.text = args["msg"];
		m_CloseButton.gameObject.SetActive(item);
		m_CountDown.gameObject.SetActive(!item);
		m_CountDownText = m_CountDown.GetComponentInChildren<Text>();
		TryStartCountDown();
		m_RemainCountDown = 0;
	}

	private void OnComeBackUI()
	{
		if (m_RemainCountDown > 0)
		{
			m_CountDownQuit = m_Host.StartCoroutine(ButtonCountDown(m_RemainCountDown));
		}
	}

	private void OnDestroy()
	{
		if ((bool)TouristSystem.Inst)
		{
			TouristSystem.Inst.SetShowingPopup(show: false);
		}
	}

	private void TryStartCountDown()
	{
		if (m_CountDown.gameObject.activeSelf)
		{
			if (m_CountDownFormat == null)
			{
				m_CountDownFormat = m_CountDownText.text;
			}
			m_CountDownQuit = m_Host.StartCoroutine(ButtonCountDown(m_DelayTime));
		}
	}

	private void EndCountDown()
	{
		if (m_CountDownQuit != null)
		{
			m_Host.StopCoroutine(m_CountDownQuit);
		}
	}

	private IEnumerator ButtonCountDown(int time)
	{
		while (time > 0)
		{
			SetTIme(time);
			m_CountDownText.text = string.Format(m_CountDownFormat, time);
			yield return new WaitForSeconds(1f);
			time--;
		}
		QuitGame();
	}

	private void SetTIme(int t)
	{
		m_RemainCountDown = t;
	}

	public void QuitGame()
	{
		Application.Quit();
	}

	public void OnBind()
	{
		EndCountDown();
		AccountSetPwdUI.ShowUI((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName, "", "", OnBindSuccess);
	}

	private void OnBindSuccess(int id)
	{
		TouristSystem.ClearTouristPlayedTime();
		m_Host.GetComponent<UIPopup>().GoBack();
	}
}
