using System;
using UnityEngine;
using UnityEngine.Events;

public class AutoCoinSupplement : MonoBehaviour
{
	public float m_FirstTime = 10f;

	public float m_Interval = 30f;

	private PlayerController m_PlayerController;

	private void Start()
	{
		m_PlayerController = GetComponent<PlayerController>();
		if (m_PlayerController.PlayingRole == RoleType.Thief && !GameRuntime.IsMapBoss && !GameRuntime.IsMapRedEnvelopeFight)
		{
			UnityEngine.Object.Destroy(this);
			return;
		}
		InGameStartup inst = InGameStartup.Inst;
		inst.OnCountDownStart = (UnityAction)Delegate.Combine(inst.OnCountDownStart, new UnityAction(Initialize));
	}

	private void Initialize()
	{
		if (this != null)
		{
			InvokeRepeating("TriggerSupplement", m_FirstTime, m_Interval);
		}
	}

	private void TriggerSupplement()
	{
		if (!InGameStore.Inst.gameObject.activeSelf || !m_PlayerController.IsMine)
		{
			return;
		}
		InGameCoinRewardReason reason;
		if (GameRuntime.MapType == MapType.TypeBoss)
		{
			if (m_PlayerController.PlayingRole != RoleType.Thief)
			{
				return;
			}
			switch (VaultObject.StolenCount)
			{
			case 0:
				reason = InGameCoinRewardReason.Auto1_BossMode_Thief;
				break;
			case 1:
				reason = InGameCoinRewardReason.Auto2_BossMode_Thief;
				break;
			case 2:
				reason = InGameCoinRewardReason.Auto3_BossMode_Thief;
				break;
			case 3:
				reason = InGameCoinRewardReason.Auto4_BossMode_Thief;
				break;
			default:
				reason = InGameCoinRewardReason.Auto5_BossMode_Thief;
				break;
			}
		}
		else if (GameRuntime.IsMapRedEnvelopeFight)
		{
			reason = ((InGameScene.Inst.GameTime < 60f) ? InGameCoinRewardReason.RedEnvelope1 : ((!(InGameScene.Inst.GameTime < 150f)) ? InGameCoinRewardReason.RedEnvelope3 : InGameCoinRewardReason.RedEnvelope2));
		}
		else if (GameRuntime.MapType == MapType.Type4v1)
		{
			switch (VaultObject.StolenCount)
			{
			case 0:
				reason = InGameCoinRewardReason.Auto1_4v1;
				break;
			case 1:
				reason = InGameCoinRewardReason.Auto2_4v1;
				break;
			case 2:
				reason = InGameCoinRewardReason.Auto3_4v1;
				break;
			default:
				reason = InGameCoinRewardReason.Auto4_4v1;
				break;
			}
		}
		else
		{
			switch (VaultObject.StolenCount)
			{
			case 0:
				reason = InGameCoinRewardReason.Auto1_8v2;
				break;
			case 1:
				reason = InGameCoinRewardReason.Auto2_8v2;
				break;
			case 2:
				reason = InGameCoinRewardReason.Auto3_8v2;
				break;
			case 3:
				reason = InGameCoinRewardReason.Auto4_8v2;
				break;
			case 4:
				reason = InGameCoinRewardReason.Auto5_8v2;
				break;
			default:
				reason = InGameCoinRewardReason.Auto6_8v2;
				break;
			}
		}
		AddCoin(reason);
	}

	private void AddCoin(InGameCoinRewardReason reason)
	{
		m_PlayerController.RpcAddCoin(reason);
	}
}
