using GameMessages;
using LightUI;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class BuyGoodsUI_ExpAdd
{
	public UIDataBinder m_Host;

	public Text m_RoleLevelText;

	public Text m_CharacterName;

	public Image m_BarAdd;

	public Image m_Bar;

	public Text m_Value;

	public GameObject m_Root;

	public Text m_RoleUpLevelText;

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["id"];
		DataItem dataItem = args["exp"];
		DropItem dropItem = LocalResources.DropItemTable.Get(item);
		if (dropItem.Type == DropItemType.SkinPart || dropItem.Type == DropItemType.SkinSuite)
		{
			int id = (dropItem.Type == DropItemType.SkinPart) ? LocalResources.SkinPartTable.Get(dropItem.TypeParam).CharacterID : LocalResources.ShopSuiteTable.Get(dropItem.TypeParam).CharacterID;
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(id);
			PlayerCharacterInfo playerCharacter = CharacterUtility.GetOwnedCharacterInfo(id);
			if (playerCharacter.ExpLevel < LocalResources.ExpLevelTable.Last().Level)
			{
				float num = LocalResources.ExpLevelTable.Find((ExpLevelInfo a) => a.Level == playerCharacter.ExpLevel).ExpNeed;
				int num2 = playerCharacter.ExpPoint + (int)dataItem;
				int expLevel = playerCharacter.ExpLevel;
				int levelTo = GetLevelTo(expLevel, num2);
				SetRoleLevel(expLevel, levelTo);
				m_Bar.fillAmount = (float)playerCharacter.ExpPoint / num;
				m_BarAdd.fillAmount = (float)num2 / num;
				m_BarAdd.gameObject.SetActive(value: true);
				m_Value.text = $"+{dataItem}";
			}
			else
			{
				SetRoleLevel(playerCharacter.ExpLevel, playerCharacter.ExpLevel);
				m_Bar.fillAmount = 1f;
				m_BarAdd.gameObject.SetActive(value: false);
				m_Value.text = Localization.MaxLevel;
			}
			if (m_CharacterName != null)
			{
				m_CharacterName.text = characterInfo.Name;
			}
			m_Root.SetActive(value: true);
		}
		else
		{
			m_Root.SetActive(value: false);
		}
	}

	private void SetRoleLevel(int levelFrom, int levelTo)
	{
		if (m_RoleUpLevelText != null)
		{
			m_RoleLevelText.text = $"Lv.{levelFrom}";
			m_RoleUpLevelText.text = levelTo.ToString();
			bool active = levelFrom < levelTo;
			for (int i = 1; i < m_RoleUpLevelText.transform.parent.childCount; i++)
			{
				m_RoleUpLevelText.transform.parent.GetChild(i).gameObject.SetActive(active);
			}
		}
		else if (m_RoleLevelText != null)
		{
			if (levelFrom == levelTo)
			{
				m_RoleLevelText.text = levelFrom.ToString();
			}
			else
			{
				m_RoleLevelText.text = $"{levelFrom}->{levelTo}";
			}
		}
	}

	private int GetLevelTo(int levelFrom, int expTotal)
	{
		ExpLevelInfo info = LocalResources.ExpLevelTable.Find((ExpLevelInfo a) => a.Level == levelFrom);
		while (info.ExpNeed < expTotal)
		{
			expTotal -= info.ExpNeed;
			ExpLevelInfo expLevelInfo = LocalResources.ExpLevelTable.Find((ExpLevelInfo a) => a.Level == info.Level + 1);
			if (expLevelInfo == null)
			{
				break;
			}
			info = expLevelInfo;
		}
		return info.Level;
	}
}
