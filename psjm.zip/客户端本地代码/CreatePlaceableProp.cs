using BehaviorDesigner.Runtime.Tasks;
using System.Collections.Generic;
using UnityEngine;

[TaskName("地图上创建道具")]
[TaskCategory("考驾照功能")]
public class CreatePlaceableProp : Action
{
	public List<Vector3> positions = new List<Vector3>();

	public int typeParam;

	public override void OnStart()
	{
	}

	public override TaskStatus OnUpdate()
	{
		PropInfo propInfo = LocalResources.PropTable.Get(typeParam);
		foreach (Vector3 position in positions)
		{
			CardSkinInfo skinInfo;
			CardStyleInfo styleInfo = CardUtility.GetStyleInfo(propInfo.InGameStoreItemID, null, null, null, out skinInfo);
			string prefabName = (styleInfo == null || string.IsNullOrEmpty(styleInfo.Prefabs)) ? skinInfo.Prefabs : styleInfo.Prefabs;
			object[] data = new object[5]
			{
				PlayerController.Inst.UserId,
				position,
				propInfo.TypeParam,
				Vector3.right,
				skinInfo.Id
			};
			PhotonNetwork.InstantiateSceneObject(prefabName, position, Quaternion.LookRotation(Vector3.right), 0, data);
		}
		return TaskStatus.Success;
	}
}
