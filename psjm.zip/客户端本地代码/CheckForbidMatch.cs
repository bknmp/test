using LightUtility;

public class CheckForbidMatch
{
	public static bool CanEntryMatch()
	{
		return LocalPlayerDatabase.PrivatePlayerInfo.forbidMatchTime <= UtcTimeStamp.Now;
	}
}
