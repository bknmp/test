using LightUtility;
using System;

[Serializable]
public class CharacterUpgradeReward : IdBased
{
	public string Desc;

	public int CharacterID;

	public int[] ItemID;

	public int[] ItemCount;
}
