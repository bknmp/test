using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUpgradeTipsUI
{
	public UIDataBinder m_Host;

	public Button m_StartGameButton;

	public Button m_GotoStoreButton;

	public GameObject m_StartGameItem;

	public void Bind(CommonDataCollection args)
	{
		m_StartGameItem.gameObject.SetActive(!TeamRoomUI.IsShowing);
		m_Host.EventProxy(m_StartGameButton, "StartGame");
		m_Host.EventProxy(m_GotoStoreButton, "GotoGetCard");
	}

	public void StartGame()
	{
		UILobby.Current.GoHome();
		LobbyScene.Inst.OnStartGameClicked();
	}

	public void GotoGetCard()
	{
		UILobby.Current.GoBack();
		JumpModuleManager.Inst.DoJump(JumpModule.Store);
	}
}
