using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class BulletIcon : MonoBehaviour
{
	public ProjectileLauncher m_Laucncher;

	public Image m_BulletIcon;

	public UIProgressImage m_FireRoundProgress;

	public Sprite m_SpriteBullet;

	public Sprite m_FillSpriteBullet;

	public Sprite m_SpriteSaber;

	public Sprite m_FillSpriteSaber;

	private AnimatorType m_WeaponType;

	private void Awake()
	{
		m_Laucncher.OnWeaponChange += Update;
	}

	private void OnDestroy()
	{
		m_Laucncher.OnWeaponChange -= Update;
	}

	private void Update()
	{
		if (!(m_Laucncher == null) && m_WeaponType != m_Laucncher.WeaponType)
		{
			m_WeaponType = m_Laucncher.WeaponType;
			m_BulletIcon.sprite = ((m_WeaponType == AnimatorType.WeaponSword) ? m_SpriteSaber : m_SpriteBullet);
			m_FireRoundProgress.m_FillSprite = ((m_WeaponType == AnimatorType.WeaponSword) ? m_FillSpriteSaber : m_FillSpriteBullet);
			m_FireRoundProgress.UpdateProgress();
		}
	}
}
