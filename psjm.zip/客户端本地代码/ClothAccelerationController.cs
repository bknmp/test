using DG.Tweening;
using UnityEngine;

public class ClothAccelerationController : MonoBehaviour
{
	public Vector3 m_localExternalAcceleration;

	public Vector3 m_localRandomAcceleration;

	private Cloth m_cloth;

	private Transform m_transform;

	private float m_TargetBendingStiffness;

	private void Awake()
	{
		m_cloth = GetComponent<Cloth>();
		m_transform = base.transform.parent;
		m_TargetBendingStiffness = m_cloth.bendingStiffness;
	}

	private void OnEnable()
	{
		m_cloth.bendingStiffness = 1f;
		DOTween.To(() => m_cloth.bendingStiffness, delegate(float x)
		{
			m_cloth.bendingStiffness = x;
		}, m_TargetBendingStiffness, 0.5f).SetDelay(0.5f);
	}

	private void Update()
	{
		m_cloth.externalAcceleration = m_transform.TransformDirection(m_localExternalAcceleration);
		m_cloth.randomAcceleration = m_transform.TransformDirection(m_localRandomAcceleration);
	}
}
