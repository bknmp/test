using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine.UI;

public class DailyBoxPage
{
	public UIDataBinder m_Host;

	public Button m_ButtonBuy;

	public UIStateRawImage m_Quality;

	public Image m_Icon;

	public Text m_ItemName;

	public Text m_Price;

	public UIStateImage m_PriceType;

	public Text m_DiscountText;

	public Text m_LimitText;

	public UIDataScrollView m_MustGetTemplateInitiator;

	public UIDataScrollView m_MayGetTemplateInitiator;

	public CommonRewardPopupUI m_StoreRewardPopupUI;

	private ShopRecommendInfo m_ShopRecommendInfo;

	private ShopInfo m_ShopInfo;

	private DropItem m_BoxInfo;

	private bool m_IsEnable;

	private int m_DailyLimitNum;

	private int m_BuyNum;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_ButtonBuy, "OnYes");
		m_ShopRecommendInfo = (args["ShopRecommendInfo"].val as ShopRecommendInfo);
		m_ShopInfo = LocalResources.ShopTable.Get(m_ShopRecommendInfo.Id);
		m_BoxInfo = LocalResources.DropItemTable.Get(m_ShopRecommendInfo.Id);
		m_IsEnable = (bool)args["IsEnable"].val;
		m_BuyNum = (int)args["AlreadyBuyNum"].val;
		m_DailyLimitNum = (int)args["DailyLimitNum"].val;
		m_Quality.State = m_BoxInfo.Quality;
		m_Icon.sprite = SpriteSource.Inst.Find(m_BoxInfo.Icon);
		m_ItemName.text = m_BoxInfo.Name;
		float num = (m_ShopInfo.CostTicket == 0f) ? m_ShopInfo.CostDiamond : m_ShopInfo.CostTicket;
		m_Price.text = num.ToString();
		m_PriceType.State = ((m_ShopInfo.CostTicket != 0f) ? 1 : 2);
		m_DiscountText.text = m_ShopInfo.Discount.ToString() + Localization.Discount;
		m_LimitText.text = string.Format(Localization.LimitBuy, m_BuyNum, m_DailyLimitNum);
		SetMustGetScrollview();
		SetMayGetScrollview();
	}

	private void SetMustGetScrollview()
	{
		List<DropItem> shopInfoFromBoxString = GetShopInfoFromBoxString(m_ShopRecommendInfo.GiftBoxRegular);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int num = 0;
		foreach (DropItem item in shopInfoFromBoxString)
		{
			commonDataCollection[num]["DropItem"].val = item;
			num++;
		}
		int num2 = 0;
		string[] amountFromAmountString = GetAmountFromAmountString(m_ShopRecommendInfo.GiftBoxRegularNum);
		foreach (string val in amountFromAmountString)
		{
			commonDataCollection[num2]["Amount"].val = val;
			num2++;
		}
		m_MustGetTemplateInitiator.m_TemplateInitiator.Args = commonDataCollection;
		m_MustGetTemplateInitiator.m_TemplateInitiator.UpdateImmediately();
	}

	private void SetMayGetScrollview()
	{
		List<DropItem> shopInfoFromBoxString = GetShopInfoFromBoxString(m_ShopRecommendInfo.GiftBoxRandom);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int num = 0;
		foreach (DropItem item in shopInfoFromBoxString)
		{
			commonDataCollection[num]["DropItem"].val = item;
			num++;
		}
		int num2 = 0;
		string[] amountFromAmountString = GetAmountFromAmountString(m_ShopRecommendInfo.GiftBoxRandomNum);
		foreach (string val in amountFromAmountString)
		{
			commonDataCollection[num2]["Amount"].val = val;
			num2++;
		}
		m_MayGetTemplateInitiator.m_TemplateInitiator.Args = commonDataCollection;
		m_MayGetTemplateInitiator.m_TemplateInitiator.UpdateImmediately();
	}

	private List<DropItem> GetShopInfoFromBoxString(string boxStr)
	{
		List<DropItem> list = new List<DropItem>();
		string[] array = boxStr.Split('_');
		foreach (string s in array)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(int.Parse(s));
			if (dropItem != null)
			{
				list.Add(dropItem);
			}
		}
		return list;
	}

	private string[] GetAmountFromAmountString(string amountStr)
	{
		return amountStr.Split('_');
	}

	public void OnYes()
	{
		if (!m_IsEnable)
		{
			UILobby.Current.ShowTips(Localization.CantBuyDailyBox);
		}
		else if (m_ShopInfo.CostTicket != 0f)
		{
			ShopUtility.CheckMoneyEnough(CurrencyType.Tickets, (int)m_ShopInfo.CostTicket, BuyBox, m_ShopInfo.DropItemID, currentUIGoBack: false);
		}
		else if (m_ShopInfo.CostDiamond != 0f)
		{
			ShopUtility.CheckMoneyEnough(CurrencyType.Diamonds, (int)m_ShopInfo.CostDiamond, BuyBox);
		}
	}

	private void BuyBox()
	{
		HttpRequestBuyItemNew msg = new HttpRequestBuyItemNew();
		msg.type = ((m_ShopInfo.CostTicket != 0f) ? CurrencyType.Tickets : CurrencyType.Diamonds);
		msg.shopID = m_ShopInfo.Id;
		GameHttpManager.Inst.Send(msg, delegate(HttpResponseBuyItemNew response)
		{
			LocalPlayerDatabase.RefreshDailyBoxBuyInfo();
			m_Host.GetComponent<UIPopup>().GoBack();
			ItemInfo[] itemList = response.itemList;
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_StoreRewardPopupUI, null, showExpAdd: false);
			ItemInfo[] array = itemList;
			foreach (ItemInfo itemInfo in array)
			{
				commonRewardPopupUI.AddItem(itemInfo.itemID, itemInfo.itemCount);
				commonRewardPopupUI.SetTitleAndTips(null, null);
			}
			UIDataEvents.Inst.InvokeEvent("OnBuySomething");
			LocalPlayerDatabase.ReportClickEvent((msg.type == CurrencyType.Tickets) ? ClickEventParam.DAILY_BOX_TICKET_SUCCESS_CLICK : ClickEventParam.DAILY_BOX_DIAMOND_SUCCESS_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString());
		});
		LocalPlayerDatabase.ReportClickEvent((msg.type == CurrencyType.Tickets) ? ClickEventParam.DAILY_BOX_TICKET_BUY_CLICK : ClickEventParam.DAILY_BOX_DIAMOND_BUY_CLICK, LocalPlayerDatabase.PlayerInfo.publicInfo.HigherLargeGrade.ToString());
	}

	private void GoBack()
	{
		m_Host.GetComponent<UILobbyElement>().GoBack();
	}
}
