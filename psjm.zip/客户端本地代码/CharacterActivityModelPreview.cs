using GameMessages;
using UnityEngine;
using UnityEngine.UI;

public class CharacterActivityModelPreview : MonoBehaviour
{
	public int m_CharacterId;

	public RawImage m_PreviewImage;

	private void OnEnable()
	{
		ShowCharacterPreview();
	}

	private void ShowCharacterPreview()
	{
		MatchPlayerData playerData = CharacterUtility.GetPlayerData(m_CharacterId);
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_CharacterId);
		PlayerCharacterInfo characterDefaultInfo = CharacterUtility.GetCharacterDefaultInfo(m_CharacterId);
		if (playerData != null)
		{
			LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, LocalPlayerDatabase.PlayerInfo.publicInfo.name, characterDefaultInfo, playerData, m_PreviewImage, notRTMethod: false);
		}
	}
}
