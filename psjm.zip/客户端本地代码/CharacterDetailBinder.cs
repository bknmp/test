using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UI;

internal class CharacterDetailBinder
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_SuitePreviewBtn;

	public UITemplateInitiator m_Talents;

	public UIProgressBar m_ExpBar;

	public Text m_LevelText;

	public UITemplateInitiator m_Label;

	public Button m_LevelUpButton;

	public UIPopup m_TalentGoLevelUpUI;

	public static Delegates.VoidCallback OnCancelPreview;

	private CharacterInfo m_characterInfo;

	private int id;

	public void Bind(CommonDataCollection args)
	{
		id = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		m_characterInfo = LocalResources.CharacterTable.Get(id);
		SetLabel(m_characterInfo);
		args.Clear();
		for (int i = 0; i < m_characterInfo.TalentIDs.Length; i++)
		{
			args[i]["id"] = m_characterInfo.TalentIDs[i];
		}
		m_Talents.Args = args;
		m_LevelUpButton.gameObject.SetActive(CharacterUtility.IsOwnCharacter(id) && CharacterUtility.GetOwnedCharacterInfo(id).ExpLevel < LocalResources.ExpLevelTable.Last().Level);
		m_Host.EventProxy(m_LevelUpButton, "OnClickLevelUpButton");
		PlayerCharacterInfo playerCharacter = CharacterUtility.GetOwnedCharacterInfo(id);
		m_LevelText.text = playerCharacter.ExpLevel.ToString();
		if (playerCharacter.ExpLevel < LocalResources.ExpLevelTable.Last().Level)
		{
			m_ExpBar.SetProgress(playerCharacter.ExpPoint, LocalResources.ExpLevelTable.Find((ExpLevelInfo a) => a.Level == playerCharacter.ExpLevel).ExpNeed);
		}
		else
		{
			m_ExpBar.SetProgress(1f, 1f, Localization.MaxLevel);
		}
		if (m_SuitePreviewBtn != null)
		{
			bool flag = CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			if (CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected))
			{
				commonDataCollection[commonDataCollection.ArraySize]["suiteName"] = "current";
			}
			if (!flag)
			{
				ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Find((ShopSuiteInfo x) => x.GainType == ShopGainType.Default && x.CharacterID == CharacterUI_SelectCharacterItemTemplate.globalSelected);
				commonDataCollection[commonDataCollection.ArraySize]["suiteName"] = shopSuiteInfo.Name;
			}
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, List<int>> suite in ShopSuiteUtility.CharacterSuites[m_characterInfo.Id].suites)
			{
				list.Add(suite.Key);
			}
			for (int j = 0; j < list.Count; j++)
			{
				ShopSuiteInfo shopSuiteInfo2 = LocalResources.ShopSuiteTable.Get(ShopSuiteUtility.CharacterSuites[m_characterInfo.Id].suites[list[j]][0]);
				ShopInfo shopInfo = LocalResources.ShopTable.Get(shopSuiteInfo2.ShopItemIDs[0]);
				if ((shopInfo.SellStartTime == 0 || shopInfo.SellStartTime <= UtcTimeStamp.Now) && (shopInfo.SellEndTime == 0 || shopInfo.SellEndTime >= UtcTimeStamp.Now) && (flag || shopSuiteInfo2.GainType != ShopGainType.Default))
				{
					commonDataCollection[commonDataCollection.ArraySize]["suiteName"] = list[j];
				}
			}
			CharacterDetail_SuiteBtnItem.SelectedSuite = commonDataCollection[0]["suiteName"];
			m_SuitePreviewBtn.Args = commonDataCollection;
		}
		OnCancelPreview = CancelPreview;
	}

	public void OnClickLevelUpButton()
	{
		UILobby.Current.ShowUI(m_TalentGoLevelUpUI, null);
	}

	private void SetLabel(CharacterInfo info)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < info.Label.Length; i++)
		{
			commonDataCollection[i]["label"] = info.Label[i];
		}
		m_Label.Args = commonDataCollection;
	}

	private void CancelPreview()
	{
		CharacterDetail_SuiteBtnItem.SelectedSuite = "current";
		UIDataEvents.Inst.InvokeEvent("OnCharacterDetailSuitePreviewChange");
	}
}
