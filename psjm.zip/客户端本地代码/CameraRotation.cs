using LightUI;
using UnityEngine;

public class CameraRotation : MonoBehaviour
{
	public UIPointerBehaviour m_Input;

	public Transform m_Root;

	public Vector3 m_Diretion;

	public float speed;

	public float m_ResetSpeed;

	public float m_ContinuteRotateTime = 2f;

	public float m_Duration = 1f;

	private float m_RotateX;

	private float m_CoolDownTime;

	private Quaternion m_defaultRotation;

	private void Awake()
	{
		m_RotateX = m_Root.eulerAngles.x;
		m_defaultRotation = m_Root.rotation;
	}

	private void OnEnable()
	{
		ResetRotation();
	}

	public void ResetRotation()
	{
		m_Root.rotation = m_defaultRotation;
	}

	public void ResetCoolDown()
	{
		m_CoolDownTime = m_ContinuteRotateTime;
	}

	private void Update()
	{
		if (!PointerPressing())
		{
			if (m_CoolDownTime >= m_ContinuteRotateTime)
			{
				m_Root.Rotate(m_Diretion * Time.deltaTime * speed, Space.World);
				TryResetRotateX();
			}
			else
			{
				m_CoolDownTime += Time.deltaTime;
			}
		}
		else
		{
			m_CoolDownTime = 0f;
		}
	}

	private bool PointerPressing()
	{
		if (m_Input != null)
		{
			return m_Input.PointerPressing;
		}
		return Input.GetMouseButton(0);
	}

	private void TryResetRotateX()
	{
		if (!((double)Mathf.Abs(m_Root.eulerAngles.x - m_RotateX) > 0.5))
		{
			return;
		}
		if (m_Root.eulerAngles.x > 0f && m_Root.eulerAngles.x < 180f)
		{
			if (m_Root.eulerAngles.x > m_RotateX)
			{
				m_Root.Rotate(Vector3.left * Time.deltaTime * speed);
			}
			else
			{
				m_Root.Rotate(Vector3.right * Time.deltaTime * speed);
			}
		}
		else
		{
			m_Root.Rotate(Vector3.right * Time.deltaTime * speed);
		}
	}
}
