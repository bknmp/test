using eageramoeba.DeviceRating;
using ExitGames.Client.Photon;
using ExitGames.Client.Photon.LoadBalancing;
using LightUI;
using LightUtility;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class DebugInfoUI : MonoBehaviour
{
	public Text m_Text;

	private StringBuilder sb = new StringBuilder();

	private static int state;

	private bool m_Record;

	private float m_SendTotalPacketBytes;

	private float m_RecvTotalPacketBytes;

	private float m_RecordTime;

	public static bool show => state > 0;

	private void Awake()
	{
		base.gameObject.SetActive(LocalPlayerDatabase.Settings != null && LocalPlayerDatabase.Settings.showDebugInfo);
	}

	private void Start()
	{
		m_Text.text = "";
		UpdateState();
	}

	private void Update()
	{
		if (UnityEngine.Input.GetKeyDown(KeyCode.P) && !UIShortcutSelectable.DisableAllShortcut)
		{
			ToggleShow();
		}
	}

	private void UpdateInfo()
	{
		if (FpsCounter.Inst == null)
		{
			return;
		}
		sb.Length = 0;
		sb.AppendFormat("FPS:{0}\n", FpsCounter.Inst.FPS);
		if (PhotonNetwork.connected)
		{
			NetworkingPeer networkingPeer = PhotonNetwork.networkingPeer;
			TrafficStatsGameLevel trafficStatsGameLevel = networkingPeer.TrafficStatsGameLevel;
			sb.AppendFormat("Server:{0}\n", PhotonNetwork.ServerAddress);
			sb.AppendFormat("Ping:{0}[+/-{1}]ms\n", networkingPeer.RoundTripTime, networkingPeer.RoundTripTimeVariance);
			float num = (float)networkingPeer.TrafficStatsOutgoing.TotalPacketBytes / 1024f;
			float num2 = (float)networkingPeer.TrafficStatsIncoming.TotalPacketBytes / 1024f;
			m_SendTotalPacketBytes += num;
			m_RecvTotalPacketBytes += num2;
			sb.AppendFormat("Send:{0:N2}KB/s({1}p/s)\n", num, networkingPeer.TrafficStatsOutgoing.TotalPacketCount);
			sb.AppendFormat("Recv:{0:N2}KB/s({1}p/s)\n", num2, networkingPeer.TrafficStatsIncoming.TotalPacketCount);
			sb.AppendFormat("Interval:{0}ms\n", trafficStatsGameLevel.LongestDeltaBetweenSending);
			sb.AppendFormat("LogicRate:{0}ms\n", (int)(1000f / (float)PhotonNetwork.sendRateOnSerialize));
			sb.AppendFormat("Velocity:{0}\n", (PlayerController.Inst != null) ? PlayerController.Inst.LinearVelocity.magnitude : 0f);
			sb.AppendFormat("ServerTime:{0}s\n", AntiCheatingSystem.ElapsedServer);
			sb.AppendFormat("LocalTime:{0}s\n", AntiCheatingSystem.ElapsedLocal);
			sb.AppendFormat("DeviceScore:{0}\n", DeviceRating.TotalScore);
			if (PhotonNetwork.inRoom)
			{
				sb.AppendFormat("Master:{0},{1},{2}\n", PhotonNetwork.isMasterClient, PhotonNetwork.masterClient.UserId, (PlayerController.Inst != null) ? PlayerController.Inst.PerformanceQuality : 0);
			}
			PhotonNetwork.NetworkStatisticsReset();
		}
		if (PhotonVoiceNetwork.instance != null && PhotonVoiceNetwork.Client.IsConnected)
		{
			ExitGames.Client.Photon.LoadBalancing.LoadBalancingPeer loadBalancingPeer = PhotonVoiceNetwork.Client.loadBalancingPeer;
			if (loadBalancingPeer != null)
			{
				if (loadBalancingPeer.TrafficStatsOutgoing != null)
				{
					sb.AppendFormat("Voice Send:{0:N2}KB/s({1}p/s)\n", (float)loadBalancingPeer.TrafficStatsOutgoing.TotalPacketBytes / 1024f, loadBalancingPeer.TrafficStatsOutgoing.TotalPacketCount);
				}
				if (loadBalancingPeer.TrafficStatsIncoming != null)
				{
					sb.AppendFormat("Voice Recv:{0:N2}KB/s({1}p/s)\n", (float)loadBalancingPeer.TrafficStatsIncoming.TotalPacketBytes / 1024f, loadBalancingPeer.TrafficStatsIncoming.TotalPacketCount);
				}
				loadBalancingPeer.TrafficStatsReset();
			}
		}
		if (m_Record)
		{
			float num3 = Time.realtimeSinceStartup - m_RecordTime;
			sb.AppendFormat("Average Send:{0}KB {1}s {2:N2}KB/s\n", m_SendTotalPacketBytes, num3, m_SendTotalPacketBytes / num3);
			sb.AppendFormat("Average Recv:{0}KB {1}s {2:N2}KB/s\n", m_RecvTotalPacketBytes, num3, m_RecvTotalPacketBytes / num3);
		}
		m_Text.text = sb.ToString().Trim();
	}

	private void UpdateState()
	{
		if (show)
		{
			PhotonNetwork.NetworkStatisticsEnabled = true;
			InvokeRepeating("UpdateInfo", 0f, 1f);
			base.transform.GetChild(0).gameObject.SetActive(value: true);
		}
		else
		{
			PhotonNetwork.NetworkStatisticsEnabled = false;
			CancelInvoke();
			base.transform.GetChild(0).gameObject.SetActive(value: false);
		}
	}

	public void ToggleShow()
	{
		state = (state + 1) % 2;
		UpdateState();
	}
}
