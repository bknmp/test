using DG.Tweening;
using LightUtility;
using UnityEngine;

public class AttackArea : MonoBehaviour
{
	public enum AreaType
	{
		Line,
		Circle
	}

	public AreaType m_AreaType;

	public bool m_TargetFollowAttackDirection = true;

	protected ProjectileLauncher m_Launcher;

	protected float m_MaxDistance;

	private float m_DefaultHeight;

	protected GameObject m_Range;

	private CanvasGroup m_Alpha;

	private Vector3 m_AttackAreaScale;

	protected Vector3 m_Postion;

	private Vector3 m_AimingDirection;

	public Vector3 Position => m_Postion;

	public Vector3 Direction => m_AimingDirection;

	public float MaxDistance => m_MaxDistance;

	public bool IsShow
	{
		get;
		set;
	}

	private void Awake()
	{
		m_AttackAreaScale = base.transform.localScale;
	}

	public virtual void Bind(ProjectileLauncher launcher, GameObject prefab)
	{
		m_Launcher = launcher;
		m_DefaultHeight = base.transform.localPosition.y;
		m_Alpha = GetComponent<CanvasGroup>();
		m_Range = launcher.GetComponent<PlaceableCreater>().m_Range;
		PlaceableObject component = prefab.GetComponent<PlaceableObject>();
		if (component != null)
		{
			m_MaxDistance = component.MaxPlaceDistance;
		}
		else
		{
			m_MaxDistance = 0f;
		}
		if (m_AreaType == AreaType.Circle)
		{
			SetPosition(m_Launcher.transform.position);
		}
		else
		{
			base.transform.SetParent(m_Launcher.transform, worldPositionStays: false);
		}
	}

	public virtual void Show()
	{
		IsShow = true;
		base.gameObject.SetActive(value: true);
		if (FireController.Inst != null)
		{
			FireController.Inst.StartPreview(base.gameObject);
		}
		if (m_AreaType == AreaType.Line)
		{
			m_Alpha.DOKill();
			m_Alpha.alpha = 0f;
			m_Alpha.DOFade(1f, 0.1f).SetDelay(0.1f);
		}
		else
		{
			m_Alpha.DOKill();
			m_Alpha.alpha = 0f;
			m_Alpha.DOFade(1f, 0.1f);
			m_Range.SetActive(value: true);
			m_Range.transform.localScale = Vector3.one * m_MaxDistance;
		}
	}

	public void Hide(bool immediately = false)
	{
		IsShow = false;
		if (base.gameObject.activeSelf)
		{
			if (FireController.Inst != null)
			{
				FireController.Inst.StopPreview();
			}
			if (m_AreaType == AreaType.Line && (m_Launcher == null || !m_Launcher.IsSubMachineGun) && !immediately)
			{
				m_Alpha.DOKill();
				m_Alpha.alpha = 1f;
				m_Alpha.DOFade(0f, 0.2f).SetDelay(0.1f).OnComplete(delegate
				{
					base.gameObject.SetActive(value: false);
				});
			}
			else
			{
				m_Range.SetActive(value: false);
				base.gameObject.SetActive(value: false);
			}
		}
	}

	private void LateUpdate()
	{
		if (m_AreaType == AreaType.Line)
		{
			base.transform.rotation = Quaternion.LookRotation(m_AimingDirection);
		}
		UpdatePosition();
	}

	protected virtual void UpdatePosition()
	{
	}

	public void Reset()
	{
		if (m_AreaType == AreaType.Line)
		{
			Vector3 forward = m_Launcher.transform.forward;
			base.transform.forward = forward;
			m_AimingDirection = forward;
		}
		else
		{
			base.transform.position = m_Launcher.transform.position;
		}
	}

	public virtual void SetPositionOffset(Vector2 deltaRatio)
	{
		Vector3 b = deltaRatio.ExpandZ().SwapYZ() * m_MaxDistance;
		SetPosition(m_Launcher.transform.position + b);
	}

	public void SetPosition(Vector3 posInWorld)
	{
		m_Postion = posInWorld.FlattenY(m_DefaultHeight);
		if (m_AreaType == AreaType.Circle)
		{
			base.transform.position = Position;
			base.transform.localScale = (PlayerController.Inst.BuffManager.IsLoseControl ? (m_AttackAreaScale * 0.8f) : m_AttackAreaScale);
		}
		Vector3 vector = m_AimingDirection = PlayerController.Inst.BuffManager.GetOverrideControllOffset((Position - PlayerController.Inst.transform.position).FlattenY());
	}
}
