using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class CollectionPage_SkinPartPage
{
	public UIDataBinder m_Host;

	public Text m_CollectProgress;

	public Text m_Personality;

	public UITemplateInitiator m_Content;

	public Button m_SwitchButton;

	public GameObject m_SkinPartPanel;

	public GameObject m_PreviewPort;

	public UIScrollRect m_ScrollView;

	public GameObject m_NotHaveTips;

	public Button m_ButtonGain;

	public UIPopup m_BuySuiteUI;

	public UIPopup m_BuyGoodsUI;

	public GameObject m_EmptyTips;

	public GameObject m_Right;

	private string m_CollectFormat;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	private int m_AllSkinPartNum;

	private int m_NotHaveNotInSellTimeNum;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SwitchButton, "OnSwitchButtonClick");
		m_Host.EventProxy(m_ButtonGain, "OnGainButtonClick");
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_NotHaveTips.SetActive(value: false);
		m_SkinPartPanel.SetActive(value: false);
		m_PreviewPort.SetActive(value: true);
		m_ButtonGain.gameObject.SetActive(value: false);
		CollectionPage_SkinPartItem_Left.Selected = 0;
		LoadSkinPartData();
		if (m_CollectFormat == null)
		{
			m_CollectFormat = m_CollectProgress.text;
		}
		m_CollectProgress.text = string.Format(m_CollectFormat, CollectionUtility.GetForeverSkinPartCount(m_PlayerInfo, out List<ShopInfo> _), m_AllSkinPartNum - m_NotHaveNotInSellTimeNum);
		m_Personality.text = CollectionUtility.GetForeverSkinPartItems_NotInSuite(m_PlayerInfo).Sum((DropItem a) => a.Personality).ToString();
		m_ScrollView.ScrollToStart(immediately: true);
	}

	public void OnSwitchButtonClick()
	{
		m_SkinPartPanel.SetActive(!m_SkinPartPanel.activeSelf);
		m_PreviewPort.SetActive(!m_PreviewPort.activeSelf);
	}

	private void LoadSkinPartData()
	{
		m_AllSkinPartNum = 0;
		m_NotHaveNotInSellTimeNum = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		ShopInfo[] array = (from a in LocalResources.ShopTable
			orderby LocalResources.DropItemTable.Get(a.DropItemID).Quality descending
			select a).ToArray();
		foreach (ShopInfo shopInfo in array)
		{
			DropItem item = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
			bool flag = false;
			if (LocalResources.DropItemTable.Get(shopInfo.DropItemID).Type != DropItemType.SkinPart || !CollectionUtility.IsForeverSkinPart(shopInfo))
			{
				continue;
			}
			foreach (ShopSuiteInfo item2 in LocalResources.ShopSuiteTable)
			{
				if (item2.ShopItemIDs.Contains(shopInfo.Id))
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				continue;
			}
			if (!CollectionUtility.OwnedForever(item, m_PlayerInfo))
			{
				if (shopInfo.SellStartTime != 0 && shopInfo.SellStartTime > UtcTimeStamp.Now)
				{
					continue;
				}
				list2.Add(shopInfo.Id);
			}
			else
			{
				list.Add(shopInfo.Id);
			}
			m_AllSkinPartNum++;
		}
		int num = 0;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (list.Count > 0)
		{
			commonDataCollection[num]["state"] = 0;
			commonDataCollection[num]["skinPart"].val = list.ToList();
			commonDataCollection[num]["roleID"].val = m_PlayerID;
			commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num++;
		}
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID && list2.Count > 0)
		{
			commonDataCollection[num]["state"] = 2;
			commonDataCollection[num]["skinPart"].val = list2.ToList();
			commonDataCollection[num]["roleID"].val = m_PlayerID;
			commonDataCollection[num]["playerInfo"].val = m_PlayerInfo;
			commonDataCollection[num]["playerCardConfigs"].val = m_PlayerCardConfigs;
			num++;
		}
		m_Content.Args = commonDataCollection;
		m_Content.UpdateImmediately(withChildren: true);
		bool flag2 = commonDataCollection.ArraySize > 0;
		m_EmptyTips.SetActive(!flag2);
		m_Right.SetActive(flag2);
		m_ScrollView.transform.parent.parent.gameObject.SetActive(flag2);
	}

	public void OnGainButtonClick()
	{
		DropItem dropItem = LocalResources.DropItemTable.Find(CollectionPage_SkinPartItem_Left.Selected);
		ShopInfo shopInfo = LocalResources.ShopTable.Find((ShopInfo a) => a.DropItemID == CollectionPage_SkinPartItem_Left.Selected);
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(dropItem.TypeParam);
		ShopGainType shopGainType = ShopGainType.None;
		int characterID = 0;
		shopGainType = (shopInfo?.GainType ?? ShopGainType.Default);
		characterID = skinPartInfo.CharacterID;
		switch (shopGainType)
		{
		case ShopGainType.Default:
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Find(characterID);
			string msg = string.Format(Localization.TipsDefaultPartsBuy, CharacterUtility.GetColorRoleName(characterInfo.Role, characterInfo.Name));
			UILobby.Current.ShowMessageBoxYesNo(msg, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				DoBuyCharacter(characterID);
			}, null);
			break;
		}
		case ShopGainType.Buy:
		{
			if (CharacterUtility.IsOwnCharacter(characterID))
			{
				DoBuySkinPart(shopInfo.Id);
				break;
			}
			CharacterInfo characterInfo = LocalResources.CharacterTable.Find(characterID);
			string msg = string.Format(Localization.TipsBuyCharacterFirst, CharacterUtility.GetColorRoleName(characterInfo.Role, characterInfo.Name));
			UILobby.Current.ShowMessageBoxYesNo(msg, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				DoBuyCharacter(characterID);
			}, null);
			break;
		}
		default:
			UILobby.Current.ShowTips(shopInfo.GainTips);
			break;
		}
	}

	private void DoBuyCharacter(int characterID)
	{
		CharacterUI_SelectCharacterItemTemplate.globalSelected = characterID;
		JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI);
	}

	private void DoBuySkinPart(int shopID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection[0]["Id"] = shopID;
		JumpModuleManager.Inst.DoJump(JumpModule.BuyGoodsUI, commonDataCollection);
	}
}
