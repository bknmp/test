using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;

internal class ActivityLobbyPreviewUI
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollViewTop;

	public void Bind(CommonDataCollection args)
	{
		List<Activity> list = new List<Activity>();
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit && (UtcTimeStamp.Now >= activity.startTime || UtcTimeStamp.Now >= activity.exchangeStartTime) && (UtcTimeStamp.Now <= activity.endTime || UtcTimeStamp.Now <= activity.exchangeEndTime) && activity.previewPictureUrl != null && !string.IsNullOrEmpty(activity.previewPictureUrl))
			{
				list.Add(activity);
			}
		}
		list.Sort((Activity a, Activity b) => LocalResources.ActivityLobbyInfos.Get(a.activityId).Rank.CompareTo(LocalResources.ActivityLobbyInfos.Get(b.activityId).Rank));
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		foreach (Activity item in list)
		{
			commonDataCollection[commonDataCollection.ArraySize]["Activity"].val = item;
		}
		m_DataScrollViewTop.ClearItems();
		m_DataScrollViewTop.AddItems(commonDataCollection.Array);
	}
}
