using DG.Tweening;
using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_ItemTemplate
{
	private enum State
	{
		Use,
		Unload,
		Compose,
		Empty,
		GainTips
	}

	public UIDataBinder m_Host;

	public Image m_Icon;

	public GameObject m_InUseCheck;

	public GameObject m_Selected;

	public Image m_Frame;

	public GameObject m_CardSkinRedPoint;

	public Button m_ButtonUse;

	public Button m_ButtonUnload;

	public RectTransform m_Root;

	public UIStateItem m_State;

	public Text m_Level;

	public Button m_ButtonBuy;

	public UIScrollRect m_ScrollView;

	public CardPieceProcessBar m_Process;

	public Button m_ButtonUpgrade;

	public MultiTargetGraphicButton m_SelectButton;

	public GameObject m_Lock;

	public UIStateItem m_TitleStatus;

	public Text m_GradeLimit;

	public Text m_NotMatchRole;

	public UIPopup m_CardComposeUI;

	public UIPage m_CardDetailUI;

	public Button m_ButtonDetail;

	public ParticleSystemRenderer m_glow;

	public Button m_ButtonGainTips;

	public UIPopup m_GainCardTipsUI;

	public GameObject m_NewArrival;

	public CanvasGroup m_Canvas;

	public UIMaskItem m_MaskItem;

	public Material m_UI_Default_Gray;

	public Material m_UI_Default_Optimized;

	public GameObject m_ComposeRedPoint;

	public GameObject m_UnlockEffect;

	public GameObject m_CollectRedPoint;

	public static int SelectedID = -1;

	public static int ScrollItemID = -1;

	public static Vector3 SelectedPosition = Vector3.zero;

	private bool m_InitalSelection;

	private int m_ItemID;

	private int m_cardLevel;

	private string m_LevelFormat;

	private string m_MatchRoleFormat;

	private string m_GradeLimitFormat;

	private bool m_own;

	private bool canDropCardPiece;

	private bool matchRole;

	private bool unlock;

	private bool m_init;

	public static bool AnyUpgradableTips => AnyUpgradableCardID != 0;

	public static int AnyUpgradableCardID
	{
		get
		{
			InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
			foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
			{
				if (CardUtility.CanUpgradeCard(inGameStoreInfo.Id))
				{
					return inGameStoreInfo.Id;
				}
			}
			return 0;
		}
	}

	public static int UpgradableCardNum
	{
		get
		{
			int num = 0;
			InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
			for (int i = 0; i < allCardInfos.Length; i++)
			{
				if (CardUtility.CanUpgradeCard2(allCardInfos[i].Id))
				{
					num++;
				}
			}
			return num;
		}
	}

	public void Bind(CommonDataCollection args)
	{
		if (!m_init)
		{
			m_LevelFormat = m_Level.text;
			m_MatchRoleFormat = m_NotMatchRole.text;
			m_GradeLimitFormat = m_GradeLimit.text;
			m_init = true;
		}
		m_ItemID = args["id"];
		if (m_ItemID == -1)
		{
			m_Canvas.interactable = false;
			m_Canvas.alpha = 0f;
			return;
		}
		m_Canvas.interactable = true;
		m_Canvas.alpha = 1f;
		m_cardLevel = CardUtility.GetCardLevel(m_ItemID);
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_ItemID);
		CardSkinInfo skinInfo = CardUtility.GetSkinInfo(m_ItemID);
		CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(CardUtility.CurCardStyle(skinInfo.Id));
		string name = (cardStyleInfo == null || string.IsNullOrEmpty(cardStyleInfo.Icon)) ? skinInfo.Icon : cardStyleInfo.Icon;
		m_Icon.sprite = SpriteSource.Inst.Find(name);
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_InUseCheck.SetActive(CardUtility.InActiveCardConfig(m_ItemID));
		m_own = CardUtility.IsOwned(m_ItemID);
		canDropCardPiece = CardUtility.CanDropCardPiece(inGameStoreInfo.Id);
		unlock = (GameRuntime.PlayerGrade >= CardUtility.GetCardGrowth(m_ItemID).UnlockGrade);
		matchRole = CardUtility.IsCardRoleMatch(inGameStoreInfo);
		m_Lock.SetActive(!matchRole || !canDropCardPiece || !unlock);
		m_Icon.material = (m_own ? m_UI_Default_Optimized : m_UI_Default_Gray);
		m_Process.SetInfo(m_ItemID);
		UpdateTitleStatus();
		UpdateState();
		UpdateSelection();
		TryShowScrollToItemAnimation();
		TryShowUnlockCardAnimation();
		m_CardSkinRedPoint.SetActive(NewCardSkinTips.Inst.HaveNewCardSkin(m_ItemID) || NewCardSkinTips.Inst.HaveNewCardStyle(m_ItemID) || NewCardSkinTips.HaveCardSkinCanUnlock(m_ItemID));
		m_ComposeRedPoint.SetActive(m_State.State == 2);
		m_NewArrival.gameObject.SetActive(!m_ComposeRedPoint.activeSelf && NewArrivalUtility.IsCardNewArrival(m_ItemID));
		m_CollectRedPoint.gameObject.SetActive(LocalPlayerDatabase.GetPrefValue("CollectRedPoint_" + m_ItemID));
		m_Host.EventProxy(m_SelectButton, "OnButtonClicked");
		m_Host.EventProxy(m_ButtonBuy, "OnClickBuy");
		m_Host.EventProxy(m_ButtonUpgrade, "ShowDetailUI");
		m_Host.EventProxy(m_ButtonDetail, "ShowDetailUI");
		m_Host.EventProxy(m_ButtonGainTips, "ShowGainTipsUI");
	}

	private void UpdateTitleStatus()
	{
		if (!matchRole)
		{
			m_TitleStatus.State = 3;
			m_NotMatchRole.text = string.Format(m_MatchRoleFormat, (GameRuntime.PlayingRole == RoleType.Police) ? Localization.Thief : Localization.Police);
		}
		else if (!unlock)
		{
			m_TitleStatus.State = 0;
			GradeMappingInfo mapping;
			GradeInfo gradeInfo = LocalResources.GetGradeInfo(CardUtility.GetCardGrowth(m_ItemID).UnlockGrade, out mapping);
			m_GradeLimit.text = string.Format(m_GradeLimitFormat, gradeInfo.Name);
		}
		else if (!m_own)
		{
			m_TitleStatus.State = 1;
		}
		else
		{
			m_TitleStatus.State = 2;
			m_Level.text = string.Format(m_LevelFormat, m_cardLevel);
		}
	}

	private void UpdateState()
	{
		m_ButtonUpgrade.gameObject.SetActive(value: false);
		m_State.State = 3;
		if (!m_own)
		{
			if (m_Process.IsFull)
			{
				m_State.State = 2;
			}
			else
			{
				m_State.State = (unlock ? 4 : 3);
			}
		}
		else
		{
			if (CardUtility.GetUpgradeLimit(m_ItemID, out int upgradeLimitGrade, out int _, out int _) && Mathf.Max(LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice, LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief) >= upgradeLimitGrade && m_Process.IsFull)
			{
				m_ButtonUpgrade.gameObject.SetActive(value: true);
			}
			if (!canDropCardPiece || !matchRole || !unlock)
			{
				m_State.State = 3;
			}
			else if (m_InUseCheck.activeSelf)
			{
				m_State.State = 1;
			}
			else
			{
				m_State.State = 0;
			}
		}
		m_ButtonDetail.gameObject.SetActive(m_State.State != 2 && !m_ButtonUpgrade.gameObject.activeSelf);
	}

	private void UpdateSelection()
	{
		bool flag = SelectedID == m_ItemID;
		m_glow.sortingOrder = ((!flag) ? 1 : (-3));
		m_Process.GetComponent<CanvasGroup>().alpha = ((!flag) ? 1 : 0);
		if (flag != m_Selected.activeSelf || !m_InitalSelection)
		{
			if (flag)
			{
				SelectedPosition = m_Host.transform.position;
				m_Root.transform.DOScale(1.1f, 0.2f).SetEase(Ease.OutBack);
				m_Root.anchoredPosition = new Vector2(0f, 13f);
				Canvas canvas = m_Host.gameObject.AddComponent<Canvas>();
				canvas.overrideSorting = true;
				canvas.sortingOrder = -1;
				m_Host.gameObject.AddComponent<GraphicRaycaster>();
				m_Host.EventProxy(m_ButtonUnload, "OnButtonUnloadClicked");
				m_Host.EventProxy(m_ButtonUse, "OnButtonUseClicked");
				ScrollToItemAnimation();
			}
			else
			{
				m_Root.transform.DOKill();
				m_Root.transform.localScale = Vector3.one;
				m_Root.anchoredPosition = new Vector2(0f, -20f);
				UnityEngine.Object.Destroy(m_Host.gameObject.GetComponent<GraphicRaycaster>());
				UnityEngine.Object.Destroy(m_Host.gameObject.GetComponent<Canvas>());
			}
			m_Selected.SetActive(flag);
			m_InitalSelection = true;
		}
	}

	public void OnButtonClicked()
	{
		m_CardSkinRedPoint.SetActive(value: false);
		SelectedID = m_ItemID;
		if (m_NewArrival.activeSelf)
		{
			NewArrivalUtility.SaveNewArrivalCardData(m_ItemID);
		}
		LocalPlayerDatabase.SetPrefValue("CollectRedPoint_" + m_ItemID, value: false);
		UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
	}

	public void OnButtonUnloadClicked()
	{
		CardUtility.UnloadCard(SelectedID);
	}

	public void OnButtonUseClicked()
	{
		ActiveCardConfigView.Replacing = true;
		UIDataEvents.Inst.InvokeEvent("ActiveCardConfigReplacing");
	}

	public void OnClickBuy()
	{
		if (CardUtility.GetOwnCardPieceNum(m_ItemID) < CardUtility.GetCardGrowth(m_ItemID).ComposePiece)
		{
			UILobby.Current.ShowMessageBoxYesNo(Localization.PieceNotEnoughGotoBuyCardBox, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, delegate
			{
				JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
			}, null);
		}
		else
		{
			CardUtility.ComposeCard(m_ItemID, delegate
			{
				UILobby.Current.ShowUI(m_CardComposeUI, null).GetComponent<CardNewGainUI>().ShowCard(m_ItemID);
				LocalPlayerDatabase.RefreshAssetsInfo();
			});
		}
	}

	public void ShowDetailUI()
	{
		UILobby.Current.ShowUI(m_CardDetailUI, CardUtility.CardDetailUIArgsWraper(m_ItemID, m_cardLevel));
	}

	public void ShowGainTipsUI()
	{
		if (LobbyScene.Inst.CurrentMode == LobbyScene.Mode.Team)
		{
			JumpModuleManager.Inst.DoJump(JumpModule.CardLottery);
		}
		else
		{
			UILobby.Current.Popup(m_GainCardTipsUI);
		}
	}

	private void TryShowScrollToItemAnimation()
	{
		if (ScrollItemID == m_ItemID)
		{
			ScrollItemID = -1;
			ScrollToItemAnimation();
		}
	}

	private void ScrollToItemAnimation()
	{
		m_ScrollView.content.DOMoveY(m_ScrollView.content.transform.position.y + m_MaskItem.IsTotalVisible(2), 0.2f);
	}

	private void TryShowUnlockCardAnimation()
	{
		if (CardUtility.NewUnlockCardIDs.Contains(m_ItemID) && m_Host.gameObject.activeInHierarchy && !GameLobby.Inst.m_Intro.gameObject.activeSelf)
		{
			m_Host.StartCoroutine(OnShowUnlockCardAnimation());
		}
	}

	private IEnumerator OnShowUnlockCardAnimation()
	{
		m_TitleStatus.State = 0;
		GradeMappingInfo mapping;
		GradeInfo gradeInfo = LocalResources.GetGradeInfo(CardUtility.GetCardGrowth(m_ItemID).UnlockGrade, out mapping);
		m_GradeLimit.text = string.Format(m_GradeLimitFormat, gradeInfo.Name);
		m_CollectRedPoint.SetActive(value: false);
		yield return Yielders.GetWaitForSeconds(0.5f);
		CardUtility.NewUnlockCardIDs.Remove(m_ItemID);
		PoolSpawner.Spawn(m_UnlockEffect, m_Root).GetComponent<RectTransform>().anchoredPosition = Vector3.zero;
		yield return Yielders.GetWaitForSeconds(0.3f);
		m_TitleStatus.State = 1;
		yield return Yielders.GetWaitForSeconds(0.2f);
		m_CollectRedPoint.SetActive(value: true);
		LocalPlayerDatabase.SetPrefValue("CollectRedPoint_" + m_ItemID, value: true);
	}
}
