using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUpgradeActivity_RewardTemplate
{
	public UIDataBinder m_Host;

	public Text m_Text;

	public UITemplateInitiator m_Reward;

	public Button m_ButtonClaim;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public Button m_Button_CantClaim;

	public GameObject m_Claimed;

	public RectTransform m_Self;

	public Text m_Desc;

	private int m_Index;

	private bool m_HadClaimed;

	private bool m_CanClaim;

	private CharacterUpgradeActivity m_CharacterUpgradeActivity;

	private int m_CharacterID;

	private string m_DescFormat;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["Id"];
		m_Text.text = args["Desc"];
		m_CharacterID = args["CharacterID"];
		int[] array = args["itemIds"].val as int[];
		int[] array2 = args["itemCounts"].val as int[];
		m_HadClaimed = args["claimed"];
		m_CharacterUpgradeActivity = (args["CharacterUpgradeActivity"].val as CharacterUpgradeActivity);
		if (m_Desc != null)
		{
			if (string.IsNullOrEmpty(m_DescFormat))
			{
				m_DescFormat = m_Desc.text;
			}
			m_Desc.text = string.Format(m_DescFormat, LocalResources.CharacterTable.Get(m_CharacterID).Name);
		}
		int num = CharacterUtility.IsOwnForeverCharacter(m_CharacterID) ? CharacterUtility.GetOwnedCharacterInfo(m_CharacterID).ExpLevel : 0;
		m_CanClaim = (num >= m_Index);
		m_ButtonClaim.gameObject.SetActive(m_CanClaim && !m_HadClaimed);
		m_Button_CantClaim.gameObject.SetActive(!m_CanClaim);
		m_Claimed.SetActive(m_HadClaimed);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < array.Length; i++)
		{
			ItemInfo val = new ItemInfo(array[i], array2[i]);
			CommonDataCollection commonDataCollection2 = new CommonDataCollection();
			commonDataCollection2["dropItemInfo"].val = val;
			commonDataCollection[commonDataCollection.ArraySize] = commonDataCollection2;
		}
		m_Reward.Args = commonDataCollection;
		m_Host.EventProxy(m_ButtonClaim, "OnClickClaim");
		m_Host.EventProxy(m_Button_CantClaim, "OnClickCantClaim");
		if (m_HadClaimed)
		{
			m_Self.SetAsLastSibling();
		}
	}

	public void OnClickCantClaim()
	{
		UILobby.Current.ShowTips(Localization.CantClaim);
	}

	public void OnClickClaim()
	{
		HttpRequestClaimCharacterUpgradeActivity httpRequestClaimCharacterUpgradeActivity = new HttpRequestClaimCharacterUpgradeActivity();
		httpRequestClaimCharacterUpgradeActivity.characterId = m_CharacterID;
		httpRequestClaimCharacterUpgradeActivity.level = m_Index;
		GameHttpManager.Inst.Send(httpRequestClaimCharacterUpgradeActivity, delegate(HttpResponseClaimCharacterUpgradeActivity onResponse)
		{
			m_CharacterUpgradeActivity.m_Host.UpdateBinding();
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.AddItems(onResponse.items);
			commonRewardPopupUI.SetTitleAndTips("", "");
		});
	}
}
