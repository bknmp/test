using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class BuySuiteUI_DiscountTips
{
	public UIDataBinder m_Host;

	public Text m_DiscountTips;

	public GameObject m_NoDiscount;

	private string m_Format;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_Format))
		{
			m_Format = m_DiscountTips.text;
		}
		List<int> obj = args["suiteIDs"].val as List<int>;
		BuyUI buyUI = (BuyUI)args["buyUI"].val;
		int id = obj[buyUI.GlobalIndex];
		int[] selectedShopItemIDs = ShopSuiteUtility.GetSelectedShopItemIDs(LocalResources.ShopSuiteTable.Get(id).ShopItemIDs);
		ShopSuiteUtility.SuitePrice suitePrice = ShopSuiteUtility.CalculateSuitePrice(selectedShopItemIDs);
		string text = "";
		int num = 0;
		switch (buyUI.SelectedType)
		{
		case CurrencyType.Gold:
			text = Localization.Gold;
			num = suitePrice.OriginalCostGold;
			break;
		case CurrencyType.Tickets:
			text = Localization.Ticket;
			num = suitePrice.OriginalCostTicket;
			break;
		default:
			text = Localization.Diamonds;
			num = suitePrice.OriginalCostDiamond;
			break;
		}
		if (selectedShopItemIDs.Length <= 1)
		{
			m_DiscountTips.text = "";
		}
		else
		{
			int num2 = (suitePrice.Discount % 10 == 0) ? (suitePrice.Discount / 10) : suitePrice.Discount;
			m_DiscountTips.text = string.Format(m_Format, num, text, selectedShopItemIDs.Length, num2);
		}
		m_NoDiscount.SetActive(selectedShopItemIDs.Length == 1);
	}
}
