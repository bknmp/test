using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CommonExchangeUI_NeedItem
{
	public UIDataBinder m_Host;

	public DropItemUI m_DropItem;

	public Text m_Amount;

	private string m_AmountFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_AmountFormat))
		{
			m_AmountFormat = m_Amount.text;
		}
		ItemInfo itemInfo = args["dropItemInfo"].val as ItemInfo;
		m_DropItem.SetInfo(itemInfo.itemID, itemInfo.itemCount);
		m_Amount.text = string.Format(m_AmountFormat, ShopUtility.GetCurrencyAmount(itemInfo.itemID), itemInfo.itemCount);
	}
}
