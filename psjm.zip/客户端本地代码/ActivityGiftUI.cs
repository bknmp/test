using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class ActivityGiftUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiator;

	public Text m_Time;

	public Text m_FirstRechargeTips;

	private bool restore;

	private string m_TimeFormat;

	public void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		if (m_Time != null)
		{
			if (string.IsNullOrEmpty(m_TimeFormat))
			{
				m_TimeFormat = m_Time.text;
			}
			m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		}
		m_FirstRechargeTips.gameObject.SetActive(!FirstRechargeUtility.AllRewardsReceived);
		HttpRequestActivityGifts httpRequestActivityGifts = new HttpRequestActivityGifts();
		httpRequestActivityGifts.activityId = activity.activityId;
		m_TemplateInitiator.Args = null;
		GameHttpManager.Inst.Send(httpRequestActivityGifts, delegate(HttpResponseActivityGifts OnHttpResponse)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < OnHttpResponse.infos.Length; i++)
			{
				commonDataCollection[i]["activity"].val = activity;
				commonDataCollection[i]["ActivityGift"].val = OnHttpResponse.infos[i];
				commonDataCollection[i]["ActivityGiftUI"].val = this;
				commonDataCollection[i]["expiredTime"] = activity.endTime;
				commonDataCollection[i]["index"] = i;
			}
			m_TemplateInitiator.Args = commonDataCollection;
		}, null, null, LocalPlayerDatabase.DummyWait);
		SetRedPointData(activity);
		if (!restore)
		{
			restore = true;
			PaymentUtility.RestorePay();
		}
	}

	protected virtual void SetRedPointData(Activity activity)
	{
		string text = "";
		text = GetActivityGiftPrefValueKey(LocalResources.ActivityLobbyInfos.Get(activity.activityId).Type);
		if (!string.IsNullOrEmpty(text) && LocalPlayerDatabase.GetPrefValueInt(text) != activity.startTime)
		{
			LocalPlayerDatabase.SetPrefValue(text, activity.startTime);
			UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
		}
	}

	public static string GetActivityGiftPrefValueKey(ActivityType type)
	{
		switch (type)
		{
		case ActivityType.NEW_CARD_GIFT:
			return "CardActivityGift";
		case ActivityType.CHARACTER_GIFT:
			return "CharacterActivityGift";
		case ActivityType.CHARACTER_BUY_DIRECT:
			return "CharacterBuyDirect";
		case ActivityType.ANNIVERSARY_GIFT:
			return "AnniversaryGift";
		default:
			return "";
		}
	}

	public static bool ActivityGiftRedPoint(ActivityType type)
	{
		if (LocalPlayerDatabase.Settings == null || LocalPlayerDatabase.Settings.activitys == null)
		{
			return false;
		}
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(type, ActivityCollectionType.NONE);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		string activityGiftPrefValueKey = GetActivityGiftPrefValueKey(type);
		if (string.IsNullOrEmpty(activityGiftPrefValueKey))
		{
			return false;
		}
		ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activityByActivityTypeAndCollectionType.activityId);
		switch ((activityLobbyInfo.CollectionType == ActivityCollectionType.OLD_CARD_ACTIVITY) ? 2 : ((activityLobbyInfo.CollectionType == ActivityCollectionType.NEW_CARD_ACTIVITY) ? 1 : 0))
		{
		case 1:
			if (UtcTimeStamp.IsInSameWeek(UtcTimeStamp.GetDate(LocalPlayerDatabase.GetPrefValueInt(activityGiftPrefValueKey)), UtcTimeStamp.NowDateTime))
			{
				return false;
			}
			return true;
		case 2:
			if (!UtcTimeStamp.IsCrossDay(LocalPlayerDatabase.GetPrefValueInt(activityGiftPrefValueKey), UtcTimeStamp.Now))
			{
				return false;
			}
			return true;
		default:
			if (activityByActivityTypeAndCollectionType.startTime == LocalPlayerDatabase.GetPrefValueInt(activityGiftPrefValueKey))
			{
				return false;
			}
			return true;
		}
	}
}
