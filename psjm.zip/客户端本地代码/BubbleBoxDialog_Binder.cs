using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BubbleBoxDialog_Binder
{
	public UIDataBinder m_Host;

	public Image m_Middle;

	public Text m_DialogText;

	public UIStateItem m_Dialog;

	public Image m_Other;

	public Image m_Extra;

	public Button m_Self;

	public void Bind(CommonDataCollection args)
	{
		int num = args["activeBubbleBoxID"];
		bool num2 = args["other"];
		HeadBubbleBoxInfo headBubbleBoxInfo = LocalResources.HeadBubbleBoxInfos.Get(num);
		m_DialogText.color = GameChatColors.HexToColor(headBubbleBoxInfo.TextColor);
		if (m_Self != null)
		{
			m_Host.EventProxy(m_Self, "OnCopyButtonClicked");
		}
		if (num2 && num == 910001)
		{
			m_Dialog.State = 1;
			return;
		}
		m_Dialog.State = 0;
		m_Middle.sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon);
		if (m_Extra != null)
		{
			Sprite sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon + "_extra");
			if (sprite != null)
			{
				m_Extra.gameObject.SetActive(value: true);
				m_Extra.sprite = sprite;
				m_Extra.SetNativeSize();
			}
			else
			{
				m_Extra.gameObject.SetActive(value: false);
			}
		}
	}

	public void OnCopyButtonClicked()
	{
		ClipboardTool.CopyToSystemClipboard(m_DialogText.text.ToString());
		UILobby.Current.ShowTips(Localization.TipsCopyOK);
	}
}
