using LightUI;
using UnityEngine;

public class ChatEntryReparent : MonoBehaviour
{
	public static int m_Counter;

	public void OnEnable()
	{
		if (LobbyScene.Inst != null && LobbyScene.Inst.ChatEntry != null)
		{
			GameObject chatEntry = LobbyScene.Inst.ChatEntry;
			if (chatEntry.transform.parent != base.transform)
			{
				UIDataEvents.Inst.InvokeEvent("OnChatEntryParentChanged");
			}
			chatEntry.transform.SetParent(base.transform, worldPositionStays: false);
			chatEntry.transform.SetAsLastSibling();
		}
	}
}
