using LightUtility;
using UnityEngine;

public class BarrelObject : DirectionalObject
{
	public float m_Damage;

	public int m_DeBuffID = 200;

	protected override bool CanTriggerTarget(DamagableTarget target, ref int numID, ref int viewID, ref int localNum)
	{
		switch (target.m_TargetType)
		{
		case DamagableTarget.TargetType.Player:
		{
			PlayerController playerController = (PlayerController)target.Target;
			if (IsMyPassenger(playerController))
			{
				return false;
			}
			if (!playerController.IsDying)
			{
				return playerController.UserId != m_PlayerController.UserId;
			}
			return false;
		}
		case DamagableTarget.TargetType.Dog:
			return !((DogObject)target.Target).IsDead;
		case DamagableTarget.TargetType.Portal:
			return false;
		case DamagableTarget.TargetType.Genius:
		{
			GeniusObject geniusObject = (GeniusObject)target.Target;
			if (m_PlayerController.InSameTeam(geniusObject.PlayerController))
			{
				return false;
			}
			return true;
		}
		case DamagableTarget.TargetType.Bubble:
			return false;
		case DamagableTarget.TargetType.Mine:
		{
			MineObject mineObject = (MineObject)target.Target;
			if (!string.IsNullOrEmpty(mineObject.UserId))
			{
				return !mineObject.Underground;
			}
			return false;
		}
		default:
			return true;
		}
	}

	public override void OnFinishHit(Vector3 hitPos, int numID, int viewID, int localNum)
	{
		base.OnFinishHit(hitPos, numID, viewID, localNum);
		SafeDestroy();
	}

	protected override void OnDestroy()
	{
		if (!string.IsNullOrEmpty(base.UserId) && m_PlayerController != null)
		{
			foreach (PlayerController allPlayer in PlayerController.AllPlayers)
			{
				if (allPlayer.m_PhotonViewForTransform.isMine && IsEnemy(allPlayer) && InExposionRange(allPlayer.transform))
				{
					Vector3 normalized = (allPlayer.transform.localPosition - m_Root.transform.position).FlattenY().normalized;
					PlayerPush.Push(GetComponent<PushCurve>().m_PushCurve, allPlayer.gameObject, normalized, 0.5f);
				}
			}
		}
		base.OnDestroy();
	}

	protected override void CalculateHit()
	{
		if (!(m_PlayerController == null) && m_PlayerController.m_PhotonView.isMine)
		{
			int numID = UserId2NumId.Get(m_PlayerController.UserId);
			foreach (PlayerController allPlayersAndPuppet in PlayerController.AllPlayersAndPuppets)
			{
				if (allPlayersAndPuppet.CanBeAttacked && IsEnemy(allPlayersAndPuppet) && InExposionRange(allPlayersAndPuppet.transform))
				{
					InGameMinimap.Inst.ShowEnemyInMinimap(2f, allPlayersAndPuppet.UserId);
					allPlayersAndPuppet.RpcApplyDamage(m_Damage, numID, DamageSourceType.Barrel, m_DeBuffID);
				}
			}
		}
	}

	private bool IsEnemy(PlayerController player)
	{
		return !player.InSameTeam(m_PlayerController);
	}

	private bool InExposionRange(Transform target)
	{
		Vector3 b = m_Root.transform.position.FlattenY();
		return Vector3.Distance(target.position.FlattenY(), b) < m_ExplosionRadius;
	}
}
