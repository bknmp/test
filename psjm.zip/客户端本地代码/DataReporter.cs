using GameMessages;
using System;
using UnityEngine;

public class DataReporter : MonoBehaviour
{
	private int mActivityId;

	private float mEnterTime;

	private string mFirstOpenPage = "FirstOpenPinkLottery";

	private string mOpenPage = "OpenPinkLottery";

	private void OnEnable()
	{
		mEnterTime = Time.time;
		ActivityLobby.IsActicityAvailable(ActivityType.PINK_LOTTERY_ACTIVITY, ActivityCollectionType.LOTTERY_ACTIVITY, out mActivityId);
		ReportEnter();
	}

	private void OnDisable()
	{
		ReportFirstStayTime();
	}

	private void ReportFirstStayTime()
	{
		if (!LocalPlayerDatabase.GetPrefValue(mFirstOpenPage + mActivityId))
		{
			LocalPlayerDatabase.ReportClickEvent(param3: (Time.time - mEnterTime).ToString(), param1: ClickEventParam.PINK_LOTTERY_STAYTIME, param2: mActivityId.ToString());
			LocalPlayerDatabase.SetPrefValue(mFirstOpenPage + mActivityId, value: true);
		}
	}

	private void ReportEnter()
	{
		int day = DateTime.Now.Date.Day;
		int prefValueInt = LocalPlayerDatabase.GetPrefValueInt(mOpenPage);
		if (day != prefValueInt)
		{
			int num = Mathf.Max(LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief, LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice);
			LocalPlayerDatabase.SetPrefValue(mOpenPage, day);
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.PINK_LOTTERY_OPEN, num.ToString());
		}
	}
}
