using LightUI;
using UnityEngine.UI;

internal class ChatEntry_ChatItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public UIStateImage m_Channel;

	public Text m_Content;

	public TeamRoomChatItemLayout m_Layout;

	public void Bind(CommonDataCollection args)
	{
		string text = args["sender"];
		uint num = args["senderID"];
		string text2 = args["content"];
		int num2 = args["channel"];
		bool flag = args["membership"];
		if (LocalPlayerDatabase.LoginInfo.roleID == num)
		{
			text = Localization.Me;
		}
		m_Name.text = text;
		if (m_Channel != null)
		{
			m_Channel.State = num2;
			switch (num2)
			{
			case 0:
				m_Content.color = GameChatColors.HexToColor("#ffffff");
				if (flag)
				{
					m_Name.color = GameChatColors.HexToColor("#FFF700");
				}
				else
				{
					m_Name.color = GameChatColors.HexToColor("#ffffff");
				}
				break;
			case 1:
				m_Content.color = GameChatColors.HexToColor("#e357b6");
				m_Name.color = GameChatColors.HexToColor("#e357b6");
				break;
			case 2:
				m_Content.color = GameChatColors.HexToColor("#44b7ec");
				if (flag)
				{
					m_Name.color = GameChatColors.HexToColor("#FFF700");
				}
				else
				{
					m_Name.color = GameChatColors.HexToColor("#bdf8ff");
				}
				break;
			}
		}
		if (m_Layout != null)
		{
			m_Name.text += ":\u00a0";
			m_Content.SetText(text2);
			m_Layout.FixLayout();
		}
		else
		{
			m_Content.SetText($":\u00a0{text2}");
		}
	}
}
