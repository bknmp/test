using LightUI;
using LightUtility;
using UnityEngine.UI;

public class ActiveCardConfigView_ConfigTemplete
{
	public UIDataBinder m_Host;

	public Image m_Image;

	public MultiTargetGraphicButton m_Button;

	public Text m_Text;

	private int m_Index;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_Button, "OnButtonClicked");
		m_Index = args["idx"];
		m_Text.text = (m_Index + 1).ToString();
		m_Image.gameObject.SetActive(ActiveCardConfigView.CardConfigIndex == m_Index);
	}

	public void OnButtonClicked()
	{
		if (ActiveCardConfigView.CardConfigIndex != m_Index)
		{
			if (CardUtility.ContainsMultiWeaponCard())
			{
				UILobby.Current.ShowMessageBoxOK(Localization.TipsMultiWeaponCard, Localization.MsgBoxOK, Localization.MsgBoxTitle, null);
			}
			else if (GameRuntime.PlayingRole == RoleType.Police && !CardUtility.ContainsWeaponCard())
			{
				UILobby.Current.ShowMessageBoxOK(Localization.TipsOneWeaponCard, Localization.MsgBoxOK, Localization.MsgBoxTitle, null);
			}
			else
			{
				CardUtility.localChangeActiveCardConfigIndex(m_Index, null);
			}
		}
	}
}
