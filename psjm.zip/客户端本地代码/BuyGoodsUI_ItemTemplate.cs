using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class BuyGoodsUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Unit;

	public Text m_Price;

	public GameObject m_Selected;

	public Button m_SelectBtn;

	public Text m_PriceType;

	public Text m_SelectedTime;

	public Text m_ExpValue;

	public UIDataBinder m_ExpAdd;

	public Text m_OriginalPriceType;

	public Text m_OriginalPrice;

	public GameObject m_OriginalPriceContainer;

	private int m_shopID;

	private CurrencyType m_type;

	private string m_UnitTxt;

	private int m_index;

	private BuyUI m_buyGoodsUI;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_SelectBtn, "OnClickSelect");
		m_shopID = args["id"];
		m_index = args["index"];
		int amount = args["amount"];
		int num = args["price"];
		m_buyGoodsUI = (args["BuyGoodsUI"].val as BuyUI);
		ShopInfo shopInfo = LocalResources.ShopTable.Get(m_shopID);
		DropItem dropInfo = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
		m_UnitTxt = GetUnitString(dropInfo, amount);
		m_Unit.text = m_UnitTxt;
		int num2 = args["exp"];
		m_ExpValue.text = ((num2 > 0) ? string.Format(Localization.AddExpValueFromat, num2) : "");
		if (num == 0)
		{
			m_Price.text = "0";
			m_type = CurrencyType.Gold;
		}
		else
		{
			if (shopInfo.OriginalCost > 0f)
			{
				if ((bool)m_OriginalPrice && (bool)m_OriginalPriceType && (bool)m_OriginalPriceContainer)
				{
					m_OriginalPrice.text = (shopInfo.OriginalCost / 100f).ToString();
					m_OriginalPriceContainer.gameObject.SetActive(value: true);
					m_OriginalPriceType.text = ((m_type == CurrencyType.Gold) ? Localization.Gold : ((m_type == CurrencyType.Tickets) ? Localization.Ticket : Localization.Diamonds));
				}
			}
			else if ((bool)m_OriginalPrice && (bool)m_OriginalPriceType && (bool)m_OriginalPriceContainer)
			{
				m_OriginalPriceContainer.gameObject.SetActive(value: false);
			}
			m_Price.text = num.ToString();
			m_type = (CurrencyType)args["currency"].val;
		}
		m_PriceType.text = ((m_type == CurrencyType.Gold) ? Localization.Gold : ((m_type == CurrencyType.Tickets) ? Localization.Ticket : Localization.Diamonds));
		UpdateSelectState();
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["id"] = shopInfo.DropItemID;
		commonDataCollection["exp"] = num2;
		if (m_Selected.activeSelf && m_ExpAdd != null)
		{
			m_ExpAdd.Args = commonDataCollection;
			m_ExpAdd.UpdateImmediately();
		}
	}

	private void UpdateSelectState()
	{
		m_Selected.SetActive(m_buyGoodsUI.GlobalSelectID == m_shopID && m_buyGoodsUI.SelectedType == m_type);
		if (m_buyGoodsUI.GlobalIndex == m_index && m_buyGoodsUI.GlobalSelectID != m_shopID)
		{
			OnClickSelect();
		}
	}

	public void OnClickSelect()
	{
		m_buyGoodsUI.GlobalIndex = m_index;
		m_buyGoodsUI.GlobalSelectID = m_shopID;
		m_buyGoodsUI.SelectedType = m_type;
		if (m_SelectedTime != null)
		{
			m_SelectedTime.text = m_UnitTxt;
		}
		UIDataEvents.Inst.InvokeEvent("OnStoreGoodsBuyTimeChanged");
	}

	public static string GetUnitString(DropItem dropInfo, int amount = 1)
	{
		if (dropInfo.expiredTime >= 0)
		{
			if (dropInfo.expiredTime == 0)
			{
				return Localization.Forever;
			}
			return UITimeText.GetFormatTimeShort(dropInfo.expiredTime * amount, withAgo: false);
		}
		return "x" + amount;
	}
}
