using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterLotteryItem : MonoBehaviour
{
	public GameObject hightLightPref;

	public Image m_Icon;

	public Text m_ItemName;

	public Text m_ItemCount;

	public Image m_Tag;

	public UIStateItem m_QualityBG;

	private ParticleSystem hightLightFx;

	public List<int> gridId = new List<int>();

	public List<CharacterLotteryItemInfo> info;

	public List<DropItem> dropItem = new List<DropItem>();

	private Navigation customNav;

	public UITipsDialogController m_Tips;

	public UIPage m_PreviewDetailUI;

	public GameObject innerLightFx;

	public Sprite rareItemTag;

	public Sprite limitItemTag;

	public Sprite ownedItemTag;

	private bool m_SingleItem;

	private string m_ItemTimes;

	private int m_MinCount;

	private int m_MaxCount;

	private bool m_SingleItemId
	{
		get
		{
			if (m_SingleItem)
			{
				if (info.Count != 1)
				{
					return info[0].ItemId == info[1].ItemId;
				}
				return true;
			}
			return false;
		}
	}

	private void Awake()
	{
		GameObject gameObject = UnityEngine.Object.Instantiate(hightLightPref);
		gameObject.transform.SetParent(base.transform, worldPositionStays: false);
		gameObject.transform.SetAsFirstSibling();
		gameObject.transform.localPosition = Vector3.zero;
		hightLightFx = gameObject.GetComponentInChildren<ParticleSystem>();
		hightLightFx.Stop();
		UIDataEvents.Inst.AddEventListener("OnPlayerInfoChanged", this, Refresh);
	}

	private void OnEnable()
	{
		if (hightLightFx != null)
		{
			hightLightFx.Stop();
		}
	}

	public void Show(bool isHightLight)
	{
		if (!(hightLightFx == null))
		{
			if (isHightLight)
			{
				hightLightFx.Play();
			}
			else
			{
				hightLightFx.Stop();
			}
		}
	}

	public void Init(List<CharacterLotteryItemInfo> info, Transform iconRoot)
	{
		this.info = info;
		GetListInfo();
		if (!m_SingleItem)
		{
			GetComponent<UIStateItem>().State = 1;
			SetDetailButton();
		}
		else
		{
			GetComponent<UIStateItem>().State = 0;
			if (m_Icon != null && m_Icon.transform.parent != iconRoot)
			{
				m_Icon.transform.SetParent(iconRoot, worldPositionStays: true);
			}
			SetButtonType();
			SetDropInfo();
			if (m_Tips != null && m_SingleItemId && !string.IsNullOrEmpty(dropItem[0].BubbleTips))
			{
				m_Tips.m_Tips = dropItem[0].BubbleTips;
			}
		}
		innerLightFx.SetActive(info[0].PopValue > 0 && (bool)innerLightFx);
		m_QualityBG.State = info[0].Quality;
		Refresh();
	}

	public void Refresh()
	{
		if (info != null && info.Count > 0 && m_SingleItem && m_Tag != null)
		{
			ShowItemTag(!LocalPlayerDatabase.NotOwnPermanentItem(info[0].ItemId, includeNormal: true), info[0].Type);
		}
	}

	public void OnShowDetailUI()
	{
		CommonDataCollection argWarpper = PreviewDetailUI.GetArgWarpper(info[0].ItemId, string.Empty, "", 0, 0, string.Empty, null, info[0].Preview);
		UILobby.Current.ShowUI(m_PreviewDetailUI, argWarpper);
	}

	private void ShowItemTag(bool isOwned, int type)
	{
		if (isOwned)
		{
			m_Tag.enabled = true;
			if (ownedItemTag != null)
			{
				m_Tag.sprite = ownedItemTag;
			}
			return;
		}
		switch (type)
		{
		case 2:
			m_Tag.enabled = true;
			if (rareItemTag != null)
			{
				m_Tag.sprite = rareItemTag;
			}
			break;
		case 1:
			m_Tag.enabled = true;
			if (limitItemTag != null)
			{
				m_Tag.sprite = limitItemTag;
			}
			break;
		case 0:
			m_Tag.enabled = false;
			break;
		}
	}

	private void GetListInfo()
	{
		if (info.Count <= 0)
		{
			return;
		}
		string b = "";
		m_SingleItem = true;
		gridId.Clear();
		dropItem.Clear();
		for (int i = 0; i < info.Count; i++)
		{
			gridId.Add(info[i].GridId);
			dropItem.Add(LocalResources.DropItemTable.Get(info[i].ItemId));
			if (i == 0)
			{
				m_MinCount = (m_MaxCount = info[i].ItemCount);
				b = dropItem[i].Icon;
			}
			if (dropItem[i].Icon != b)
			{
				m_SingleItem = false;
			}
			m_MinCount = Mathf.Min(m_MinCount, info[i].ItemCount);
			m_MaxCount = Mathf.Max(m_MaxCount, info[i].ItemCount);
		}
	}

	public string GetAmountText()
	{
		if (dropItem.Count <= 0 || !m_SingleItem)
		{
			return "";
		}
		if (info.Count == 1)
		{
			return BuyGoodsUI_ItemTemplate.GetUnitString(dropItem[0], info[0].ItemCount);
		}
		if (m_SingleItemId)
		{
			return "x" + m_MinCount + "-" + m_MaxCount;
		}
		string text = "";
		List<DropItem> list = new List<DropItem>(dropItem.ToArray());
		list.Sort((DropItem x, DropItem y) => ((x.expiredTime == 0) ? 9999999 : x.expiredTime) - ((y.expiredTime == 0) ? 9999999 : y.expiredTime));
		for (int i = 0; i < list.Count; i++)
		{
			string unitString = BuyGoodsUI_ItemTemplate.GetUnitString(list[i]);
			text += ((i == 0) ? unitString : ("/" + unitString));
		}
		return text;
	}

	private void SetDetailButton()
	{
		if (dropItem.Count > 0)
		{
			GameObject gameObject = (m_Tips == null) ? base.gameObject : m_Tips.gameObject;
			if (gameObject.GetComponent<Button>() == null)
			{
				Button button = gameObject.AddComponent<Button>();
				customNav.mode = Navigation.Mode.None;
				button.navigation = customNav;
				button.onClick.AddListener(delegate
				{
					CharacterLotteryUI.m_PreClickTime = Time.time;
					UIPopup result = null;
					using (ResManager.Load("LotteryItemDetail", out result))
					{
						if (result != null)
						{
							CommonDataCollection args = new CommonDataCollection
							{
								["info"] = 
								{
									val = info
								}
							};
							UILobby.Current.ShowUI(result, args);
						}
					}
				});
			}
		}
	}

	private void SetButtonType()
	{
		if (this.dropItem.Count <= 0)
		{
			return;
		}
		DropItem dropItem = this.dropItem[0];
		if (info[0].Preview > 0)
		{
			dropItem = LocalResources.DropItemTable.Get(info[0].Preview);
		}
		GameObject gameObject = (m_Tips == null) ? base.gameObject : m_Tips.gameObject;
		switch (dropItem.Type)
		{
		case DropItemType.Character:
			if (gameObject.GetComponent<Button>() == null)
			{
				Button button = gameObject.AddComponent<Button>();
				customNav.mode = Navigation.Mode.None;
				button.navigation = customNav;
				button.onClick.AddListener(delegate
				{
					CharacterLotteryUI.m_PreClickTime = Time.time;
					CharacterUI_SelectCharacterItemTemplate.globalSelected = info[0].ItemId;
					CommonDataCollection arg = new CommonDataCollection
					{
						["arg"] = 0
					};
					JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI, arg);
				});
			}
			break;
		case DropItemType.SkinPart:
		case DropItemType.CardSkin:
		case DropItemType.SkinSuite:
		case DropItemType.IngameEmotion:
			if (gameObject.GetComponent<Button>() == null)
			{
				gameObject.AddComponent<Button>().onClick.AddListener(delegate
				{
					CharacterLotteryUI.m_PreClickTime = Time.time;
					OnShowDetailUI();
				});
			}
			break;
		}
	}

	public virtual void SetDropInfo()
	{
		if (dropItem.Count <= 0)
		{
			return;
		}
		if (m_Icon != null)
		{
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem[0].Icon);
		}
		if (m_ItemName != null)
		{
			string str = (MessagesExtension.IsDropItemAppearance(dropItem[0].Type) || dropItem[0].Type == DropItemType.Character) ? ("(" + GetAmountText() + ")") : GetAmountText();
			m_ItemName.text = dropItem[0].Name.Split(new string[1]
			{
				"\n"
			}, StringSplitOptions.None)[0] + str;
		}
		if (m_ItemCount != null)
		{
			m_ItemCount.text = GetAmountText();
			UIStateColor component = m_ItemCount.GetComponent<UIStateColor>();
			if (component != null)
			{
				component.State = info[0].Quality;
			}
		}
	}
}
