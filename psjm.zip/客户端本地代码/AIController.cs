using BehaviorDesigner.Runtime;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

public class AIController : BatchUpdateBehaviour
{
	private enum Strategy
	{
		Default,
		Conservative
	}

	public enum NavArea
	{
		Walkable,
		NotWalkable,
		Jump,
		Bridge,
		OnlyPoliceWalkable
	}

	public delegate bool SelectCondition<T>(T x);

	public float m_IdleTimeMin = 1f;

	public float m_IdleTimeMax = 5f;

	public float m_WanderRange = 5f;

	public float m_AttackRange = 5f;

	public float m_ViewRange = 6f;

	public float m_NearReachRange = 0.2f;

	public float m_RotationLerpFactor = 10f;

	public float m_AvoidanceFactor = 1f;

	public float m_AvoidanceAhead = 1f;

	public float m_AvoidanceRadius = 0.5f;

	public float m_StuckTimeThreshold = 1f;

	public float m_StuckDistThreshold = 0.5f;

	public float m_InterestProbability = 0.5f;

	public Vector3 m_GuardPosition;

	public float m_GuardRange = 5f;

	private float m_GuardPursuitRange = 5f;

	private float m_PatrolRange = 3.5f;

	private float m_PatrolPursuitRange = 3.5f;

	public string m_WindowTag;

	public string m_WallTag;

	public string m_FinalEscapeTag;

	public LayerMask m_AvoidanceMask;

	[EnumFlag]
	public NavArea m_NavAreaMask;

	public static bool Pause;

	private AIMode m_AIMode;

	private ProjectileLauncher m_ProjectileLauncher;

	private PlayerController m_PlayerController;

	private SkillLauncher m_SkillLauncher;

	private bool m_IsMovingOnPath;

	private bool m_UsingObject;

	private float m_LastOwnershipCheckTime;

	private Vector3 m_TargetDirection;

	private Vector3 m_TargetDirectionLatest;

	private Vector3 m_TargetPosition;

	private Vector3 m_AvoidanceDirection;

	private Vector3 m_LastCheckPosition;

	private int m_LastCheckCornerIdx;

	private float m_LastJumpTime;

	private float m_LastTryAttackTime;

	private float m_LastReEscapePathTime;

	private float m_RevivedTime;

	private Vector3[] m_PatrolCorners;

	private int m_PatrolPathCornerIdx;

	private int m_PatrolTargetIndex;

	[HideInInspector]
	public Vector3 m_NavigationPosition;

	private Delegates.ObjectCallback<bool> m_OnNavigateComplete;

	private bool m_IsNavigateComplete;

	private bool m_NavigateAllowPursuit;

	[HideInInspector]
	public float m_NavigateNearReach;

	private BossAIController m_BossAI;

	private Strategy m_Strategy;

	private NavMeshPath m_Path;

	private Vector3[] m_Corners = new Vector3[32];

	private int m_CornersCount;

	private int m_CornerIdx;

	private BehaviorTree ai;

	private UsableObject m_UsableObject;

	private float m_AutoFireTime = -1f;

	private Vector3 m_Up = new Vector3(0f, 0.5f, 0f);

	private List<InGameStoreInfo> m_CardInfos = new List<InGameStoreInfo>();

	private List<float> m_CardCoolTime = new List<float>();

	private List<float> m_CardLastUsedTime = new List<float>();

	private int m_Aggressive;

	private float m_AggressiveDuration;

	private bool m_IsAggressive;

	private int m_Focus;

	public float m_FocusDuration;

	private bool m_IsFocus;

	private float m_IgnoreWarningDuration;

	private bool m_IgnoreWarning;

	public bool m_IsTeleport;

	public bool PerformanceMode
	{
		get;
		set;
	}

	public NavMeshPath Path => m_Path;

	private float HidingViewRange => m_PlayerController.m_ViewProperties.hidingPlayerViewDistance;

	public bool IsControlling
	{
		get
		{
			if (m_IsMovingOnPath && !Pause && !Sleeping)
			{
				return !Forbid;
			}
			return false;
		}
	}

	public Vector3 CurrentAttackPosition
	{
		get;
		set;
	}

	public bool CanEnable => !m_PlayerController.FinalDeadOrEscaped;

	public bool Sleeping
	{
		get;
		set;
	}

	public bool SelectTargetInSequence
	{
		get;
		set;
	}

	public int PatrolPathCornerIdx => m_PatrolPathCornerIdx;

	public bool Forbid
	{
		get
		{
			if (m_PlayerController.PlayingRole == RoleType.Thief && m_PlayerController.IsDying)
			{
				return ImprisonObject.InFullImprisonArea(base.transform.localPosition);
			}
			return false;
		}
	}

	public PlayerController PlayerController => m_PlayerController;

	public bool IsPolice => m_PlayerController.PlayingRole.IsPoliceLike();

	public bool IsMoving => m_IsMovingOnPath;

	public bool IsUsingObject => m_UsingObject;

	public int Money => m_PlayerController.CurCoin;

	private void Awake()
	{
		m_SkillLauncher = GetComponent<SkillLauncher>();
		m_BossAI = GetComponent<BossAIController>();
		m_PlayerController = GetComponent<PlayerController>();
		m_ProjectileLauncher = m_PlayerController.ProjectileLauncher;
		PlayerController playerController = m_PlayerController;
		playerController.OnDied = (UnityAction)Delegate.Combine(playerController.OnDied, new UnityAction(OnDie));
		PlayerController playerController2 = m_PlayerController;
		playerController2.OnRevived = (UnityAction)Delegate.Combine(playerController2.OnRevived, new UnityAction(OnRevived));
		ai = base.gameObject.AddComponent<BehaviorTree>();
		ai.StartWhenEnabled = false;
		ai.DisableBehavior();
	}

	private void Start()
	{
		BatchUpdateManager.Inst.AddUpdate(this);
		m_TargetDirection = base.transform.forward;
		m_TargetDirectionLatest = m_TargetDirection;
		m_TargetPosition = base.transform.localPosition;
		m_LastCheckPosition = m_TargetPosition;
		if (BehaviorManager.instance != null)
		{
			BehaviorManager.instance.UpdateInterval = UpdateIntervalType.SpecifySeconds;
			BehaviorManager.instance.UpdateIntervalSeconds = 0.2f;
		}
	}

	protected override void OnEnable()
	{
		base.OnEnable();
		m_Path = new NavMeshPath();
		InvokeRepeating("CheckAvoidance", 0.3f, 0.3f);
		if (ai == null)
		{
			ai = base.gameObject.AddComponent<BehaviorTree>();
			ai.StartWhenEnabled = false;
		}
		if (!m_PlayerController.IsAI && m_PlayerController.PlayingRole == RoleType.Thief && !GameRuntime.IsOfflineMode && !GameRuntime.WitnessMode && !m_PlayerController.Shifter.IsMissile && !GameRuntime.IsPerformanceTest)
		{
			SetAIConfig(AIConfig.Instance.conservativeAI);
			if (!GameRuntime.IsMapBattleRoyale && !GameRuntime.IsMapCoinFight && !GameRuntime.IsMapRedEnvelopeFight)
			{
				Invoke("ResetStrategy", 60f);
			}
		}
		else
		{
			ResetStrategy();
		}
	}

	public override void BatchUpdate()
	{
		m_TargetDirection = Vector3.Slerp(m_TargetDirection, m_TargetDirectionLatest, m_RotationLerpFactor * Time.deltaTime);
		m_PlayerController.SetTargetDirection(m_TargetDirection);
	}

	private void ReplaceBehavior(ExternalBehavior behavior)
	{
		m_IsMovingOnPath = false;
		ai.DisableBehavior();
		ai.ExternalBehavior = behavior;
		ai.EnableBehavior();
		SetBTVariableSafely("自己", m_PlayerController);
		SetBTVariableSafely("AI", this);
	}

	private void ResetStrategy()
	{
		if (m_PlayerController.IsAI && !GameRuntime.WitnessMode && !GameRuntime.IsNormalGameOver)
		{
			int id = GameRuntime.RoomPlayers[m_PlayerController.UserId].MatchData.ai;
			AIInfo aIInfo = LocalResources.AITable.Get(id);
			if (aIInfo != null && !string.IsNullOrEmpty(aIInfo.Behavior))
			{
				SetAIConfig(ResManager.Load<ExternalBehaviorTree>(aIInfo.Behavior));
				return;
			}
		}
		if (GameRuntime.IsPerformanceTest)
		{
			GameRuntimePerformanceTest.SetAIConfig(this);
			return;
		}
		switch (GameRuntime.GameMode)
		{
		case GameMode.Robots:
		case GameMode.AI:
			if (!IsPolice && GameRuntime.PlayingRole == RoleType.Police && GameRuntime.TotalThiefs.IndexOf(m_PlayerController.UserId) >= LocalPlayerDatabase.Settings.PoliceAIModeNewAINum)
			{
				SetAIConfig(AIConfig.Instance.defaultAI);
				break;
			}
			if (m_PlayerController.PlayingRole == RoleType.Boss)
			{
				SetAIConfig(AIConfig.Instance.defaultAI);
			}
			else
			{
				SetAIConfig(IsPolice ? AIConfig.Instance.defaultPoliceAI : AIConfig.Instance.defaultThiefAI);
			}
			SetPersonality(UnityEngine.Random.Range(0, 50), UnityEngine.Random.Range(0, 80));
			break;
		case GameMode.Training:
			SetAIConfig(IsPolice ? AIConfig.Instance.defaultPoliceAI : AIConfig.Instance.defaultThiefAI);
			SetPersonality(UnityEngine.Random.Range(0, 50), UnityEngine.Random.Range(0, 80));
			break;
		case GameMode.Exam:
			ai.DisableBehavior();
			break;
		default:
			SetAIConfig(AIConfig.Instance.defaultAI);
			break;
		}
	}

	public void SetAIConfig(ExternalBehaviorTree aiConfig, Delegates.ObjectCallback2<BehaviorTree, AIController> aiPostProcess = null)
	{
		if (ai == null)
		{
			ai = base.gameObject.AddComponent<BehaviorTree>();
			ai.StartWhenEnabled = false;
		}
		if (aiConfig == null)
		{
			ai.DisableBehavior();
			ai.ExternalBehavior = null;
		}
		else
		{
			ReplaceBehavior(aiConfig);
			SetUsableCards(m_PlayerController.Cards);
		}
		aiPostProcess?.Invoke(ai, this);
	}

	private void SetBTVariableSafely(string key, object value)
	{
		if (ai.GetVariable(key) != null)
		{
			ai.SetVariableValue(key, value);
		}
	}

	protected override void OnDisable()
	{
		base.OnDisable();
		CancelInvoke();
		if (ai != null)
		{
			ai.DisableBehavior();
		}
		if (m_UsingObject)
		{
			m_UsingObject = false;
			m_IsMovingOnPath = false;
			m_UsableObject.RpcEndUsing(m_PlayerController.UserId);
			m_UsableObject = null;
		}
	}

	public void SetWander()
	{
		m_AIMode = AIMode.Wander;
		m_IsMovingOnPath = false;
	}

	public void SetLockTarget(PlayerController target)
	{
		ai.SetVariableValue("锁定的敌对目标", target);
		m_AIMode = AIMode.LockTarget;
		m_IsMovingOnPath = false;
	}

	public void SetGuard(Vector3 guardPosition, float guardRange = 5f, float guardPursuitRange = 5f)
	{
		m_AIMode = AIMode.Guard;
		m_GuardPosition = guardPosition;
		m_GuardRange = guardRange;
		m_GuardPursuitRange = guardPursuitRange;
		m_IsMovingOnPath = false;
	}

	public void SetNavigate(Vector3 navigatePosition, bool allowPursuit, Delegates.ObjectCallback<bool> onComplete = null, float nearReach = 0.25f, bool flattenY = true)
	{
		m_AIMode = AIMode.Navigate;
		if (flattenY)
		{
			m_NavigationPosition = navigatePosition.FlattenY();
		}
		else
		{
			m_NavigationPosition = navigatePosition;
		}
		m_NavigateNearReach = nearReach;
		m_OnNavigateComplete = onComplete;
		m_IsNavigateComplete = false;
		m_NavigateAllowPursuit = allowPursuit;
		m_IsMovingOnPath = false;
	}

	public void SetPatrol(Vector3[] patrolCorners, float patrolRange = 3.5f, float patrolPursuitRange = 3.5f)
	{
		m_AIMode = AIMode.Patrol;
		m_PatrolPursuitRange = patrolPursuitRange;
		m_PatrolCorners = patrolCorners;
		m_PatrolPathCornerIdx = 0;
		m_PatrolTargetIndex = 0;
		m_IsMovingOnPath = false;
	}

	private void OnDie()
	{
		if (base.enabled)
		{
			m_UsingObject = false;
		}
	}

	private void OnRevived()
	{
		if (base.enabled)
		{
			m_RevivedTime = Time.time;
		}
	}

	private bool IsIdle()
	{
		if (!m_UsingObject && (!(m_RevivedTime > 0f) || !(Time.time - m_RevivedTime < 0.5f)))
		{
			return m_PlayerController.OnVehichle != null;
		}
		return true;
	}

	private float IsEnemyNonShapeShifting(PlayerController player, float dist)
	{
		BeginProfilerSample("IsEnemyNonShapeShifting");
		if (ShapeShifter.IsShapeShiftingDefault(player.gameObject) && player.LinearVelocity.magnitude < 1f)
		{
			EndProfilerSample();
			return -1f;
		}
		EndProfilerSample();
		return dist;
	}

	private float GetEnemySqrDistance(PlayerController player)
	{
		if ((player.PlayingRole == RoleType.Thief && player.IsDying) || player.FinalDeadOrEscaped || player.InStealth)
		{
			return -1f;
		}
		if (player.Hiding)
		{
			if (m_PlayerController.Hiding)
			{
				float sqrMagnitude = (base.transform.localPosition - player.transform.localPosition).FlattenY().sqrMagnitude;
				if (!(sqrMagnitude < HidingViewRange * HidingViewRange))
				{
					return -1f;
				}
				return IsEnemyNonShapeShifting(player, sqrMagnitude);
			}
			return -1f;
		}
		float sqrMagnitude2 = (base.transform.localPosition - player.transform.localPosition).FlattenY().sqrMagnitude;
		if (!(sqrMagnitude2 < m_ViewRange * m_ViewRange))
		{
			return -1f;
		}
		return IsEnemyNonShapeShifting(player, sqrMagnitude2);
	}

	public PlayerController FindEnemyNearby()
	{
		BeginProfilerSample("FindEnemyNearby");
		PlayerController result = null;
		float num = float.MaxValue;
		foreach (PlayerController allPlayersAndPuppet in PlayerController.AllPlayersAndPuppets)
		{
			if (allPlayersAndPuppet.PlayingRole != m_PlayerController.PlayingRole)
			{
				float enemySqrDistance = GetEnemySqrDistance(allPlayersAndPuppet);
				if (enemySqrDistance > 0f && enemySqrDistance < num)
				{
					result = allPlayersAndPuppet;
					num = enemySqrDistance;
				}
			}
		}
		EndProfilerSample();
		return result;
	}

	public bool InModeRange(Vector3 pos)
	{
		float num = 0f;
		Vector3 b = pos;
		switch (m_AIMode)
		{
		case AIMode.Wander:
			return true;
		case AIMode.Guard:
			num = m_GuardRange;
			b = m_GuardPosition;
			break;
		case AIMode.Patrol:
			num = m_PatrolRange;
			b = m_PatrolCorners[m_PatrolPathCornerIdx];
			break;
		}
		if ((pos - b).sqrMagnitude >= num * num)
		{
			return false;
		}
		return true;
	}

	public bool CanPursuitEnemy(PlayerController enemy)
	{
		if (enemy != null)
		{
			switch (m_AIMode)
			{
			case AIMode.Wander:
				return true;
			case AIMode.Guard:
				if (InModeRange(base.transform.localPosition) && IsPolice && EnemyInPursuitRange(enemy))
				{
					return true;
				}
				return false;
			case AIMode.Navigate:
				if (m_NavigateAllowPursuit && (base.transform.localPosition - enemy.transform.localPosition).sqrMagnitude < 16f)
				{
					return true;
				}
				return false;
			case AIMode.Patrol:
				if (InModeRange(base.transform.localPosition) && IsPolice && EnemyInPursuitRange(enemy))
				{
					return true;
				}
				return false;
			default:
				return true;
			}
		}
		return false;
	}

	public bool EnemyInPursuitRange(PlayerController target)
	{
		float num = 0f;
		Vector3 b = target.transform.localPosition;
		float num2 = 0f;
		switch (m_AIMode)
		{
		case AIMode.Wander:
			return true;
		case AIMode.Guard:
			num = m_GuardRange;
			num2 = m_GuardPursuitRange;
			b = m_GuardPosition;
			break;
		case AIMode.Patrol:
			num = m_PatrolRange;
			num2 = m_PatrolPursuitRange;
			b = m_PatrolCorners[m_PatrolPathCornerIdx];
			break;
		}
		return Vector3.Distance(target.transform.localPosition, b) - num <= num2;
	}

	public void RecalculateEscapePath(PlayerController target)
	{
		Vector3 normalized = (base.transform.localPosition - target.transform.localPosition).normalized;
		Vector3 vector = base.transform.localPosition + normalized * m_ViewRange + m_ViewRange * 0.5f * UnityEngine.Random.insideUnitCircle.ExpandZ().SwapYZ();
		int num = 10;
		while (vector != InGameScene.Inst.Map.ConfineWorldPosition(vector, 0f) && --num > 0)
		{
			vector = base.transform.localPosition + UnityEngine.Random.insideUnitCircle.ExpandZ().SwapYZ() * m_ViewRange;
		}
		RecalculatePath(vector);
	}

	public void RecalculatePath(Vector3 targetPosition, bool isPrecise = false)
	{
		if (Pause)
		{
			return;
		}
		BeginProfilerSample("RecalculatePath");
		m_TargetPosition = InGameScene.Inst.Map.ConfineWorldPosition(targetPosition, 0f);
		m_CornerIdx = 1;
		m_CornersCount = 0;
		m_IsMovingOnPath = true;
		NavArea navArea = m_NavAreaMask;
		if (m_PlayerController.OnVehichle != null)
		{
			navArea &= (NavArea)(-3);
		}
		NavMeshHit hit2;
		NavMeshHit hit;
		if (NavMesh.CalculatePath(base.transform.localPosition, m_TargetPosition, (int)navArea, m_Path))
		{
			m_CornersCount = m_Path.GetCornersNonAlloc(m_Corners);
			if (m_CornersCount > 0 && Vector3.SqrMagnitude(m_Corners[m_CornersCount - 1] - m_TargetPosition) > 9f)
			{
				int num = Mathf.Min(m_CornersCount, m_Corners.Length - 1);
				m_Corners[num] = m_TargetPosition;
				m_CornersCount = Mathf.Min(m_CornersCount + 1, m_Corners.Length);
			}
		}
		else if (!isPrecise && NavMesh.SamplePosition(base.transform.localPosition, out hit, 5f, (int)navArea) && NavMesh.SamplePosition(m_TargetPosition, out hit2, 5f, (int)navArea))
		{
			m_TargetPosition = hit2.position;
			if (NavMesh.CalculatePath(hit.position, hit2.position, (int)navArea, m_Path))
			{
				m_CornersCount = m_Path.GetCornersNonAlloc(m_Corners);
			}
		}
		EndProfilerSample();
	}

	public bool IsAttacking()
	{
		if (m_SkillLauncher != null)
		{
			return m_SkillLauncher.IsAttacking;
		}
		return false;
	}

	private void CheckJump()
	{
		BeginProfilerSample("CheckJump");
		if (!InGameScene.Inst.IsStartCountDownFinished || Time.time - m_LastJumpTime < 0.5f || m_PlayerController.m_MovementProperties.jumpVelocity < 0.001f || m_PlayerController.IsDying)
		{
			EndProfilerSample();
			return;
		}
		int num = Physics.OverlapSphereNonAlloc(base.transform.localPosition + base.transform.forward * 0.5f, 0.2f, GameObjectUtility.CacheColliders);
		bool flag = false;
		for (int i = 0; i < num; i++)
		{
			if (!string.IsNullOrEmpty(m_WindowTag) && GameObjectUtility.CacheColliders[i].CompareTag(m_WindowTag))
			{
				flag = true;
			}
			else if (!string.IsNullOrEmpty(m_WallTag) && GameObjectUtility.CacheColliders[i].CompareTag(m_WallTag))
			{
				flag |= (UnityEngine.Random.Range(0f, 1f) < 0.5f);
			}
		}
		if (flag)
		{
			m_PlayerController.Jump();
		}
		m_LastJumpTime = Time.time;
		EndProfilerSample();
	}

	public void MoveToTarget()
	{
		if (!IsIdle() && m_Corners != null && m_CornerIdx < m_CornersCount && !IsAttacking())
		{
			BeginProfilerSample("MoveToTarget FlattenY");
			Vector3 vector = (m_Corners[m_CornerIdx] - base.transform.localPosition).FlattenY();
			while (vector.magnitude < m_NearReachRange && ++m_CornerIdx < m_CornersCount)
			{
				vector = (m_Corners[m_CornerIdx] - base.transform.localPosition).FlattenY();
			}
			EndProfilerSample();
			BeginProfilerSample("MoveToTarget CheckJump");
			if (!m_PlayerController.Shifter.IsVehicle && !m_PlayerController.Shifter.IsBall)
			{
				CheckJump();
			}
			EndProfilerSample();
			Vector3 normalized = (vector.normalized + m_AvoidanceDirection).normalized;
			RotateToTarget(normalized);
			m_IsMovingOnPath = true;
		}
		else
		{
			m_IsMovingOnPath = false;
		}
	}

	public void MoveStraightly(Vector3 dir)
	{
		if (!m_PlayerController.Shifter.IsVehicle && !m_PlayerController.Shifter.IsBall)
		{
			CheckJump();
		}
		RotateToTarget(dir.normalized);
		m_IsMovingOnPath = true;
	}

	public void RotateToTarget(Vector3 targetDir)
	{
		BeginProfilerSample("RotateToTarget");
		m_TargetDirectionLatest = targetDir;
		if (Time.time - m_LastOwnershipCheckTime > 0.5f)
		{
			m_PlayerController.RequestOwnership();
			m_LastOwnershipCheckTime = Time.time;
		}
		EndProfilerSample();
	}

	public bool HasWeapon()
	{
		if (m_ProjectileLauncher.CurrentWeapont == null)
		{
			return IsPolice;
		}
		return true;
	}

	public bool BuyWeapon(int weaponId)
	{
		int propIndex = GetPropIndex(weaponId);
		if (propIndex > 0 && m_CardInfos[propIndex].Price <= Money)
		{
			SubMoney(m_CardInfos[propIndex].Price);
			m_ProjectileLauncher.RpcSetWeaponID(weaponId);
			return true;
		}
		return false;
	}

	public bool UpgradeWeapon()
	{
		InGameStoreInfo inGameStoreInfo = null;
		foreach (InGameStoreInfo cardInfo in m_CardInfos)
		{
			if (cardInfo.Type == InGameStoreType.Weapon)
			{
				inGameStoreInfo = cardInfo;
				break;
			}
		}
		if (inGameStoreInfo == null)
		{
			return false;
		}
		foreach (InGameStoreInfo item in LocalResources.InGameStoreTable)
		{
			if (item.Type == InGameStoreType.WeaponUpgrade && LocalResources.WeaponTable.Get(item.TypeParam).BaseWeaponID == inGameStoreInfo.Id && item.TypeParam > m_ProjectileLauncher.CurrentWeapont.Id)
			{
				int cardPrice = m_PlayerController.GetCardPrice(item.Id);
				if (cardPrice <= Money)
				{
					SubMoney(cardPrice);
					m_ProjectileLauncher.RpcSetWeaponID(item.TypeParam);
					return true;
				}
			}
		}
		return false;
	}

	public bool BuyMagazine()
	{
		InGameStoreInfo inGameStoreInfo = null;
		foreach (InGameStoreInfo cardInfo in m_CardInfos)
		{
			if (cardInfo.Type == InGameStoreType.Weapon)
			{
				inGameStoreInfo = cardInfo;
				break;
			}
		}
		if (inGameStoreInfo == null)
		{
			return false;
		}
		foreach (InGameStoreInfo item in LocalResources.InGameStoreTable)
		{
			if (item.Type == InGameStoreType.Magazine && item.TypeParam == inGameStoreInfo.Id)
			{
				int cardPrice = m_PlayerController.GetCardPrice(item.Id);
				if (cardPrice <= Money)
				{
					SubMoney(cardPrice);
					m_ProjectileLauncher.RpcAddMagazine();
					return true;
				}
			}
		}
		return false;
	}

	public void TryAttack(PlayerController target, float weaponMistakeRate = 1f, float weaponAttackInterval = 2f)
	{
		if (m_PlayerController.IsDying || IsAttacking() || (m_PlayerController.Teleporter != null && m_PlayerController.Teleporter.IsTeleporting) || (m_AutoFireTime < 0f && Time.time - m_LastTryAttackTime < weaponAttackInterval) || m_PlayerController.IsDying || IsAttacking())
		{
			return;
		}
		if (m_BossAI != null && !m_PlayerController.BuffManager.IsSkillDisabled)
		{
			m_BossAI.TryAttack(target.transform);
			m_LastTryAttackTime = Time.time;
		}
		else
		{
			if (target != null && m_PlayerController.transform.localPosition.y > 1.3f && target.transform.localPosition.y < 1f && m_ProjectileLauncher.CurrentWeapont.RecoilFactor > 0f)
			{
				return;
			}
			BeginProfilerSample("TryAttack");
			Vector3 vector = (target != null) ? target.transform.localPosition : (base.transform.localPosition + base.transform.forward);
			Vector3 a = (target == null) ? base.transform.forward : (vector - base.transform.localPosition);
			float magnitude = a.magnitude;
			float num = Vector3.Dot(a / magnitude, base.transform.forward);
			if ((magnitude < 2f && num > 0f) || (magnitude < m_AttackRange && num > 0.6f))
			{
				if (!m_PlayerController.BuffManager.IsSkillDisabled && !m_PlayerController.BuffManager.IsSilence && m_BossAI == null)
				{
					if (m_AutoFireTime > 0f)
					{
						m_AutoFireTime -= Time.deltaTime;
						if (UnityEngine.Random.Range(0f, 1f) < Time.deltaTime)
						{
							CurrentAttackPosition = vector + (0.5f * UnityEngine.Random.insideUnitCircle.ExpandZ() * weaponMistakeRate).SwapYZ();
						}
						if (!(m_AutoFireTime <= 0f))
						{
						}
					}
					else
					{
						if (m_ProjectileLauncher.CurrentWeapont.ProjectileType != ProjectileType.Placeable && BulletObject.IsThroughBarrier(base.transform.localPosition + m_Up, vector + m_Up))
						{
							EndProfilerSample();
							return;
						}
						if (m_ProjectileLauncher.StartFire())
						{
							CurrentAttackPosition = vector;
							switch (m_ProjectileLauncher.CurrentWeapont.ProjectileType)
							{
							case ProjectileType.Placeable:
								CurrentAttackPosition += ((target != null) ? (target.LinearVelocity.FlattenY() * 0.8f) : base.transform.forward);
								CurrentAttackPosition += UnityEngine.Random.insideUnitCircle.ExpandZ().SwapYZ() * weaponMistakeRate;
								m_ProjectileLauncher.EndFire(tryCancel: false);
								break;
							case ProjectileType.Submachine:
								CurrentAttackPosition += (0.5f * UnityEngine.Random.insideUnitCircle.ExpandZ() * weaponMistakeRate).SwapYZ();
								m_AutoFireTime = UnityEngine.Random.Range(0.5f * weaponAttackInterval, 0.9f * weaponAttackInterval);
								m_ProjectileLauncher.EndFire(tryCancel: false);
								break;
							default:
								CurrentAttackPosition += (0.5f * UnityEngine.Random.insideUnitCircle.ExpandZ() * weaponMistakeRate).SwapYZ();
								m_ProjectileLauncher.EndFire(tryCancel: false);
								break;
							}
						}
						m_LastTryAttackTime = Time.time;
					}
				}
			}
			else
			{
				Vector3 normalized = (vector - base.transform.localPosition).FlattenY().normalized;
				RotateToTarget(normalized);
			}
			EndProfilerSample();
		}
	}

	public void StopMove()
	{
		m_IsMovingOnPath = false;
	}

	public PlayerController FindRescueTarget()
	{
		PlayerController result = null;
		float num = float.MaxValue;
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer.PlayingRole == m_PlayerController.PlayingRole && allPlayer.IsDying && allPlayer.GetComponent<UsableObject>().CanBeUsedBy(m_PlayerController, InGameInteractionType.StandStill))
			{
				float sqrMagnitude = (allPlayer.transform.localPosition - base.transform.localPosition).sqrMagnitude;
				if (sqrMagnitude < num)
				{
					result = allPlayer;
					num = sqrMagnitude;
				}
			}
		}
		return result;
	}

	public IEnumerator UseObject(UsableObject usable)
	{
		if (m_UsingObject)
		{
			yield break;
		}
		m_UsingObject = true;
		m_UsableObject = usable;
		BeginProfilerSample("UseObject start");
		usable.RpcStartUsing(m_PlayerController.UserId);
		EndProfilerSample();
		bool needCheckEnemy = usable.GetComponent<VaultObject>() != null;
		float lastCheckTime = 0f;
		while (!m_PlayerController.IsDying && !GameRuntime.PlayersState[m_PlayerController.UserId].IsFinalEscape && !m_PlayerController.BuffManager.IsSkillDisabled && usable.CanBeUsedBy(m_PlayerController, InGameInteractionType.StandStill) && Vector3.Distance(usable.transform.localPosition.FlattenY(), m_PlayerController.transform.localPosition.FlattenY()) < usable.m_StandStillUseRadiusThief)
		{
			if (needCheckEnemy && Time.time - lastCheckTime > 0.5f)
			{
				lastCheckTime = Time.time;
				if (FindEnemyNearby() != null)
				{
					break;
				}
			}
			yield return null;
		}
		BeginProfilerSample("UseObject end");
		usable.RpcEndUsing(m_PlayerController.UserId);
		EndProfilerSample();
		m_UsingObject = false;
		m_IsMovingOnPath = false;
		m_UsableObject = null;
	}

	public void CheckAvoidance()
	{
		BeginProfilerSample("CheckAvoidance");
		m_AvoidanceDirection = Vector3.zero;
		if (!m_IsMovingOnPath)
		{
			EndProfilerSample();
			return;
		}
		Vector3 vector = base.transform.localPosition + base.transform.forward * m_AvoidanceAhead;
		float num = 10000f;
		Vector3 b = vector;
		bool isVehicle = m_PlayerController.Shifter.IsVehicle;
		PlayerController playerController = null;
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (!(allPlayer == m_PlayerController) && (!isVehicle || allPlayer.PlayingRole != m_PlayerController.PlayingRole))
			{
				float sqrMagnitude = (allPlayer.transform.localPosition - vector).sqrMagnitude;
				if (sqrMagnitude < m_AvoidanceRadius * m_AvoidanceRadius && sqrMagnitude < num)
				{
					num = sqrMagnitude;
					b = allPlayer.transform.localPosition;
					playerController = allPlayer;
				}
			}
		}
		if (playerController != null)
		{
			Vector3 right = base.transform.right;
			float num2 = (Vector3.Dot(vector - b, right) > 0f) ? 1 : (-1);
			float num3 = m_PlayerController.m_BattleProperties.radius + playerController.m_BattleProperties.radius;
			float num4 = Mathf.Max(Vector3.Distance(vector, b) - num3, 0f);
			float num5 = m_AvoidanceAhead - m_PlayerController.m_BattleProperties.radius;
			float d = num2 * (num5 - num4) / num5;
			m_AvoidanceDirection = d * right * m_AvoidanceFactor;
		}
		EndProfilerSample();
	}

	public bool NeedUpdateAI()
	{
		if (!InGameScene.Inst.IsStartCountDownFinished || InGameScene.Inst.GameTime < 2f)
		{
			return false;
		}
		if (IsIdle())
		{
			return false;
		}
		if (!CanEnable)
		{
			return false;
		}
		if (m_IsTeleport)
		{
			return false;
		}
		return true;
	}

	public bool IsStuck()
	{
		if (m_UsingObject || Pause || !m_IsMovingOnPath || m_CornerIdx == 0)
		{
			return false;
		}
		bool result = false;
		if (m_LastCheckCornerIdx == m_CornerIdx && (m_LastCheckPosition - base.transform.localPosition).sqrMagnitude < m_StuckDistThreshold * m_StuckDistThreshold)
		{
			AIMode aIMode = m_AIMode;
			result = (aIMode != AIMode.Navigate || ((!m_IsNavigateComplete) ? true : false));
		}
		m_LastCheckCornerIdx = m_CornerIdx;
		m_LastCheckPosition = base.transform.localPosition;
		return result;
	}

	public bool InMode(AIMode aiMode)
	{
		return m_AIMode == aiMode;
	}

	public void UpdatePatrolling()
	{
		BeginProfilerSample("UpdatePatrolling");
		if (m_PatrolTargetIndex == m_PatrolCorners.Length - 1)
		{
			Vector3 vector = (m_PatrolCorners[m_PatrolPathCornerIdx] - base.transform.localPosition).FlattenY();
			while (vector.magnitude < m_NearReachRange && ++m_PatrolPathCornerIdx <= m_PatrolTargetIndex)
			{
				vector = (m_PatrolCorners[m_PatrolPathCornerIdx] - base.transform.localPosition).FlattenY();
			}
		}
		else if (m_PatrolTargetIndex == 0)
		{
			Vector3 vector2 = (m_PatrolCorners[m_PatrolPathCornerIdx] - base.transform.localPosition).FlattenY();
			while (vector2.magnitude < m_NearReachRange && --m_PatrolPathCornerIdx >= m_PatrolTargetIndex)
			{
				vector2 = (m_PatrolCorners[m_PatrolPathCornerIdx] - base.transform.localPosition).FlattenY();
			}
		}
		LoopPatrolling();
		RecalculatePath(m_PatrolCorners[m_PatrolPathCornerIdx]);
		EndProfilerSample();
	}

	private void LoopPatrolling()
	{
		if (m_PatrolTargetIndex == 0 && m_PatrolPathCornerIdx < 0)
		{
			m_PatrolPathCornerIdx = 0;
			m_PatrolTargetIndex = m_PatrolCorners.Length - 1;
		}
		else if (m_PatrolTargetIndex == m_PatrolCorners.Length - 1 && m_PatrolPathCornerIdx > m_PatrolTargetIndex)
		{
			m_PatrolPathCornerIdx = m_PatrolCorners.Length - 1;
			m_PatrolTargetIndex = 0;
		}
	}

	public void NotifyNavigationIfNeed(bool complete)
	{
		if (!m_IsNavigateComplete)
		{
			UnityEngine.Debug.Log(base.gameObject.name + " 导航结束, 发出通知（" + complete.ToString() + ")");
			if (complete)
			{
				m_IsNavigateComplete = true;
			}
			if (m_OnNavigateComplete != null)
			{
				m_OnNavigateComplete(complete);
				m_OnNavigateComplete = null;
			}
		}
	}

	public T RandomSelect<T>(List<T> list, SelectCondition<T> selector)
	{
		BeginProfilerSample("RandomSelect");
		List<T> list2 = new List<T>();
		for (int i = 0; i < list.Count; i++)
		{
			if (selector(list[i]))
			{
				list2.Add(list[i]);
			}
		}
		if (list2.Count == 0)
		{
			EndProfilerSample();
			return default(T);
		}
		EndProfilerSample();
		return list2[UnityEngine.Random.Range(0, list2.Count)];
	}

	public T Select<T>(List<T> list, SelectCondition<T> selector)
	{
		if (SelectTargetInSequence)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (selector(list[i]))
				{
					return list[i];
				}
			}
			return default(T);
		}
		return RandomSelect(list, selector);
	}

	private void BeginProfilerSample(string name)
	{
	}

	private void EndProfilerSample()
	{
	}

	private void SubMoney(int coin)
	{
		m_PlayerController.RpcSubCoin(coin);
	}

	public void SetUsableCards(int[] cardIds)
	{
		m_CardInfos.Clear();
		m_CardCoolTime.Clear();
		m_CardLastUsedTime.Clear();
		foreach (int num in cardIds)
		{
			if (num == 0)
			{
				continue;
			}
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Find(num);
			if (inGameStoreInfo != null)
			{
				m_CardInfos.Add(inGameStoreInfo);
				if (CardUtility.GetCardGrowth(inGameStoreInfo.Id).Type == CardGrowthType.BuyCooldown)
				{
					m_CardCoolTime.Add(m_PlayerController.GetCardLevelGrowthResult(inGameStoreInfo.Id));
				}
				else
				{
					m_CardCoolTime.Add(inGameStoreInfo.Cooldown);
				}
				m_CardLastUsedTime.Add(Time.time);
			}
		}
	}

	public void ForceCardCoolDown()
	{
		for (int i = 0; i < m_CardLastUsedTime.Count; i++)
		{
			m_CardLastUsedTime[i] = 0f;
		}
	}

	private int GetPropIndex(int typeParam)
	{
		for (int i = 0; i < m_CardInfos.Count; i++)
		{
			if (m_CardInfos[i].TypeParam == typeParam)
			{
				return i;
			}
		}
		return -1;
	}

	public bool CanUseProp(int typeParam)
	{
		if (PerformanceMode)
		{
			return true;
		}
		if (m_PlayerController.IsStoreDisabled)
		{
			return false;
		}
		int propIndex = GetPropIndex(typeParam);
		if (propIndex >= 0)
		{
			if (Money >= m_PlayerController.GetCardPrice(m_CardInfos[propIndex].Id) && Time.time - m_CardLastUsedTime[propIndex] > m_CardCoolTime[propIndex])
			{
				return true;
			}
			return false;
		}
		return false;
	}

	public bool TryUseProp(int typeParam, Vector3 targetPosition, bool ignoreDying = false)
	{
		if (!ignoreDying && m_PlayerController.IsDying)
		{
			return false;
		}
		if (m_PlayerController.BuffManager.IsCaged)
		{
			return false;
		}
		if (!GameRuntime.IsPerformanceTest)
		{
			int propIndex = GetPropIndex(typeParam);
			if (propIndex < 0)
			{
				return false;
			}
			int num = m_PlayerController.GetCardPrice(m_CardInfos[propIndex].Id);
			if (PerformanceMode)
			{
				num = Mathf.Min(Money, num);
			}
			if (Money < num)
			{
				return false;
			}
			SubMoney(num);
		}
		PropInfo propInfo = LocalResources.PropTable.Get(typeParam);
		switch (propInfo.Type)
		{
		case PropType.ShapeShifting:
			m_PlayerController.Shifter.RpcShapeShift(propInfo.TypeParam, propInfo.Id, UserId2NumId.Get(m_PlayerController.UserId));
			if (IsMoving)
			{
				RecalculatePath(m_TargetPosition);
			}
			break;
		case PropType.Buff:
			m_PlayerController.BuffManager.RpcCreateBuff(propInfo.TypeParam, propInfo.Id);
			break;
		case PropType.Placeable:
		{
			float y = 1.75f;
			if (!InGameScene.Inst.IsHighTile(targetPosition))
			{
				y = 0.05f;
			}
			m_PlayerController.m_PhotonView.RPC("PlacePlaceable", PhotonTargets.AllViaServer, propInfo.TypeParam, propInfo.Id, base.transform.localPosition.FlattenY(), base.transform.forward, targetPosition.FlattenY(y), (targetPosition - base.transform.localPosition).normalized);
			break;
		}
		case PropType.Radar:
			((PoliceController)m_PlayerController).RpcRadarScan();
			break;
		}
		return true;
	}

	public bool IsAggressive()
	{
		if (Time.time - m_AggressiveDuration >= 0f)
		{
			m_IsAggressive = (UnityEngine.Random.Range(0, 100) < m_Aggressive);
			m_AggressiveDuration = Time.time + UnityEngine.Random.Range(0f, 3f);
		}
		return m_IsAggressive;
	}

	public bool IsFocus()
	{
		if (Time.time - m_FocusDuration >= 0f)
		{
			m_IsFocus = (UnityEngine.Random.Range(0, 100) < m_Focus);
			m_FocusDuration = Time.time + UnityEngine.Random.Range(0f, 5f);
		}
		return m_IsFocus;
	}

	public void SetPersonality(int aggressive, int focus)
	{
		m_Aggressive = aggressive;
		m_Focus = focus;
	}

	public bool IsIgnoreWarning()
	{
		if (Time.time - m_IgnoreWarningDuration >= 0f)
		{
			m_IgnoreWarning = (UnityEngine.Random.Range(0f, 1f) < 0.5f);
			m_IgnoreWarningDuration = Time.time + (float)UnityEngine.Random.Range(0, 5);
		}
		return m_IgnoreWarning;
	}

	public bool Teleport(float delayToTeleport, float delayToAct, Vector3 position)
	{
		if (m_PlayerController.Teleporter.StartTeleport(enlargeMap: false))
		{
			m_IsTeleport = true;
			StartCoroutine(EndTeleport(delayToTeleport, delayToAct, position));
			return true;
		}
		return false;
	}

	private IEnumerator EndTeleport(float delayToTeleport, float delayToAct, Vector3 position)
	{
		yield return Yielders.GetWaitForSeconds(delayToTeleport);
		m_PlayerController.Teleporter.RpcTeleportIn(position);
		yield return Yielders.GetWaitForSeconds(delayToAct);
		m_IsTeleport = false;
	}
}
