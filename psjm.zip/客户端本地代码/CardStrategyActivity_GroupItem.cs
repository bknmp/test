using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

internal class CardStrategyActivity_GroupItem
{
	public UIDataBinder m_Host;

	public UIStateItem m_RoleType;

	public UIStateRawImage m_IconBg;

	public Image m_CharacterIcon;

	public Text m_CharacterName;

	public Text m_Name;

	public Text m_Text;

	public UITemplateInitiator m_CardContent;

	public MultiTargetGraphicButton m_RoleButton;

	public GameObject m_CopyPanel;

	public Button m_CopyButton;

	public Button m_TryButton;

	private int m_Index;

	private CardStrategyInfo m_CardStrategy;

	private bool m_IsThief;

	private int m_CardDefaultLevel = 7;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["index"];
		m_CardStrategy = CardStrategyActivity.m_CardStratrgyList[m_Index];
		SetInfo();
		SetCardGroup();
	}

	private void SetInfo()
	{
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_CardStrategy.CharacterID);
		m_IsThief = (characterInfo.Role == RoleType.Thief);
		int num3 = m_RoleType.State = (m_IconBg.State = ((!m_IsThief) ? 1 : 0));
		m_CharacterIcon.sprite = SpriteSource.Inst.Find(characterInfo.Icon);
		m_CharacterName.text = characterInfo.Name;
		m_Name.text = m_CardStrategy.GroupName;
		m_Text.text = m_CardStrategy.TechniqueItems;
		m_CopyButton.gameObject.SetActive(m_CardStrategy.CopyButton == 1);
		m_TryButton.gameObject.SetActive(m_CardStrategy.TryButton == 1);
		m_Host.EventProxy(m_RoleButton, "OnRoleClick");
		m_Host.EventProxy(m_CopyButton, "OnCopyButtonClicked");
		m_Host.EventProxy(m_TryButton, "OnTryButtonClick");
	}

	private void SetCardGroup()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < m_CardStrategy.GroupItems.Length; i++)
		{
			commonDataCollection[i]["itemID"] = m_CardStrategy.GroupItems[i];
		}
		m_CardContent.Args = commonDataCollection;
	}

	public void OnRoleClick()
	{
		CharacterUI_SelectCharacterItemTemplate.globalSelected = m_CardStrategy.CharacterID;
		JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI);
	}

	public void OnTryButtonClick()
	{
		UILobby.Current.ShowMessageBoxYesNo(Localization.TryCardGroup, Localization.Yes, Localization.No, "", delegate
		{
			m_Host.StartCoroutine(GameUtility.TryCharacter(m_CardStrategy.CharacterID, GetMatchPlayerData()));
			GameRuntime.EnteringJumpModuleType = 38;
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CARDACTIVITY_STRATEGY_TRY_CLICK, m_CardStrategy.Id.ToString());
		}, null);
	}

	private MatchPlayerData GetMatchPlayerData()
	{
		MatchPlayerData matchPlayerData = new MatchPlayerData();
		matchPlayerData.cards = m_CardStrategy.GroupItems;
		matchPlayerData.cardSkins = (from x in m_CardStrategy.GroupItems
			select CardUtility.CurCardSkin(x)).ToArray();
		matchPlayerData.cardStyles = new int[7];
		matchPlayerData.cardLevel = (from x in m_CardStrategy.GroupItems
			select Mathf.Max(CardUtility.GetCardLevel(x), m_CardDefaultLevel)).ToArray();
		matchPlayerData.lightnessConfig = 0;
		return matchPlayerData;
	}

	public void OnCopyButtonClicked()
	{
		if (CheckUnlockCards())
		{
			HomePage_CardGroupCopyPanel.SelectCharacterID = (m_IsThief ? LocalPlayerDatabase.PlayerInfo.activeCharacterID[1] : LocalPlayerDatabase.PlayerInfo.activeCharacterID[0]);
			m_CopyPanel.SetActive(value: true);
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["Name"] = m_CardStrategy.GroupName;
			commonDataCollection["IsThief"] = m_IsThief;
			commonDataCollection["CardConfigs"].val = m_CardStrategy.GroupItems;
			commonDataCollection["SetPosition"].val = new Vector3(-460f, -160f, 0f);
			m_CopyPanel.GetComponentInChildren<UIDataBinder>().Args = commonDataCollection;
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CARDACTIVITY_STRATEGY_COPY_CLICK, m_CardStrategy.Id.ToString());
		}
	}

	private bool CheckUnlockCards()
	{
		bool result = true;
		int[] groupItems = m_CardStrategy.GroupItems;
		int higherGrade = LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade;
		for (int i = 0; i < LocalPlayerDatabase.Settings.UnlockCardSlotGrade.Length; i++)
		{
			if (higherGrade < LocalPlayerDatabase.Settings.UnlockCardSlotGrade[i] && groupItems.Length > i && groupItems[i] > 0)
			{
				UILobby.Current.ShowTips(string.Format(Localization.CantCopyCardGroudWhenCardSlotLock, i + 1, LocalResources.GetGradeName(LocalPlayerDatabase.Settings.UnlockCardSlotGrade[i])));
				return false;
			}
		}
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		int[] array = groupItems;
		foreach (int num in array)
		{
			bool flag = (!m_IsThief) ? (LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice >= CardUtility.GetCardGrowth(num).UnlockGrade) : (LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief >= CardUtility.GetCardGrowth(num).UnlockGrade);
			if (!flag && num != 0)
			{
				list.Add(num);
				list2.Add(LocalResources.CardGrowthTable.Get(LocalResources.InGameStoreTable.Get(num).GrowthID).UnlockGrade);
			}
		}
		if (list.Count > 0)
		{
			string gradeName = "";
			int maxGrandeIdx = GetMaxGrandeIdx(list2, out gradeName);
			string fullName = LocalResources.InGameStoreTable.Get(list[maxGrandeIdx]).FullName;
			string msg = string.Format(Localization.TipsNotUnlockCard, gradeName, fullName);
			UILobby.Current.ShowTips(msg);
			result = false;
		}
		return result;
	}

	private int GetMaxGrandeIdx(List<int> gradeList, out string gradeName)
	{
		int result = 0;
		int num = -1;
		for (int i = 0; i < gradeList.Count; i++)
		{
			if (gradeList[i] > num)
			{
				result = i;
				num = gradeList[i];
			}
		}
		gradeName = LocalResources.GetGradeInfo(num, out GradeMappingInfo _).Name;
		return result;
	}
}
