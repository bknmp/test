using LightUtility;
using UnityEngine;

public class ColorPaletteInfo : IdBased
{
	public string Name;

	public int Hue;

	public int Saturation;

	public int Lightness;

	public Color Color;

	public string MatConfig;

	public static implicit operator TextureColorationInfo(ColorPaletteInfo palette)
	{
		return new TextureColorationInfo
		{
			Hue = palette.Hue,
			Saturation = palette.Saturation,
			Lightness = palette.Lightness
		};
	}
}
