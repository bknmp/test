using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UI;

internal class CollectionPage_IngameEmotionPage
{
	public UIDataBinder m_Host;

	public RawImage m_DecalRawImage;

	public UIPointerBehaviour m_Input;

	public Text m_IngameEmotionName;

	public Text m_DecalProgress;

	public Text m_DecalPersonality;

	public UITemplateInitiator m_Decal;

	public Text m_AnimationProgress;

	public Text m_AnimationPersonality;

	public UITemplateInitiator m_Animation;

	public RawImage m_AnimatorRawImage;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private uint m_PlayerID;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	private string m_DecalProgressFormat;

	private string m_AnimationProgressFormat;

	public void Bind(CommonDataCollection args)
	{
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerID = args["roleID"];
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		if (string.IsNullOrEmpty(m_DecalProgressFormat))
		{
			m_DecalProgressFormat = m_DecalProgress.text;
			m_AnimationProgressFormat = m_AnimationProgress.text;
		}
		CollectionPage_IngameEmotionItem.Selected = 0;
		DropItem[] array = (from a in LocalResources.DropItemTable
			where a.Type == DropItemType.IngameEmotion && a.expiredTime == 0
			orderby a.Quality descending, a.TypeParam, LocalResources.IngameEmotionInfo.Get(a.TypeParam).Chararcter
			select a).ToArray();
		List<DropItem> list = new List<DropItem>();
		List<DropItem> list2 = new List<DropItem>();
		List<DropItem> list3 = new List<DropItem>();
		List<DropItem> list4 = new List<DropItem>();
		DropItem[] array2 = array;
		foreach (DropItem dropItem in array2)
		{
			IngameEmotionInfo ingameEmotionInfo = LocalResources.IngameEmotionInfo.Get(dropItem.TypeParam);
			bool flag = CollectionUtility.IsOwnForeverIngameEmotion(dropItem.TypeParam, m_PlayerInfo);
			if (!flag && ((ingameEmotionInfo.SellStartTime != 0 && ingameEmotionInfo.SellStartTime > UtcTimeStamp.Now) || (ingameEmotionInfo.SellEndTime != 0 && ingameEmotionInfo.SellEndTime < UtcTimeStamp.Now)))
			{
				continue;
			}
			if (flag)
			{
				if (ingameEmotionInfo.Type == 0)
				{
					list.Add(dropItem);
				}
				else
				{
					list3.Add(dropItem);
				}
			}
			else if (ingameEmotionInfo.Type == 0)
			{
				list2.Add(dropItem);
			}
			else
			{
				list4.Add(dropItem);
			}
		}
		CommonDataCollection arg = new CommonDataCollection();
		CommonDataCollection arg2 = new CommonDataCollection();
		Wrapper(ref arg, list, own: true);
		Wrapper(ref arg2, list3, own: true);
		if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
		{
			Wrapper(ref arg, list2, own: false);
			Wrapper(ref arg2, list4, own: false);
		}
		m_Decal.Args = arg;
		m_Animation.Args = arg2;
		m_DecalProgress.text = string.Format(m_DecalProgressFormat, list.Count, list.Count + list2.Count);
		m_DecalPersonality.text = list.Sum((DropItem a) => a.Personality).ToString();
		m_AnimationProgress.text = string.Format(m_AnimationProgressFormat, list3.Count, list3.Count + list4.Count);
		m_AnimationPersonality.text = list3.Sum((DropItem a) => a.Personality).ToString();
	}

	private void Wrapper(ref CommonDataCollection arg, List<DropItem> list, bool own)
	{
		foreach (DropItem item in list)
		{
			int arraySize = arg.ArraySize;
			arg[arraySize]["dropItem"].val = item;
			arg[arraySize]["own"] = own;
			arg[arraySize]["page"].val = this;
		}
	}

	public void Preview(IngameEmotionInfo m_info)
	{
		LobbyScene.Inst.ClosePreviewPanels();
		LobbyScene.Inst.CloseCampPanels();
		if (m_info.Type == 0)
		{
			m_DecalRawImage.gameObject.SetActive(value: true);
			m_AnimatorRawImage.gameObject.SetActive(value: false);
			IngameEmotionUtility.PreviewDecal(m_info.DecalPrefab, m_DecalRawImage, hideCharacterSceneRoot: true, m_Input);
			return;
		}
		m_DecalRawImage.gameObject.SetActive(value: false);
		m_AnimatorRawImage.gameObject.SetActive(value: true);
		int chararcter = m_info.Chararcter;
		PlayerCharacterInfo playerCharacterInfo = CharacterUtility.GetPlayerCharacterInfo(chararcter, m_PlayerInfo);
		MatchPlayerData matchPlayerData = null;
		matchPlayerData = ((m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID) ? CharacterUtility.GetPlayerData(m_PlayerID, playerCharacterInfo.characterID, m_PlayerInfo, m_PlayerCardConfigs) : CharacterUtility.GetPlayerData(chararcter));
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(chararcter);
		LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, m_PlayerInfo.publicInfo.name, playerCharacterInfo, matchPlayerData, m_AnimatorRawImage, notRTMethod: false, m_Input, closeOppositeRole: true).GetComponent<IngameEmotionBaseController>().PlayAnimator(m_info);
	}
}
