using LightUI;
using UnityEngine.UI;

internal class CommoActivityInfoUI
{
	public UIDataBinder m_Host;

	public Text m_ContentText;

	public Text m_TitleText;

	public ContentSizeFitter m_ContentSizeFitter;

	public Scrollbar m_ScrollbarVertical;

	private int m_ActivityId;

	private int m_Type;

	public void Bind(CommonDataCollection args)
	{
		m_ActivityId = args["activityId"];
		m_TitleText.text = args["title"];
		m_ContentText.text = ((m_ActivityId != 0) ? LocalResources.ActivityLobbyInfos.Get(m_ActivityId).Desc : ((string)args["desc"]));
		m_ScrollbarVertical.value = 1f;
	}
}
