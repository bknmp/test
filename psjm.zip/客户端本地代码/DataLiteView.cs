using LightUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class DataLiteView : MonoBehaviour
{
	public UITemplateInitiator m_TemplateInitiator;

	public int m_NumPerView = 3;

	public float m_MinShowTime = 1f;

	private List<DataItem> m_Buffer = new List<DataItem>();

	private List<DataItem> m_Showing = new List<DataItem>();

	private float m_LastShowTime;

	private Action m_OnDisplay;

	private RectTransform m_ViewRect;

	private void Awake()
	{
		m_ViewRect = GetComponent<RectTransform>();
	}

	private void Update()
	{
		if (m_Showing.Count >= m_NumPerView - 1 && Time.realtimeSinceStartup - m_LastShowTime < 0.1f && CheckItemSize())
		{
			RemoveShowIndex(0);
		}
		if (m_Buffer.Count > 0 && Time.realtimeSinceStartup - m_LastShowTime > m_MinShowTime && m_Showing.Count >= m_NumPerView)
		{
			RemoveShowIndex(0);
		}
		int num = 0;
		while (num < m_Buffer.Count && m_Showing.Count < m_NumPerView && m_Buffer.Count > 0)
		{
			DataItem item = m_Buffer[num];
			ShowItem(item);
			m_Buffer.RemoveAt(num);
		}
	}

	public void AddItem(DataItem item, Action onDisplay = null)
	{
		m_Buffer.Add(item);
		m_OnDisplay = onDisplay;
	}

	public void Clear()
	{
		m_TemplateInitiator.Args.Clear();
		m_Buffer.Clear();
		m_Showing.Clear();
		UpdateDisplay();
	}

	private void UpdateDisplay()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < m_Showing.Count; i++)
		{
			commonDataCollection[i] = m_Showing[i];
		}
		m_TemplateInitiator.Args = commonDataCollection;
		if (m_OnDisplay != null)
		{
			m_OnDisplay();
		}
	}

	private void ShowItem(DataItem item)
	{
		m_LastShowTime = Time.realtimeSinceStartup;
		m_Showing.Add(item);
		UpdateDisplay();
	}

	private void RemoveShowIndex(int index)
	{
		m_Showing.RemoveAt(index);
		m_TemplateInitiator.Args.Array.Remove(index);
		m_TemplateInitiator.UpdateImmediately(withChildren: false, force: true);
	}

	private float GetItemsHeight()
	{
		List<UIDataBinder> items = m_TemplateInitiator.Items;
		float num = 0f;
		for (int i = 0; i < items.Count; i++)
		{
			num += items[i].RectTransform.rect.height;
		}
		return num;
	}

	private bool CheckItemSize()
	{
		return m_ViewRect.rect.height < GetItemsHeight();
	}
}
