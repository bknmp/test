using DG.Tweening;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

internal class CardSkinPage_CardSkinPreviewAnchor
{
	public UIDataBinder m_Host;

	public CardSkinEditUI m_CardSkinPage;

	public CameraOrbit m_CardPreviewCamera;

	public CameraRotation m_CameraRotation;

	public GameObject m_PrefabRoot;

	public GameObject m_Lock;

	public GameObject m_Using;

	private CardConfigEditPage_PageCardSkin m_page;

	private int m_index;

	private string m_lastPrefabInstName = "";

	private GameObject m_previewInst;

	private string m_notOwnShader = "Game/LobbyCardSkinPreview";

	private Color m_notOwnColor = new Color(94f / 255f, 94f / 255f, 94f / 255f, 1f);

	private Color m_TransparentColor = new Color(94f / 255f, 94f / 255f, 94f / 255f, 94f / 255f);

	private Dictionary<Material, List<Renderer>> m_DefaultMaterial = new Dictionary<Material, List<Renderer>>();

	private List<ParticleSystem> m_partical = new List<ParticleSystem>();

	private CardSkinInfo m_CardSkinInfo;

	private bool m_Selected;

	private bool m_IsLocalPlayer;

	private string prefabName = "";

	private List<string> m_NoChangeShaderTransformName = new List<string>
	{
		"renicapsule_05_ex",
		"medkit_05_ex",
		"eyes01",
		"eyes02",
		"Bucket_09_face"
	};

	private Dictionary<string, string> m_StopAnimWhenLostFocues = new Dictionary<string, string>
	{
		{
			"手榴弹08_Lobby",
			"Idle"
		}
	};

	public void Bind(CommonDataCollection args)
	{
		SetSimpleBillboard();
		m_CardSkinInfo = (args["cardSkinInfo"].val as CardSkinInfo);
		m_index = args["index"];
		m_page = (args["page"].val as CardConfigEditPage_PageCardSkin);
		m_PrefabRoot.transform.localPosition = new Vector3(m_PrefabRoot.transform.localPosition.x, m_PrefabRoot.transform.localPosition.y, m_CardSkinInfo.PreviewZOffset);
		m_IsLocalPlayer = args["isLocalplayer"];
		SetLockAndUsingState();
		m_Selected = (CardConfigEditPage_CardSkinItemTemplate.globalSelected == m_CardSkinInfo.Id);
		prefabName = GetPrefabName();
		UpdatePrefab();
		UpdateCamera();
	}

	private void SetSimpleBillboard()
	{
		m_Lock.GetComponent<SimpleBillboard>().OverrideCamera = m_CardPreviewCamera.GetComponent<Camera>();
		m_Using.GetComponent<SimpleBillboard>().OverrideCamera = m_CardPreviewCamera.GetComponent<Camera>();
	}

	private string GetPrefabName()
	{
		if (m_CardSkinInfo.Id <= 0)
		{
			return "cardSkinPrefabComingSoon";
		}
		if (LocalResources.InGameStoreTable.Get(m_CardSkinInfo.CardID).Type == InGameStoreType.Weapon)
		{
			CardStyleInfo styleInfo = LocalResources.CardStyleTable.Get(StyleItemTemplate.GlobleSelectedStyleId);
			if (styleInfo == null || styleInfo.BasicCardSkinId != m_CardSkinInfo.Id)
			{
				return LocalResources.CardSkinTable.FindAll((CardSkinInfo x) => x.TypeParam == m_CardSkinInfo.TypeParam)[CardConfigEditPage_PageCardSkin.WeaponCardSkinIndex].Prefabs + "_Lobby";
			}
			return LocalResources.CardStyleTable.FindAll((CardStyleInfo x) => x.TypeParam == styleInfo.TypeParam)[CardConfigEditPage_PageCardSkin.WeaponCardSkinIndex].Prefabs + "_Lobby";
		}
		return GetCurrentPrefabName() + "_Lobby";
	}

	private string GetCurrentPrefabName()
	{
		CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(StyleItemTemplate.GlobleSelectedStyleId);
		if (cardStyleInfo == null || cardStyleInfo.BasicCardSkinId != m_CardSkinInfo.Id)
		{
			return CardUtility.GetCardPrefabName(m_CardSkinInfo.Id);
		}
		return cardStyleInfo.Prefabs;
	}

	private void UpdatePrefab()
	{
		int currentSelectedIndex = m_page.GetCurrentSelectedIndex();
		if (m_lastPrefabInstName != prefabName || m_previewInst == null)
		{
			m_lastPrefabInstName = prefabName;
			if (m_previewInst != null)
			{
				m_DefaultMaterial.Clear();
				m_partical.Clear();
				UnityEngine.Object.DestroyImmediate(m_previewInst);
			}
			m_CardSkinPage.Acquire(prefabName, delegate(GameObject inst)
			{
				if (inst != null)
				{
					if (!m_Host.gameObject.activeInHierarchy || !inst.gameObject.name.Contains(prefabName))
					{
						UnityEngine.Object.DestroyImmediate(inst);
					}
					else
					{
						m_previewInst = inst;
						m_previewInst.transform.SetParent(m_PrefabRoot.transform, worldPositionStays: false);
						m_previewInst.transform.localPosition = Vector3.zero;
						SetDefault();
						UpdateMaterial(m_Selected);
						UpdateAnimator(m_Selected);
					}
				}
			}, Mathf.Abs(m_index - currentSelectedIndex));
		}
		else if (m_previewInst != null)
		{
			UpdateMaterial(m_Selected);
			UpdateAnimator(m_Selected);
			TriggerLobbyEffect(m_Selected);
		}
	}

	private void UpdateCamera()
	{
		if (m_Selected)
		{
			m_CardPreviewCamera.ObjRot = m_PrefabRoot.transform;
			m_CameraRotation.enabled = true;
		}
		else
		{
			m_CameraRotation.enabled = false;
			m_PrefabRoot.transform.DORotate(Vector3.zero, 0.3f);
		}
	}

	private void SetLockAndUsingState()
	{
		int expiredTime;
		bool flag = CardUtility.OwnCardSkin(m_CardSkinInfo.Id, out expiredTime) || CardUtility.IsDefaultCardSkin(m_CardSkinInfo.CardID, m_CardSkinInfo.Id);
		if (!m_IsLocalPlayer || m_CardSkinInfo.Id <= 0)
		{
			m_Lock.gameObject.SetActive(value: false);
			m_Using.gameObject.SetActive(value: false);
		}
		else if (!flag)
		{
			m_Lock.gameObject.SetActive(value: true);
			m_Using.gameObject.SetActive(value: false);
		}
		else if (CardUtility.CurCardSkin(m_CardSkinInfo.CardID) == m_CardSkinInfo.Id)
		{
			m_Using.gameObject.SetActive(value: true);
			m_Lock.gameObject.SetActive(value: false);
		}
		else
		{
			m_Lock.gameObject.SetActive(value: false);
			m_Using.gameObject.SetActive(value: false);
		}
	}

	private void SetDefault()
	{
		if (m_CardSkinInfo.IsSpecialMatInLobby)
		{
			return;
		}
		SkinnedMeshRenderer[] componentsInChildren = m_previewInst.GetComponentsInChildren<SkinnedMeshRenderer>();
		foreach (SkinnedMeshRenderer skinnedMeshRenderer in componentsInChildren)
		{
			if (!(skinnedMeshRenderer.GetComponent<FixedMaterial>() != null))
			{
				if (!m_DefaultMaterial.ContainsKey(skinnedMeshRenderer.material))
				{
					List<Renderer> list = new List<Renderer>();
					list.Add(skinnedMeshRenderer);
					m_DefaultMaterial.Add(skinnedMeshRenderer.material, list);
				}
				else
				{
					m_DefaultMaterial[skinnedMeshRenderer.material].Add(skinnedMeshRenderer);
				}
			}
		}
		MeshRenderer[] componentsInChildren2 = m_previewInst.GetComponentsInChildren<MeshRenderer>();
		foreach (MeshRenderer meshRenderer in componentsInChildren2)
		{
			if (!(meshRenderer.GetComponent<FixedMaterial>() != null))
			{
				if (!m_DefaultMaterial.ContainsKey(meshRenderer.material))
				{
					List<Renderer> list2 = new List<Renderer>();
					list2.Add(meshRenderer);
					m_DefaultMaterial.Add(meshRenderer.material, list2);
				}
				else
				{
					m_DefaultMaterial[meshRenderer.material].Add(meshRenderer);
				}
			}
		}
		m_partical = new List<ParticleSystem>(m_previewInst.GetComponentsInChildren<ParticleSystem>(includeInactive: true));
	}

	private void UpdateMaterial(bool selected)
	{
		if (m_CardSkinInfo.IsSpecialMatInLobby)
		{
			return;
		}
		if (!selected)
		{
			foreach (KeyValuePair<Material, List<Renderer>> item in m_DefaultMaterial)
			{
				Material material = new Material(Shader.Find(m_notOwnShader));
				material.CopyPropertiesFromMaterial(item.Key);
				material.SetColor("_Color", m_notOwnColor);
				if (item.Key.name.Contains("Transparent"))
				{
					material.SetColor("_Color", m_TransparentColor);
				}
				else
				{
					material.SetColor("_Color", m_notOwnColor);
				}
				foreach (Renderer item2 in item.Value)
				{
					if (item2 != null && !m_NoChangeShaderTransformName.Contains(item2.name))
					{
						if (item2.material.shader.name.Equals("Game/FogOfWar/Character"))
						{
							MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
							item2.GetPropertyBlock(materialPropertyBlock);
							materialPropertyBlock.SetColor("_Color", new Color(0.37f, 0.37f, 0.37f, 1f));
							item2.SetPropertyBlock(materialPropertyBlock);
						}
						else
						{
							item2.material = material;
						}
					}
				}
			}
			foreach (ParticleSystem item3 in m_partical)
			{
				item3.gameObject.SetActive(item3.gameObject.name.Contains("notSelectedShow"));
			}
		}
		else
		{
			foreach (KeyValuePair<Material, List<Renderer>> item4 in m_DefaultMaterial)
			{
				foreach (Renderer item5 in item4.Value)
				{
					if (item5.material.shader.name.Equals("Game/FogOfWar/Character"))
					{
						MaterialPropertyBlock materialPropertyBlock2 = new MaterialPropertyBlock();
						item5.GetPropertyBlock(materialPropertyBlock2);
						materialPropertyBlock2.SetColor("_Color", new Color(1f, 1f, 1f, 1f));
						item5.SetPropertyBlock(materialPropertyBlock2);
					}
					item5.material = item4.Key;
				}
			}
			foreach (ParticleSystem item6 in m_partical)
			{
				item6.gameObject.SetActive(!item6.gameObject.name.Contains("notSelectedShow"));
			}
		}
		if (!(m_previewInst.GetComponent<AutoShowCardSkinEffect>() != null))
		{
			return;
		}
		Transform[] componentsInChildren = m_previewInst.GetComponentsInChildren<Transform>(includeInactive: true);
		foreach (Transform transform in componentsInChildren)
		{
			if (transform.gameObject.name.Contains("SelectActiveGameObject"))
			{
				transform.gameObject.SetActive(selected);
			}
			else if (transform.gameObject.name.Contains("SelectNotActiveGameObject"))
			{
				transform.gameObject.SetActive(!selected);
			}
		}
	}

	private void UpdateAnimator(bool selected)
	{
		if (m_previewInst == null)
		{
			return;
		}
		Animator componentInChildren = m_previewInst.GetComponentInChildren<Animator>();
		if (componentInChildren == null)
		{
			return;
		}
		if (selected)
		{
			if (IsInStopAnimWhenLostFocuesDict())
			{
				componentInChildren.enabled = true;
				componentInChildren.Play(m_StopAnimWhenLostFocues[m_previewInst.name.Replace("(Clone)", "")], 0, 0f);
				Animation[] componentsInChildren = m_previewInst.GetComponentsInChildren<Animation>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].Play();
				}
			}
			else
			{
				componentInChildren.SetBool("Idle", value: false);
			}
		}
		else if (IsInStopAnimWhenLostFocuesDict())
		{
			componentInChildren.Play(m_StopAnimWhenLostFocues[m_previewInst.name.Replace("(Clone)", "")], 0, 0f);
			Animation[] componentsInChildren = m_previewInst.GetComponentsInChildren<Animation>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].Stop();
			}
			componentInChildren.enabled = false;
		}
		else
		{
			componentInChildren.SetBool("Idle", value: true);
		}
	}

	private void TriggerLobbyEffect(bool selected)
	{
		CardSkinPreviewEffectController[] componentsInChildren = m_PrefabRoot.transform.GetComponentsInChildren<CardSkinPreviewEffectController>();
		if (componentsInChildren.Length == 0)
		{
			return;
		}
		if (selected)
		{
			CardSkinPreviewEffectController[] array = componentsInChildren;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Trigger();
			}
		}
		else
		{
			CardSkinPreviewEffectController[] array = componentsInChildren;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Stop();
			}
		}
	}

	private bool IsInStopAnimWhenLostFocuesDict()
	{
		foreach (KeyValuePair<string, string> stopAnimWhenLostFocue in m_StopAnimWhenLostFocues)
		{
			if (m_previewInst.name.Replace("(Clone)", "").Equals(stopAnimWhenLostFocue.Key))
			{
				return true;
			}
		}
		return false;
	}
}
