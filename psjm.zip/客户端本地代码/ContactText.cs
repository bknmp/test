using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class ContactText : MonoBehaviour
{
	public Text m_ContactText;

	private void Awake()
	{
		GetComponentInChildren<Button>(includeInactive: true).onClick.AddListener(OnContactClicked);
		LocalPlayerDatabase.OnNoticeChanged = (Delegates.VoidCallback)Delegate.Combine(LocalPlayerDatabase.OnNoticeChanged, new Delegates.VoidCallback(UpdateContent));
	}

	private void OnEnable()
	{
		UpdateContent();
	}

	private void OnDestroy()
	{
		LocalPlayerDatabase.OnNoticeChanged = (Delegates.VoidCallback)Delegate.Remove(LocalPlayerDatabase.OnNoticeChanged, new Delegates.VoidCallback(UpdateContent));
	}

	private void UpdateContent()
	{
		if (LocalPlayerDatabase.NoticeInfo != null)
		{
			m_ContactText.text = LocalPlayerDatabase.NoticeInfo.contact1;
		}
	}

	public void OnContactClicked()
	{
		if (!string.IsNullOrEmpty(m_ContactText.text))
		{
			ClipboardTool.CopyToSystemClipboard(MathUtility.ExtractNumbers(m_ContactText.text));
			UILobby.Current.ShowTips(Localization.TipsContact1CopySuccess);
		}
	}
}
