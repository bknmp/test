using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AccountFindUI : MonoBehaviour
{
	public Button m_MailFind;

	public Button m_RecoverCodeFind;

	public Button m_DefaultFind;

	public Button m_CloseBtn;

	public Text m_TouristText;

	public Text m_SDKText;

	private string m_SDKFormat;

	private void Awake()
	{
		m_MailFind.onClick.AddListener(FindByMail);
		m_RecoverCodeFind.onClick.AddListener(FindByRecoverCode);
		m_DefaultFind.onClick.AddListener(FindDefault);
		m_CloseBtn.onClick.AddListener(CloseUI);
		m_SDKFormat = m_SDKText.text;
	}

	private void OnEnable()
	{
		ChangeDefaultButtonState();
	}

	private void ChangeDefaultButtonState()
	{
		if (LoginManager.SDKLoginType == 1)
		{
			m_TouristText.gameObject.SetActive(value: true);
			m_SDKText.gameObject.SetActive(value: false);
		}
		else
		{
			m_SDKText.gameObject.SetActive(value: true);
			m_TouristText.gameObject.SetActive(value: false);
			m_SDKText.text = string.Format(m_SDKFormat, LoginUtility.SDKAccountName((LoginType)LoginManager.SDKLoginType));
		}
	}

	private void FindByMail()
	{
		AccountMailVerifyUI.ShowUI(MailCodeType.FindAccount, Localization.TipsFindByMail, "", delegate
		{
			AccountSetPwdUI.ShowUI(AccountUtility.MailCodeResponse.roleID, AccountUtility.MailCodeResponse.accountName, AccountUtility.MailCodeResponse.codeKey, "", delegate(int roleID)
			{
				CloseUI();
				AccountLoginUI.ShowUI(AccountUtility.DoSwitchAccount, roleID);
			});
		});
	}

	private void FindByRecoverCode()
	{
		AccountRecoverCodeUI.ShowUI(delegate(int roleID)
		{
			CloseUI();
			AccountLoginUI.ShowUI(AccountUtility.DoSwitchAccount, roleID);
		});
	}

	private void FindDefault()
	{
		AccountUtility.FindDefaultAccount();
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI()
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountFindUI");
		UILobby.Current.ShowUI(ui, null);
	}
}
