using GameMessages;
using LightUI;
using LightUtility;

internal class Broadcast_ItemTemplate
{
	public UIDataBinder m_Host;

	public UIDataBinder m_BroadcastItemGift;

	private UIDataBinder m_Prefab;

	private UIDataBinder m_Item;

	public void Bind(CommonDataCollection args)
	{
		BroadcastInfo obj = (BroadcastInfo)args["broadcast"].val;
		UIDataBinder broadcastItemGift = m_BroadcastItemGift;
		if (obj.channel == 1)
		{
			broadcastItemGift = m_BroadcastItemGift;
		}
		if (m_Prefab != broadcastItemGift)
		{
			m_Prefab = broadcastItemGift;
			if (m_Item != null)
			{
				PoolSpawner.DeSpawn(m_Item.gameObject);
				m_Item = null;
			}
		}
		if (m_Item == null)
		{
			m_Item = PoolSpawner.Spawn(m_Prefab.gameObject).GetComponent<UIDataBinder>();
			m_Item.transform.SetParent(m_Host.transform, worldPositionStays: false);
		}
		if (m_Item != null)
		{
			m_Item.Args = args;
			m_Item.UpdateImmediately();
		}
	}
}
