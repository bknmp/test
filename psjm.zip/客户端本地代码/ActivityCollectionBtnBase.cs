using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActivityCollectionBtnBase : LobbyBaseButton
{
	public Text m_TabName;

	public UILobbyElement m_UI;

	public GameObject m_RedPoint;

	public ActivityCollectionType m_CollectionType;

	private List<ModuleStatus> m_activityRedPointList = new List<ModuleStatus>();

	private void Start()
	{
		Init();
		UIDataEvents.Inst.AddEventListener("OverDayEvent", this, Init);
		UIDataEvents.Inst.AddEventListener("OnActivityLobbyRedPointChange", this, UpdateRedPointState);
		UIDataEvents.Inst.AddEventListener("OnPlayerInfoChanged", this, UpdateRedPointState);
	}

	private void UpdateRedPointState()
	{
		foreach (ModuleStatus activityRedPoint in m_activityRedPointList)
		{
			if (ActivityLobby.RedPointState((ActivityType)activityRedPoint.value, activityRedPoint.key))
			{
				m_RedPoint.gameObject.SetActive(value: true);
				return;
			}
		}
		m_RedPoint.gameObject.SetActive(value: false);
	}

	public void OnClick()
	{
		UILobby.Current.ShowUI(m_UI, null);
	}

	private void Init()
	{
		bool flag = false;
		m_activityRedPointList.Clear();
		int num = 999;
		string text = "";
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
			if (m_CollectionType == activityLobbyInfo.CollectionType && LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit && (UtcTimeStamp.Now > activity.startTime || UtcTimeStamp.Now > activity.exchangeStartTime) && (UtcTimeStamp.Now < activity.endTime || UtcTimeStamp.Now < activity.exchangeEndTime))
			{
				m_activityRedPointList.Add(new ModuleStatus
				{
					key = activity.activityId,
					value = (int)activityLobbyInfo.Type
				});
				flag = true;
				if (m_TabName != null && activityLobbyInfo.Rank < num)
				{
					num = activityLobbyInfo.Rank;
					text = activityLobbyInfo.TabName;
				}
			}
			if (m_TabName != null)
			{
				m_TabName.text = text;
			}
		}
		UpdateRedPointState();
		if (flag)
		{
			Show();
		}
		else
		{
			Hide();
		}
	}
}
