using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CharacterBuyDirectActivity
{
	public UIDataBinder m_Host;

	public Text m_TimeText;

	public UIDataBinder m_ActivityGiftUI;

	private string m_TimeFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_TimeText.text;
		}
		Activity activity = args["Activity"].val as Activity;
		m_TimeText.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		m_ActivityGiftUI.Args = args;
	}
}
