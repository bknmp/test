using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CardCommentUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public GameObject m_HotIcon;

	public Text m_name;

	public Text m_comment;

	public Button m_LikeButton;

	public UIStateImage m_LikeState;

	public Text m_LikeNumText;

	public PlayerSpaceButton m_spaceBtn;

	public UIStateItem m_State;

	private int m_commentID;

	private bool m_liked;

	private int m_likeNum;

	private int m_defaultLikeNum;

	private uint m_roleId;

	private CommentUI m_cardCommentUI;

	private bool m_lastLiked;

	public void Bind(CommonDataCollection args)
	{
		m_State.State = args["state"];
		if (m_State.State == 0)
		{
			return;
		}
		m_HotIcon.gameObject.SetActive(args["hot"]);
		m_roleId = args["roleID"];
		m_name.text = args["name"];
		m_commentID = args["commentID"];
		m_lastLiked = (m_liked = args["liked"]);
		m_defaultLikeNum = (m_likeNum = args["likeNum"]);
		m_comment.text = args["comment"];
		m_cardCommentUI = (args["cardCommentUI"].val as CommentUI);
		bool like = false;
		if (m_cardCommentUI.HadLocalLickData(m_commentID, out like) && like != m_lastLiked)
		{
			if (like)
			{
				m_likeNum++;
			}
			else
			{
				m_likeNum--;
			}
			m_liked = like;
		}
		m_LikeState.State = ((!m_liked) ? 1 : 0);
		m_likeNum = Mathf.Clamp(m_likeNum, Mathf.Max(0, m_defaultLikeNum - 1), m_defaultLikeNum + 1);
		m_LikeNumText.text = m_likeNum.ToString();
		m_spaceBtn.SetPlayerID(m_roleId);
		m_Host.EventProxy(m_LikeButton, "OnClickLike");
	}

	public void OnClickLike()
	{
		m_liked = !m_liked;
		if (m_liked)
		{
			m_likeNum++;
			UILobby.Current.ShowTips(Localization.CommentLike);
		}
		else
		{
			m_likeNum--;
			UILobby.Current.ShowTips(Localization.CommentDisLike);
		}
		m_likeNum = Mathf.Clamp(m_likeNum, Mathf.Max(0, m_defaultLikeNum - 1), m_defaultLikeNum + 1);
		m_LikeNumText.text = m_likeNum.ToString();
		m_LikeState.State = ((!m_liked) ? 1 : 0);
		m_cardCommentUI.LocalLikeComment(m_commentID, m_liked);
	}
}
