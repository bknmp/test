using LightUI;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
[RequireComponent(typeof(Text))]
public class Copyable : MonoBehaviour
{
	public string m_RealText;

	public string m_Tips;

	private void Awake()
	{
		GetComponent<Button>().onClick.AddListener(OnCopy);
	}

	private void OnCopy()
	{
		ClipboardTool.CopyToSystemClipboard(string.IsNullOrEmpty(m_RealText) ? GetComponent<Text>().text : m_RealText);
		UILobby.Current.ShowTips((!string.IsNullOrEmpty(m_Tips)) ? m_Tips : Localization.TipsCopyOK);
	}
}
