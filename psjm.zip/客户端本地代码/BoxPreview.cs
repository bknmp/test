using GameMessages;
using LightUI;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BoxPreview
{
	public UIDataBinder m_Host;

	public UIStateItem m_State;

	public Button m_Unlocked;

	public UITimeText m_CostTime;

	public Button m_CostDiamondButton;

	public Text m_Price;

	public Button m_OpenButton;

	public UICooldownBar m_Cooldown;

	public GameObject m_AnotherUnlocking;

	public GameObject m_Ad;

	public Text m_AdText;

	public Button m_AdButton;

	public Text m_DiscountPrice;

	public Button m_BuyButton;

	public UIPage m_BoxOpenUI;

	protected BoxItemInfo m_BoxInfo;

	protected BoxInfo boxItemInfo;

	protected Coroutine m_Coroutine;

	protected int boxID;

	protected int boxPos;

	public void Bind(CommonDataCollection args)
	{
		boxID = args["boxID"];
		boxPos = args["boxPos"];
		StopUpdateDamond();
		m_BoxInfo = BoxUtility.GetBoxInfoByPosition(boxPos);
		boxItemInfo = LocalResources.BoxTable.Find(boxID);
		m_Host.EventProxy(m_Unlocked, "UnlockClicked");
		m_Host.EventProxy(m_OpenButton, "OpenBoxClicked");
		m_Host.EventProxy(m_CostDiamondButton, "OpenBoxCostDiamondClicked");
	}

	protected void ShowStateButtonDetail()
	{
		bool flag = BoxUtility.IsAnotherUnlocking(m_BoxInfo.boxPosition);
		m_State.State = ((!m_BoxInfo.CanUnlock) ? (m_BoxInfo.Unlocking ? 2 : 3) : ((!flag) ? 1 : 2));
		SetPrice(CalculatePrice(m_BoxInfo, boxItemInfo));
		if (m_BoxInfo.cdEndTimestamp < 0)
		{
			m_CostTime.SetTime(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f + (float)m_BoxInfo.cdEndTimestamp));
		}
		else
		{
			m_CostTime.SetTime(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f));
		}
		if (!flag)
		{
			m_Cooldown.gameObject.SetActive(value: true);
			m_AnotherUnlocking.SetActive(value: false);
			if (m_BoxInfo.LeftTime > 0)
			{
				m_Cooldown.SetTime((float)m_BoxInfo.LeftTime + 0.75f, Mathf.Max(1, m_BoxInfo.LeftTime), delegate
				{
					m_State.State = 3;
				});
			}
			m_Host.StartCoroutine(UpdateDamond(boxItemInfo.OpenCostDiamond));
		}
		else
		{
			m_Cooldown.gameObject.SetActive(value: false);
			m_AnotherUnlocking.SetActive(value: true);
		}
	}

	protected void OnAdClicked(int boxPos, bool unlock = false, AdScene adScene = AdScene.OPEN_BOX)
	{
		AdSDKManager.Inst.ShowAd(adScene, delegate
		{
			AdUtility.RequestRewards(adScene, boxPos, delegate
			{
				if (unlock)
				{
					BoxUtility.RequestUnlockBox(boxPos, delegate
					{
						BoxUtility.RefreshBoxList(delegate
						{
							GoBack();
						});
					});
				}
				else
				{
					BoxUtility.RefreshBoxList(delegate
					{
						GoBack();
					});
				}
			});
		});
	}

	private void StopUpdateDamond()
	{
		if (m_Coroutine != null)
		{
			m_Host.StopCoroutine(m_Coroutine);
		}
	}

	protected IEnumerator UpdateDamond(float costDiamond)
	{
		WaitForSeconds second = new WaitForSeconds(1f);
		while (m_BoxInfo.LeftTime > 0 || m_Host.gameObject.activeSelf)
		{
			int price = BoxUtility.OpenBoxCostTicket(m_BoxInfo.LeftTime, costDiamond);
			SetPrice(price);
			yield return second;
		}
	}

	protected int CalculatePrice(BoxItemInfo m_BoxInfo, BoxInfo boxItemInfo)
	{
		int num = 0;
		if (m_BoxInfo.LeftTime > 0)
		{
			return BoxUtility.OpenBoxCostTicket(m_BoxInfo.LeftTime, boxItemInfo.OpenCostDiamond);
		}
		if (m_BoxInfo.cdEndTimestamp < 0)
		{
			return BoxUtility.OpenBoxCostTicket(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f + (float)m_BoxInfo.cdEndTimestamp), boxItemInfo.OpenCostDiamond);
		}
		return BoxUtility.OpenBoxCostTicket(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f), boxItemInfo.OpenCostDiamond);
	}

	protected void SetPrice(int price)
	{
		int num = price;
		if (m_DiscountPrice != null)
		{
			int activityId = 0;
			bool flag = ActivityLobby.IsActicityAvailable(ActivityType.WEEKEND_DOUBLE, ActivityCollectionType.ANNIVERSART_ACTIVITY, out activityId);
			m_DiscountPrice.gameObject.SetActive(flag);
			m_Price.gameObject.SetActive(!flag);
			if (flag)
			{
				num = Mathf.CeilToInt((float)price * 0.5f);
				Text component = m_DiscountPrice.transform.GetChild(0).GetComponent<Text>();
				m_DiscountPrice.text = price.ToString();
				component.text = num.ToString();
			}
		}
		m_Price.text = num.ToString();
	}

	public void UnlockClicked()
	{
		UILobby.Current.ShowTips(Localization.TipsBeginUnlock);
		BoxUtility.RequestUnlockBox(m_BoxInfo.boxPosition, GoBack);
	}

	public void OpenBoxClicked()
	{
		if (m_BoxInfo != null)
		{
			BoxUtility.RequestOpenBoxByPosition(m_BoxInfo.boxPosition, GoToOpenBox);
		}
	}

	public void OpenBoxCostDiamondClicked()
	{
		int price = int.Parse(m_Price.text);
		ShopUtility.CheckMoneyEnough(CurrencyType.Tickets, price, delegate
		{
			BoxUtility.RequestOpenBoxByPosition(m_BoxInfo.boxPosition, GoToOpenBox);
		}, -1);
	}

	protected void GoToOpenBox(ItemInfo[] items)
	{
		GoBack();
		UILobby.Current.ShowUI(m_BoxOpenUI, BoxUtility.BoxOpenUIArgsWraper(m_BoxInfo.boxID, items));
	}

	protected void GoBack()
	{
		StopUpdateDamond();
		m_Host.GetComponent<UILobbyElement>().GoBack();
	}
}
