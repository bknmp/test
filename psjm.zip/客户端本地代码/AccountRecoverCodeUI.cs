using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AccountRecoverCodeUI : MonoBehaviour
{
	public InputField m_RecoverCode;

	public Button m_OK;

	public Button m_CloseBtn;

	private Delegates.IntCallback OnSuccess;

	private void Awake()
	{
		m_OK.onClick.AddListener(OnOKClick);
		m_CloseBtn.onClick.AddListener(CloseUI);
	}

	private void Init(Delegates.IntCallback onSuccess)
	{
		OnSuccess = onSuccess;
		m_RecoverCode.text = "";
	}

	private void OnOKClick()
	{
		if (m_RecoverCode.text.Length <= 0)
		{
			UILobby.Current.ShowTips(Localization.TipsInvalidRecoverCode);
			return;
		}
		HttpRequestInfoByRecoverCode httpRequestInfoByRecoverCode = new HttpRequestInfoByRecoverCode();
		httpRequestInfoByRecoverCode.recoverCode = m_RecoverCode.text;
		GameHttpManager.Inst.Send(httpRequestInfoByRecoverCode, delegate(BindAccountInfo res)
		{
			AccountSetPwdUI.ShowUI(res.roleID, res.playerName, "", m_RecoverCode.text, delegate(int roleID)
			{
				if (OnSuccess != null)
				{
					OnSuccess(roleID);
				}
			});
			CloseUI();
		});
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI(Delegates.IntCallback onSuccess)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountRecoverCodeUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountRecoverCodeUI>().Init(onSuccess);
	}
}
