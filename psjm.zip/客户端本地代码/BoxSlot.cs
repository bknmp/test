using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

public class BoxSlot
{
	public UIDataBinder m_Host;

	public MultiTargetGraphicButton m_Root;

	public UIStateItem m_SlotState;

	public Image m_Icon;

	public UICooldownBar m_Cooldown;

	public UIStateItem m_BoxState;

	public UIPopup m_BoxPreviewUI;

	public UIPage m_BoxOpenUI;

	public UIStateRawImage m_Mirror;

	public UIStateItem m_LockState;

	public UIPopup m_BoxUpgradePreviewUI;

	protected BoxItemInfo m_BoxInfo;

	protected int m_BoxPos;

	public void Bind(CommonDataCollection args)
	{
		m_BoxPos = args["boxPos"];
		if (m_BoxPos != -1)
		{
			m_SlotState.State = 1;
			m_BoxInfo = BoxUtility.GetBoxInfoByPosition(m_BoxPos);
		}
		else
		{
			m_SlotState.State = 0;
		}
	}

	public BoxInfo SetIconMirrorAndState(int boxID)
	{
		BoxInfo boxInfo = LocalResources.BoxTable.Find(boxID);
		if (boxInfo != null)
		{
			m_Icon.sprite = SpriteSource.Inst.Find(boxInfo.Icon);
			m_Mirror.State = boxInfo.Quality;
			m_BoxState.State = ((!m_BoxInfo.CanUnlock) ? (m_BoxInfo.Unlocking ? 1 : 2) : 0);
		}
		m_Host.EventProxy(m_Root, "OnOpenBoxClicked");
		return boxInfo;
	}

	public void OnOpenBoxClicked()
	{
		bool flag = LocalResources.BoxTable.Find(m_BoxInfo.boxID).OpenCostTime <= 8f;
		if (m_SlotState.State != 1)
		{
			return;
		}
		switch (m_BoxState.State)
		{
		case 0:
		case 1:
			if (flag && AdUtility.IsAdEnable(AdScene.UPGRADE_BOX))
			{
				BoxInfo upgradeBoxId = BoxUtility.GetUpgradeBoxId(m_BoxInfo.boxID);
				if (upgradeBoxId != null)
				{
					UILobby.Current.ShowUI(m_BoxUpgradePreviewUI, BoxUtility.BoxUpgradePreviewUIArgsWraper(m_BoxInfo.boxID, upgradeBoxId.Id, m_BoxPos));
				}
				else
				{
					UILobby.Current.ShowUI(m_BoxPreviewUI, BoxUtility.BoxPreviewUIArgsWraper(m_BoxInfo.boxID, m_BoxPos));
				}
			}
			else
			{
				UILobby.Current.ShowUI(m_BoxPreviewUI, BoxUtility.BoxPreviewUIArgsWraper(m_BoxInfo.boxID, m_BoxPos));
			}
			break;
		case 2:
			BoxUtility.RequestOpenBoxByPosition(m_BoxInfo.boxPosition, delegate(ItemInfo[] items)
			{
				UILobby.Current.ShowUI(m_BoxOpenUI, BoxUtility.BoxOpenUIArgsWraper(m_BoxInfo.boxID, items));
			});
			break;
		}
	}
}
