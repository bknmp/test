using GameMessages;
using UnityEngine;
using UnityEngine.UI;

public class BlueVipIcon : MonoBehaviour
{
	public PlatformID m_PlatformID;

	public Sprite m_OpenVipIcon;

	public Sprite m_RenewIcon;

	public Button m_Btn;

	private void Start()
	{
		if (m_PlatformID != 0)
		{
			base.gameObject.SetActive(m_PlatformID == LocalPlayerDatabase.LoginPlatformID);
		}
		updateMyBlueVipAwardState();
	}

	public void updateMyBlueVipAwardState()
	{
		if (LocalPlayerDatabase.PlayerInfo != null && LocalPlayerDatabase.PlayerInfo.publicInfo.vipInfo != null)
		{
			if (LocalPlayerDatabase.PlayerInfo.publicInfo.vipInfo.isVip || LocalPlayerDatabase.PlayerInfo.publicInfo.vipInfo.isSuperVip)
			{
				m_Btn.image.sprite = m_RenewIcon;
			}
			else
			{
				m_Btn.image.sprite = m_OpenVipIcon;
			}
		}
	}

	public void openBlueVipWebpage()
	{
		QQgameToDll.openBlueVip();
	}

	public void openBlueVipSpecialWebpage()
	{
		QQgameToDll.openBlueVipSpecial();
	}

	public void openYellowVipWebpage()
	{
		QQgameToDll.openYellowVip();
	}

	public void openYellowVipSpecialWebpage()
	{
		QQgameToDll.openYellowVipSpecial();
	}
}
