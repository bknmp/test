using LightUtility;
using ShapeFX;
using SimpleJson;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class CoinFightManager : RebornController
{
	public float m_DropCoinRatio;

	public int m_MinDropCoinNum;

	public string m_PropCoinPrefab;

	public Text m_PlayerCoinUIPrefab;

	public GameObject m_RebornEffect;

	public static CoinFightManager Inst;

	private SafeGameDictionary<int, int> m_GroupCoinNumDict = new SafeGameDictionary<int, int>();

	private SafeGameDictionary<string, int> m_PlayerCoinNumDict = new SafeGameDictionary<string, int>();

	private Dictionary<string, Text> m_PlayerCoinUIs = new Dictionary<string, Text>();

	private bool m_GameOver;

	private void Awake()
	{
		Inst = this;
	}

	protected new void Start()
	{
		base.Start();
		StartCoroutine(InitCoinUI());
		InGameStartup inst = InGameStartup.Inst;
		inst.OnCountDownStart = (UnityAction)Delegate.Combine(inst.OnCountDownStart, new UnityAction(AddRebornListener));
	}

	private void Update()
	{
		if (!m_GameOver && InGameScene.Inst.GameTime >= (float)GameRuntime.MapInfo.RageStartTime)
		{
			GameOver();
			m_GameOver = true;
		}
	}

	private IEnumerator InitCoinUI()
	{
		foreach (string player in GameRuntime.TotalThiefs)
		{
			PlayerController playerController = PlayerController.FindPlayer(player);
			while (playerController == null)
			{
				yield return Yielders.GetWaitForSeconds(0.1f);
				playerController = PlayerController.FindPlayer(player);
			}
			Text text = UnityEngine.Object.Instantiate(m_PlayerCoinUIPrefab, playerController.m_NameText.transform);
			m_PlayerCoinUIs.Add(playerController.UserId, text);
			text.text = "x" + m_PlayerCoinNumDict[playerController.UserId];
		}
	}

	protected override void OnPlayerDead(PlayerController player)
	{
		player.LocalExitVehicle();
		StartCoroutine(Reborn(player, GetRebornTime(player) - (InGameScene.Inst.GameTime - GetFinalDeadTime(player))));
		DropCoinOnDied(player);
	}

	protected override IEnumerator Reborn(PlayerController player, float delay)
	{
		ThiefController thief = player as ThiefController;
		if (thief.IsLocalPlayer)
		{
			InGameTipsUI.Inst.ShowRebornTips(delay);
		}
		yield return Yielders.GetWaitForSeconds(delay);
		bool waitRPC = false;
		while (thief.FinalDead && !GameRuntime.IsNormalGameOver && !waitRPC)
		{
			if (thief.m_PhotonView.isMine)
			{
				thief.RpcReborn(GetRebornPos(thief));
				waitRPC = true;
			}
			yield return Yielders.GetWaitForSeconds(0.1f);
		}
		FinishReborn(player);
	}

	protected override Vector3 GetRebornPos(PlayerController player)
	{
		return MathUtility.GetRandomPosition(InGameScene.Inst.m_SpawnAreaThief.GetComponentsInChildren<BoxCollider>());
	}

	private void AddRebornListener()
	{
		foreach (PlayerController player in PlayerController.AllPlayers)
		{
			ThiefController thiefController = player as ThiefController;
			if (thiefController != null)
			{
				ThiefController thiefController2 = thiefController;
				thiefController2.OnReborn = (Action)Delegate.Combine(thiefController2.OnReborn, (Action)delegate
				{
					OnPlayerReborn(player);
				});
			}
		}
	}

	private void OnPlayerReborn(PlayerController player)
	{
		StartCoroutine(ShowRebornEffect(player));
	}

	private IEnumerator ShowRebornEffect(PlayerController player)
	{
		if (player == PlayerController.Inst)
		{
			InGameStore.Inst.Disabled = true;
			InGameSkillUI.Inst.DisableAll = true;
		}
		player.m_PhysicsBody.isKinematic = true;
		player.m_PhysicsBody.Colliders.SetActive(value: false);
		player.m_Body.gameObject.SetActive(value: false);
		player.m_UI.gameObject.SetActive(value: false);
		player.BuffManager.DoCreateBuff(107, 1.5f, BuffCorrelation.PoliceRevive);
		GameObject gameObject = PoolSpawner.Spawn(m_RebornEffect);
		gameObject.GetComponent<ShFX_EffectHandler>().shakeCamera = (player == PlayerController.Inst);
		gameObject.transform.localPosition = player.transform.localPosition + m_RebornEffect.transform.localPosition;
		yield return Yielders.GetWaitForSeconds(1.5f);
		if (player == PlayerController.Inst)
		{
			InGameSkillUI.Inst.DisableAll = false;
			InGameStore.Inst.Disabled = false;
		}
		player.m_PhysicsBody.isKinematic = false;
		player.m_PhysicsBody.Colliders.SetActive(value: true);
		player.m_Body.gameObject.SetActive(value: true);
		player.m_UI.gameObject.SetActive(value: true);
	}

	public void AddCoin(string userId, int num)
	{
		SafeGameDictionary<int, int> groupCoinNumDict = m_GroupCoinNumDict;
		int groupID = IngameGroupUtility.GetGroupID(userId);
		groupCoinNumDict[groupID] += num;
		SafeGameDictionary<string, int> playerCoinNumDict = m_PlayerCoinNumDict;
		playerCoinNumDict[userId] += num;
		if (m_PlayerCoinUIs.ContainsKey(userId))
		{
			m_PlayerCoinUIs[userId].text = "x" + m_PlayerCoinNumDict[userId];
		}
		IngameCoinFightUI.Inst.UpdateTeamRank();
	}

	private void DropCoinOnDied(PlayerController player)
	{
		int num = Mathf.Min(Mathf.Max((int)((float)m_PlayerCoinNumDict[player.UserId] * m_DropCoinRatio), m_MinDropCoinNum), m_PlayerCoinNumDict[player.UserId]);
		AddCoin(player.UserId, -num);
		if (PhotonNetwork.isMasterClient)
		{
			for (int i = 0; i < num; i++)
			{
				PhotonNetwork.InstantiateSceneObject(m_PropCoinPrefab, BattleRoyaleManager.Inst.GetPropSpawnPos(player.transform.localPosition + new Vector3(0f, 0.5f, 0f)).FlattenY(), Quaternion.Euler(46f, -160f, 4f), 0, new object[2]
				{
					player.transform.position,
					1
				});
			}
		}
	}

	public int GetPlayerCoinNum(string userId)
	{
		return m_PlayerCoinNumDict[userId];
	}

	public int GetGroupCoinNum(int groupId)
	{
		return m_GroupCoinNumDict[groupId];
	}

	private void GameOver()
	{
		if (GameRuntime.WitnessMode)
		{
			InGameScene.Inst.BackToLobby();
		}
		else
		{
			InGameScene.Inst.InvokeGameOver();
		}
	}

	public int GetMyRank()
	{
		return GetGroupRank(IngameGroupUtility.MyGroupID);
	}

	public int GetGroupRank(int groupId)
	{
		int num = 1;
		int num2 = m_GroupCoinNumDict[groupId];
		foreach (KeyValuePair<int, int> item in m_GroupCoinNumDict)
		{
			if (item.Value > num2)
			{
				num++;
			}
		}
		return num;
	}

	private void OnReSyncWrite(object data)
	{
		JsonObject obj = data as JsonObject;
		obj["groupPointDict"] = JsonUtility.ToJson(new Serialization<int, int>(m_GroupCoinNumDict));
		obj["playerPointDict"] = JsonUtility.ToJson(new Serialization<string, int>(m_PlayerCoinNumDict));
	}

	private void OnReSyncRead(object data)
	{
		JsonObject jsonObject = data as JsonObject;
		m_GroupCoinNumDict.CopyFromDictionary(JsonUtility.FromJson<Serialization<int, int>>((string)jsonObject["groupPointDict"]).ToDictionary());
		m_PlayerCoinNumDict.CopyFromDictionary(JsonUtility.FromJson<Serialization<string, int>>((string)jsonObject["playerPointDict"]).ToDictionary());
		IngameCoinFightUI.Inst.UpdateTeamRank();
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (m_PlayerCoinUIs.ContainsKey(allPlayer.UserId))
			{
				m_PlayerCoinUIs[allPlayer.UserId].text = "x" + m_PlayerCoinNumDict[allPlayer.UserId];
			}
		}
	}
}
