using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using UnityEngine;

[TaskName("配置玩家AI")]
[TaskCategory("考驾照功能")]
public class ConfigPlayerAI : Action
{
	public RoleType roleType = RoleType.Thief;

	public int index = 1;

	public ExternalBehaviorTree aiAsset;

	public int aggressive;

	public int focus;

	public float viewRange = -1f;

	public override void OnStart()
	{
	}

	public override TaskStatus OnUpdate()
	{
		PlayerController player = GetPlayer(roleType, index);
		if (aiAsset == null)
		{
			player.AI.SetAIConfig(aiAsset);
			player.AI.StopMove();
		}
		else
		{
			player.AI.SetAIConfig(aiAsset);
			player.AI.SetPersonality(aggressive, focus);
			player.AI.ForceCardCoolDown();
			if (viewRange > 0f)
			{
				player.AI.m_ViewRange = viewRange;
			}
			ExamLevelInfo examLevelInfo = InGameScene.Inst.ExamLevelInfo;
			player.RpcAddCoin(InGameCoinRewardReason.ExamLevel, null, examLevelInfo.AICoins);
		}
		return TaskStatus.Success;
	}

	public static PlayerController GetPlayer(RoleType type, int index)
	{
		if (index == 0)
		{
			return PlayerController.Inst;
		}
		int num = 0;
		PlayerController playerController = null;
		for (int i = 0; i < PlayerController.AllPlayers.Count; i++)
		{
			playerController = PlayerController.AllPlayers[i];
			if (type == playerController.PlayingRole && !playerController.IsCurrentPlayer)
			{
				num++;
				if (num == index)
				{
					return playerController;
				}
			}
		}
		if (index > 0)
		{
			UnityEngine.Debug.LogError("配置有误！不存在该角色");
		}
		return null;
	}
}
