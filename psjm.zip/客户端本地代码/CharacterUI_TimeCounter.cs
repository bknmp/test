using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_TimeCounter
{
	public UIDataBinder m_Host;

	public Text m_TimeCounter;

	private int m_expiredTime;

	public void Bind(CommonDataCollection args)
	{
		m_expiredTime = (int)args[0]["time"].val;
		if (m_expiredTime > 0)
		{
			m_TimeCounter.fontSize = 26;
			if (m_expiredTime > UtcTimeStamp.Now)
			{
				m_TimeCounter.text = GetTimeLeftText(m_expiredTime - UtcTimeStamp.Now);
				return;
			}
			m_TimeCounter.text = "";
			m_expiredTime = 0;
			NewSkinPartTips.Inst.CheckOutOfDate();
			NewIngameEmotionTips.Inst.CheckOutOfDate();
			NewLightnessTips.Inst.CheckOutOfDate();
			UIDataEvents.Inst.InvokeEvent("OnPlayerInfoChanged");
		}
		else if (m_expiredTime < 0)
		{
			m_TimeCounter.fontSize = 20;
			m_TimeCounter.text = UITimeText.GetFormatTimeShort(m_expiredTime * -1, withAgo: false) + Localization.CountDownUntilBuyCharacter;
		}
		else
		{
			m_TimeCounter.fontSize = 26;
			m_TimeCounter.text = Localization.Forever;
		}
	}

	private string GetTimeLeftText(int seconds)
	{
		seconds = Mathf.Max(seconds, 60);
		return string.Format(Localization.TimeLeft, UITimeText.GetFormatTimeShort(seconds, withAgo: false));
	}
}
