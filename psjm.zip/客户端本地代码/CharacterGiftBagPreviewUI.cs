using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine.UI;

internal class CharacterGiftBagPreviewUI
{
	public UIDataBinder m_Host;

	public ToggleGroup m_ItemGroup;

	public Button m_BuyButton;

	public UIDataBinder m_Preview;

	public Image m_CharacterIcon;

	public Image m_SuitIcon;

	public InfoPanelController m_ItemInfo;

	public UITemplateInitiator m_Talents;

	public Text m_BagPrice;

	public Text m_BagCost;

	public Text m_ReturnTicket;

	public UIStateItem m_StateItem;

	public UIStateImage m_Good;

	public Text m_BuyBtnTitle;

	private List<DropItem> m_PreviewList = new List<DropItem>();

	private int m_LastSelect = -1;

	private string m_HaveChatacterFormat;

	private int m_CharacterId;

	private int m_SuitItemId;

	private int m_CurrentPrice;

	private int m_OriginalPrice;

	private int m_PackageID;

	private int m_ActivityID;

	private int m_PriceID;

	private CommonDataCollection m_Args;

	public static bool IsShowing;

	private bool m_HasCharacter;

	private ItemInfo[] m_ItemInfos;

	public void Bind(CommonDataCollection args)
	{
		m_Args = args;
		m_ActivityID = m_Args["activityID"];
		m_CharacterId = m_Args["characterID"];
		m_SuitItemId = m_Args["suitItemId"];
		m_CurrentPrice = m_Args["discountPrice"];
		m_OriginalPrice = m_Args["orgPrice"];
		m_PackageID = m_Args["packageID"];
		m_PriceID = m_Args["priceID"];
		SetToggleItems();
		SetCharacterBuyInfo();
		SetTalent();
		SetInfo();
		CurrencyHandle();
		m_Host.EventProxy(m_BuyButton, "OnBuyClick");
		Preview(ToggleGroupUtility.GetToggleGroupValue(m_ItemGroup));
		IsShowing = true;
		LobbyScene.Inst.ShowCampPanels(show: true);
	}

	private void OnDisable()
	{
		m_LastSelect = -1;
		IsShowing = false;
		LobbyScene.Inst.ShowCampPanels(show: false);
	}

	private void SetInfo()
	{
		m_BagPrice.text = m_OriginalPrice.ToString();
		m_BagCost.text = m_CurrentPrice.ToString();
		if (m_HaveChatacterFormat == null)
		{
			m_HaveChatacterFormat = m_ReturnTicket.text;
		}
		if ((int)m_Args["type"] == 1)
		{
			m_ReturnTicket.text = string.Format(m_HaveChatacterFormat, CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.characterCost);
			m_ReturnTicket.gameObject.SetActive(m_HasCharacter);
			return;
		}
		if (m_SuitItemId > 0)
		{
			m_ReturnTicket.text = string.Format(m_HaveChatacterFormat, CharacterDiscountUtility.ReturnTicketHandle(m_SuitItemId));
		}
		m_ReturnTicket.gameObject.SetActive(CharacterDiscountUtility.ReturnTicketHandle(m_SuitItemId) > 0f);
	}

	private void CurrencyHandle()
	{
		m_StateItem.State = ((m_PriceID == 99) ? 1 : 0);
		switch (m_PriceID)
		{
		case 2:
			m_Good.State = 2;
			break;
		case 4:
			m_Good.State = 1;
			break;
		}
	}

	private void SetToggleItems()
	{
		m_PreviewList.Clear();
		if (m_CharacterId > 0)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(m_CharacterId);
			m_PreviewList.Add(dropItem);
			m_CharacterIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		}
		else
		{
			DropItem dropItem2 = LocalResources.DropItemTable.Get(CharacterDiscountUtility.GetCollectionCharacterID(m_ActivityID, m_Args["collectionID"]));
			m_PreviewList.Add(dropItem2);
			m_CharacterIcon.sprite = SpriteSource.Inst.Find(dropItem2.Icon);
		}
		DropItem dropItem3 = LocalResources.DropItemTable.Get(m_SuitItemId);
		m_PreviewList.Add(dropItem3);
		m_SuitIcon.sprite = SpriteSource.Inst.Find(dropItem3.Icon);
		if (m_CharacterId == 200)
		{
			ToggleGroupUtility.SetValue(m_ItemGroup, 1);
			m_ItemGroup.transform.GetChild(0).gameObject.SetActive(value: false);
		}
		else
		{
			m_ItemGroup.transform.GetChild(0).gameObject.SetActive(value: true);
			ToggleGroupUtility.SetValue(m_ItemGroup, (m_Args["index"] == null) ? 1 : ((int)m_Args["index"]));
		}
		ToggleGroupUtility.SetListener(m_ItemGroup, delegate(bool isOn)
		{
			if (isOn)
			{
				int toggleGroupValue = ToggleGroupUtility.GetToggleGroupValue(m_ItemGroup);
				if (toggleGroupValue != m_LastSelect)
				{
					Preview(toggleGroupValue);
				}
			}
		});
	}

	private void SetCharacterBuyInfo()
	{
		if (m_PreviewList.Count > 0)
		{
			m_HasCharacter = DropItemUtility.IsOwnPermanent(m_PreviewList[0]);
			List<ItemInfo> list = new List<ItemInfo>();
			foreach (DropItem preview in m_PreviewList)
			{
				list.Add(new ItemInfo
				{
					itemID = preview.Id,
					itemCount = 1
				});
			}
			m_ItemInfos = list.ToArray();
		}
	}

	private void Preview(int idx)
	{
		idx = ((m_CharacterId == 200) ? 1 : idx);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["dropItem"].val = m_PreviewList[idx];
		commonDataCollection["IsPreviewInScene"] = true;
		commonDataCollection["StoreUICameraView"].val = m_Preview.GetComponent<StoreUICameraView>();
		m_Preview.Args = commonDataCollection;
		m_ItemInfo.SetItemInfo(m_PreviewList[idx]);
		m_LastSelect = idx;
	}

	private void SetTalent()
	{
		if (m_CharacterId.Equals(200))
		{
			m_Talents.gameObject.SetActive(value: false);
			return;
		}
		m_Talents.gameObject.SetActive(value: true);
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(m_PreviewList[0].TypeParam);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < characterInfo.TalentIDs.Length; i++)
		{
			commonDataCollection[i]["id"] = characterInfo.TalentIDs[i];
		}
		m_Talents.Args = commonDataCollection;
	}

	public void OnBuyClick()
	{
		if (m_PackageID == 0 && m_PreviewList.Count > 0)
		{
			EnsureBuyPopUp.EnsureBuyItems(m_ItemInfos, 99, CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.bagPrice / 10, CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.bagCost / 10, DoBuy);
		}
		else if (CharacterDiscountUtility.IsOwnCollection(m_ActivityID, m_Args["collectionID"]))
		{
			UILobby.Current.ShowTips(Localization.OwnedForever);
		}
		else
		{
			CharacterDiscountUtility.TryBuy(m_ActivityID, m_PackageID, null);
		}
	}

	private void DoBuy()
	{
		GoodsInfo goodsInfo = LocalResources.GoodsTable.Find(CharacterActivityPreviewUI.m_CharacterActivityGoodsInfo.bagGoodsId);
		PaymentUtility.DoPay(goodsInfo.Id, goodsInfo.ItemDesc, null, delegate(int res)
		{
			if (res > 0)
			{
				m_Host.GetComponent<UIPage>().GoBack();
				if (!m_HasCharacter)
				{
					CharacterFeatureUI.Inst.TryShowNewCharacter(m_PreviewList[0].TypeParam);
				}
				CommonRewardPopupUI.Show(PrefabSource.Inst.Load<CommonRewardPopupUI>("CommonRewardPopupUI")).AddItems(m_ItemInfos);
				CharacterActivityBuyUI.m_BuyCharacterBag = true;
			}
		}, SocialModuleType.RechargeGift);
	}
}
