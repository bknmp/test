using GameMessages;
using LightUI;
using UnityEngine.UI;

internal class CharacterActivityPreviewUI
{
	public UIDataBinder m_Host;

	public Button m_BuyCharater;

	public Button m_BuyBag;

	public Text m_CharaterCost;

	public Text m_CharaterPrice;

	public Text m_Cost;

	public Text m_Price;

	public UIPopup m_CharacterActivityBuyUI;

	public UIPage m_CharacterGiftBagPreviewUI;

	public Text m_Time;

	public Text m_DiscounText;

	public UIStateItem m_BuyCharaterState;

	private string m_TimeFormat;

	public static CharacterActivityGoodsInfo m_CharacterActivityGoodsInfo;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_BuyCharater, "OnBuyCharaterClick");
		m_Host.EventProxy(m_BuyBag, "OnBuyBagClick");
		Activity activity = args["Activity"].val as Activity;
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		if (m_CharacterActivityGoodsInfo == null)
		{
			GetCharacterActivityGoodsInfo(activity);
		}
		else
		{
			SetInfo();
		}
	}

	private void OnDestroy()
	{
		m_CharacterActivityGoodsInfo = null;
	}

	private void GetCharacterActivityGoodsInfo(Activity activity)
	{
		HttpRequestCharacterActivityGoods httpRequestCharacterActivityGoods = new HttpRequestCharacterActivityGoods();
		httpRequestCharacterActivityGoods.activityId = activity.activityId;
		GameHttpManager.Inst.Send(httpRequestCharacterActivityGoods, delegate(CharacterActivityGoodsInfo res)
		{
			m_CharacterActivityGoodsInfo = res;
			SetInfo();
		});
	}

	private void SetInfo()
	{
		bool flag = DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(m_CharacterActivityGoodsInfo.characterId));
		bool flag2 = DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(m_CharacterActivityGoodsInfo.suitItemId));
		m_BuyCharater.gameObject.SetActive(!(flag && flag2));
		m_BuyCharaterState.State = (flag ? 1 : 0);
		m_BuyBag.gameObject.SetActive(!flag || !flag2);
		m_CharaterCost.text = m_CharacterActivityGoodsInfo.characterCost.ToString();
		m_CharaterPrice.text = m_CharacterActivityGoodsInfo.characterPrice.ToString();
		m_Price.text = m_CharacterActivityGoodsInfo.bagPrice / 10 + Localization.RMB;
		m_Cost.text = m_CharacterActivityGoodsInfo.bagCost / 10 + Localization.RMB;
		m_DiscounText.text = m_CharacterActivityGoodsInfo.bagDiscount;
	}

	public void OnBuyCharaterClick()
	{
		if (DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(m_CharacterActivityGoodsInfo.characterId)))
		{
			UILobby.Current.ShowTips(Localization.OwnedForever);
			return;
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["type"] = 1;
		commonDataCollection["characterID"] = m_CharacterActivityGoodsInfo.characterId;
		commonDataCollection["suitItemId"] = m_CharacterActivityGoodsInfo.suitItemId;
		UILobby.Current.ShowUI(m_CharacterActivityBuyUI, commonDataCollection);
	}

	public void OnBuyBagClick()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["type"] = 1;
		commonDataCollection["characterID"] = m_CharacterActivityGoodsInfo.characterId;
		commonDataCollection["suitItemId"] = m_CharacterActivityGoodsInfo.suitItemId;
		commonDataCollection["discountPrice"] = m_CharacterActivityGoodsInfo.bagCost / 10;
		commonDataCollection["orgPrice"] = m_CharacterActivityGoodsInfo.bagPrice / 10;
		commonDataCollection["priceID"] = 99;
		UILobby.Current.ShowUI(m_CharacterGiftBagPreviewUI, commonDataCollection);
	}
}
