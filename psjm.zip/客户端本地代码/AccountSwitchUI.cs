using LightUI;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AccountSwitchUI : MonoBehaviour
{
	public AccountInfoController m_SelectedAccount;

	public UITemplateInitiator m_Content;

	public RectTransform m_HistoryList;

	public GameObject m_Empty;

	public Button m_ShowHistory;

	public Button m_CloseBtn;

	public Button m_Switch;

	public Button m_Others;

	public UIStateItem m_LoginState;

	public GameObject m_DeleteTips;

	public Button m_DoDelete;

	public Button m_Cancle;

	private int m_SelectIndex = -1;

	private int m_DoDeleteIndex = -1;

	private GameObject m_DoDeleteItem;

	private List<int> m_DeleteIndex = new List<int>();

	private bool m_IsShowHistory;

	public static List<LocalAccountInfo> AccountHistory
	{
		get;
		set;
	}

	private void Awake()
	{
		m_ShowHistory.onClick.AddListener(ShowHistory);
		m_Switch.onClick.AddListener(OnSwitchClick);
		m_Others.onClick.AddListener(OnOthersClick);
		m_CloseBtn.onClick.AddListener(CloseUI);
		m_DoDelete.onClick.AddListener(OnDeleteClick);
		m_Cancle.onClick.AddListener(OnCancleClick);
	}

	private void Init()
	{
		m_SelectIndex = -1;
		ShowOrHideHistory(show: false);
		SetHistoryList();
		if (AccountUtility.LoginAccountInfo == null)
		{
			m_SelectedAccount.gameObject.SetActive(value: false);
		}
		else
		{
			m_SelectedAccount.gameObject.SetActive(value: true);
			m_SelectedAccount.SetAccountInfo((int)AccountUtility.LoginAccountInfo.roleID, AccountUtility.LoginAccountInfo.accountName);
		}
		m_LoginState.State = 0;
		m_DeleteTips.SetActive(value: false);
	}

	private void ShowOrHideHistory(bool show)
	{
		m_HistoryList.gameObject.SetActive(show);
		m_ShowHistory.transform.localScale = (show ? new Vector3(1f, -1f, 1f) : Vector3.one);
		m_IsShowHistory = show;
	}

	private void SetHistoryList()
	{
		AccountHistory = new List<LocalAccountInfo>();
		if (LoginManager.HistoryAccountList != null)
		{
			AccountHistory.AddRange(LoginManager.HistoryAccountList);
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (AccountHistory.Count <= 0)
		{
			m_Empty.SetActive(value: true);
		}
		else
		{
			m_Empty.SetActive(value: false);
			for (int i = 0; i < AccountHistory.Count; i++)
			{
				commonDataCollection[i]["index"] = i;
				commonDataCollection[i]["onItemSelected"].val = new Action<int>(OnItemSelected);
				commonDataCollection[i]["onItemDelete"].val = new Action<int, GameObject>(OnItemDelete);
			}
		}
		m_Content.Args = commonDataCollection;
	}

	private void OnItemSelected(int index)
	{
		m_SelectIndex = index;
		m_SelectedAccount.gameObject.SetActive(value: true);
		m_SelectedAccount.SetAccountInfo(AccountHistory[index].roleId, AccountHistory[index].name);
		ShowOrHideHistory(show: false);
		m_LoginState.State = ((AccountUtility.LoginAccountInfo == null || AccountUtility.LoginAccountInfo.roleID != AccountHistory[index].roleId) ? 1 : 0);
	}

	private void OnItemDelete(int index, GameObject item)
	{
		m_DoDeleteIndex = index;
		m_DoDeleteItem = item;
		m_DeleteTips.SetActive(value: true);
	}

	private void OnDeleteClick()
	{
		if (m_DoDeleteIndex >= 0 && m_DoDeleteIndex < AccountHistory.Count && m_DoDeleteItem != null)
		{
			m_DoDeleteItem.SetActive(value: false);
			m_DeleteIndex.Add(m_DoDeleteIndex);
			if (m_DeleteIndex.Count >= AccountHistory.Count)
			{
				m_Empty.SetActive(value: true);
			}
		}
		OnCancleClick();
	}

	private void OnCancleClick()
	{
		m_DoDeleteIndex = -1;
		m_DoDeleteItem = null;
		m_DeleteTips.SetActive(value: false);
	}

	private void ShowHistory()
	{
		ShowOrHideHistory(!m_IsShowHistory);
	}

	private void OnSwitchClick()
	{
		int roleID = AccountHistory[m_SelectIndex].roleId;
		string loginKey = AccountHistory[m_SelectIndex].loginKey;
		CloseUI();
		if (m_SelectIndex >= 0 && (AccountUtility.LoginAccountInfo == null || roleID != AccountUtility.LoginAccountInfo.roleID))
		{
			AccountUtility.LoginByDmmAccount(roleID, "", loginKey, DoSwitchAccount, delegate(bool isNotSafe)
			{
				if (!isNotSafe)
				{
					AccountLoginUI.ShowUI(DoSwitchAccount, roleID);
				}
			});
		}
	}

	private void OnOthersClick()
	{
		CloseUI();
		AccountLoginUI.ShowUI(DoSwitchAccount);
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
		TryRefreshAccountCache();
	}

	private void DoSwitchAccount()
	{
		AccountUtility.DoSwitchAccount();
	}

	private void TryRefreshAccountCache()
	{
		if (m_DeleteIndex.Count >= 0)
		{
			m_DeleteIndex.Sort((int x, int y) => y - x);
			foreach (int item in m_DeleteIndex)
			{
				AccountHistory.RemoveAt(item);
			}
			LoginManager.HistoryAccountList = AccountHistory;
			m_DeleteIndex.Clear();
		}
	}

	public static void ShowUI()
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountSwitchUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountSwitchUI>().Init();
	}
}
