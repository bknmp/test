using LightUI;

internal class CardLotteryUI_CardPreviewUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Content;

	public void Bind(CommonDataCollection args)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < 2; i++)
		{
			CommonDataCollection commonDataCollection2 = new CommonDataCollection();
			commonDataCollection2["unlocked"] = (i == 0);
			commonDataCollection[i] = commonDataCollection2;
			if (CardUtility.AllCardsCanDropPiece())
			{
				break;
			}
		}
		m_Content.Args = commonDataCollection;
	}
}
