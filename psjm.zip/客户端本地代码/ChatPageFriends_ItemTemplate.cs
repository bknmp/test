using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChatPageFriends_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_PlayerName;

	public UIStateItem m_State;

	public Button m_ItemTemplate;

	public GameObject m_RedPoint;

	public Text m_Message;

	public PlayerIcon m_PlayerIcon;

	public UIStateImage m_Sex;

	public GameObject m_Selected;

	public UIDataBinder m_ChatViewPort;

	public GameObject m_Empty;

	private uint m_RoleID;

	private int m_OnlineState;

	private List<LocalChatMessage> m_Messages = new List<LocalChatMessage>();

	public static uint Selected;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_ItemTemplate, "OnSelectButtonClick");
		m_RoleID = args["roleID"];
		m_OnlineState = args["online"];
		if (m_OnlineState > 4)
		{
			m_State.State = 0;
		}
		else
		{
			m_State.State = m_OnlineState;
		}
		SocialUtility.GetFriendSocialInfo(m_RoleID, delegate(SocialInfo socialInfo)
		{
			if (socialInfo != null)
			{
				m_PlayerName.text = SocialUtility.GetShowNameOrRemark(socialInfo.headInfo.name, socialInfo.remark, bracket: false, MembershipUtility.IsInTime(0, socialInfo.headInfo.membershipInfo));
				m_PlayerIcon.SetTexture(socialInfo.headInfo.icon, socialInfo.headInfo.activeHeadBoxID);
				m_Sex.State = socialInfo.headInfo.sex;
				if (SocialChatManager.GetSession(m_RoleID) == null)
				{
					m_RedPoint.SetActive(value: false);
				}
				else
				{
					int num = (Selected != m_RoleID) ? SocialChatManager.GetUnreadCount(m_RoleID) : 0;
					if (num > 0)
					{
						m_RedPoint.SetActive(value: true);
						m_RedPoint.GetComponentInChildren<Text>().text = num.ToString();
					}
					else
					{
						m_RedPoint.SetActive(value: false);
					}
				}
				m_Messages.Clear();
				SocialChatManager.ReadMessages(SocialChatManager.GetChatSessionID(m_RoleID), m_Messages, 1, readed: false);
				m_Message.SetText((m_Messages.Count > 0) ? m_Messages[m_Messages.Count - 1].content : "");
				UpdateSelectState();
			}
			else
			{
				if (Selected == m_RoleID)
				{
					Selected = 0u;
				}
				m_Host.gameObject.SetActive(value: false);
			}
		});
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_RoleID)
		{
			Selected = m_RoleID;
			UIDataEvents.Inst.InvokeEvent("OnSelectFriendItemChanged");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool flag = m_RoleID == Selected;
			m_Selected.SetActive(flag);
			bool flag2 = flag;
			m_ItemTemplate.interactable = !flag2;
			ColorBlock colors = m_ItemTemplate.colors;
			Color disabledColor = colors.disabledColor;
			disabledColor.a = (flag2 ? 1f : 0f);
			colors.disabledColor = disabledColor;
			colors.fadeDuration = (flag2 ? 0f : 0.1f);
			m_ItemTemplate.colors = colors;
			if (flag)
			{
				ShowChatUI();
			}
		}
	}

	private void ShowChatUI()
	{
		if (ChatPanel.m_ChatUIInst == null || (uint)ChatPanel.m_ChatUIInst.Args["roleID"] != m_RoleID)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["session"] = SocialChatManager.GetChatSessionID(m_RoleID);
			commonDataCollection["roleID"] = m_RoleID;
			m_ChatViewPort.Args = commonDataCollection;
			m_ChatViewPort.gameObject.SetActive(value: false);
			m_ChatViewPort.gameObject.SetActive(value: true);
			m_Empty.SetActive(value: false);
			ChatPanel.m_ChatUIInst = m_ChatViewPort;
		}
	}
}
