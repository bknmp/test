using UnityEngine;
using UnityEngine.Events;

public abstract class BasePlayerController : SeparatePhysicsObject
{
	public PhotonView m_PhotonView;

	public Animator m_Animator;

	public UnityAction<float> OnDamageApplied;

	public UnityAction<float, DamageSourceType, BasePlayerController, float> OnDamageAppliedWithSource;

	public UnityAction OnDied;

	public UnityAction OnRevived;

	public UnityAction OnUpdatePhysicsSpeed;

	public UnityAction OnLocalJump;

	protected ProjectileLauncher m_ProjectileLauncher;

	public abstract Vector3 PhysicsSpeed
	{
		get;
		set;
	}

	public abstract Vector3 LinearVelocity
	{
		get;
	}

	public abstract BuffManager BuffManager
	{
		get;
	}

	public abstract PhotonView OnVehichle
	{
		get;
	}

	public abstract RoleType PlayingRole
	{
		get;
	}

	public abstract AIController AI
	{
		get;
	}

	public abstract TalentManager TalentManager
	{
		get;
	}

	public abstract SkillManager SkillManager
	{
		get;
	}

	public abstract ShapeShifter Shifter
	{
		get;
	}

	public abstract SeparatePhysicsBody PhysicsBody
	{
		get;
	}

	public abstract float SpeedForAnimator
	{
		get;
		set;
	}

	public abstract bool IsDying
	{
		get;
	}

	public virtual bool IsHurt => false;

	public abstract bool IsVisible
	{
		get;
	}

	public abstract int[] Cards
	{
		get;
		set;
	}

	public abstract int[] CardLevels
	{
		get;
		set;
	}

	public abstract int[] CardSkins
	{
		get;
		set;
	}

	public abstract int[] CardStyles
	{
		get;
		set;
	}

	public virtual bool InAir => false;

	public string UserId
	{
		get;
		set;
	}

	public int CharacterID
	{
		get;
		set;
	}

	public ProjectileLauncher ProjectileLauncher => m_ProjectileLauncher;

	public abstract void SetTargetDirection(Vector3 dirInWorldSpace, bool immediately = false);

	public virtual void SetTowardsDirection(Vector3 dirInWorldSpace, bool immediately = false)
	{
	}

	public virtual void OnPlayMovement()
	{
	}

	public virtual BaseCardSkinInfo GetBaseCardSkinInfo(int useCardID)
	{
		return null;
	}

	public virtual void UpdateMeshRendererGroup()
	{
	}
}
