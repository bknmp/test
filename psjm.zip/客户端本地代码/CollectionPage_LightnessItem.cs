using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CollectionPage_LightnessItem
{
	public UIDataBinder m_Host;

	public Text m_Personality;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public Image m_Icon;

	public GameObject m_Selected;

	public Text m_NameText;

	public RawImage m_Preview;

	public UIPointerBehaviour m_Input;

	public Button m_Button;

	public GameObject m_NotCollected;

	public GameObject m_NotHaveTips;

	public GameObject m_NotOwnedText;

	public GameObject m_ButtonGain;

	public UIStateItem m_LimitedEdition;

	public Text m_PassSeason;

	private string m_PersonalityFormat;

	private int m_ItemID;

	private DropItem m_ItemInfo;

	private bool m_Owned;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	private LightnessInfo m_Info;

	private HttpResponseCardConfigs m_PlayerCardConfigs;

	public static int Selected;

	public void Bind(CommonDataCollection args)
	{
		if (m_PersonalityFormat == null)
		{
			m_PersonalityFormat = m_Personality.text;
		}
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		m_PlayerCardConfigs = (HttpResponseCardConfigs)args["playerCardConfigs"].val;
		m_ItemID = args["itemID"];
		m_ItemInfo = LocalResources.DropItemTable.Find(m_ItemID);
		m_Info = LocalResources.LightnessInfo.Find(m_ItemInfo.TypeParam);
		int limitedEdition = m_Info.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeason.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		if (LightnessController.IsOwnForeverLightness(m_ItemInfo.TypeParam, m_PlayerInfo))
		{
			m_Owned = true;
			m_Personality.text = string.Format(m_PersonalityFormat, m_ItemInfo.Personality);
		}
		else
		{
			m_Owned = false;
		}
		m_Personality.gameObject.SetActive(m_Owned);
		m_NotCollected.SetActive(!m_Owned);
		m_NotOwnedText.SetActive(!m_Owned);
		m_Icon.sprite = SpriteSource.Inst.Find(m_ItemInfo.Icon);
		m_QualityBG.State = m_ItemInfo.Quality;
		m_Effect.State = m_ItemInfo.Quality;
		m_Effect.gameObject.SetActive(m_Owned);
		if (Selected == 0)
		{
			Selected = m_ItemID;
			ShowLightnessPreview();
		}
		UpdateSelectState();
		m_Host.EventProxy(m_Button, "OnSelectButtonClick");
	}

	public void OnSelectButtonClick()
	{
		if (Selected != m_ItemID)
		{
			Selected = m_ItemID;
			ShowLightnessPreview();
			UIDataEvents.Inst.InvokeEvent("OnLightnessSelectChange");
		}
	}

	private void UpdateSelectState()
	{
		if (m_Selected != null)
		{
			bool active = m_ItemID == Selected;
			m_Selected.SetActive(active);
		}
	}

	private void ShowLightnessPreview()
	{
		m_NameText.text = m_Info.Name;
		m_NameText.color = m_ItemInfo.QualityColor;
		m_NotHaveTips.SetActive(!m_Owned);
		int num = m_PlayerInfo.activeCharacterID[m_PlayerInfo.activeRoleType];
		PlayerCharacterInfo playerCharacterInfo = CharacterUtility.GetPlayerCharacterInfo(num, m_PlayerInfo);
		MatchPlayerData matchPlayerData = null;
		matchPlayerData = ((m_PlayerID != LocalPlayerDatabase.LoginInfo.roleID) ? CharacterUtility.GetPlayerData(m_PlayerID, playerCharacterInfo.characterID, m_PlayerInfo, m_PlayerCardConfigs) : CharacterUtility.GetPlayerData(num));
		LobbyScene.Inst.UpdateCampPanel((RoleType)m_PlayerInfo.activeRoleType, m_PlayerInfo.publicInfo.name, playerCharacterInfo, matchPlayerData, m_Preview, notRTMethod: false, m_Input, closeOppositeRole: true).LightnessController.ShowLight(m_Info.Prefab, m_Info.Id);
	}
}
