using UnityEngine;
using UnityEngine.EventSystems;

public class CardLotteryTipsController : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
	public GameObject m_Container;

	private int m_ShowCounter;

	public void OnPointerEnter(PointerEventData eventData)
	{
		IncrementShowCounter();
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		DecrementShowCounter();
	}

	public void OnPointerDown(PointerEventData eventData)
	{
		IncrementShowCounter();
	}

	public void OnPointerUp(PointerEventData eventData)
	{
		DecrementShowCounter();
	}

	private void OnApplicationPause(bool pause)
	{
		DecrementShowCounter();
	}

	private void OnDisable()
	{
		DecrementShowCounter();
	}

	private void OnDestroy()
	{
		DecrementShowCounter();
	}

	private void IncrementShowCounter()
	{
		m_ShowCounter++;
		if (m_ShowCounter == 1)
		{
			m_Container.SetActive(value: true);
		}
	}

	private void DecrementShowCounter()
	{
		if (m_ShowCounter > 0)
		{
			m_ShowCounter--;
			if (m_ShowCounter == 0)
			{
				m_Container.SetActive(value: false);
			}
		}
	}
}
