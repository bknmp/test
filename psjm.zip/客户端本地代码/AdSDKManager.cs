using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class AdSDKManager : MonoBehaviour
{
	public static bool DisableIOSAdapter01;

	public static bool DisableIOSAdapter02;

	public static int DefaultAdapter2Ratio;

	public bool DEBUG_MODEL;

	private UnityAction m_OnRewardSuccess;

	private AdScene m_CurAdScene;

	private bool m_Showing;

	private bool m_Clicked;

	private bool m_Initialized;

	private int m_LastFailureTime;

	private BaseAdAdapter m_AdAdapter;

	private static AdSDKManager instance;

	private List<string> mLines = new List<string>();

	public static AdSDKManager Inst
	{
		get
		{
			if (instance == null)
			{
				GameObject gameObject = new GameObject("AdSDKManager");
				instance = gameObject.AddComponent<AdSDKManager>();
				ResManager.DontDestroyOnLoad(gameObject);
			}
			return instance;
		}
	}

	public AdType AdType
	{
		get
		{
			if (m_AdAdapter != null)
			{
				return m_AdAdapter.AdType;
			}
			return AdType.None;
		}
	}

	public bool AdEnabled => AdType != AdType.None;

	public static event UnityAction m_BeforeShowAd;

	private void OnApplicationPause(bool pause)
	{
		Log("AdSDKManager OnApplicationPause " + pause.ToString());
		if (!pause)
		{
			OnAdClosed();
		}
	}

	private void OnDestroy()
	{
		if (instance == this)
		{
			instance = null;
		}
	}

	public void Initialize()
	{
		if (!m_Initialized)
		{
			Log("Initialize");
			m_AdAdapter = CreateAdAdapter();
			m_AdAdapter.Initialize();
			m_AdAdapter.SetDebug(DEBUG_MODEL);
			Invoke("DelayFetchAll", 3f);
			m_Initialized = true;
		}
	}

	public static void TryReportEvent(AdScene adScene, AdStatistics status)
	{
		int num = (int)adScene;
		string param = num.ToString();
		num = (int)status;
		LocalPlayerDatabase.ReportEvent(GameMessages.Event.AD_STATISTICS, param, num.ToString());
	}

	private void DelayFetchAll()
	{
		FetchAd(AdScene.CARD_DRAW);
	}

	public void ShowTestSuite()
	{
		if (DEBUG_MODEL && m_AdAdapter != null)
		{
			m_AdAdapter.ShowTestSuit();
		}
	}

	private void Release()
	{
		if (m_AdAdapter != null)
		{
			m_AdAdapter.Release();
		}
	}

	public void SetCurrentUserInfo()
	{
	}

	private bool IsAdAvailable(AdScene scene)
	{
		if (m_AdAdapter != null)
		{
			return m_AdAdapter.IsAvailable(scene);
		}
		return false;
	}

	private void FetchAd(AdScene scene)
	{
		if (m_AdAdapter != null)
		{
			m_AdAdapter.Fetch(scene);
		}
	}

	public void ShowAd(AdScene scene, UnityAction onSuccess)
	{
		if (AdUtility.IsSkipAd(scene))
		{
			onSuccess();
			TryReportEvent(scene, AdStatistics.SkipAd);
			return;
		}
		m_CurAdScene = scene;
		if (IsAdAvailable(scene))
		{
			AdSDKManager.m_BeforeShowAd?.Invoke();
			ResumeBGM(pause: true);
			m_Showing = true;
			m_Clicked = false;
			m_OnRewardSuccess = onSuccess;
			m_AdAdapter.SetRoleID(LocalPlayerDatabase.LoginInfo.roleID);
			m_AdAdapter.Show(scene);
			TryReportEvent(scene, AdStatistics.Watch);
		}
		else
		{
			TipsNoAd();
			if (UtcTimeStamp.Now - m_LastFailureTime > 10)
			{
				m_LastFailureTime = UtcTimeStamp.Now;
				m_AdAdapter.Fetch(m_CurAdScene);
			}
		}
	}

	private void OnAdShowComplete()
	{
		CancelInvoke("OnAdShowIncomplete");
		Log("OnShowComplete");
		Loom.QueueOnMainThread(delegate
		{
			if (m_OnRewardSuccess != null)
			{
				m_OnRewardSuccess();
				m_OnRewardSuccess = null;
				TryReportEvent(m_CurAdScene, AdStatistics.Complete);
			}
		});
	}

	private void OnAdShowIncomplete()
	{
		m_OnRewardSuccess = null;
		Log("OnShowIncomplete");
		Loom.QueueOnMainThread(delegate
		{
			UILobby.Current.ShowMessageBoxOK(Localization.TipsAdPlayingIncomplete, Localization.MsgBoxOK, Localization.MsgBoxTitle, null, showCloseButton: false);
		});
	}

	private void OnAdSkip()
	{
		OnAdShowIncomplete();
	}

	private void OnAdShowIncomplete(float delay)
	{
		Log("OnShowIncomplete delay " + delay);
		CancelInvoke("OnAdShowIncomplete");
		Invoke("OnAdShowIncomplete", delay);
	}

	private void OnAdClosed()
	{
		Log("OnAdClosed");
		if (m_Showing)
		{
			m_Showing = false;
			Release();
			FetchAd(m_CurAdScene);
			Loom.QueueOnMainThread(delegate
			{
				ResumeBGM(pause: false);
			});
		}
	}

	private void OnAdClicked()
	{
		Log("OnAdClicked");
		if (!m_Clicked)
		{
			m_Clicked = true;
			TryReportEvent(m_CurAdScene, AdStatistics.Click);
		}
	}

	private void OnLoadAdFailure()
	{
		if (m_AdAdapter != null)
		{
			m_AdAdapter.OnLoadAdFailure();
		}
	}

	private void OnNoAd()
	{
		Log("OnNoAd");
		TipsNoAd();
	}

	private void OnCustomLog(string strlog)
	{
		Log(strlog);
	}

	public void TipsNoAd()
	{
		if (!GameRuntime.ActiveSceneName.Equals("Loading"))
		{
			UILobby.Current.ShowTips(Localization.TipsNoAd);
		}
	}

	private void ResumeBGM(bool pause)
	{
		if (GameRuntime.ActiveSceneName.Equals("Lobby") && LobbyBGMCtrl.Inst != null)
		{
			LobbyBGMCtrl.Inst.SetPlay(!pause && GameSettings.Inst.MusicEnable);
		}
	}

	public void Log(params object[] objs)
	{
		if (!DEBUG_MODEL)
		{
			return;
		}
		string text = "";
		for (int i = 0; i < objs.Length; i++)
		{
			text = ((i != 0) ? (text + ", " + objs[i].ToString()) : (text + objs[i].ToString()));
		}
		UnityEngine.Debug.Log(text);
		if (Application.isPlaying)
		{
			if (mLines.Count > 35)
			{
				mLines.RemoveAt(0);
			}
			mLines.Add("[AD_SDK_Unity]  " + Time.time + " " + text);
		}
	}

	private BaseAdAdapter CreateAdAdapter()
	{
		BaseAdAdapter baseAdAdapter = null;
		switch (AndroidSDKAdapter.AndroidChannel)
		{
		case AndroidChannel.VIVO:
			baseAdAdapter = new VivoAdAdapter();
			break;
		case AndroidChannel.HUAWEI:
			baseAdAdapter = new HuaweiAdAdapter();
			break;
		case AndroidChannel.OPPO:
			baseAdAdapter = new OppoAdAdapter();
			break;
		case AndroidChannel.M4399:
			baseAdAdapter = new M4399AdAdapter();
			break;
		case AndroidChannel.TAPTAP:
			baseAdAdapter = new TapTapAdAdapter();
			break;
		case AndroidChannel.MOMOYU:
			baseAdAdapter = new MomoyuAdAdapter();
			break;
		case AndroidChannel.HYKB:
			baseAdAdapter = new HYKBAdAdapter();
			break;
		case AndroidChannel.TMGP:
			baseAdAdapter = new TMGPAdAdapter();
			break;
		case AndroidChannel.QuickSDK:
		{
			int platformID = AndroidSDKAdapter.Adapter.PlatformID;
			baseAdAdapter = ((platformID != 47 && platformID != 50) ? ((BaseAdAdapter)new EmptyAdAdapter()) : ((BaseAdAdapter)new M233AdAdapter()));
			break;
		}
		default:
			baseAdAdapter = new EmptyAdAdapter();
			break;
		}
		if (baseAdAdapter is IOSAdAdapter)
		{
			((IOSAdAdapter)baseAdAdapter).DisableAdapter01 = DisableIOSAdapter01;
			((IOSAdAdapter)baseAdAdapter).DisableAdapter02 = DisableIOSAdapter02;
			((IOSAdAdapter)baseAdAdapter).DefaultAdapter2Ratio = DefaultAdapter2Ratio;
			if (DisableIOSAdapter01 && DisableIOSAdapter02)
			{
				baseAdAdapter = new EmptyAdAdapter();
			}
		}
		return baseAdAdapter;
	}
}
