namespace LightNet
{
	public struct BinaryPacket
	{
		public ushort protocalID;

		public byte[] data;

		public int Length;
	}
}
