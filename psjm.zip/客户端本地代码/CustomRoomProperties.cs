using ExitGames.Client.Photon;
using UnityEngine;

public static class CustomRoomProperties
{
	public static readonly string[] LobbyPropertiesListed = new string[7]
	{
		"owner",
		"thiefNum",
		"policeNum",
		"maxThiefNum",
		"maxPoliceNum",
		"map",
		"gradeLimit"
	};

	public const string Owner = "owner";

	public const string ThiefNum = "thiefNum";

	public const string PoliceNum = "policeNum";

	public const string MaxThiefNum = "maxThiefNum";

	public const string MaxPoliceNum = "maxPoliceNum";

	public const string Map = "map";

	public const string GradeLimit = "gradeLimit";

	public const string TeamID = "teamID";

	public static int GetPropertyInt(this Hashtable hashTable, string key)
	{
		if (hashTable == null || hashTable.Count == 0)
		{
			UnityEngine.Debug.LogError("hashTable is empty ," + key);
			return -1;
		}
		if (!hashTable.ContainsKey(key))
		{
			UnityEngine.Debug.LogError("hashTable is not contains this key : " + key);
			return -2;
		}
		int.TryParse(hashTable[key].ToString(), out int result);
		return result;
	}
}
