using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

internal class CharacterUI_PageSkinPart
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_PageSkinPart;

	public UIDataScrollView m_PageSuite;

	public UIStateItem m_SkinPartState;

	public static Delegates.VoidCallback OnCancelPreview;

	private int m_lastTabIndex = -1;

	private int m_lastCharacterSelected;

	public void Bind(CommonDataCollection args)
	{
		TryClearRedPoint();
		if (args["tabIndex"] != null)
		{
			m_lastTabIndex = args["tabIndex"];
		}
		OnTabChange();
		m_lastCharacterSelected = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		OnCancelPreview = delegate
		{
			WardrobeUI_SuiteItemTemplate.Selected = 0;
			SetDefaultSelectedSkinPart();
			UIDataEvents.Inst.InvokeEvent("OnSelectSkinPartChanged");
		};
	}

	private void OnDisable()
	{
		TryClearRedPoint();
		m_lastTabIndex = -1;
	}

	private void OnTabChange()
	{
		SkinPartType lastTabIndex = (SkinPartType)m_lastTabIndex;
		if (lastTabIndex == SkinPartType.PartCount)
		{
			WardrobeUI_SuiteItemTemplate.Selected = 0;
			m_PageSkinPart.gameObject.SetActive(value: false);
			m_PageSuite.gameObject.SetActive(value: true);
			m_PageSuite.ResetContentPosition();
			List<ShopSuiteInfo> list = new List<ShopSuiteInfo>();
			List<int> list2 = new List<int>();
			List<ShopSuiteInfo> list3 = new List<ShopSuiteInfo>();
			List<int> list4 = new List<int>();
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			foreach (KeyValuePair<string, List<int>> suite in ShopSuiteUtility.CharacterSuites[CharacterUI_SelectCharacterItemTemplate.globalSelected].suites)
			{
				ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suite.Value[0]);
				bool flag = true;
				int num = 0;
				int[] shopItemIDs = shopSuiteInfo.ShopItemIDs;
				foreach (int id in shopItemIDs)
				{
					DropItem dropItem = LocalResources.DropItemTable.Get(id);
					int expiredTime = 0;
					if (!CharacterUtility.OwnSkinPart(dropItem.TypeParam, out expiredTime, out int _) || (expiredTime > 0 && (expiredTime <= 0 || UtcTimeStamp.Now >= expiredTime)))
					{
						flag = false;
						break;
					}
					int num2 = Mathf.Abs(expiredTime);
					int num3 = Mathf.Abs(num);
					if (num == 0 || num2 < num3)
					{
						num = expiredTime;
					}
				}
				if (flag)
				{
					if (NewSkinPartTips.Inst.IsSuiteNew(shopSuiteInfo.Name, CharacterUI_SelectCharacterItemTemplate.globalSelected))
					{
						list3.Add(shopSuiteInfo);
						list4.Add(num);
					}
					else
					{
						list.Add(shopSuiteInfo);
						list2.Add(num);
					}
				}
			}
			for (int j = 0; j < list3.Count; j++)
			{
				int arraySize = commonDataCollection.ArraySize;
				commonDataCollection[arraySize]["suiteInfo"].val = list3[j];
				commonDataCollection[arraySize]["expiredTime"].val = list4[j];
			}
			for (int k = 0; k < list.Count; k++)
			{
				int arraySize2 = commonDataCollection.ArraySize;
				commonDataCollection[arraySize2]["suiteInfo"].val = list[k];
				commonDataCollection[arraySize2]["expiredTime"].val = list2[k];
			}
			m_PageSuite.m_TemplateInitiator.Args = commonDataCollection;
			return;
		}
		SetDefaultSelectedSkinPart();
		m_PageSkinPart.gameObject.SetActive(value: true);
		m_PageSuite.gameObject.SetActive(value: false);
		m_PageSkinPart.ResetContentPosition();
		ShopUtility.SkinPartGoodsDictKey skinPartGoodsDictKey = new ShopUtility.SkinPartGoodsDictKey();
		skinPartGoodsDictKey.characterID = CharacterUI_SelectCharacterItemTemplate.globalSelected;
		skinPartGoodsDictKey.type = lastTabIndex;
		int num4 = 0;
		List<int> list5 = new List<int>();
		List<string> list6 = new List<string>();
		List<int> list7 = new List<int>();
		List<string> list8 = new List<string>();
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		if (!ShopUtility.SkinPartGoodsDict.ContainsKey(JsonUtility.ToJson(skinPartGoodsDictKey)))
		{
			m_SkinPartState.State = 0;
			return;
		}
		m_SkinPartState.State = 2;
		foreach (KeyValuePair<int, ShopUtility.ShopGoodsData> good in ShopUtility.SkinPartGoodsDict[JsonUtility.ToJson(skinPartGoodsDictKey)].goods)
		{
			if (CharacterUtility.OwnSkinPart(good.Key, out int expiredTime2, out int _) && (expiredTime2 <= 0 || (expiredTime2 > 0 && UtcTimeStamp.Now < expiredTime2)))
			{
				if (NewSkinPartTips.Inst.IsNew(good.Key))
				{
					list7.Add(good.Key);
					list8.Add(JsonUtility.ToJson(good.Value));
				}
				else
				{
					list5.Add(good.Key);
					list6.Add(JsonUtility.ToJson(good.Value));
				}
			}
		}
		for (int l = 0; l < list7.Count; l++)
		{
			commonDataCollection2[num4]["skinPartID"] = list7[l];
			commonDataCollection2[num4]["goodsData"] = list8[l];
			num4++;
		}
		for (int m = 0; m < list5.Count; m++)
		{
			commonDataCollection2[num4]["skinPartID"] = list5[m];
			commonDataCollection2[num4]["goodsData"] = list6[m];
			num4++;
		}
		if (num4 == 0)
		{
			m_SkinPartState.State = 1;
		}
		else
		{
			m_PageSkinPart.m_TemplateInitiator.Args = commonDataCollection2;
		}
	}

	private void SetDefaultSelectedSkinPart()
	{
		CharacterUtility.FindSkinPart(CharacterUtility.GetOwnedCharacterInfo(CharacterUI_SelectCharacterItemTemplate.globalSelected).currentSkinInfo, (SkinPartType)m_lastTabIndex, out int partID, out int _);
		CharacterUI_SkinPartItemTemplate.globalSelected = partID;
	}

	private void TryClearRedPoint()
	{
		if (m_lastTabIndex >= 0)
		{
			SkinPartType lastTabIndex = (SkinPartType)m_lastTabIndex;
			if (lastTabIndex == SkinPartType.PartCount)
			{
				NewSkinPartTips.Inst.ClearSuiteRedPoint(m_lastCharacterSelected);
			}
			else
			{
				NewSkinPartTips.Inst.ClearRedPointByCharacterAndType(m_lastCharacterSelected, lastTabIndex);
			}
			UIDataEvents.Inst.InvokeEvent("OnWardrobeUIRedPointChanged");
		}
	}
}
