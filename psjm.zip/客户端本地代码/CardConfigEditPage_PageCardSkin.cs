using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_PageCardSkin
{
	public static int m_LastSelectedStyleID;

	public UIDataBinder m_Host;

	public UITemplateInitiator m_Content;

	public Button m_LeftBtn;

	public Button m_RightBtn;

	public UIStateItem m_States;

	public UIDataBinder m_Time;

	public CanvasGroup m_StatesCanvasGroup;

	public Button m_UnlockBtn;

	public Button m_UseBtn;

	public Text m_UnlockTips;

	public GameObject m_LeftBtnRedPoint_Skin;

	public GameObject m_RightBtnRedPoint_Skin;

	public GameObject m_LeftBtnRedPoint_Style;

	public GameObject m_RightBtnRedPoint_Style;

	public CardSkinEditUI m_CardSkinEditUI;

	public Text m_SkinName;

	public GameObject m_LockIcon;

	public UITemplateInitiator m_PreviewTemplate;

	public RawImage m_RawImage;

	public CardSkinPreviewScene m_CardSkinScene;

	public UIPage m_CardSkinRewardUI;

	public GameObject m_OwnedLoginAwardTips;

	public Text m_OtherGainTypeTips;

	public Text m_Desc;

	public Image m_Icon;

	public UITemplateInitiator m_WeaponIndexItems;

	public Button m_StyleBtn;

	public GameObject m_StyleBtnRedPoint;

	public GameObject m_Style;

	public UITemplateInitiator m_StyleItems;

	private RenderTexture m_PreviewTexture;

	private string m_UnlockTipsFormat;

	private string m_DescFormat;

	private int m_cardID;

	private int m_cardLevel;

	private bool m_isLocalPlayer;

	private CommonDataCollection m_skinArgs = new CommonDataCollection();

	private CommonDataCollection m_weaponCardSkinArgs = new CommonDataCollection();

	private List<int> m_skinIDs = new List<int>();

	private bool m_Scrolling;

	private int m_lastCardId;

	private bool m_lastIsLocalPlayer;

	private bool m_IsFromStore;

	private bool m_IsFromShowUI;

	private int m_LastSelectedSkinID;

	public static int WeaponCardSkinIndex;

	private int[] CardSkinLevelSetting = new int[5]
	{
		0,
		4,
		7,
		10,
		13
	};

	public static bool HadSetCardSkinDefaultSelect
	{
		get;
		set;
	}

	public void Bind(CommonDataCollection args)
	{
		UpdatePreviewPanel();
		if (string.IsNullOrEmpty(m_UnlockTipsFormat))
		{
			m_UnlockTipsFormat = m_UnlockTips.text;
			m_DescFormat = m_Desc.text;
		}
		m_cardID = args["cardID"];
		m_isLocalPlayer = args["isLocalPlayer"];
		m_cardLevel = args["cardLevel"];
		m_IsFromStore = args["IsFromStore"];
		m_IsFromShowUI = args["IsFromShowUI"];
		if (m_lastCardId != m_cardID || m_lastIsLocalPlayer != m_isLocalPlayer || m_IsFromStore)
		{
			m_Style.SetActive(value: false);
			m_skinArgs.Clear();
			m_skinIDs.Clear();
			foreach (int item in ShopUtility.CardSkinDict[m_cardID])
			{
				CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(item);
				if (CardUtility.OwnCardSkin(item, out int _) || ((cardSkinInfo.SellStartTime == 0 || cardSkinInfo.SellStartTime <= UtcTimeStamp.Now) && (cardSkinInfo.SellEndTime == 0 || cardSkinInfo.SellEndTime >= UtcTimeStamp.Now)))
				{
					m_skinIDs.Add(item);
				}
			}
			m_skinIDs.Sort((int a, int b) => LocalResources.CardSkinTable.Get(b).Rank.CompareTo(LocalResources.CardSkinTable.Get(a).Rank));
			int num = 0;
			foreach (int skinID in m_skinIDs)
			{
				CardSkinInfo cardSkinInfo2 = LocalResources.CardSkinTable.Get(skinID);
				if (CardSkinLevelSetting.Contains(cardSkinInfo2.UnlockLevel))
				{
					num++;
				}
			}
			if (num < CardSkinLevelSetting.Length)
			{
				m_skinIDs.Add(-2);
			}
			WeaponCardSkinIndex = 0;
			m_weaponCardSkinArgs.Clear();
			if (LocalResources.InGameStoreTable.Get(m_cardID).Type == InGameStoreType.Weapon)
			{
				List<WeaponInfo> list = LocalResources.WeaponTable.FindAll((WeaponInfo x) => x.BaseWeaponID == m_cardID);
				for (int i = 0; i < list.Count; i++)
				{
					m_weaponCardSkinArgs[i]["index"] = i;
					m_weaponCardSkinArgs[i]["cardSkinEditUI"].val = m_CardSkinEditUI;
				}
				m_WeaponIndexItems.Args = m_weaponCardSkinArgs;
			}
			m_WeaponIndexItems.gameObject.SetActive(m_weaponCardSkinArgs.ArraySize > 1);
			for (int j = 0; j < m_skinIDs.Count; j++)
			{
				int arraySize = m_skinArgs.ArraySize;
				m_skinArgs[arraySize]["cardID"] = m_cardID;
				m_skinArgs[arraySize]["cardSkinID"] = m_skinIDs[j];
				m_skinArgs[arraySize]["cardSkinPage"].val = this;
				m_skinArgs[arraySize]["isLocalplayer"] = m_isLocalPlayer;
				m_skinArgs[arraySize]["cardSkinInfo"].val = LocalResources.CardSkinTable.Get(m_skinIDs[j]);
				m_skinArgs[arraySize]["page"].val = this;
				m_skinArgs[arraySize]["index"] = j;
			}
			m_Content.Args = m_skinArgs;
			m_PreviewTemplate.Args = m_skinArgs;
		}
		else
		{
			UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
		}
		m_lastCardId = m_cardID;
		m_lastIsLocalPlayer = m_isLocalPlayer;
		CardSkinInfo cardSkinInfo3 = LocalResources.CardSkinTable.Get(CardConfigEditPage_CardSkinItemTemplate.globalSelected);
		if ((!HadSetCardSkinDefaultSelect && !m_IsFromStore) || (cardSkinInfo3 != null && cardSkinInfo3.CardID != m_cardID))
		{
			SetCardSkinDefaultSelect(m_isLocalPlayer, m_cardID);
		}
		ItemScroll(tween: false);
		m_Host.EventProxy(m_LeftBtn, "OnClickLeftBtn");
		m_Host.EventProxy(m_RightBtn, "OnClickRightBtn");
		m_Host.EventProxy(m_UnlockBtn, "OnClickUnlock");
		m_Host.EventProxy(m_UseBtn, "OnClickUse");
		m_Host.EventProxy(m_StyleBtn, "OnClickStyle");
	}

	private void SetCardSkinDefaultSelect(bool isLocalPlayer, int cardID)
	{
		if (isLocalPlayer)
		{
			CardConfigEditPage_CardSkinItemTemplate.globalSelected = CardUtility.CurCardSkin(cardID);
		}
		else
		{
			CardConfigEditPage_CardSkinItemTemplate.globalSelected = LocalResources.InGameStoreTable.Get(cardID).DefaultSkinID;
		}
		HadSetCardSkinDefaultSelect = true;
	}

	public void UpdateButton()
	{
		int num = ArrayUtility.IndexOf(m_skinIDs.ToArray(), CardConfigEditPage_CardSkinItemTemplate.globalSelected);
		m_LeftBtn.gameObject.SetActive(num != 0);
		m_RightBtn.gameObject.SetActive(num != m_skinIDs.Count - 1);
		UpdateLeftRightRedPoint(num);
	}

	private void UpdateLeftRightRedPoint(int curIndex)
	{
		m_LeftBtnRedPoint_Skin.SetActive(value: false);
		m_RightBtnRedPoint_Skin.SetActive(value: false);
		m_LeftBtnRedPoint_Style.SetActive(value: false);
		m_RightBtnRedPoint_Style.SetActive(value: false);
		if (!m_isLocalPlayer)
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < curIndex; i++)
		{
			int num = m_skinIDs[i];
			if (NewCardSkinTips.Inst.IsNew(num) || NewCardSkinTips.IsCardSkinCanUnlock(num, m_cardLevel))
			{
				m_LeftBtnRedPoint_Skin.SetActive(value: true);
				flag = true;
				break;
			}
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(num);
			if (cardSkinInfo != null && cardSkinInfo.Styles != null)
			{
				int[] styles = cardSkinInfo.Styles;
				foreach (int item in styles)
				{
					list.Add(item);
				}
			}
		}
		if (!flag)
		{
			for (int k = 0; k < list.Count; k++)
			{
				if (NewCardSkinTips.Inst.IsNew(list[k]))
				{
					m_LeftBtnRedPoint_Style.SetActive(value: true);
					break;
				}
			}
		}
		for (int l = curIndex + 1; l < m_skinIDs.Count; l++)
		{
			int num2 = m_skinIDs[l];
			if (NewCardSkinTips.Inst.IsNew(num2) || NewCardSkinTips.IsCardSkinCanUnlock(num2, m_cardLevel))
			{
				m_RightBtnRedPoint_Skin.SetActive(value: true);
				flag2 = true;
				break;
			}
			CardSkinInfo cardSkinInfo2 = LocalResources.CardSkinTable.Get(num2);
			if (cardSkinInfo2 != null && cardSkinInfo2.Styles != null)
			{
				int[] styles = cardSkinInfo2.Styles;
				foreach (int item2 in styles)
				{
					list2.Add(item2);
				}
			}
		}
		if (flag2)
		{
			return;
		}
		int num3 = 0;
		while (true)
		{
			if (num3 < list2.Count)
			{
				if (NewCardSkinTips.Inst.IsNew(list2[num3]))
				{
					break;
				}
				num3++;
				continue;
			}
			return;
		}
		m_RightBtnRedPoint_Style.SetActive(value: true);
	}

	public void OnClickLeftBtn()
	{
		if (!m_Scrolling)
		{
			int num = ArrayUtility.IndexOf(m_skinIDs.ToArray(), CardConfigEditPage_CardSkinItemTemplate.globalSelected);
			CardConfigEditPage_CardSkinItemTemplate.globalSelected = m_skinIDs[num - 1];
			UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
			ItemScroll();
		}
	}

	public void OnClickRightBtn()
	{
		if (!m_Scrolling)
		{
			int num = ArrayUtility.IndexOf(m_skinIDs.ToArray(), CardConfigEditPage_CardSkinItemTemplate.globalSelected);
			CardConfigEditPage_CardSkinItemTemplate.globalSelected = m_skinIDs[num + 1];
			UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
			ItemScroll();
		}
	}

	public void UpdateCardSkinData(CardSkinInfo cardSkinInfo)
	{
		bool num = m_LastSelectedSkinID != CardConfigEditPage_CardSkinItemTemplate.globalSelected;
		m_SkinName.transform.parent.gameObject.SetActive(!string.IsNullOrEmpty(cardSkinInfo.Name));
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_cardID);
		int num2 = (CardConfigEditPage_CardSkinItemTemplate.globalSelected > 0) ? CardConfigEditPage_CardSkinItemTemplate.globalSelected : inGameStoreInfo.DefaultSkinID;
		CardSkinInfo cardSkinInfo2 = LocalResources.CardSkinTable.Get(num2);
		CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(StyleItemTemplate.GlobleSelectedStyleId);
		string name;
		string icon;
		if (cardStyleInfo != null && cardStyleInfo.BasicCardSkinId == num2)
		{
			name = cardStyleInfo.Name;
			icon = cardStyleInfo.Icon;
		}
		else
		{
			name = cardSkinInfo2.Name;
			icon = cardSkinInfo2.Icon;
		}
		m_SkinName.text = name;
		m_Icon.sprite = SpriteSource.Inst.Find(icon);
		float cardLevelGrowthResult = CardUtility.GetCardLevelGrowthResult(m_cardID, m_cardLevel);
		string priceText = GetPriceText(inGameStoreInfo, cardLevelGrowthResult);
		string text = string.Format(arg0: (CardUtility.GetCardGrowth(m_cardID).Type == CardGrowthType.Discount) ? string.Format(inGameStoreInfo.Desc, priceText) : string.Format(inGameStoreInfo.Desc, cardLevelGrowthResult), arg1: cardSkinInfo2.Description, format: m_DescFormat);
		m_Desc.text = text;
		if (num && !m_IsFromShowUI)
		{
			StyleItemTemplate.GlobleSelectedStyleId = -1;
		}
		m_LastSelectedStyleID = StyleItemTemplate.GlobleSelectedStyleId;
		m_LastSelectedSkinID = CardConfigEditPage_CardSkinItemTemplate.globalSelected;
	}

	private void LoadStyles()
	{
		int globalSelected = CardConfigEditPage_CardSkinItemTemplate.globalSelected;
		List<int> canShowStyleList = CardUtility.GetCanShowStyleList(globalSelected);
		m_StyleBtnRedPoint.SetActive(value: false);
		if (canShowStyleList == null || canShowStyleList.Count == 0)
		{
			m_StyleBtn.gameObject.SetActive(value: false);
			m_Style.SetActive(value: false);
			return;
		}
		m_StyleBtn.gameObject.SetActive(value: true);
		m_Style.SetActive(value: true);
		if (StyleItemTemplate.GlobleSelectedStyleId == -1)
		{
			StyleItemTemplate.GlobleSelectedStyleId = CardUtility.CurCardStyle(globalSelected);
		}
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection[0]["IsDefault"] = true;
		commonDataCollection[0]["CardSkinInfo"].val = LocalResources.CardSkinTable.Get(globalSelected);
		commonDataCollection[0]["IsSelected"] = (StyleItemTemplate.GlobleSelectedStyleId == 0);
		for (int i = 1; i <= canShowStyleList.Count; i++)
		{
			int num = canShowStyleList[i - 1];
			commonDataCollection[i]["IsDefault"] = false;
			commonDataCollection[i]["CardStyleInfo"].val = LocalResources.CardStyleTable.Get(num);
			commonDataCollection[i]["IsSelected"].val = (StyleItemTemplate.GlobleSelectedStyleId == num);
			bool flag = NewCardSkinTips.Inst.IsNew(num);
			commonDataCollection[i]["IsNew"] = flag;
			if (flag)
			{
				m_StyleBtnRedPoint.SetActive(value: true);
			}
		}
		m_StyleItems.Args = commonDataCollection;
	}

	public void UpdateStates(int cardId)
	{
		if (CardConfigEditPage_CardSkinItemTemplate.globalSelected == -2)
		{
			m_States.State = 6;
			m_States.gameObject.SetActive(value: true);
			m_Time.gameObject.SetActive(value: false);
			m_OwnedLoginAwardTips.SetActive(value: false);
			m_StyleBtn.gameObject.SetActive(value: false);
			m_Style.SetActive(value: false);
		}
		else if (m_isLocalPlayer)
		{
			LoadStyles();
			m_States.gameObject.SetActive(value: true);
			m_Time.gameObject.SetActive(value: false);
			m_OwnedLoginAwardTips.SetActive(value: false);
			int globalSelected = CardConfigEditPage_CardSkinItemTemplate.globalSelected;
			bool flag = CardUtility.CurCardSkin(cardId) == globalSelected;
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(globalSelected);
			if (cardSkinInfo.UnlockLevel != 0 && !CardUtility.CardSkinIsClaimed(globalSelected))
			{
				int expiredTime;
				if (m_cardLevel >= cardSkinInfo.UnlockLevel)
				{
					m_States.State = 0;
				}
				else if (CardUtility.OwnCardSkin(globalSelected, out expiredTime))
				{
					if (expiredTime != 0)
					{
						CommonDataCollection commonDataCollection = new CommonDataCollection();
						m_Time.gameObject.SetActive(value: true);
						commonDataCollection["expiredTime"] = expiredTime;
						commonDataCollection["cardSkinPage"].val = this;
						m_Time.Args = commonDataCollection;
					}
					if (flag)
					{
						m_States.State = 2;
					}
					else
					{
						m_States.State = 1;
						NewCardSkinTips.Inst.TryToClear(CardConfigEditPage_CardSkinItemTemplate.globalSelected);
					}
					if (cardSkinInfo.GainType == 1)
					{
						m_OwnedLoginAwardTips.SetActive(value: true);
					}
				}
				else if (cardSkinInfo.GainType != 0)
				{
					m_States.State = 5;
					m_OtherGainTypeTips.text = cardSkinInfo.GainTips;
					NewCardSkinTips.Inst.TryToClear(globalSelected);
				}
				else
				{
					m_States.State = 3;
					m_UnlockTips.text = string.Format(m_UnlockTipsFormat, cardSkinInfo.UnlockLevel);
					NewCardSkinTips.Inst.TryToClear(globalSelected);
				}
			}
			else if (flag)
			{
				m_States.State = 2;
			}
			else
			{
				m_States.State = 1;
				NewCardSkinTips.Inst.TryToClear(CardConfigEditPage_CardSkinItemTemplate.globalSelected);
			}
		}
		else
		{
			m_States.gameObject.SetActive(value: false);
			m_Time.gameObject.SetActive(value: false);
			m_OwnedLoginAwardTips.SetActive(value: false);
			m_StyleBtn.gameObject.SetActive(value: false);
		}
	}

	public void OnClickUse()
	{
		if (LocalResources.CardSkinTable.Get(CardConfigEditPage_CardSkinItemTemplate.globalSelected).CardID == m_cardID)
		{
			m_CardSkinEditUI.LocalSetCardSkin(m_cardID, CardConfigEditPage_CardSkinItemTemplate.globalSelected);
			UILobby.Current.ShowTips(Localization.UseSuccess);
			UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
		}
		else
		{
			UnityEngine.Debug.LogError("异常数据 " + m_cardID + " / " + CardConfigEditPage_CardSkinItemTemplate.globalSelected);
		}
	}

	public void OnClickUnlock()
	{
		HttpRequestClaimCardSkin httpRequestClaimCardSkin = new HttpRequestClaimCardSkin();
		httpRequestClaimCardSkin.cardSkinID = CardConfigEditPage_CardSkinItemTemplate.globalSelected;
		GameHttpManager.Inst.Send(httpRequestClaimCardSkin, delegate(HttpResponseClaimCardSkin onResponse)
		{
			CardUtility.OnClaimCardSkin(CardConfigEditPage_CardSkinItemTemplate.globalSelected);
			CommonDataCollection args = new CommonDataCollection
			{
				["ItemInfo"] = 
				{
					val = onResponse.items[0]
				}
			};
			UILobby.Current.ShowUI(m_CardSkinRewardUI, args);
			LocalPlayerDatabase.RefreshAssetsInfo();
		});
	}

	public void OnClickStyle()
	{
		m_Style.SetActive(!m_Style.activeSelf);
	}

	private void UpdatePreviewPanel()
	{
		RectTransform component = m_RawImage.GetComponent<RectTransform>();
		int width = (int)component.sizeDelta.x;
		int height = (int)component.sizeDelta.y;
		m_CardSkinScene.m_Camera.targetTexture = null;
		LobbyScene.CreateRenderTextureIfNeeded(ref m_PreviewTexture, width, height);
		m_RawImage.texture = m_PreviewTexture;
		m_CardSkinScene.m_Camera.targetTexture = m_PreviewTexture;
		RenderTextureCamrea component2 = m_CardSkinScene.m_Camera.GetComponent<RenderTextureCamrea>();
		RenderTextureRawImage component3 = m_RawImage.GetComponent<RenderTextureRawImage>();
		if (component2 != null)
		{
			component2.SetClearTexture(component3);
		}
	}

	private void ItemScroll(bool tween = true)
	{
		if (tween)
		{
			m_Scrolling = true;
		}
		int index = ArrayUtility.IndexOf(m_skinIDs.ToArray(), CardConfigEditPage_CardSkinItemTemplate.globalSelected);
		m_CardSkinScene.Scroll(index, tween, delegate
		{
			m_Scrolling = false;
		});
	}

	private string GetPriceText(InGameStoreInfo itemInfo, float discount)
	{
		string text = CardConfigEditPage_DetailPage.GetCardPrice(itemInfo.Id, discount).ToString();
		if (itemInfo.Type != InGameStoreType.Weapon)
		{
			return text;
		}
		return string.Format(Localization.PriceStartFormat, text);
	}

	public int GetCurrentSelectedIndex()
	{
		return ArrayUtility.IndexOf(m_skinIDs.ToArray(), CardConfigEditPage_CardSkinItemTemplate.globalSelected);
	}
}
