using LightUI;
using LightUtility;
using UnityEngine.UI;

public class BoxUpgradePreviewUI_BoxInfo
{
	public UIDataBinder m_Host;

	public Text m_BoxName;

	public Image m_TimeBoxIcon;

	public UIStateRawImage m_Mirror;

	public Image m_TimeBoxIcon_Upgrade;

	public UIStateRawImage m_Mirror_Upgrade;

	public void Bind(CommonDataCollection args)
	{
		int boxID = args["boxID"];
		int boxUpgradeID = args["boxUpgradeID"];
		SetBoxRelate(boxID, boxUpgradeID);
	}

	private void SetBoxRelate(int boxID, int boxUpgradeID)
	{
		BoxInfo boxInfo = LocalResources.BoxTable.Find(boxID);
		BoxInfo boxInfo2 = LocalResources.BoxTable.Find(boxUpgradeID);
		m_BoxName.text = boxInfo.Name;
		string icon = boxInfo.Icon;
		m_TimeBoxIcon.sprite = SpriteSource.Inst.Find(icon);
		m_TimeBoxIcon.transform.parent.gameObject.SetActive(value: true);
		m_Mirror.gameObject.SetActive(value: true);
		m_Mirror.State = boxInfo.Quality;
		string icon2 = boxInfo2.Icon;
		m_TimeBoxIcon_Upgrade.sprite = SpriteSource.Inst.Find(icon2);
		m_TimeBoxIcon_Upgrade.transform.parent.gameObject.SetActive(value: true);
		m_Mirror.gameObject.SetActive(value: true);
		m_Mirror_Upgrade.State = boxInfo2.Quality;
	}
}
