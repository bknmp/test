using LightUtility;
using UnityEngine;

public class DirectionalPlaceableObject : PlaceableObject
{
	[HideInInspector]
	public PlayerController m_PlayerController;

	private Vector3 m_DefaultPos;

	private RaycastHit[] WallHits;

	private RaycastHit Wall;

	public override bool Forbidden => false;

	private new void Awake()
	{
		base.Awake();
		m_DefaultPos = m_PreviewArea.transform.localPosition;
	}

	protected new void Start()
	{
		base.Start();
	}

	public override void StartPreview()
	{
		base.StartPreview();
		m_Root.SetActive(value: false);
		base.transform.localPosition = Vector3.zero;
		m_PreviewArea.transform.localPosition = m_DefaultPos;
		UpdatePreviewArea();
		if (m_PreviewColor != null)
		{
			m_PreviewColor.ForceUpdate();
		}
	}

	private bool ForbidEscapeArea()
	{
		Vector3 previewPosition = base.PreviewPosition;
		Vector3 position = PlayerController.Inst.PhysicsBody.position;
		if (EscapeAreaContains(previewPosition, -0.5f) && EscapeAreaContains(position, 0f))
		{
			return false;
		}
		if (!EscapeAreaContains(previewPosition, 0.5f) && !EscapeAreaContains(position, 0f))
		{
			return false;
		}
		return true;
	}

	private bool IsInValidPos(Vector3 pos, float expand = 0f)
	{
		return InGameScene.Inst.Map.IsWorldPositionOutOfBorder(pos, expand);
	}

	private bool EscapeAreaContains(Vector3 pos, float expand)
	{
		return EscapeAreaGuard.InEscapeArea(pos, expand);
	}

	private bool InBossSkillRange(Vector3 pos)
	{
		foreach (BossPlayerController allBossPlayer in BossPlayerController.AllBossPlayers)
		{
			Skill playingSkill = allBossPlayer.SkillLauncher.PlayingSkill;
			if (playingSkill != null && playingSkill.Kind == SkillKind.BigBomb)
			{
				float num = Mathf.Max(playingSkill.MaxPlaceDistance, playingSkill.Properties.attackRadius);
				if (Vector3.Distance(allBossPlayer.transform.localPosition.FlattenY(), pos.FlattenY()) <= num + 0.2f)
				{
					return true;
				}
			}
		}
		return false;
	}

	public void CheckPreviewPosition()
	{
		bool isBreak = false;
		base.PreviewPosition = InGameScene.Inst.Map.ConfineWorldPosition(base.PreviewPosition, 1f);
		if (IsInValidPos(base.PreviewPosition) || ForbidEscapeArea() || (InBossSkillRange(PlayerController.Inst.transform.position) && !InBossSkillRange(base.PreviewPosition)))
		{
			bool flag = false;
			float num = 100f;
			WallHits = Physics.RaycastAll(PlayerController.Inst.transform.position.FlattenY(4f), base.PreviewDirection, m_PlaceMaxDistance + 1f);
			RaycastHit[] wallHits = WallHits;
			for (int i = 0; i < wallHits.Length; i++)
			{
				RaycastHit wall = wallHits[i];
				if ((EscapeAreaGuard.InEscapeArea(wall.point, 1f) || IsInValidPos(wall.point, 1f) || InBossSkillRange(wall.point)) && Vector3.Distance(wall.point, PlayerController.Inst.transform.position) < num)
				{
					Wall = wall;
					flag = true;
					num = Vector3.Distance(wall.point, PlayerController.Inst.transform.position);
				}
			}
			if (flag)
			{
				Vector3 normal = Wall.normal;
				base.PreviewPosition = Wall.point.FlattenY() + normal.normalized * 0.2f;
			}
			else
			{
				base.PreviewPosition = PlayerController.Inst.transform.position;
			}
			isBreak = true;
		}
		if (InGameScene.Inst.IsTile(base.PreviewPosition, InGameScene.TileType.Boat) || EscapeAreaGuard.InEscapeArea(base.PreviewPosition, 2f) || IsInValidPos(base.PreviewPosition, 2f))
		{
			isBreak = true;
		}
		if (PlayerController.Inst != null)
		{
			((WaterEscape)PlayerController.Inst.SkillManager.RoleSkill).isBreak = isBreak;
		}
	}

	protected override Vector3 GetPreviewTouchWorldOffset(float maxDistance)
	{
		if (PreviewAreaController.Inst != null)
		{
			return PreviewAreaController.Inst.GetPreviewWorldOffset(maxDistance, AttackArea.AreaType.Line, GameSettings.Inst.CardJoystickSensitivityFloat, m_MobileAutoAime, m_MobileAutoAimeEnemy, m_MobileAutoAimeDead, m_MobileAutoAimeSpeed);
		}
		return Vector3.zero;
	}

	protected override void UpdatePreviewArea()
	{
		base.UpdatePreviewArea();
		if (!(PlayerController.Inst != null))
		{
			return;
		}
		if (GetPreviewTouchWorldOffset(m_PlaceMaxDistanceMobile) == Vector3.zero)
		{
			base.PreviewDirection = PlayerController.Inst.transform.forward;
			base.PreviewPosition = PlayerController.Inst.transform.position + base.PreviewDirection.normalized * base.MaxPlaceDistance;
		}
		if (m_PreviewArea != null)
		{
			Vector3 vector = base.transform.position.FlattenY();
			Vector2 posInScreen = DirectionalObject.WorldToScreenPoint(base.PreviewPosition);
			Vector3 lhs = DirectionalObject.ScreenPositionToTargetDirection(vector, posInScreen);
			base.PreviewDirection = lhs.FlattenY().normalized;
			float num = Vector3.Distance(vector.FlattenY(), base.PreviewPosition.FlattenY());
			if (num <= m_PlaceMaxDistance)
			{
				base.PreviewPosition += base.PreviewDirection * Mathf.Clamp(m_PlaceMaxDistance - num, 0f, m_PlaceMaxDistance);
				num = m_PlaceMaxDistance;
			}
			CheckPreviewPosition();
			base.PreviewDirection = (base.PreviewPosition - PlayerController.Inst.transform.position).FlattenY().normalized;
			num = Vector3.Distance(vector.FlattenY(), base.PreviewPosition.FlattenY());
			m_PreviewArea.transform.rotation = Quaternion.LookRotation(base.PreviewDirection);
			m_PreviewArea.transform.localScale = new Vector3(1f, 1f, num / 3f) * 0.01f;
			m_PreviewArea.transform.position = m_PreviewArea.transform.position.FlattenY(0.2f);
		}
	}
}
