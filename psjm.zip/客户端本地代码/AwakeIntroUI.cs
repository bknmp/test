using System;
using UnityEngine;

public class AwakeIntroUI : MonoBehaviour
{
	public IntroUI m_Component;

	public GameObject m_PCInfo;

	public GameObject m_MobileInfo;

	private AndroidJavaObject m_Activity;

	private bool m_SkipPermission;

	private bool m_RequestPermission;

	private void Awake()
	{
		m_PCInfo.SetActive(value: false);
		m_MobileInfo.SetActive(value: true);
		AndroidSDKAdapter.Instance.Initialize();
		if (!m_Component.enabled)
		{
			m_Activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");
			CheckPermissionState();
		}
	}

	public void RequestPermission()
	{
		if (!m_RequestPermission)
		{
			m_RequestPermission = true;
			AndroidChannel androidChannel = AndroidSDKAdapter.AndroidChannel;
			if (androidChannel != AndroidChannel.OPPO && androidChannel != AndroidChannel.QIHOO && androidChannel != AndroidChannel.MI)
			{
				PermissionManager.RequestPermission(0, 1);
			}
		}
	}

	private void CheckPermissionState()
	{
		int num = m_Activity.Call<int>("GetPermissionState", Array.Empty<object>());
		m_SkipPermission = (num == 0);
		UnityEngine.Debug.LogFormat("CheckPermissionState {0}", m_SkipPermission);
		if (m_SkipPermission)
		{
			FinishedPermissionCheck();
		}
	}

	public void FinishedPermissionCheck(string ret = "")
	{
		UnityEngine.Debug.Log("FinishedPermissionCheck");
		m_SkipPermission = true;
		m_Component.enabled = true;
	}
}
