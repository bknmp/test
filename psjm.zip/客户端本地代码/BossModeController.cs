using LightUtility;
using System.Collections;
using UnityEngine;

public class BossModeController : RebornController
{
	public float m_ThiefViewHeight = 13.5f;

	public static BossModeController Inst;

	private void Awake()
	{
		Inst = this;
	}

	private void OnDestroy()
	{
		Inst = null;
	}

	protected override bool CanReborn(PlayerController player)
	{
		return player is ThiefController;
	}

	protected override IEnumerator Reborn(PlayerController player, float delay)
	{
		ThiefController thief = player as ThiefController;
		if (thief.IsLocalPlayer)
		{
			InGameTipsUI.Inst.ShowRebornTips(delay);
		}
		yield return Yielders.GetWaitForSeconds(delay);
		bool waitRPC = false;
		while (thief.FinalDead && !GameRuntime.IsNormalGameOver && !waitRPC)
		{
			if (thief.m_PhotonView.isMine && !GameRuntime.CheckThiefsAllDying())
			{
				thief.RpcReborn(GetRebornPos(thief));
				waitRPC = true;
			}
			yield return Yielders.GetWaitForSeconds(0.1f);
		}
		FinishReborn(player);
	}

	protected override Vector3 GetRebornPos(PlayerController player)
	{
		return InGameScene.Inst.m_SpawnAreaThief.transform.position;
	}
}
