using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class CharacterUtility
{
	public struct SkinPartArray
	{
		public int[] skinPartIDs;

		public int[] colorIDs;

		public int characterID;
	}

	private static Dictionary<int, int> CharacterPartCounts = new Dictionary<int, int>();

	private static List<int> SkinPartIDTemps = new List<int>();

	private static List<int> SkinPartTypeTemps = new List<int>();

	private static List<int> SkinPartColorTemps = new List<int>();

	private static List<int> LastGroupTemps = new List<int>();

	public static int PartCount(this int characterID)
	{
		if (characterID == 0)
		{
			return 5;
		}
		if (!CharacterPartCounts.TryGetValue(characterID, out int value))
		{
			value = LocalResources.CharacterTable.Get(characterID).DefaultParts.Length;
			CharacterPartCounts[characterID] = value;
		}
		return value;
	}

	public static int GetTrySkinSuiteID(int charactorID)
	{
		int[] array = ShopSuiteUtility.NotOwnSuites(charactorID, 2);
		if (array.Length != 0)
		{
			return array[UnityEngine.Random.Range(0, array.Length)];
		}
		return 0;
	}

	public static PlayerCharacterInfo GetTrySuiteCharacter(int suiteID)
	{
		if (suiteID <= 0)
		{
			return null;
		}
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suiteID);
		int[] suiteParts = GetSuiteParts(shopSuiteInfo);
		int num = suiteParts.Length;
		PlayerCharacterInfo ownedCharacterInfo = GetOwnedCharacterInfo(shopSuiteInfo.CharacterID);
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo
		{
			expiredTime = new int[num],
			skinPartColors = new int[num],
			skinPartIDs = new int[num]
		};
		for (int i = 0; i < suiteParts.Length; i++)
		{
			playerSkinInfo.skinPartIDs[i] = suiteParts[i];
			playerSkinInfo.skinPartColors[i] = LocalResources.SkinPartTable.Get(suiteParts[i]).DefaultColorID;
		}
		return new PlayerCharacterInfo
		{
			characterID = ownedCharacterInfo.characterID,
			currentSkinInfo = playerSkinInfo,
			expiredTime = ownedCharacterInfo.expiredTime,
			ExpLevel = ownedCharacterInfo.ExpLevel,
			ExpPoint = ownedCharacterInfo.ExpPoint,
			TalentLevels = ownedCharacterInfo.TalentLevels,
			TalentPointRemained = ownedCharacterInfo.TalentPointRemained
		};
	}

	public static PlayerCharacterInfo GetTryCharacter(int characterID)
	{
		PlayerCharacterInfo characterDefaultInfo = GetCharacterDefaultInfo(characterID);
		characterDefaultInfo.TalentLevels = new int[3]
		{
			3,
			3,
			3
		};
		return characterDefaultInfo;
	}

	public static PlayerCharacterInfo GetUsedCharacterInMatch(RoleType role)
	{
		PlayerCharacterInfo activeCharacterOrAdCharacter = GetActiveCharacterOrAdCharacter(role);
		if (CharacterFreeUtility.IsCharacterFree)
		{
			return ChangeCharacterInfo(activeCharacterOrAdCharacter, isTalentMax: true);
		}
		return MathUtility.Clone(activeCharacterOrAdCharacter);
	}

	public static PlayerCharacterInfo ChangeCharacterInfo(PlayerCharacterInfo character, bool isTalentMax = false)
	{
		PlayerCharacterInfo playerCharacterInfo = MathUtility.Clone(character);
		int[] array = playerCharacterInfo.TalentLevels = (from x in LocalResources.CharacterTable.Get(playerCharacterInfo.characterID).TalentIDs
			select LocalResources.TalentTable.Get(x).MaxLevel).ToArray();
		return playerCharacterInfo;
	}

	public static PlayerCharacterInfo GetActiveCharacterOrAdCharacter(RoleType role)
	{
		if (GameRuntime.MapType == MapType.Type4v1 || GameRuntime.MapType == MapType.Type8v2)
		{
			PlayerCharacterInfo tryPlayerCharacterInfo = AdUtility.TryPlayerCharacterInfo;
			if (tryPlayerCharacterInfo == null || LocalResources.CharacterTable.Get(tryPlayerCharacterInfo.characterID).Role != role)
			{
				return GetActiveCharacter(role);
			}
			return tryPlayerCharacterInfo;
		}
		return GetActiveCharacter(GameRuntime.PlayingRole);
	}

	public static PlayerCharacterInfo GetActiveCharacter(RoleType role)
	{
		if (role == RoleType.Boss)
		{
			role = RoleType.Police;
		}
		int num = (role == RoleType.Police) ? LocalPlayerDatabase.PlayerInfo.activeCharacterID[0] : LocalPlayerDatabase.PlayerInfo.activeCharacterID[1];
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(playerCharacterInfo.characterID);
			if (characterInfo.Role == role && (num == 0 || playerCharacterInfo.characterID == num))
			{
				if (playerCharacterInfo.currentSkinInfo == null)
				{
					playerCharacterInfo.currentSkinInfo = CreatePlayerSkinInfo(characterInfo.DefaultParts);
				}
				return playerCharacterInfo;
			}
		}
		return null;
	}

	public static PlayerCharacterInfo GetOwnedCharacterInfo(int id)
	{
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == id)
			{
				return playerCharacterInfo;
			}
		}
		PlayerCharacterInfo characterDefaultInfo = GetCharacterDefaultInfo(id);
		List<PlayerCharacterInfo> list = new List<PlayerCharacterInfo>(LocalPlayerDatabase.PlayerInfo.ownedCharacters);
		list.Add(characterDefaultInfo);
		LocalPlayerDatabase.PlayerInfo.ownedCharacters = list.ToArray();
		return characterDefaultInfo;
	}

	public static bool IsUsingSkin(int Skin)
	{
		bool result = true;
		if (ShopUtility.IsGroup(Skin))
		{
			SkinGroupInfo skinGroupInfo = LocalResources.SkinGroupTable.Get(Skin);
			for (int i = 0; i < skinGroupInfo.SkinPartIds.Length; i++)
			{
				if (!IsUsingSkinPart(skinGroupInfo.SkinPartIds[i]))
				{
					result = false;
					break;
				}
			}
		}
		else
		{
			result = IsUsingSkinPart(Skin);
		}
		return result;
	}

	public static bool IsDefaultColor(int skinID, int color)
	{
		int id = skinID;
		if (ShopUtility.IsGroup(skinID))
		{
			id = LocalResources.SkinGroupTable.Get(skinID).SkinPartIds[0];
		}
		return LocalResources.SkinPartTable.Get(id).DefaultColorID == color;
	}

	private static bool IsUsingSkinPart(int partID)
	{
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(partID);
		return GetOwnedCharacterInfo(skinPartInfo.CharacterID).currentSkinInfo.skinPartIDs[(int)skinPartInfo.PartType] == partID;
	}

	public static PlayerCharacterInfo GetCharacterDefaultInfo(int id)
	{
		int num = id.PartCount();
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo
		{
			expiredTime = new int[num],
			skinPartColors = new int[num],
			skinPartIDs = LocalResources.CharacterTable.Get(id).DefaultParts.ToArray()
		};
		for (int i = 0; i < playerSkinInfo.skinPartIDs.Length; i++)
		{
			playerSkinInfo.skinPartColors[i] = LocalResources.SkinPartTable.Get(playerSkinInfo.skinPartIDs[i]).DefaultColorID;
		}
		PlayerCharacterInfo playerCharacterInfo = new PlayerCharacterInfo();
		playerCharacterInfo.characterID = id;
		playerCharacterInfo.currentSkinInfo = playerSkinInfo;
		playerCharacterInfo.expiredTime = 1u;
		playerCharacterInfo.ExpLevel = 1;
		playerCharacterInfo.ExpPoint = 0;
		playerCharacterInfo.TalentLevels = new int[3]
		{
			1,
			1,
			1
		};
		playerCharacterInfo.TalentPointRemained = 0;
		return playerCharacterInfo;
	}

	public static PlayerSkinInfo CreatePlayerSkinInfo(int[] partIDs, int[] colorIDs = null)
	{
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo();
		playerSkinInfo.skinPartIDs = partIDs;
		if (colorIDs == null)
		{
			playerSkinInfo.skinPartColors = new int[partIDs.Length];
			for (int i = 0; i < playerSkinInfo.skinPartColors.Length; i++)
			{
				playerSkinInfo.skinPartColors[i] = LocalResources.SkinPartTable.Get(playerSkinInfo.skinPartIDs[i]).DefaultColorID;
			}
		}
		else
		{
			playerSkinInfo.skinPartColors = colorIDs;
		}
		return playerSkinInfo;
	}

	public static bool FindCurrentSkinPart(SkinPartType type, out int partID, out int colorID)
	{
		return FindSkinPart(GetActiveCharacter(GameRuntime.PlayingRole).currentSkinInfo, type, out partID, out colorID);
	}

	public static bool FindSkinPart(PlayerSkinInfo info, SkinPartType type, out int partID, out int colorID)
	{
		for (int i = 0; i < info.skinPartIDs.Length; i++)
		{
			int num = info.skinPartIDs[i];
			if (LocalResources.SkinPartTable.Get(num).PartType == type)
			{
				partID = num;
				colorID = info.skinPartColors[i];
				return true;
			}
		}
		partID = 0;
		colorID = 0;
		return false;
	}

	public static bool IsColor(int colorID, int partID, PlayerSkinInfo info)
	{
		for (int i = 0; i < info.skinPartIDs.Length; i++)
		{
			if (info.skinPartIDs[i] == partID && info.skinPartColors[i] == colorID)
			{
				return true;
			}
		}
		return false;
	}

	public static void RevertCurrentColors()
	{
		if (LobbyScene.Inst != null)
		{
			LobbyPlayerController currentCharacter = LobbyScene.Inst.CurrentCharacter;
			if (currentCharacter != null)
			{
				currentCharacter.m_SkinPartController.ColorController.UpdateColors(GetOwnedCharacterInfo(currentCharacter.CharacterID).currentSkinInfo);
			}
		}
	}

	public static int[] CurrentColorIDs()
	{
		if (LobbyScene.Inst != null)
		{
			return LobbyScene.Inst.CurrentCharacter.m_SkinPartController.ColorController.ColorIDs;
		}
		return null;
	}

	public static void SetSkinPart(List<int> partID, Delegates.VoidCallback onSuccess = null)
	{
		if (partID.Count > 0)
		{
			HttpRequestSetSkinPart httpRequestSetSkinPart = new HttpRequestSetSkinPart();
			httpRequestSetSkinPart.skinPartID = partID.ToArray();
			GameHttpManager.Inst.Send(httpRequestSetSkinPart, delegate
			{
				LocalPlayerDatabase.Invoke(LocalPlayerDatabase.OnPlayerInfoChanged);
			}, onSuccess);
		}
	}

	public static void UpdateSkinPartColor(int partID, int colorID)
	{
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			for (int j = 0; j < playerCharacterInfo.currentSkinInfo.skinPartIDs.Length; j++)
			{
				if (playerCharacterInfo.currentSkinInfo.skinPartIDs[j] == partID)
				{
					playerCharacterInfo.currentSkinInfo.skinPartColors[j] = colorID;
				}
			}
		}
		if (LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs != null)
		{
			for (int k = 0; k < LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs.Length; k++)
			{
				if (LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs[k] == partID)
				{
					LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartColors[k] = colorID;
				}
			}
		}
		LocalPlayerDatabase.Invoke(LocalPlayerDatabase.OnPlayerInfoChanged);
	}

	public static SkinInfo GetSkinInfo(int skinID)
	{
		if (ShopUtility.IsGroup(skinID))
		{
			return LocalResources.SkinGroupTable.Get(skinID);
		}
		return LocalResources.SkinPartTable.Get(skinID);
	}

	public static void BuyColor(int colorID, int[] partID, Delegates.ObjectCallback<int[]> onSuccess)
	{
		if (LocalPlayerDatabase.PlayerInfo.coloringAgentNum < LocalPlayerDatabase.Settings.coloringAgentCost)
		{
			UILobby.Current.ShowMessageBoxYesNo(Localization.TipsNoEnoughColoring, Localization.MsgBoxOK, Localization.MsgBoxNo, Localization.MsgBoxTitle, LobbyScene_Money.BuyColor, null);
			return;
		}
		HttpRequestColoring httpRequestColoring = new HttpRequestColoring();
		httpRequestColoring.colorID = colorID;
		httpRequestColoring.skinPartIDs = partID;
		GameHttpManager.Inst.Send(httpRequestColoring, delegate(HttpResponseColoring response)
		{
			LocalPlayerDatabase.PlayerInfo.coloringAgentNum = response.coloringAgentNum;
			if (onSuccess != null)
			{
				onSuccess(response.colorIDs);
			}
			UIDataEvents.Inst.InvokeEvent("OnSkinColorChanged");
			LocalPlayerDatabase.Invoke(LocalPlayerDatabase.OnPlayerInfoChanged);
		});
	}

	public static bool OwnSkinPart(int skinID, out int expiredTime, out int color)
	{
		int num = ShopUtility.IsGroup(skinID) ? LocalResources.SkinGroupTable.Get(skinID).SkinPartIds[0] : skinID;
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs[i] == num)
			{
				expiredTime = LocalPlayerDatabase.PlayerInfo.ownedSkins.expiredTime[i];
				color = LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartColors[i];
				return true;
			}
		}
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(num);
		if (LocalResources.CharacterTable.Get(skinPartInfo.CharacterID).DefaultParts.Contains(num))
		{
			expiredTime = 0;
			color = skinPartInfo.DefaultColorID;
			return true;
		}
		expiredTime = 1;
		color = -1;
		return false;
	}

	public static bool OwnPermanentSkinGroup(int groupID)
	{
		return OwnPermanentSkinPart(LocalResources.SkinGroupTable.Get(groupID).SkinPartIds[0]);
	}

	public static bool OwnPermanentSkinPart(int partID)
	{
		for (int i = 0; i < LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs.Length; i++)
		{
			if (LocalPlayerDatabase.PlayerInfo.ownedSkins.skinPartIDs[i] == partID && LocalPlayerDatabase.PlayerInfo.ownedSkins.expiredTime[i] == 0)
			{
				return true;
			}
		}
		return false;
	}

	public static MatchPlayerData GetPlayerData(int characterID = 0)
	{
		MatchPlayerData matchPlayerData = new MatchPlayerData();
		CharacterCardConfig characterCardConfigs = CardUtility.GetCharacterCardConfigs(characterID);
		matchPlayerData.cards = ((characterCardConfigs != null) ? characterCardConfigs.allConfigs[characterCardConfigs.activeIndex].config : CardUtility.DefaultCards);
		matchPlayerData.cardLevel = CardUtility.GetCardLevels(matchPlayerData.cards);
		matchPlayerData.cardSkins = CardUtility.GetCardSkins(matchPlayerData.cards);
		matchPlayerData.cardStyles = CardUtility.GetCardStyles(matchPlayerData.cards);
		matchPlayerData.ingameEmotion = IngameEmotionUtility.GetCharacterConfig(characterID);
		matchPlayerData.lightnessConfig = LocalPlayerDatabase.PlayerInfo.lightness.config;
		matchPlayerData.lockCardConfig = ((characterCardConfigs != null && GameSettings.Inst.LockCardEnable && !GameRuntime.IsMapRedEnvelopeFight) ? characterCardConfigs.allConfigs[characterCardConfigs.activeIndex].LockIndex : new int[0]);
		return matchPlayerData;
	}

	public static MatchPlayerData GetDefaultPlayerData()
	{
		MatchPlayerData matchPlayerData = new MatchPlayerData();
		matchPlayerData.cards = CardUtility.DefaultCards;
		matchPlayerData.cardLevel = CardUtility.GetCardLevels(matchPlayerData.cards);
		matchPlayerData.cardSkins = CardUtility.GetCardSkins(matchPlayerData.cards);
		matchPlayerData.cardStyles = CardUtility.GetCardStyles(matchPlayerData.cards);
		matchPlayerData.ingameEmotion = IngameEmotionUtility.GetCharacterConfig(0);
		matchPlayerData.lightnessConfig = LocalPlayerDatabase.PlayerInfo.lightness.config;
		matchPlayerData.lockCardConfig = new int[0];
		return matchPlayerData;
	}

	public static bool IsOwnCharacter(int id)
	{
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == id && (playerCharacterInfo.expiredTime == 0 || playerCharacterInfo.expiredTime > UtcTimeStamp.Now))
			{
				return true;
			}
		}
		return false;
	}

	public static bool IsOwnForeverCharacter(int id)
	{
		PlayerCharacterInfo[] ownedCharacters = LocalPlayerDatabase.PlayerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == id && playerCharacterInfo.expiredTime == 0)
			{
				return true;
			}
		}
		return false;
	}

	public static void SetActiveCharacter(int id)
	{
		if (GameRuntime.IsMatching || (TeamRoomUI.IsShowing && TeamRoomUI.IsReady))
		{
			UILobby.Current.ShowTips(Localization.IllegalOperation);
			return;
		}
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(id);
		if (LocalPlayerDatabase.PlayerInfo.activeCharacterID[(int)characterInfo.Role] != id)
		{
			LocalPlayerDatabase.PlayerInfo.activeCharacterID[(int)characterInfo.Role] = id;
		}
		if (characterInfo.Role != GameRuntime.PlayingRole)
		{
			LobbyScene.Inst.MoveViewToSide(GameUtility.GetEnemyRole(), entranceAnimation: false);
		}
		else
		{
			LobbyScene.Inst.ChangeCharacterInst();
		}
		UIDataEvents.Inst.InvokeEvent("OnPlayerInfoChanged");
		HttpRequestSetActiveCharacter httpRequestSetActiveCharacter = new HttpRequestSetActiveCharacter();
		httpRequestSetActiveCharacter.characterID = LocalPlayerDatabase.PlayerInfo.activeCharacterID;
		httpRequestSetActiveCharacter.roleType = (int)GameRuntime.PlayingRole;
		GameHttpManager.Inst.SendNoWait(httpRequestSetActiveCharacter);
	}

	public static bool IsActiveCharacter(int id)
	{
		if (LocalResources.CharacterTable.Get(id).Role != GameRuntime.PlayingRole)
		{
			return false;
		}
		if (LocalPlayerDatabase.PlayerInfo.activeCharacterID[(int)GameRuntime.PlayingRole] != id)
		{
			return false;
		}
		return true;
	}

	public static PlayerCharacterInfo GetActiveCharacter(RoleType role, HttpResponsePlayerInfo playerInfo)
	{
		int num = (role == RoleType.Police) ? playerInfo.activeCharacterID[0] : playerInfo.activeCharacterID[1];
		PlayerCharacterInfo[] ownedCharacters = playerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(playerCharacterInfo.characterID);
			if (characterInfo.Role == role && (num == 0 || playerCharacterInfo.characterID == num))
			{
				if (playerCharacterInfo.currentSkinInfo == null)
				{
					playerCharacterInfo.currentSkinInfo = CreatePlayerSkinInfo(characterInfo.DefaultParts);
				}
				return playerCharacterInfo;
			}
		}
		return null;
	}

	public static PlayerCharacterInfo GetPlayerCharacterInfo(int characterId, HttpResponsePlayerInfo playerInfo)
	{
		PlayerCharacterInfo[] ownedCharacters = playerInfo.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == characterId)
			{
				if (playerCharacterInfo.currentSkinInfo == null)
				{
					playerCharacterInfo.currentSkinInfo = CreatePlayerSkinInfo(LocalResources.CharacterTable.Get(characterId).DefaultParts);
				}
				return playerCharacterInfo;
			}
		}
		return new PlayerCharacterInfo
		{
			characterID = characterId,
			currentSkinInfo = CreatePlayerSkinInfo(LocalResources.CharacterTable.Get(characterId).DefaultParts)
		};
	}

	public static MatchPlayerData GetPlayerData(uint roleID, int characterID, HttpResponsePlayerAssets assets, HttpResponseCardConfigs cardConfigs)
	{
		MatchPlayerData matchPlayerData = new MatchPlayerData();
		CharacterCardConfig[] allCharacterCardConfigs = cardConfigs.allCharacterCardConfigs;
		foreach (CharacterCardConfig characterCardConfig in allCharacterCardConfigs)
		{
			if (characterID == characterCardConfig.characterID)
			{
				matchPlayerData.cardSkins = CardUtility.GetActiveCardSkins(matchPlayerData.cards = characterCardConfig.allConfigs[characterCardConfig.activeIndex].config, assets.cardIDs, assets.cardCurSkin);
				matchPlayerData.cardStyles = CardUtility.GetActiveCardStyles(matchPlayerData.cardSkins, assets.cardCurStyle);
				matchPlayerData.lockCardConfig = characterCardConfig.allConfigs[characterCardConfig.activeIndex].LockIndex;
				break;
			}
		}
		matchPlayerData.ingameEmotion = IngameEmotionUtility.GetCharacterConfig(characterID);
		matchPlayerData.lightnessConfig = assets.lightness.config;
		return matchPlayerData;
	}

	public static string GetColorRoleName(RoleType roleType, string roleName)
	{
		return string.Format((roleType == RoleType.Police) ? Localization.PoliceColorFormat : Localization.ThiefColorFormat, roleName);
	}

	public static bool IsOwnCharacter(int id, HttpResponsePlayerAssets assets)
	{
		PlayerCharacterInfo[] ownedCharacters = assets.ownedCharacters;
		foreach (PlayerCharacterInfo playerCharacterInfo in ownedCharacters)
		{
			if (playerCharacterInfo.characterID == id && (playerCharacterInfo.expiredTime == 0 || playerCharacterInfo.expiredTime > UtcTimeStamp.Now))
			{
				return true;
			}
		}
		return false;
	}

	public static int[] AllNotOwnedCharacters(RoleType roleType)
	{
		List<int> list = new List<int>();
		foreach (CharacterInfo item in LocalResources.CharacterTable)
		{
			if (item.IsVisibleInUI && item.Role == roleType && !IsOwnForeverCharacter(item.Id))
			{
				list.Add(item.Id);
			}
		}
		return list.ToArray();
	}

	public static int OwnCharacterNum()
	{
		int num = 0;
		foreach (CharacterInfo item in LocalResources.CharacterTable)
		{
			if (item.IsVisibleInUI && IsOwnForeverCharacter(item.Id))
			{
				num++;
			}
		}
		return num;
	}

	public static int[] GetPartIDs(int suiteID)
	{
		return GetSuiteParts(LocalResources.ShopSuiteTable.Get(suiteID));
	}

	public static MatchPlayerData GetMatchPlayerData(int[] cards, int[] cardLevels, int[] cardSkins = null, int[] cardStyles = null)
	{
		MatchPlayerData matchPlayerData = new MatchPlayerData
		{
			cards = cards,
			cardLevel = cardLevels,
			cardSkins = new int[cards.Length],
			cardStyles = new int[cards.Length],
			ingameEmotion = new int[0],
			lightnessConfig = 0,
			lockCardConfig = new int[0]
		};
		bool flag = cardSkins == null || cardSkins.Length == 0;
		bool flag2 = cardStyles == null || cardStyles.Length == 0;
		for (int i = 0; i < cards.Length; i++)
		{
			matchPlayerData.cardSkins[i] = (flag ? LocalResources.InGameStoreTable.Get(cards[i]).DefaultSkinID : cardSkins[i]);
		}
		for (int j = 0; j < cards.Length; j++)
		{
			matchPlayerData.cardStyles[j] = ((!flag2) ? cardStyles[j] : 0);
		}
		return matchPlayerData;
	}

	public static PlayerCharacterInfo GetPlayerCharacterInfo(CharacterInfo character, int[] talentLevels, int suiteID = 0)
	{
		int[] array = (suiteID == 0) ? character.DefaultParts : GetPartIDs(suiteID);
		PlayerCharacterInfo playerCharacterInfo = new PlayerCharacterInfo
		{
			characterID = character.Id,
			currentSkinInfo = new PlayerSkinInfo
			{
				expiredTime = new int[array.Length],
				skinPartColors = new int[array.Length],
				skinPartIDs = array
			},
			expiredTime = 0u,
			ExpLevel = 0,
			ExpPoint = 0,
			TalentLevels = talentLevels,
			TalentPointRemained = 0
		};
		for (int i = 0; i < array.Length; i++)
		{
			playerCharacterInfo.currentSkinInfo.skinPartColors[i] = LocalResources.SkinPartTable.Get(array[i]).DefaultColorID;
		}
		return playerCharacterInfo;
	}

	public static PlayerCharacterInfo CreateCharacterInfoBySuite(int suiteID)
	{
		if (suiteID <= 0)
		{
			return null;
		}
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suiteID);
		int[] suiteParts = GetSuiteParts(shopSuiteInfo);
		int num = suiteParts.Length;
		PlayerSkinInfo playerSkinInfo = new PlayerSkinInfo
		{
			expiredTime = new int[num],
			skinPartColors = new int[num],
			skinPartIDs = new int[num]
		};
		for (int i = 0; i < suiteParts.Length; i++)
		{
			int num2 = suiteParts[i];
			playerSkinInfo.skinPartIDs[i] = num2;
			playerSkinInfo.skinPartColors[i] = LocalResources.SkinPartTable.Get(num2).DefaultColorID;
		}
		PlayerCharacterInfo playerCharacterInfo = new PlayerCharacterInfo();
		playerCharacterInfo.characterID = shopSuiteInfo.CharacterID;
		playerCharacterInfo.currentSkinInfo = playerSkinInfo;
		playerCharacterInfo.expiredTime = 1u;
		playerCharacterInfo.ExpLevel = 1;
		playerCharacterInfo.ExpPoint = 0;
		playerCharacterInfo.TalentLevels = new int[3]
		{
			1,
			1,
			1
		};
		playerCharacterInfo.TalentPointRemained = 0;
		return playerCharacterInfo;
	}

	public static SkinPartArray GetRealChangedParts(int skinID, int[] lastPartIDs, bool useLocalColor = true)
	{
		SkinPartIDTemps.Clear();
		SkinPartColorTemps.Clear();
		SkinPartTypeTemps.Clear();
		int characterID;
		if (ShopUtility.IsGroup(skinID))
		{
			SkinGroupInfo skinGroupInfo = LocalResources.SkinGroupTable.Get(skinID);
			characterID = skinGroupInfo.CharacterID;
			LastGroupTemps.Clear();
			int[] skinPartIds = skinGroupInfo.SkinPartIds;
			foreach (int num in skinPartIds)
			{
				SkinPartIDTemps.Add(num);
				SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(num);
				SkinPartTypeTemps.Add((int)skinPartInfo.PartType);
				int groupID = ShopUtility.GetGroupID(lastPartIDs[(int)skinPartInfo.PartType]);
				if (groupID > 0 && !LastGroupTemps.Contains(groupID))
				{
					LastGroupTemps.Add(groupID);
				}
			}
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(characterID);
			foreach (int lastGroupTemp in LastGroupTemps)
			{
				skinPartIds = LocalResources.SkinGroupTable.Get(lastGroupTemp).SkinPartIds;
				foreach (int id in skinPartIds)
				{
					int partType = (int)LocalResources.SkinPartTable.Get(id).PartType;
					if (!SkinPartTypeTemps.Contains(partType) && partType < characterInfo.DefaultParts.Length)
					{
						SkinPartTypeTemps.Add(partType);
						SkinPartIDTemps.Add(characterInfo.DefaultParts[partType]);
					}
				}
			}
		}
		else
		{
			SkinPartInfo skinPartInfo2 = LocalResources.SkinPartTable.Get(skinID);
			int skinPartID = lastPartIDs[(int)skinPartInfo2.PartType];
			CharacterInfo characterInfo2 = LocalResources.CharacterTable.Get(skinPartInfo2.CharacterID);
			characterID = skinPartInfo2.CharacterID;
			int groupID2 = ShopUtility.GetGroupID(skinPartID);
			if (groupID2 > 0)
			{
				SkinPartIDTemps.Add(skinID);
				int[] skinPartIds = LocalResources.SkinGroupTable.Get(groupID2).SkinPartIds;
				foreach (int id2 in skinPartIds)
				{
					SkinPartInfo skinPartInfo3 = LocalResources.SkinPartTable.Get(id2);
					if (skinPartInfo2.PartType != skinPartInfo3.PartType)
					{
						int item = characterInfo2.DefaultParts[(int)skinPartInfo3.PartType];
						SkinPartIDTemps.Add(item);
					}
				}
			}
			else
			{
				SkinPartIDTemps.Add(skinID);
			}
		}
		foreach (int skinPartIDTemp in SkinPartIDTemps)
		{
			int item2 = useLocalColor ? GetOwnedSkinPartColor(skinPartIDTemp) : LocalResources.SkinPartTable.Get(skinPartIDTemp).DefaultColorID;
			SkinPartColorTemps.Add(item2);
		}
		SkinPartArray result = default(SkinPartArray);
		result.skinPartIDs = SkinPartIDTemps.ToArray();
		result.colorIDs = SkinPartColorTemps.ToArray();
		result.characterID = characterID;
		return result;
	}

	public static int GetOwnedSkinPartColor(int skinPartID)
	{
		PlayerSkinInfo ownedSkins = LocalPlayerDatabase.PlayerInfo.ownedSkins;
		int num = Array.IndexOf(ownedSkins.skinPartIDs, skinPartID);
		if (num > -1)
		{
			return ownedSkins.skinPartColors[num];
		}
		return LocalResources.SkinPartTable.Get(skinPartID).DefaultColorID;
	}

	public static int[] GetSuiteParts(ShopSuiteInfo suiteInfo)
	{
		List<int> list = new List<int>();
		int[] shopItemIDs = suiteInfo.ShopItemIDs;
		foreach (int id in shopItemIDs)
		{
			int typeParam = LocalResources.DropItemTable.Get(id).TypeParam;
			if (ShopUtility.IsGroup(typeParam))
			{
				int[] skinPartIds = LocalResources.SkinGroupTable.Get(typeParam).SkinPartIds;
				foreach (int item in skinPartIds)
				{
					list.Add(item);
				}
			}
			else
			{
				list.Add(typeParam);
			}
		}
		return list.ToArray();
	}

	public static void DoChangeParts(SkinPartArray realPartArray, LobbyPlayerController controller = null)
	{
		if (controller == null)
		{
			controller = LobbyScene.Inst.CurrentCharacter;
		}
		for (int i = 0; i < realPartArray.skinPartIDs.Length; i++)
		{
			int partID = realPartArray.skinPartIDs[i];
			int colorID = realPartArray.colorIDs[i];
			controller.ChangePart(partID, colorID, isInGame: false, i == realPartArray.skinPartIDs.Length - 1);
		}
	}

	public static void LocalChangePlayerPartsData(SkinPartArray realPartArray, PlayerSkinInfo skinInfo, int characterID)
	{
		for (int i = 0; i < realPartArray.skinPartIDs.Length; i++)
		{
			int num = realPartArray.skinPartIDs[i];
			int num2 = realPartArray.colorIDs[i];
			SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(num);
			if (characterID == skinPartInfo.CharacterID)
			{
				skinInfo.skinPartIDs[(int)skinPartInfo.PartType] = num;
				skinInfo.skinPartColors[(int)skinPartInfo.PartType] = num2;
			}
		}
	}

	public static int GetWearingSuiteID(int[] partIDs)
	{
		foreach (ShopSuiteInfo item in LocalResources.ShopSuiteTable)
		{
			int[] suiteParts = GetSuiteParts(item);
			if (suiteParts.Contains(partIDs[0]))
			{
				for (int i = 1; i < partIDs.Length; i++)
				{
					if (!suiteParts.Contains(partIDs[i]))
					{
						return 0;
					}
				}
				return item.Id;
			}
		}
		return 0;
	}
}
