using UnityEngine;

public class AutoHideLobbyCharacter : MonoBehaviour
{
	private static int m_HideCounter;

	private bool m_ReadyForRequestHiding;

	public static void RequestHiding()
	{
	}

	public static void ReleaseHiding(bool force = false)
	{
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}

	private void LateUpdate()
	{
		if (m_ReadyForRequestHiding)
		{
			m_ReadyForRequestHiding = false;
			RequestHiding();
		}
	}
}
