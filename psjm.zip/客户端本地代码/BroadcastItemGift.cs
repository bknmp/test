using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class BroadcastItemGift
{
	public UIDataBinder m_Host;

	public Text m_Player;

	public Image m_Icon;

	public Text m_Gift;

	public PlayerSpaceButton m_SpaceButton;

	public UIStateRawImage m_Bg;

	private string m_GiftFormat;

	public void Bind(CommonDataCollection args)
	{
		if (m_GiftFormat == null)
		{
			m_GiftFormat = m_Gift.text;
		}
		BroadcastInfo broadcast = (BroadcastInfo)args["broadcast"].val;
		GiftBroadcast giftBroadcast = broadcast.ConvertTo<GiftBroadcast>();
		GiftInfo giftInfo = LocalResources.GiftInfo.Find(giftBroadcast.giftID);
		bool flag = giftInfo.Broadcast > 100;
		m_Bg.State = (flag ? 1 : 0);
		m_Player.GetComponent<UIStateColor>().State = (flag ? 1 : 0);
		string format = flag ? Localization.ExpensiveGiftBroadFormat : Localization.NormalGiftBroadFormat;
		m_SpaceButton.SetPlayerID(giftBroadcast.receiverID);
		m_Icon.sprite = SpriteSource.Inst.Find(giftInfo.BroadcastIcon);
		m_Gift.text = string.Format(m_GiftFormat, giftInfo.Name, giftBroadcast.count);
		m_Gift.GetComponent<UIStateColor>().State = (flag ? 1 : 0);
		m_Player.text = string.Format(format, giftBroadcast.giverName, giftBroadcast.receiverName);
		m_SpaceButton.SetDirty();
		m_SpaceButton.OnClickedSpace = delegate
		{
			Broadcast.Inst.RemoveBroadcast(broadcast.id);
			GiftChecker.Inst.OnHideGiftUI();
			if (UILobby.Current.CurrentPopup() != null)
			{
				UILobby.Current.CurrentPopup().GoBack();
			}
		};
	}
}
