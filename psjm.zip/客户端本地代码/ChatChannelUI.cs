using LightUI;
using UnityEngine;

public class ChatChannelUI : MonoBehaviour
{
	public UITemplateInitiator m_Content;

	private RectTransform m_Rect;

	private bool m_Show;

	private void Awake()
	{
		m_Rect = GetComponent<RectTransform>();
		m_Rect.anchoredPosition = Vector2.zero;
	}

	private void Update()
	{
		if ((Input.GetMouseButtonDown(0) || (UnityEngine.Input.touchCount > 0 && UnityEngine.Input.GetTouch(0).phase == TouchPhase.Began)) && !CheckPosInRange())
		{
			Hide();
		}
	}

	private bool CheckPosInRange()
	{
		RectTransformUtility.ScreenPointToLocalPointInRectangle(UILobby.Current.GetComponent<RectTransform>(), GetTouchPosition(), UILobby.Current.GetComponent<Canvas>().worldCamera, out Vector2 localPoint);
		return m_Rect.rect.Contains(localPoint);
	}

	public void Show()
	{
		if (!m_Show)
		{
			m_Show = true;
			base.gameObject.SetActive(value: true);
			base.transform.SetAsLastSibling();
			LoadChannelList();
		}
	}

	private void LoadChannelList()
	{
		if (LocalPlayerDatabase.ChatChannelList != null)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			for (int i = 0; i < LocalPlayerDatabase.ChatChannelList.infos.Length; i++)
			{
				commonDataCollection[i]["channelID"] = LocalPlayerDatabase.ChatChannelList.infos[i].channelID;
			}
			m_Content.Args = commonDataCollection;
			LocalPlayerDatabase.RequsetChatChannelList(delegate
			{
				UIDataEvents.Inst.InvokeEvent("OnSelectChannelItemChanged");
			});
		}
		else
		{
			LocalPlayerDatabase.RequsetChatChannelList(LoadChannelList);
		}
	}

	public void Hide()
	{
		if (m_Show)
		{
			m_Show = false;
			base.gameObject.SetActive(value: false);
		}
	}

	private Vector2 GetTouchPosition()
	{
		Vector2 result = UnityEngine.Input.mousePosition;
		int touchCount = UnityEngine.Input.touchCount;
		if (touchCount > 0)
		{
			for (int i = 0; i < touchCount; i++)
			{
				Touch touch = UnityEngine.Input.GetTouch(i);
				if (touch.phase == TouchPhase.Began)
				{
					result = touch.position;
					break;
				}
			}
		}
		return result;
	}
}
