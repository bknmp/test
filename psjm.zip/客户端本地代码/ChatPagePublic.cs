using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class ChatPagePublic
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	public InputField m_InputField;

	public UIShortcutSelectable m_Send;

	public Text m_TitleText;

	public Button m_ChannelButton;

	public Text m_CoolDownText;

	public UIShortcutSelectable m_CoolDown;

	public GameObject m_ChatPagePublic;

	public Button m_EmojiBuntton;

	private string m_TitleFormat;

	private string m_CoolDownFormat;

	private const int MaxInputCount = 30;

	private List<RpcChat> m_Messages = new List<RpcChat>();

	private static float LastSendTime;

	private ChatPanel m_ChatPanel;

	private Coroutine m_Coroutine;

	public static int m_LastChannelID;

	public void Bind(CommonDataCollection args)
	{
		EmojiItem.SetChatInput(m_InputField);
		m_ChatPanel = m_ChatPagePublic.GetComponentInParent<ChatPanel>();
		if (m_TitleFormat == null)
		{
			m_TitleFormat = m_TitleText.text;
		}
		if (m_CoolDownFormat == null)
		{
			m_CoolDownFormat = m_CoolDownText.text;
		}
		ChatChannelInfo chatChannelInfo = ChatUtility.GetChatChannelInfo(PublicChatManager.ChannelID);
		ChatRegionInfo chatRegionInfo = LocalResources.ChatRegionTable.Find(chatChannelInfo.regionID);
		m_TitleText.text = string.Format(m_TitleFormat, chatRegionInfo.Name, chatChannelInfo.number);
		m_Messages.Clear();
		bool flag = m_LastChannelID != PublicChatManager.ChannelID;
		if (flag)
		{
			m_InputField.GetComponent<SensitiveWordFilter>().SetMaxInputCount(30);
			m_InputField.placeholder.GetComponent<Text>().text = Localization.TipsAntiFraud;
			m_LastChannelID = PublicChatManager.ChannelID;
			m_DataScrollView.ClearItems();
			m_DataScrollView.m_TemplateInitiator.UpdateImmediately();
			PublicChatManager.Inst.ExtractChannelCache(m_Messages);
		}
		else
		{
			PublicChatManager.Inst.ExtractPublicMessages(m_Messages);
		}
		if (m_Messages.Count > 0)
		{
			args.Clear();
			for (int i = 0; i < m_Messages.Count; i++)
			{
				args[i]["roleID"] = m_Messages[i].senderID;
				if (m_Messages[i].senderID == LocalPlayerDatabase.LoginInfo.roleID)
				{
					args[i]["sender"] = Localization.Me;
					m_Messages[i].info.activeHeadBoxID = LocalPlayerDatabase.PlayerInfo.activeHeadBoxID;
				}
				else
				{
					args[i]["sender"] = m_Messages[i].info.name;
				}
				args[i]["content"] = m_Messages[i].content;
				args[i]["icon"] = m_Messages[i].info.icon;
				args[i]["sex"] = m_Messages[i].info.sex;
				args[i]["activeHeadBoxID"] = m_Messages[i].info.activeHeadBoxID;
				args[i]["activeBubbleBoxID"] = m_Messages[i].info.activeBubbleBoxID;
				args[i]["membership"] = MembershipUtility.IsInTime(0, m_Messages[i].info.membershipInfo);
			}
			m_DataScrollView.AddItems(args.Array);
			m_DataScrollView.m_TemplateInitiator.UpdateImmediately();
		}
		UIScrollRect scrollRect = m_DataScrollView.m_ScrollRect;
		if ((scrollRect.ContentPos > scrollRect.ContentSize - scrollRect.ViewSize - 150f) | flag)
		{
			m_DataScrollView.m_ScrollRect.ScrollToEnd(flag);
		}
		if (m_Messages.Count > 0 && m_DataScrollView.ItemCount > 1000)
		{
			int count = m_DataScrollView.ItemCount / 2;
			m_DataScrollView.RemoveItems(0, count, stayContentPos: true);
		}
		m_Send.OnButtonDown = OnSendClicked;
		m_CoolDown.OnButtonDown = OnCoolDownButtonClicked;
		m_Host.EventProxy(m_ChannelButton, "OnChannelButtonClick");
		m_Host.EventProxy(m_EmojiBuntton, "OnEmojiButtonClicked");
		m_InputField.onEndEdit.RemoveListener(OnEndEdit);
		m_InputField.onEndEdit.AddListener(OnEndEdit);
		StartCoolDown();
	}

	private void OnEndEdit(string text)
	{
		UnityEngine.Debug.Log("OnEndEdit: " + text);
	}

	private void StartCoolDown()
	{
		if (m_Coroutine != null)
		{
			m_Host.StopCoroutine(m_Coroutine);
		}
		m_Coroutine = m_Host.StartCoroutine(UpdateCoolDownState());
	}

	private IEnumerator UpdateCoolDownState()
	{
		bool cooling = true;
		while (cooling)
		{
			float num = Time.realtimeSinceStartup - LastSendTime;
			float num2 = 5f;
			cooling = (LastSendTime > 0f && num < num2);
			int num3 = Mathf.CeilToInt(Mathf.Max(0f, num2 - num));
			m_Send.gameObject.SetActive(!cooling);
			m_CoolDown.gameObject.SetActive(cooling);
			m_CoolDownText.text = string.Format(m_CoolDownFormat, num3);
			yield return new WaitForSeconds(1f);
		}
	}

	private void OnSendMsg(string msg)
	{
		if (!m_Send.gameObject.activeSelf || !AntiAddictionUtility.CheckCanSendInput(SpeakType.PublicChat))
		{
			return;
		}
		if (LocalPlayerDatabase.PlayerInfo.publicInfo.gradePolice < LocalPlayerDatabase.Settings.unlockChatGrade && LocalPlayerDatabase.PlayerInfo.publicInfo.gradeThief < LocalPlayerDatabase.Settings.unlockChatGrade)
		{
			GradeMappingInfo mapping;
			GradeInfo gradeInfo = LocalResources.GetGradeInfo(LocalPlayerDatabase.Settings.unlockChatGrade, out mapping);
			UILobby.Current.ShowTips(string.Format(Localization.TipsUnlockChatGrade, LocalResources.GetGradeName(gradeInfo, mapping)));
			return;
		}
		if (LocalPlayerDatabase.PrivatePlayerInfo.forbidChatTime > UtcTimeStamp.Now)
		{
			TimeSpan timeSpan = new TimeSpan(0, 0, LocalPlayerDatabase.PrivatePlayerInfo.forbidChatTime - UtcTimeStamp.Now);
			string arg = (timeSpan.Days > 0) ? (timeSpan.Days + Localization.Day) : string.Empty;
			UILobby.Current.ShowTips(string.Format(Localization.TipsPublicChatForbit, arg + timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds));
			return;
		}
		SoundManager.PlayOnce(PublicChatManager.Inst.m_SendSound);
		msg = msg.Trim().Replace(" ", "\u00a0").Replace("\r", "")
			.Replace("\n", "");
		if (!string.IsNullOrEmpty(msg))
		{
			PublicChatManager.Inst.SendChat(msg);
			m_DataScrollView.m_ScrollRect.ScrollToEnd(immediately: true);
			LastSendTime = Time.realtimeSinceStartup;
			StartCoolDown();
			ClearInput();
		}
	}

	public void OnSendClicked(UIShortcutSelectable.OperationType opType)
	{
		if (LocalPlayerDatabase.Settings.disablePublicChat)
		{
			UILobby.Current.ShowTips(Localization.TipsFuntionFixing);
		}
		else if (HeadBubbleBoxUtility.CheckExpiredTime(HeadBubbleBox.BubbleBox))
		{
			UILobby.Current.ShowTips(Localization.BubbleBoxExpiredTips);
		}
		else
		{
			OnSendMsg(m_InputField.text);
		}
	}

	public void OnChannelButtonClick()
	{
		LobbyScene.Inst.ChatPanel.ShowChatChannelUI();
	}

	public void OnCoolDownButtonClicked(UIShortcutSelectable.OperationType opType)
	{
		UILobby.Current.ShowTips(Localization.TipsChatCoolDowning);
	}

	public void OnEmojiButtonClicked()
	{
		if (m_ChatPanel != null)
		{
			m_ChatPanel.ToggleEmojiPanel();
		}
	}

	private void ClearInput()
	{
		m_InputField.text = "";
	}
}
