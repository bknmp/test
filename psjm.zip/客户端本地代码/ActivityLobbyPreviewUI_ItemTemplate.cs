using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class ActivityLobbyPreviewUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Time;

	public RemoteTexture m_RawImage;

	public Text m_Name;

	public MultiTargetGraphicButton m_Button;

	private ActivityLobby m_activityLobby;

	private Activity m_activity;

	public void Bind(CommonDataCollection args)
	{
		if (m_activityLobby == null)
		{
			m_activityLobby = m_Host.GetComponentInParent<ActivityLobby>();
		}
		m_activity = (args["Activity"].val as Activity);
		m_RawImage.SetTexture(m_activity.previewPictureUrl);
		ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(m_activity.activityId);
		m_Name.text = activityLobbyInfo.TitleName;
		m_Time.text = UITimeText.GetDateTime(m_activity.startTime) + "-" + UITimeText.GetDateTime(m_activity.endTime);
		m_Host.EventProxy(m_Button, "OnClick");
	}

	public void OnClick()
	{
		ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(m_activity.activityId);
		if (activityLobbyInfo.CollectionType == ActivityCollectionType.ACTIVITY_LOBBY)
		{
			int selectedTabIndex = m_activityLobby.ActivityLobbyTabPageIndex(m_activity.previewPictureUrl);
			m_activityLobby.m_DataTabPage.TabPage.SetSelectedTabIndex(selectedTabIndex);
		}
		else if (activityLobbyInfo.CollectionType == ActivityCollectionType.ANNIVERSART_ACTIVITY)
		{
			AnniversaryActivityUI component = JumpModuleManager.Inst.DoJump(JumpModule.AnniversaryActivity).GetComponent<AnniversaryActivityUI>();
			int index = m_activityLobby.ActivityLobbyTabPageIndex(m_activity.previewPictureUrl);
			component.JumpTabByIndex(index);
		}
		else if (activityLobbyInfo.CollectionType == ActivityCollectionType.LOVER_ACTIVITY)
		{
			AnniversaryActivityUI component2 = JumpModuleManager.Inst.DoJump(JumpModule.LoverActivity).GetComponent<AnniversaryActivityUI>();
			int index2 = m_activityLobby.ActivityLobbyTabPageIndex(m_activity.previewPictureUrl);
			component2.JumpTabByIndex(index2);
		}
		else
		{
			UILobby.Current.ShowTips("暂不支持此跳转");
		}
	}
}
