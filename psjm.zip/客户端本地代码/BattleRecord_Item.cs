using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

public class BattleRecord_Item
{
	public UIDataBinder m_Host;

	public UIStateItem m_Result;

	public UnionBadgeItem m_UnionBadge;

	public Text m_Time;

	public Button m_BattleItem;

	public UIPopup m_GameDetailUI;

	private int m_Index;

	private string m_UnionName;

	private UnionBattleRecord m_RecordInfo;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["index"];
		m_UnionName = args["unionName"];
		bool flag = args["isPopUp"];
		m_RecordInfo = UnionBattleRecord_Binder.m_BattleRecordList[m_Index];
		m_Result.State = m_RecordInfo.result;
		m_UnionBadge.SetBadge(m_RecordInfo.enemyUnion.badge, 0, m_RecordInfo.enemyUnion.name);
		m_Time.text = UtcTimeStamp.GetDate(m_RecordInfo.battleTime).ToString("MM/dd HH:mm");
		m_Host.GetComponent<Image>().color = ((!flag || m_Index % 2 == 0) ? "FFFFFFFF".ToColor() : "FFFFFF00".ToColor());
		m_Host.EventProxy(m_BattleItem, "ShowDetailRecord");
	}

	public void ShowDetailRecord()
	{
		UILobby.Current.Popup(m_GameDetailUI);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["roomID"].val = m_RecordInfo.twoRoomId;
		commonDataCollection["title"] = Localization.UnionBattle;
		commonDataCollection["time"] = m_RecordInfo.battleTime;
		commonDataCollection["useTime"].val = m_RecordInfo.playTime;
		commonDataCollection["mapType"] = (int)m_RecordInfo.map;
		commonDataCollection["local"] = false;
		commonDataCollection["UnionBattle"] = 0;
		commonDataCollection["unionName"].val = new string[2]
		{
			"<color=#FFFA5AFF>" + m_UnionName + "</color>",
			m_RecordInfo.enemyUnion.name
		};
		UILobby.Current.CurrentPopup().GetComponent<UIDataBinder>().Args = commonDataCollection;
	}
}
