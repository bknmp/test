using GameMessages;
using LightUI;
using System;

internal class CommonBoxOpenUI : SupplyBoxOpenUI
{
	public override void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_OK, "OnCloseClicked");
		m_Skip.onButtonClicked.RemoveAllListeners();
		m_Skip.onButtonClicked.AddListener(base.OnSkipValueChanged);
		m_Skip.Toggle(SupplyUtility.Skip);
		int boxID = args["id"];
		m_Items = (ItemInfo[])args["items"].val;
		m_OpenType = (OpenSupplyBoxType)(int)args["openType"];
		OnOpenSupplyBox(boxID, m_Items, m_OpenType);
		m_Open = (Action<OpenSupplyBoxType, ItemInfo[]>)args["onOpen"].val;
	}

	protected override void OnOpenSupplyBox(int boxID, ItemInfo[] items, OpenSupplyBoxType openType)
	{
		m_Items = items;
		m_OpenType = openType;
		AddItems(items);
		StartCoroutineWrapper(Playing());
	}
}
