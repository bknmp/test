using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CardButton
{
	private enum TipsState
	{
		None,
		NewCard,
		ComposeCard,
		Upgrade,
		NewSkin,
		NewArrival,
		UnlockCard,
		CanUnlockCardSkin
	}

	public UIDataBinder m_Host;

	public Button m_Button;

	public UIPage m_CardConfigEditPage;

	public UIStateItem m_RedPoint;

	public Text m_Count;

	public GameObject m_UniversalPieceTips;

	public void Bind(CommonDataCollection args)
	{
		NewCardSkinTips.Inst.CheckOutOfDate();
		m_Host.EventProxy(m_Button, "OnClicked");
		int num = 0;
		if (GetTipsState() != 0)
		{
			if (CardUtility.AnyCanComposeCard())
			{
				m_RedPoint.State = 0;
				m_RedPoint.gameObject.SetActive(value: true);
			}
			else if ((num = CardConfigEditPage_ItemTemplate.UpgradableCardNum) > 0)
			{
				m_RedPoint.State = 1;
				m_Count.text = num.ToString();
				m_RedPoint.gameObject.SetActive(value: true);
			}
			else
			{
				m_RedPoint.State = 0;
				m_RedPoint.gameObject.SetActive(value: true);
			}
		}
		else
		{
			m_RedPoint.gameObject.SetActive(value: false);
		}
		m_UniversalPieceTips.SetActive(UniversalPieceCtrl.IsExchangeOpen() && !LocalPlayerDatabase.GetPrefValue("HadOpenUniversalPiecePage"));
	}

	private int GetTipsState()
	{
		if (CardUtility.NewUnlockCardIDs.Count > 0)
		{
			return 6;
		}
		if (NewCardSkinTips.HaveCardSkinCanUnlock())
		{
			return 7;
		}
		if (NewArrivalUtility.CardNewArrival() && !CardConfigEditPage.HadEnteyCardPage)
		{
			return 5;
		}
		if (CardUtility.AnyCanComposeCard())
		{
			return 2;
		}
		if (CardConfigEditPage_ItemTemplate.UpgradableCardNum > 0)
		{
			return 3;
		}
		if (NewCardSkinTips.Inst.HaveNew())
		{
			return 4;
		}
		return 0;
	}

	public void OnClicked()
	{
		UILobby.Current.ShowUI(m_CardConfigEditPage, null);
	}
}
