using UnityEngine;

public class ConnectPreviewObject : SelectableSectorObject
{
	protected override void InitCheckList()
	{
		base.InitCheckList();
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			SelectableInfo item = new SelectableInfo(UserId2NumId.Get(allPlayer.UserId), allPlayer.LocalNum, 0, allPlayer.transform);
			m_CheckList.Add(item);
		}
	}

	protected override bool CheckTargetConditionAndSetWeight(float sqrDis, ref SelectableInfo status)
	{
		PlayerController playerController = PlayerController.FindPlayer(status.numID, status.localNum);
		if (playerController != null && playerController.UserId != m_PlayerController.UserId && playerController.InSameTeam(m_PlayerController) && !playerController.FinalDeadOrEscaped && !playerController.IsPuppet)
		{
			base.CheckTargetConditionAndSetWeight(sqrDis, ref status);
			if (ForbidEscapeArea(status.transform.position))
			{
				return false;
			}
			bool flag = InSectorRange(sqrDis, status.transform.position);
			if (base.SectorShowing && !flag)
			{
				status.numID = 0;
				status.localNum = 0;
				return false;
			}
			status.numID = UserId2NumId.Get(playerController.UserId);
			status.localNum = playerController.LocalNum;
			status.weight = Mathf.Min(1f / sqrDis, 3f) + ((!playerController.IsDying) ? 1f : 0f) * 3f;
			return true;
		}
		return false;
	}

	private bool ForbidEscapeArea(Vector3 targetPos)
	{
		Vector3 position = PlayerController.Inst.PhysicsBody.position;
		if (EscapeAreaGuard.InEscapeArea(targetPos, 0f) && EscapeAreaGuard.InEscapeArea(position, 0f))
		{
			return false;
		}
		if (!EscapeAreaGuard.InEscapeArea(targetPos, 0f) && !EscapeAreaGuard.InEscapeArea(position, 0f))
		{
			return false;
		}
		return true;
	}
}
