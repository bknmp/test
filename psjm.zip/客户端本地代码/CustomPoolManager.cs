using LightUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;

public class CustomPoolManager : MonoBehaviour
{
	private class Pool
	{
		public Queue<GameObject> queue;

		public int capacity = 10;
	}

	private Dictionary<string, Pool> m_Pools = new Dictionary<string, Pool>(32);

	private List<string> m_ReservedPrefabs = new List<string>();

	private List<GameObject> m_WarmingUpPrefabs = new List<GameObject>();

	private List<GameObject> m_WarmingUpInstances = new List<GameObject>();

	private List<GameObject> m_ReferencePrefabs = new List<GameObject>();

	private List<Renderer> m_Renderers = new List<Renderer>();

	private List<Material> m_Materials = new List<Material>();

	private List<string> m_ReservedMaterials = new List<string>();

	private Transform m_ReserveRoot;

	private Vector3 m_ReservePos = new Vector3(-100f, -100f, -100f);

	private Camera m_ReserveCamera;

	private float m_BackupVolume;

	private Mesh m_Mesh;

	private string[] m_IgnoreMaterials = new string[1]
	{
		"Sprites-Default"
	};

	private string[] m_CanReserveds = new string[2]
	{
		"ImprisonAppearance",
		"ImprisonPreview"
	};

	public static CustomPoolManager Inst;

	public int ReservedCount
	{
		get
		{
			if (Inst == null)
			{
				return 0;
			}
			if (Inst.m_ReserveRoot == null)
			{
				return 0;
			}
			return Inst.m_ReserveRoot.childCount;
		}
	}

	private void Awake()
	{
		if (Inst == null)
		{
			Inst = this;
		}
		else
		{
			UnityEngine.Object.Destroy(this);
		}
	}

	private void Start()
	{
		InitRoots();
		StartCoroutine(WarmingUp());
	}

	private void OnDestroy()
	{
		Clear();
		m_Pools.Clear();
		if (Inst == this)
		{
			Inst = null;
		}
	}

	private void Clear()
	{
		m_ReservedPrefabs.Clear();
		m_WarmingUpPrefabs.Clear();
		m_WarmingUpInstances.Clear();
		m_ReferencePrefabs.Clear();
		m_Renderers.Clear();
		m_Materials.Clear();
		m_ReservedMaterials.Clear();
		UnityEngine.Object.Destroy(m_Mesh);
	}

	private void InitRoots()
	{
		GameObject gameObject = new GameObject("Reserve Root");
		m_ReserveRoot = gameObject.transform;
		m_ReserveRoot.position = m_ReservePos;
		m_ReserveRoot.SetParent(base.transform);
	}

	private void AddWarmingCamera()
	{
		Camera camera = new GameObject("Reserve Camera").AddComponent<Camera>();
		camera.clearFlags = CameraClearFlags.Color;
		camera.farClipPlane = 50f;
		camera.useOcclusionCulling = false;
		camera.allowHDR = false;
		camera.allowMSAA = false;
		camera.depth = -100f;
		camera.fieldOfView = 50f;
		camera.transform.SetParent(base.transform);
		camera.transform.position = m_ReservePos + new Vector3(0f, 0f, -10f);
		m_ReserveCamera = camera;
		m_BackupVolume = AudioListener.volume;
		AudioListener.volume = 0f;
	}

	private void RemoveWarmingCamera()
	{
		AudioListener.volume = m_BackupVolume;
		if (m_ReserveCamera != null)
		{
			UnityEngine.Object.Destroy(m_ReserveCamera.gameObject);
		}
	}

	private void WarmingInstances(bool warming)
	{
		foreach (GameObject warmingUpInstance in m_WarmingUpInstances)
		{
			try
			{
				if (warming)
				{
					warmingUpInstance.transform.SetParent(m_ReserveRoot);
					warmingUpInstance.transform.localPosition = UnityEngine.Random.insideUnitCircle.ExpandZ() * 3f;
					warmingUpInstance.SetActive(value: true);
				}
				else
				{
					PoolSpawner.DeSpawn(warmingUpInstance);
				}
			}
			catch (Exception ex)
			{
				UnityEngine.Debug.LogError(ex.Message);
			}
		}
	}

	private IEnumerator WarmingUp()
	{
		UnityEngine.Debug.Log("WarmingUp Start... ");
		AddWarmingCamera();
		CollectReservedPrefabs();
		WarmingPrefabs();
		yield return null;
		WarmingInstances(warming: true);
		yield return Yielders.GetWaitForSeconds(0.5f);
		WarmingInstances(warming: false);
		yield return Yielders.GetWaitForSeconds(0.5f);
		RemoveWarmingCamera();
		Clear();
		UnityEngine.Debug.Log("WarmingUp End... ");
	}

	private void CollectReservedPrefabs()
	{
		try
		{
			CollectReservedCards();
			CollectReservedOthers();
		}
		catch (Exception ex)
		{
			UnityEngine.Debug.LogError("AddReserves " + ex.Message);
		}
	}

	private void WarmingPrefabs()
	{
		List<string> list = new List<string>();
		foreach (string reservedPrefab in m_ReservedPrefabs)
		{
			if (!list.Contains(reservedPrefab))
			{
				list.Add(reservedPrefab);
			}
		}
		m_WarmingUpPrefabs.Clear();
		m_WarmingUpInstances.Clear();
		m_ReservedMaterials.Clear();
		m_ReservedMaterials.AddRange(m_IgnoreMaterials);
		foreach (string item3 in list)
		{
			GameObject gameObject = PrefabSource.Inst.Load(item3);
			if (!(gameObject == null))
			{
				GameObject item = InstantiateCleanObject(gameObject);
				m_WarmingUpInstances.Add(item);
				m_WarmingUpPrefabs.Add(gameObject);
				foreach (GameObject referencePrefab in GetReferencePrefabs(gameObject))
				{
					if (!m_WarmingUpPrefabs.Contains(referencePrefab))
					{
						m_WarmingUpPrefabs.Add(referencePrefab);
						GameObject item2 = (referencePrefab.GetComponent<Poolable>() != null && m_CanReserveds.Contains(referencePrefab.name)) ? PoolSpawner.Spawn(referencePrefab) : InstantiateCleanObject(referencePrefab);
						m_WarmingUpInstances.Add(item2);
					}
				}
			}
		}
	}

	private List<GameObject> GetReferencePrefabs(GameObject prefab)
	{
		m_ReferencePrefabs.Clear();
		MonoBehaviour[] components = prefab.GetComponents<MonoBehaviour>();
		foreach (MonoBehaviour monoBehaviour in components)
		{
			if (!(monoBehaviour != null))
			{
				continue;
			}
			FieldInfo[] fields = monoBehaviour.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
			for (int j = 0; j < fields.Length; j++)
			{
				GameObject gameObject = fields[j].GetValue(monoBehaviour) as GameObject;
				if (gameObject != null && gameObject.GetComponent<Poolable>() != null)
				{
					GameObject item = gameObject;
					m_ReferencePrefabs.Add(item);
				}
			}
		}
		return m_ReferencePrefabs;
	}

	private void CollectReservedCards()
	{
		foreach (RuntimePlayerInfo value in GameRuntime.RoomPlayers.Values)
		{
			int[] cards = value.MatchData.cards;
			int[] cardSkins = value.MatchData.cardSkins;
			int[] cardStyles = value.MatchData.cardStyles;
			int[] array = cards;
			foreach (int num in array)
			{
				string cardPrefab = GetCardPrefab(num, cards, cardSkins, cardStyles);
				if (!string.IsNullOrEmpty(cardPrefab))
				{
					m_ReservedPrefabs.Add(cardPrefab);
					if (LocalResources.InGameStoreTable.Get(num).Type == InGameStoreType.Weapon)
					{
						string item = cardPrefab.Remove(cardPrefab.Length - 1, 1) + "2";
						string item2 = cardPrefab.Remove(cardPrefab.Length - 1, 1) + "3";
						m_ReservedPrefabs.Add(item);
						m_ReservedPrefabs.Add(item2);
					}
				}
			}
		}
	}

	private string GetCardPrefab(int cardID, int[] cards, int[] cardSkins, int[] cardStyles)
	{
		if (cardID == 0)
		{
			return null;
		}
		if (LocalResources.InGameStoreTable.Get(cardID).Type == InGameStoreType.Magazine)
		{
			return null;
		}
		if (cardStyles != null && cardStyles.Length == cards.Length)
		{
			for (int i = 0; i < cardStyles.Length; i++)
			{
				if (cards[i] == cardID)
				{
					if (cardStyles[i] <= 0)
					{
						break;
					}
					return CardUtility.GetBaseCardSkinInfo(cardStyles[i]).Prefabs;
				}
			}
		}
		for (int j = 0; j < cards.Length && j < cardSkins.Length; j++)
		{
			if (cards[j] == cardID)
			{
				return CardUtility.GetBaseCardSkinInfo(cardSkins[j]).Prefabs;
			}
		}
		return null;
	}

	private GameObject InstantiateCleanObject(GameObject prefab)
	{
		m_Renderers.Clear();
		m_Materials.Clear();
		GameObject gameObject = new GameObject(prefab.name);
		try
		{
			prefab.GetComponentsInChildren(includeInactive: true, m_Renderers);
			foreach (Renderer renderer in m_Renderers)
			{
				if (renderer != null)
				{
					Material[] sharedMaterials = renderer.sharedMaterials;
					foreach (Material material in sharedMaterials)
					{
						if (material != null && !m_Materials.Contains(material) && !m_ReservedMaterials.Contains(material.name))
						{
							m_Materials.Add(material);
							m_ReservedMaterials.Add(material.name);
						}
					}
				}
			}
			if (m_Materials.Count > 0)
			{
				if (m_Mesh == null)
				{
					Mesh mesh = new Mesh();
					mesh.vertices = new Vector3[4]
					{
						new Vector3(0f, 0f, 0f),
						new Vector3(0f, 1f, 0f),
						new Vector3(1f, 1f, 0f),
						new Vector3(1f, 0f, 0f)
					};
					mesh.uv = new Vector2[4]
					{
						new Vector2(1f, 1f),
						new Vector2(1f, 0f),
						new Vector2(0f, 0f),
						new Vector2(0f, 1f)
					};
					mesh.triangles = new int[12]
					{
						2,
						1,
						0,
						0,
						3,
						2,
						0,
						1,
						2,
						2,
						3,
						0
					};
					m_Mesh = mesh;
				}
				gameObject.AddComponent<MeshFilter>().mesh = m_Mesh;
				MeshRenderer meshRenderer = gameObject.AddComponent<MeshRenderer>();
				meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
				meshRenderer.receiveShadows = false;
				meshRenderer.lightProbeUsage = LightProbeUsage.Off;
				meshRenderer.reflectionProbeUsage = ReflectionProbeUsage.Off;
				meshRenderer.materials = m_Materials.ToArray();
			}
			gameObject.SetActive(value: false);
		}
		catch (Exception ex)
		{
			UnityEngine.Debug.LogError("CleanObject " + ex.Message);
		}
		m_Renderers.Clear();
		m_Materials.Clear();
		return gameObject;
	}

	private void CollectReservedOthers()
	{
		foreach (RuntimePlayerInfo value in GameRuntime.RoomPlayers.Values)
		{
			if (value.CharacterInfo.characterID == 700)
			{
				m_ReservedPrefabs.Add("能量禁锢");
				break;
			}
		}
	}
}
