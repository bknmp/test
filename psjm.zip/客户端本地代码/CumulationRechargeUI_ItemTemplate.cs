using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine.UI;

internal class CumulationRechargeUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiatorHorizontal;

	public UIStateItem m_Btns;

	public Text m_TargetText;

	public MultiTargetGraphicButton m_GotoRecharge;

	public MultiTargetGraphicButton m_ClaimBtn;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public UIDataBinder m_CumulationRechargeUI;

	private string m_TargetTextFormat;

	private CumulationRechargeInfo m_cumulationRechargeInfo;

	private Activity m_activity;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TargetTextFormat))
		{
			m_TargetTextFormat = m_TargetText.text;
		}
		m_cumulationRechargeInfo = (args["CumulationRechargeInfo"].val as CumulationRechargeInfo);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < m_cumulationRechargeInfo.item.Length; i++)
		{
			commonDataCollection[i]["dropItemInfo"].val = m_cumulationRechargeInfo.item[i];
		}
		m_TemplateInitiatorHorizontal.Args = commonDataCollection;
		DataItem dataItem = args["rechargeNum"];
		m_activity = (args["Activity"].val as Activity);
		m_TargetText.text = string.Format(m_TargetTextFormat, dataItem, m_cumulationRechargeInfo.targetNum);
		m_TargetText.gameObject.SetActive(!m_cumulationRechargeInfo.received);
		if (m_cumulationRechargeInfo.received)
		{
			m_Btns.State = 2;
		}
		else if ((int)dataItem < m_cumulationRechargeInfo.targetNum)
		{
			m_Btns.State = 0;
		}
		else
		{
			m_Btns.State = 1;
		}
		m_Host.EventProxy(m_ClaimBtn, "OnClickClaim");
		m_Host.EventProxy(m_GotoRecharge, "GotoRecharge");
	}

	public void OnClickClaim()
	{
		HttpRequestCumulationRechargeReceive httpRequestCumulationRechargeReceive = new HttpRequestCumulationRechargeReceive();
		httpRequestCumulationRechargeReceive.id = m_cumulationRechargeInfo.id;
		httpRequestCumulationRechargeReceive.activityId = m_activity.activityId;
		GameHttpManager.Inst.Send(httpRequestCumulationRechargeReceive, delegate(HttpResponseCumulationRechargeReceive onResponse)
		{
			m_CumulationRechargeUI.UpdateBinding();
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.SetTitleAndTips("", "");
			commonRewardPopupUI.AddItems(onResponse.item);
		});
	}

	public void OnClickHadClaim()
	{
		UILobby.Current.ShowTips(Localization.hadClaim);
	}

	public void GotoRecharge()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.Recharge);
	}
}
