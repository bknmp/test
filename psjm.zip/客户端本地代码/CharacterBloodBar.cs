using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class CharacterBloodBar : MonoBehaviour
{
	public Image m_Bar;

	public Image m_SecondaryBar;

	public Image m_Shield;

	public float m_SplitUnit;

	public float m_SplitSpacing;

	private float m_CurrentLife;

	private float m_CurrentMaxLife;

	private float m_CurrentShield;

	private float m_Total;

	private Tweener m_LifeTweener;

	private Tweener m_ShieldTweener;

	private Tweener m_TotalTweener;

	private Slider m_Slier;

	private RectTransform m_RectTransform;

	private UIShaderProgress m_ShaderProgress;

	private UIShaderProgress m_SecondaryShaderProgress;

	private UIShaderProgress m_ShieldShaderProgress;

	public bool DisableAutoLength
	{
		get;
		set;
	}

	private void Awake()
	{
		if (m_Bar != null)
		{
			m_ShaderProgress = m_Bar.AddUIShaderProgress();
		}
		if (m_SecondaryBar != null)
		{
			m_SecondaryShaderProgress = m_SecondaryBar.AddUIShaderProgress();
		}
		if (m_Shield != null)
		{
			m_ShieldShaderProgress = m_Shield.AddUIShaderProgress();
		}
	}

	private void Start()
	{
		FixPrefab();
	}

	private void FixPrefab()
	{
		if (!DisableAutoLength)
		{
			if (m_Bar != null)
			{
				m_Bar.type = Image.Type.Tiled;
				m_ShaderProgress.UpdateTilingFactor();
			}
			if (m_SecondaryBar != null)
			{
				m_SecondaryBar.type = Image.Type.Tiled;
				m_SecondaryShaderProgress.UpdateTilingFactor();
			}
			if (m_Shield != null)
			{
				m_Shield.type = Image.Type.Tiled;
				m_ShieldShaderProgress.UpdateTilingFactor();
			}
		}
		Transform transform = base.transform.Find("Frame");
		if (transform != null)
		{
			UnityEngine.Object.Destroy(transform.gameObject);
		}
		Transform transform2 = base.transform.Find("Image");
		if (transform2 != null)
		{
			UnityEngine.Object.Destroy(transform2.gameObject);
		}
	}

	private bool Approximately(float a, float b)
	{
		return Mathf.Abs(a - b) < 0.01f;
	}

	private void UpdateTiling()
	{
		if (m_ShaderProgress != null)
		{
			m_ShaderProgress.UpdateTilingFactor();
		}
		if (m_SecondaryShaderProgress != null)
		{
			m_SecondaryShaderProgress.UpdateTilingFactor();
		}
		if (m_ShieldShaderProgress != null)
		{
			m_ShieldShaderProgress.UpdateTilingFactor();
		}
	}

	public virtual void SetProgress(float life, float maxLife, float shield, float total = 0f, bool killTween = false)
	{
		total = ((total == 0f) ? Mathf.Max(maxLife, life + shield) : total);
		bool flag = !Approximately(total, m_Total);
		if (!flag && Approximately(life, m_CurrentLife) && Approximately(shield, m_CurrentShield))
		{
			return;
		}
		if (killTween)
		{
			KillTween();
		}
		m_CurrentShield = shield;
		m_CurrentMaxLife = maxLife;
		m_CurrentLife = life;
		m_Total = total;
		float num = 0f;
		if (total > 0f)
		{
			num = Mathf.Clamp01(m_CurrentLife / Mathf.Max(total, 0.001f));
		}
		if (m_Bar != null)
		{
			SetBar(num);
		}
		else
		{
			if (m_Slier == null)
			{
				m_Slier = GetComponent<Slider>();
			}
			if (m_Slier != null)
			{
				m_Slier.value = num;
			}
		}
		if ((!DisableAutoLength && m_SplitUnit > 0.1f) & flag)
		{
			if (m_RectTransform == null)
			{
				m_RectTransform = GetComponent<RectTransform>();
			}
			m_RectTransform.sizeDelta = new Vector2(m_Total * m_SplitSpacing / m_SplitUnit, m_RectTransform.sizeDelta.y);
			UpdateTiling();
		}
		if (m_ShieldShaderProgress != null)
		{
			m_ShieldShaderProgress.Progress = ((shield > 0f) ? ((life + shield) / total) : 0f);
		}
	}

	protected virtual void SetBar(float ratio)
	{
		if (!(null == m_ShaderProgress))
		{
			m_ShaderProgress.Progress = ratio;
		}
	}

	public void TweenTo(float life, float maxLife, float shield, float duration, bool showSecondaryBarTween = false)
	{
		KillTween();
		if (life + shield < m_CurrentLife + m_CurrentShield && showSecondaryBarTween && m_SecondaryBar != null)
		{
			float num = m_CurrentLife + m_CurrentShield;
			SetProgress(life, maxLife, shield, m_Total);
			float endValue = Mathf.Clamp01((life + shield) / Mathf.Max(m_Total, 0.001f));
			float progress = Mathf.Clamp01(num / Mathf.Max(m_Total, 0.001f));
			m_SecondaryBar.gameObject.SetActive(value: true);
			if (null != m_SecondaryShaderProgress)
			{
				m_SecondaryShaderProgress.Progress = progress;
				m_SecondaryShaderProgress.DOProgress(endValue, 0.3f).SetDelay(0.2f).OnComplete(delegate
				{
					m_SecondaryBar.gameObject.SetActive(value: false);
				});
			}
		}
		else
		{
			m_CurrentMaxLife = maxLife;
			m_LifeTweener = DOTween.To(() => m_CurrentLife, delegate(float x)
			{
				SetProgress(x, m_CurrentMaxLife, m_CurrentShield, m_Total);
			}, life, duration);
			m_ShieldTweener = DOTween.To(() => m_CurrentShield, delegate(float x)
			{
				SetProgress(m_CurrentLife, m_CurrentMaxLife, x, m_Total);
			}, shield, duration);
		}
		float num2 = Mathf.Max(life + shield, maxLife);
		if (showSecondaryBarTween && num2 < m_Total)
		{
			m_TotalTweener = DOTween.To(() => m_Total, delegate(float x)
			{
				SetProgress(m_CurrentLife, m_CurrentMaxLife, m_CurrentShield, x);
			}, num2, duration).SetDelay(0.3f);
		}
		else
		{
			m_TotalTweener = DOTween.To(() => m_Total, delegate(float x)
			{
				SetProgress(m_CurrentLife, m_CurrentMaxLife, m_CurrentShield, x);
			}, num2, duration);
		}
	}

	private void KillTween()
	{
		if (m_LifeTweener != null)
		{
			m_LifeTweener.Kill();
		}
		if (m_TotalTweener != null)
		{
			m_TotalTweener.Kill();
		}
		if (m_ShieldTweener != null)
		{
			m_ShieldTweener.Kill();
		}
	}
}
