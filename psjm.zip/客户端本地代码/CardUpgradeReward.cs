using LightUtility;
using System;

[Serializable]
public class CardUpgradeReward : IdBased
{
	public string Desc;

	public int CardID;

	public int[] ItemID;

	public int[] ItemCount;
}
