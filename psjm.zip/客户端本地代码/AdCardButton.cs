using GameMessages;
using LightUI;
using UnityEngine;

public class AdCardButton : MonoBehaviour
{
	public UIPage m_CardLotteryOpenUI;

	public void OnClick()
	{
		BoxInfo m_BoxInfo = CardLotteryUtility.GetLotteryBox(CardLotteryType.Normal, LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade);
		AdScene adScene = AdScene.CARD_DRAW;
		if (AdUtility.IsAdEnable(adScene))
		{
			AdSDKManager.Inst.ShowAd(adScene, delegate
			{
				AdUtility.RequestRewards(adScene, 0, delegate
				{
					BoxUtility.RequestOpenBoxByID(m_BoxInfo.Id, delegate(ItemInfo[] items)
					{
						GetComponent<UIPopup>().GoBack();
						CardLotteryItem cardLotteryItem = LobbyScene.Inst.GetCardLotteryItem((CardLotteryType)m_BoxInfo.Type);
						CardLotteryUI.Inst.OnOpenBox(m_BoxInfo.Id, m_CardLotteryOpenUI, cardLotteryItem, items);
						LocalPlayerDatabase.RefreshCardLotteryInfo();
					}, null, 1);
				});
			});
		}
	}
}
