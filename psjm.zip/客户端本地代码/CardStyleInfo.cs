public class CardStyleInfo : BaseCardSkinInfo
{
	public int BasicCardSkinId;

	protected override BaseCardSkinInfo GetTypeParamSkin()
	{
		return LocalResources.CardStyleTable.Find(TypeParam);
	}

	protected override DropItem FindDropItemWithTypeIdAndType()
	{
		return LocalResources.FindDropItemFromTypeIdAndType(Id, DropItemType.CardStyle);
	}
}
