using LightUtility;
using UnityEngine;

public class CollisionStayListener : MonoBehaviour
{
	public Delegates.ObjectCallback<Collision> onCollisionStay;

	private void OnCollisionStay(Collision hit)
	{
		if (onCollisionStay != null)
		{
			onCollisionStay(hit);
		}
	}
}
