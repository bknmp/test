using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;

public class ActivityLobbyPage : MonoBehaviour
{
	public UIStateItem m_State;

	private Activity m_activity;

	private void OnEnable()
	{
		CheckTime();
	}

	public void SetTime(Activity activity)
	{
		m_activity = activity;
		CheckTime();
	}

	private void CheckTime()
	{
		if (m_activity != null)
		{
			int num = Mathf.Max(m_activity.endTime, m_activity.exchangeEndTime);
			m_State.State = ((UtcTimeStamp.Now > num) ? 1 : 0);
		}
		else
		{
			m_State.State = 1;
		}
	}
}
