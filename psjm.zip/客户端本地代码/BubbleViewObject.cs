using UnityEngine;

public class BubbleViewObject : FogViewObject
{
	private BubbleObject m_BubbleObject;

	public override void Initialized(PlayerController player)
	{
		base.Initialized(player);
		m_BubbleObject = GetComponent<BubbleObject>();
	}

	public override bool CanViewBy(PlayerController player)
	{
		if (base.CanViewBy(player))
		{
			return !m_BubbleObject.IsNetworkDestroyed;
		}
		return false;
	}

	public override bool CanShowInMiniMap(PlayerController player, InGameMinimap.IconTemplates iconTemplates, out RectTransform icon)
	{
		icon = null;
		if (m_BubbleObject == null)
		{
			return false;
		}
		return base.CanShowInMiniMap(player, iconTemplates, out icon);
	}
}
