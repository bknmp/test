using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class CardUpgradeUI
{
	public UIDataBinder m_Host;

	public Text m_CardName;

	public Image m_Frame;

	public Image m_Icon;

	public Text m_LevelFrom;

	public Text m_LevelTo;

	public Text m_AttributeDesc;

	public Text m_AttributeBase;

	public Text m_AttributeChange;

	public GameObject m_UnLockSkin;

	public Image m_CardSkinIcon;

	public Image m_AttributeIcon;

	public Button m_BackButton;

	public Text m_CardPieceNum;

	public Text m_CardSkinName;

	private string m_levelFormat;

	public AudioItemData m_Settlement;

	public AudioItemData m_ShowCardSound;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_levelFormat))
		{
			m_levelFormat = m_LevelFrom.text;
		}
		DataItem item = args["cardId"];
		DataItem dataItem = args["cardLevel"];
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(item);
		m_CardName.text = inGameStoreInfo.FullName;
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_Icon.sprite = SpriteSource.Inst.Find(CardUtility.GetSkinInfo(inGameStoreInfo).Icon);
		m_LevelFrom.text = string.Format(m_levelFormat, dataItem);
		int num = (int)dataItem + 1;
		m_LevelTo.text = string.Format(m_levelFormat, num);
		CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(item);
		float num2 = CardUtility.GetCardLevelGrowthResult(item, dataItem);
		if (cardGrowth.Type == CardGrowthType.SpeedRatio)
		{
			num2 = num2 * cardGrowth.DefaultValue / 2.8f - 1f;
			num2 *= 100f;
		}
		string text;
		string text2;
		if (cardGrowth.Type == CardGrowthType.Discount)
		{
			int cardPrice = CardConfigEditPage_DetailPage.GetCardPrice(item, num2);
			float cardLevelGrowthResult = CardUtility.GetCardLevelGrowthResult(item, num);
			int cardPrice2 = CardConfigEditPage_DetailPage.GetCardPrice(item, cardLevelGrowthResult);
			text = cardPrice.ToString();
			text2 = string.Format(cardGrowth.ChangeFormat, cardPrice - cardPrice2);
		}
		else
		{
			text = StringUtility.RemoveUselessZeroInDecimal(num2.ToString("F2"));
			if (cardGrowth.Type == CardGrowthType.SpeedRatio)
			{
				float num3 = Mathf.Abs(cardGrowth.Rate) * cardGrowth.DefaultValue / 2.8f;
				text2 = string.Format(cardGrowth.ChangeFormat, num3);
			}
			else
			{
				text2 = string.Format(cardGrowth.ChangeFormat, Mathf.Abs(cardGrowth.Rate));
			}
		}
		m_AttributeDesc.text = cardGrowth.AttrDesc[0];
		m_AttributeBase.text = text;
		m_AttributeChange.text = text2;
		m_AttributeIcon.sprite = SpriteSource.Inst.Find(cardGrowth.AttrIcon[0]);
		m_Host.StartCoroutine(AutoShowBackBtn());
		m_Host.StartCoroutine(CardPieceNumChange(CardUtility.GetCardGrowth(item).PieceCostNew[(int)dataItem - 1], 1f));
		m_Host.StartCoroutine(AutoPlayAudio());
		foreach (int item2 in ShopUtility.CardSkinDict[item])
		{
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(item2);
			if (cardSkinInfo.UnlockLevel == num)
			{
				m_UnLockSkin.gameObject.SetActive(value: true);
				m_CardSkinName.text = cardSkinInfo.Name;
				m_CardSkinIcon.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(cardSkinInfo.DropId).Icon);
				CardConfigEditPage_CardSkinItemTemplate.globalSelected = cardSkinInfo.Id;
				UIDataEvents.Inst.InvokeEvent("CardConfigSkinSelectedChanged");
				return;
			}
		}
		m_UnLockSkin.gameObject.SetActive(value: false);
	}

	private IEnumerator AutoShowBackBtn()
	{
		m_BackButton.gameObject.SetActive(value: false);
		yield return Yielders.GetWaitForSeconds(2.5f);
		m_BackButton.gameObject.SetActive(value: true);
	}

	private IEnumerator CardPieceNumChange(int maxNum, float time)
	{
		int newValue = maxNum;
		float speed = (float)maxNum / time;
		if ((bool)m_Settlement)
		{
			SoundManager.PlayOnce(m_Settlement.Item);
		}
		while (newValue > 0)
		{
			newValue -= (int)(speed * Time.deltaTime);
			SetCardPieceNum(Mathf.Max(0, newValue), maxNum);
			yield return null;
		}
	}

	private IEnumerator AutoPlayAudio()
	{
		yield return Yielders.GetWaitForSeconds(1.8f);
		if ((bool)m_ShowCardSound)
		{
			SoundManager.PlayOnce(m_ShowCardSound.Item);
		}
		yield return Yielders.GetWaitForSeconds(0.2f);
		if ((bool)m_ShowCardSound)
		{
			SoundManager.PlayOnce(m_ShowCardSound.Item);
		}
	}

	private void SetCardPieceNum(int cur, int max)
	{
		m_CardPieceNum.text = cur + "/" + max;
	}
}
