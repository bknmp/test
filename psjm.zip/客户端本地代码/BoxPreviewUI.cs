using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class BoxPreviewUI : BoxPreview
{
	public UIProgressBar m_Bar;

	public Image m_ScoreBoxIcon;

	public Text m_BuyDiamond;

	public UIStateRawImage m_Mirror;

	public UIDataBinder m_Gift;

	public GameObject m_InGameBG;

	public UIDataBinder m_Content;

	public Image m_TimeBoxIcon;

	private string m_ArenaFormat;

	private string m_ProgressFormat;

	private ScoreBoxItemInfo m_ScoreBoxInfo;

	private int m_ShopID;

	public new void Bind(CommonDataCollection args)
	{
		base.Bind(args);
		int num = args["shopID"];
		m_InGameBG.SetActive(InGameScene.Inst != null);
		m_Host.EventProxy(m_BuyButton, "BuyBoxClicked");
		m_ShopID = num;
		bool num2 = boxID == LocalPlayerDatabase.BoxListInfo.scoreBox.boxID;
		string icon = boxItemInfo.Icon;
		if (num2)
		{
			m_BoxInfo = null;
			m_ScoreBoxInfo = LocalPlayerDatabase.BoxListInfo.scoreBox;
			m_Bar.SetProgress(m_ScoreBoxInfo.progress, boxItemInfo.NeedPoint);
			m_State.State = ((m_ScoreBoxInfo.progress >= boxItemInfo.NeedPoint) ? 3 : 0);
			m_ScoreBoxIcon.sprite = SpriteSource.Inst.Find(icon);
			m_ScoreBoxIcon.transform.parent.gameObject.SetActive(value: true);
			m_TimeBoxIcon.transform.parent.gameObject.SetActive(value: false);
			m_Mirror.gameObject.SetActive(value: false);
		}
		else
		{
			m_ScoreBoxInfo = null;
			m_TimeBoxIcon.sprite = SpriteSource.Inst.Find(icon);
			m_TimeBoxIcon.transform.parent.gameObject.SetActive(value: true);
			m_ScoreBoxIcon.transform.parent.gameObject.SetActive(value: false);
			m_Mirror.gameObject.SetActive(value: true);
			m_Mirror.State = boxItemInfo.Quality;
			if (num == 0)
			{
				m_State.State = 5;
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				commonDataCollection["boxId"] = boxID;
				m_Gift.Args = commonDataCollection;
				m_Gift.UpdateImmediately();
			}
			else if (num > 0)
			{
				m_State.State = 4;
				m_BuyDiamond.text = LocalResources.ShopTable.Find(num).CostDiamond.FormatAmount();
			}
			else
			{
				ShowStateButtonDetail();
			}
		}
		AdScene scene = AdScene.OPEN_BOX;
		if (AdUtility.IsAdEnable(scene))
		{
			m_AdButton.onClick.RemoveAllListeners();
			AdConfig adConfig = AdUtility.GetAdConfig(scene);
			if (m_State.State == 2)
			{
				if (!BoxUtility.IsAnotherUnlocking(m_BoxInfo.boxPosition))
				{
					m_Ad.gameObject.SetActive(value: true);
					if (m_BoxInfo.LeftTime > adConfig.param1)
					{
						m_AdText.text = string.Format(Localization.ReduceTime, adConfig.param1 / 3600);
						m_AdButton.onClick.AddListener(delegate
						{
							OnAdClicked(boxPos);
						});
					}
					else
					{
						m_AdText.text = Localization.OpenImmediately;
						m_AdButton.onClick.AddListener(delegate
						{
							OnAdClicked(boxPos);
						});
					}
				}
				else
				{
					m_Ad.gameObject.SetActive(value: true);
					if (boxItemInfo.OpenCostTime * 60f + (float)m_BoxInfo.cdEndTimestamp <= (float)adConfig.param1)
					{
						m_AdText.text = Localization.OpenImmediately;
						m_AdButton.onClick.AddListener(delegate
						{
							OnAdClicked(boxPos);
						});
					}
					else
					{
						m_AdText.text = string.Format(Localization.ReduceTime, adConfig.param1 / 3600);
						m_AdButton.onClick.AddListener(delegate
						{
							OnAdClicked(boxPos);
						});
					}
				}
			}
			else if (m_State.State == 1)
			{
				if (boxItemInfo.OpenCostTime <= 8f)
				{
					m_Ad.gameObject.SetActive(value: false);
				}
				else if (boxItemInfo.OpenCostTime * 60f + (float)m_BoxInfo.cdEndTimestamp <= (float)adConfig.param1)
				{
					m_Ad.gameObject.SetActive(value: true);
					m_AdText.text = Localization.OpenImmediately;
					m_AdButton.onClick.AddListener(delegate
					{
						OnAdClicked(boxPos);
					});
				}
				else
				{
					m_Ad.gameObject.SetActive(value: true);
					m_AdText.text = string.Format(Localization.ReduceTime, adConfig.param1 / 3600);
					m_AdButton.onClick.AddListener(delegate
					{
						OnAdClicked(boxPos, unlock: true);
					});
				}
			}
			else
			{
				m_Ad.gameObject.SetActive(value: false);
			}
		}
		else
		{
			m_Ad.gameObject.SetActive(value: false);
		}
		if (m_Ad.activeSelf)
		{
			AdSDKManager.TryReportEvent(AdScene.OPEN_BOX, AdStatistics.Show);
		}
		ShowDetails(boxID);
	}

	private void ShowDetails(int boxID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["boxID"] = boxID;
		m_Content.Args = commonDataCollection;
	}

	public new void OpenBoxClicked()
	{
		if (m_BoxInfo != null)
		{
			BoxUtility.RequestOpenBoxByPosition(m_BoxInfo.boxPosition, base.GoToOpenBox);
		}
		else if (m_ScoreBoxInfo != null)
		{
			BoxUtility.RequestOpenBoxByID(m_ScoreBoxInfo.boxID, base.GoToOpenBox);
		}
	}

	public void BuyBoxClicked()
	{
		ShopInfo shopInfo = LocalResources.ShopTable.Get(m_ShopID);
		DropItem dropInfo = LocalResources.DropItemTable.Get(shopInfo.DropItemID);
		HttpRequestBuyItemNew message = new HttpRequestBuyItemNew();
		message.shopID = m_ShopID;
		message.type = CurrencyType.Diamonds;
		ShopUtility.CheckMoneyEnough(CurrencyType.Diamonds, (int)shopInfo.CostDiamond, delegate
		{
			GameHttpManager.Inst.Send(message, delegate(HttpResponseBuyItemNew onResponse)
			{
				m_Host.GetComponent<UIPopup>().GoBack();
				if (ShopUtility.BuyTimeList.ContainsKey(dropInfo.Id))
				{
					Dictionary<int, int> buyTimeList = ShopUtility.BuyTimeList;
					int id = dropInfo.Id;
					buyTimeList[id]++;
				}
				UILobby.Current.ShowUI(m_BoxOpenUI, BoxUtility.BoxOpenUIArgsWraper(dropInfo.Id, onResponse.itemList));
				UIDataEvents.Inst.InvokeEvent("OnBuySomething");
			});
		});
	}
}
