using UnityEngine;
using UnityEngine.UI;

public class CharacterLotteryRuleUI : MonoBehaviour
{
	public Text m_Desc;
}
