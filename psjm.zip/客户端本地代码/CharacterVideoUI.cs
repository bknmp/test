using LightUI;

internal class CharacterVideoUI
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiatorVertical;

	private CommonDataCollection m_arg = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["characterId"];
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(item);
		m_arg.Clear();
		int[] talentIDs = characterInfo.TalentIDs;
		foreach (int x in talentIDs)
		{
			int arraySize = m_arg.ArraySize;
			m_arg[arraySize]["talent"] = x;
			m_arg[arraySize]["page"].val = this;
		}
		CharacterVideoUI_TalentItem.Selected = characterInfo.TalentIDs[0];
		m_TemplateInitiatorVertical.Args = m_arg;
	}

	public void OnSelecteChange()
	{
		foreach (UIDataBinder item in m_TemplateInitiatorVertical.Items)
		{
			item.UpdateBinding();
		}
	}
}
