using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_DetailPage
{
	public UIDataBinder m_Host;

	public Button m_CommentButton;

	public Button m_VideoButton;

	public UIDataBinder m_UpgradeDataBinder;

	public UIPage m_CardVideoUI;

	public Image m_Frame;

	public Text m_LevelText;

	public Text m_QualityText;

	public UIDataBinder m_CardSkinPage;

	public UIPopup m_CardCommentUI;

	public Text m_Title;

	private InGameStoreInfo m_itemInfo;

	private string m_LevelFormat;

	private int m_cardID;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_LevelFormat))
		{
			m_LevelFormat = m_LevelText.text;
		}
		m_cardID = args["cardID"];
		int num;
		if ((bool)args["isLocalPlayer"])
		{
			DataItem item = args["cardLevel"] = CardUtility.GetCardLevel(m_cardID);
			num = item;
		}
		else
		{
			num = args["cardLevel"];
		}
		m_itemInfo = LocalResources.InGameStoreTable.Get(m_cardID);
		m_Title.text = m_itemInfo.FullName;
		m_LevelText.text = string.Format(m_LevelFormat, num);
		m_QualityText.text = m_itemInfo.QualityTips;
		m_Frame.sprite = SpriteSource.Inst.Find(m_itemInfo.Frame);
		m_UpgradeDataBinder.Args = args;
		m_CardSkinPage.Args = args;
		m_Host.EventProxy(m_CommentButton, "OnClickComment");
		m_Host.EventProxy(m_VideoButton, "OnClickVideoBtn");
	}

	public static int GetCardPrice(int cardID, float discount)
	{
		int price = LocalResources.InGameStoreTable.Get(cardID).Price;
		if (CardUtility.GetCardGrowth(cardID).Type == CardGrowthType.Discount)
		{
			return Mathf.RoundToInt((float)price * discount);
		}
		return price;
	}

	public void OnClickVideoBtn()
	{
		if (VirtualUniqueDeviceID.IsLowMemory)
		{
			UILobby.Current.ShowTips(Localization.TipsNotSupportVedio);
			return;
		}
		UILobby.Current.GoToPage(m_CardVideoUI);
		UILobby.Current.CurrentPage().GetComponent<VideoUI>().TryDownloadAndPlay(1, m_itemInfo.Id);
	}

	public void OnClickComment()
	{
		UILobby.Current.ShowUI(m_CardCommentUI, CommentUIBinder.WrapperCommentData(m_cardID, 1));
	}
}
