using LightUtility;
using System;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(PlayerController))]
public class AutoRecoverable : MonoBehaviour
{
	public GameObject m_Effect;

	public float m_FriendMinRange = 3f;

	public float m_Interval = 1f;

	public float m_Amount = 10f;

	private PlayerController m_Controller;

	private void Start()
	{
		m_Controller = GetComponent<PlayerController>();
		PlayerController controller = m_Controller;
		controller.OnDamageApplied = (UnityAction<float>)Delegate.Combine(controller.OnDamageApplied, new UnityAction<float>(OnDamageApplied));
		InvokeRepeating("AutoRecoverBlood", m_Interval, m_Interval);
	}

	private void AutoRecoverBlood()
	{
		if (m_Amount != 0f && m_Controller.m_PhotonView.isMine && !m_Controller.IsDying && !(m_Controller.m_BattleProperties.life >= m_Controller.m_BattleProperties.maxLife))
		{
			bool flag = false;
			if (!(m_FriendMinRange > 0f) || AnyFriendInRange(m_FriendMinRange))
			{
				m_Controller.RpcApplyDamage(0f - m_Amount, UserId2NumId.Get(m_Controller.UserId), DamageSourceType.AutoRecover);
			}
		}
	}

	public bool AnyFriendInRange(float range)
	{
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer != m_Controller && m_Controller.InSameTeam(allPlayer) && !allPlayer.IsDying && !GameRuntime.PlayersState[allPlayer.UserId].IsFinalEscape && (base.transform.localPosition - allPlayer.transform.localPosition).FlattenY().magnitude < range)
			{
				return true;
			}
		}
		return false;
	}

	private void OnDamageApplied(float damage)
	{
		if (damage < 0f && m_Effect != null && m_Controller.IsVisible && !m_Controller.IsKinematic)
		{
			GameObject gameObject = PoolSpawner.Spawn(m_Effect, base.transform);
			gameObject.transform.localPosition = m_Effect.transform.localPosition;
			ParticleSystem.MainModule main = gameObject.GetComponent<ParticleSystem>().main;
			main.maxParticles = (int)Mathf.Clamp(0f - damage, 1f, 20f);
		}
	}
}
