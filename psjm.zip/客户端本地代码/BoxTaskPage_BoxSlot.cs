using GameMessages;
using LightUI;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class BoxTaskPage_BoxSlot : BoxSlot
{
	public UITimeText m_CostTime;

	public Text m_Price;

	public Text m_BoxName;

	public Animator m_BoxAnimator;

	public Button m_AdButton;

	public Text m_DiscountPrice;

	private Coroutine m_Coroutine;

	public new void Bind(CommonDataCollection args)
	{
		base.Bind(args);
		bool flag = args["ad"];
		if (m_BoxPos != -1 && m_BoxInfo != null)
		{
			BoxInfo boxInfo = SetIconMirrorAndState(m_BoxInfo.boxID);
			if (boxInfo != null)
			{
				SetStateDetail(boxInfo);
			}
			else
			{
				UnityEngine.Debug.LogError("找不到该宝箱:" + m_BoxInfo.boxID);
				m_SlotState.State = 0;
			}
		}
		else
		{
			m_SlotState.State = 0;
		}
		if (m_AdButton != null)
		{
			m_AdButton.gameObject.SetActive(flag);
			if (flag)
			{
				AdSDKManager.TryReportEvent(AdScene.FREE_BOX, AdStatistics.Show);
				m_AdButton.onClick.RemoveAllListeners();
				m_AdButton.onClick.AddListener(OnAdClick);
			}
		}
	}

	private void SetStateDetail(BoxInfo boxItemInfo)
	{
		if (m_BoxInfo.cdEndTimestamp < 0)
		{
			m_CostTime.SetTime(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f + (float)m_BoxInfo.cdEndTimestamp));
		}
		else
		{
			m_CostTime.SetTime(Mathf.CeilToInt(boxItemInfo.OpenCostTime * 60f));
		}
		int num = BoxUtility.OpenBoxCostTicket(m_BoxInfo.LeftTime, boxItemInfo.OpenCostDiamond);
		m_BoxName.text = boxItemInfo.Name;
		if (m_BoxInfo.CanUnlock)
		{
			m_LockState.State = ((BoxUtility.HaveBoxUnlocking() > 0) ? 1 : 0);
		}
		else if (m_BoxInfo.Unlocking && m_DiscountPrice != null)
		{
			int activityId = 0;
			bool flag = ActivityLobby.IsActicityAvailable(ActivityType.WEEKEND_DOUBLE, ActivityCollectionType.ANNIVERSART_ACTIVITY, out activityId);
			m_DiscountPrice.gameObject.SetActive(flag);
			m_Price.gameObject.SetActive(!flag);
			if (flag)
			{
				Text component = m_DiscountPrice.transform.GetChild(0).GetComponent<Text>();
				m_DiscountPrice.text = num.ToString();
				component.text = Mathf.CeilToInt((float)num * 0.5f).ToString();
			}
		}
		m_Price.text = num.ToString();
		if (m_BoxInfo.LeftTime > 0)
		{
			m_Cooldown.SetTime((float)m_BoxInfo.LeftTime + 0.75f, Mathf.Max(1, m_BoxInfo.LeftTime), delegate
			{
				m_BoxState.State = 2;
			});
		}
		m_BoxAnimator.enabled = (m_BoxState.State == 2);
		StopUpdateDamond();
		m_Host.StartCoroutine(UpdateDamond(boxItemInfo.OpenCostDiamond));
	}

	private void StopUpdateDamond()
	{
		if (m_Coroutine != null)
		{
			m_Host.StopCoroutine(m_Coroutine);
		}
	}

	private IEnumerator UpdateDamond(float costDiamond)
	{
		WaitForSeconds second = new WaitForSeconds(1f);
		while (m_BoxInfo != null && (m_BoxInfo.LeftTime > 0 || m_Host.gameObject.activeSelf))
		{
			m_Price.text = BoxUtility.OpenBoxCostTicket(m_BoxInfo.LeftTime, costDiamond).ToString();
			yield return second;
		}
	}

	private void OnAdClick()
	{
		AdScene adScene = AdScene.FREE_BOX;
		AdSDKManager.Inst.ShowAd(adScene, delegate
		{
			AdUtility.RequestRewards(adScene, 0, delegate
			{
				BoxUtility.RefreshBoxList();
			});
		});
	}
}
