using LightUtility;
using System;

[Serializable]
public class CardStrategyInfo : IdBased
{
	public int CardID;

	public int CharacterID;

	public string GroupName;

	public int[] GroupItems;

	public string TechniqueItems;

	public int[] LimitGrade;

	public int CopyButton;

	public int TryButton;
}
