using DG.Tweening;
using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

internal class CardNewsItem_DonateCard
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public Image m_Frame;

	public Text m_Name;

	public UIProgressBar m_ProgressBar;

	public Text m_Num;

	public DonateButton m_DonateButton;

	public UITipsDialogController m_Tips;

	private string m_NumFormat;

	private UIStateItem m_BtnState;

	private RectTransform m_BtnRect;

	private string m_PieceCost;

	private int m_OwnCardNum;

	private PropQuality m_CardQuality;

	private string m_QualityTips;

	private DonateCardNews m_CardNews;

	private bool m_Playing;

	private static bool m_Donating;

	public static bool Donating
	{
		get
		{
			return m_Donating;
		}
		set
		{
			m_Donating = value;
		}
	}

	public void Bind(CommonDataCollection args)
	{
		if (m_NumFormat == null)
		{
			m_NumFormat = m_Num.text;
			if (m_DonateButton != null)
			{
				m_BtnState = m_DonateButton.GetComponent<UIStateItem>();
				m_BtnRect = m_DonateButton.GetComponent<RectTransform>();
			}
		}
		DataItem item = args["id"];
		LocalNews news = UnionNewsManager.GetNews(item);
		if (news == null)
		{
			Remove(item);
			return;
		}
		m_CardNews = news.ConvertTo<DonateCardNews>();
		if (m_CardNews.totalPieces > 0 && m_CardNews.getPieces >= m_CardNews.totalPieces)
		{
			Remove(item);
			return;
		}
		int cardID = m_CardNews.cardID;
		InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
		CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID);
		CardGrowthInfo cardGrowthInfo = LocalResources.CardGrowthTable.Get(inGameStoreInfo.GrowthID);
		m_CardQuality = (PropQuality)inGameStoreInfo.Quality;
		m_QualityTips = inGameStoreInfo.QualityTips;
		m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
		m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		m_Name.text = inGameStoreInfo.FullName;
		if (CardUtility.IsOwned(cardID))
		{
			int cardLevel = CardUtility.GetCardLevel(cardID);
			m_PieceCost = ((cardLevel >= cardGrowthInfo.MaxLevel) ? Localization.MaxLevel : cardGrowthInfo.PieceCostNew[cardLevel - 1].ToString());
		}
		else
		{
			m_PieceCost = Localization.NotCompose;
		}
		m_OwnCardNum = CardUtility.GetOwnCardPieceNum(m_CardNews.cardID);
		m_Num.text = string.Format(m_NumFormat, string.Format(UnionUtility.GetOwnCardNumFormat(m_CardQuality), m_OwnCardNum), m_PieceCost);
		m_ProgressBar.SetProgress(m_CardNews.getPieces, m_CardNews.totalPieces);
		if (m_DonateButton != null)
		{
			m_CardNews.canDonate = UnionUtility.GetCanDonate(m_CardNews.cardDonateId, m_CardQuality);
			m_BtnState.State = ((!CheckCanDonate()) ? 1 : 0);
			m_DonateButton.SetInfo(CanDonate, OnDonate, OnFinalDonate);
		}
		UpdateTips();
	}

	private void Remove(uint newsID)
	{
		UnityEngine.Debug.Log("Remove " + newsID);
		if (NewsPage_ChatPage.OnRemove != null)
		{
			NewsPage_ChatPage.OnRemove(newsID);
		}
	}

	private bool CheckCanDonate()
	{
		if (m_CardNews.canDonate > 0 && m_OwnCardNum > 0)
		{
			return !UnionUtility.IsLimitedDonateCard(m_CardQuality);
		}
		return false;
	}

	private void UpdateTips()
	{
		if (m_Tips != null)
		{
			m_Tips.SetTips(string.Format(Localization.DonateDayMaxFormat, UnionUtility.MyUnionInfo.donateWhiteCard, UnionUtility.Settings.donateWhiteCardMax, UnionUtility.MyUnionInfo.donateBlueCard, UnionUtility.Settings.donateBlueCardMax, UnionUtility.MyUnionInfo.donatePurpleCard, UnionUtility.Settings.donatePurpleCardMax));
		}
	}

	private bool CanDonate(int count)
	{
		int num = m_CardNews.canDonate - count;
		int num2 = m_OwnCardNum - count;
		bool flag = num2 >= 0 && num >= 0 && count <= m_CardNews.totalPieces;
		if (num < 0)
		{
			if (UnionUtility.IsLimitedDonateCard(m_CardQuality))
			{
				UILobby.Current.ShowTips(string.Format(Localization.LimitedDonateDayFormat, UnionUtility.GetDonateCardMaxNum(m_CardQuality), m_QualityTips));
			}
			else
			{
				UILobby.Current.ShowTips(string.Format(Localization.LimitedDonateOnceFormat, UnionUtility.GetDonateCardOnceNum(m_CardQuality)));
			}
		}
		if (num2 < 0)
		{
			UILobby.Current.ShowTips(Localization.TipsOwnCardZero);
		}
		m_BtnState.State = ((!flag) ? 1 : 0);
		if (flag)
		{
			return !m_Donating;
		}
		return false;
	}

	private void OnDonate(int count)
	{
		Play();
		count = Mathf.Min(count, m_CardNews.canDonate);
		count = Mathf.Min(count, m_CardNews.totalPieces - m_CardNews.getPieces);
		m_ProgressBar.SetProgress(m_CardNews.getPieces + count, m_CardNews.totalPieces);
		m_Num.text = string.Format(m_NumFormat, string.Format(UnionUtility.GetOwnCardNumFormat(m_CardQuality), m_OwnCardNum - count), m_PieceCost);
	}

	private void Play()
	{
		if (!m_Playing)
		{
			m_Playing = true;
			m_BtnRect.DOKill();
			m_BtnRect.localScale = Vector3.one;
			m_BtnRect.DOScale(1.1f, 0.15f).OnComplete(delegate
			{
				m_BtnRect.DOScale(1f, 0.1f).OnComplete(delegate
				{
					m_Playing = false;
				});
			});
		}
		SoundManager.PlayOnce(UILobby.Current.m_Audio.ButtonEventClip);
	}

	private void OnFinalDonate(int count)
	{
		if (!m_Donating)
		{
			m_Donating = true;
			UnionUtility.DonateCard(m_CardNews.cardDonateId, count, delegate(HttpResponseUnionDonateCard res)
			{
				switch (m_CardQuality)
				{
				case PropQuality.White:
					UnionUtility.MyUnionInfo.donateWhiteCard += res.count;
					break;
				case PropQuality.Blue:
					UnionUtility.MyUnionInfo.donateBlueCard += res.count;
					break;
				case PropQuality.Purple:
					UnionUtility.MyUnionInfo.donatePurpleCard += res.count;
					break;
				}
				m_CardNews.getPieces += res.count;
				LocalPlayerDatabase.PlayerInfo.gold += res.coin;
				UnionUtility.UpdateCardNews(m_CardNews);
				UnionUtility.DonateOwnCardPieceNum(m_CardNews.cardID, res.count);
				UnionUtility.UpdateCanDonate(m_CardNews.cardDonateId, res.count);
				UILobby.Current.ShowTips(string.Format(Localization.TipsDonateCardSuccess, res.count, res.coin, (float)res.liveness / 10f));
			}, OnDonateSuccess, OnDonateFailure);
		}
	}

	private void OnDonateSuccess()
	{
		LocalPlayerDatabase.OnPlayerInfoChanged();
		UnionUtility.RefreshMyUnionInfo();
		UnionUtility.RequestUnionMembers();
		UILobby.Current.StartCoroutine(StopDonating());
	}

	private void OnDonateFailure()
	{
		m_ProgressBar.SetProgress(m_CardNews.getPieces, m_CardNews.totalPieces);
		UnionUtility.RequestDonateCardList();
		UILobby.Current.StartCoroutine(StopDonating());
	}

	private IEnumerator StopDonating()
	{
		yield return new WaitForSeconds(0.2f);
		m_Donating = false;
	}
}
