using LightUI;
using LightUtility;
using UnityEngine;

public class BossPrisonObject : PlaceableObject
{
	public GameObject m_ForbiddenAreaTips;

	public GameObject m_StartEffect;

	public GameObject m_MeshEffect;

	public UICooldownBar m_ProgressBar;

	public float m_Duration = 5f;

	private Vector3 m_DefaultPos;

	public bool IsPreviewInValid => InGameScene.Inst.Map.IsWorldPositionOutOfBorder(base.PreviewPosition, 0f);

	private new void Awake()
	{
		base.Awake();
		m_DefaultPos = m_PreviewArea.transform.localPosition;
	}

	private new void Start()
	{
		if (!string.IsNullOrEmpty(base.UserId))
		{
			m_Root.SetActive(value: true);
			m_PreviewArea.SetActive(value: false);
			foreach (BossPlayerController allBossPlayer in BossPlayerController.AllBossPlayers)
			{
				if (!(allBossPlayer == null))
				{
					Collider[] componentsInChildren = allBossPlayer.PhysicsBody.Colliders.GetComponentsInChildren<Collider>(includeInactive: true);
					foreach (Collider collider in componentsInChildren)
					{
						Collider[] componentsInChildren2 = GetComponentsInChildren<Collider>(includeInactive: true);
						foreach (Collider collider2 in componentsInChildren2)
						{
							Physics.IgnoreCollision(collider, collider2);
						}
					}
				}
			}
			PoolSpawner.Spawn(m_StartEffect, base.transform);
			m_ProgressBar.SetTime(m_Duration, m_Duration, SelfDestroy);
		}
		base.Start();
	}

	private void SelfDestroy()
	{
		m_MeshEffect.GetComponentInChildren<Animator>().SetTrigger("end");
		Invoke("DoDestroy", 0.4f);
	}

	private void DoDestroy()
	{
		UnityEngine.Object.Destroy(base.gameObject);
	}

	public override void StartPreview()
	{
		base.StartPreview();
		m_Root.SetActive(value: false);
		m_PreviewArea.SetActive(value: true);
		base.transform.localPosition = Vector3.zero;
		m_PreviewArea.transform.localPosition = m_DefaultPos;
		UpdatePreviewArea();
		if (m_PreviewColor != null)
		{
			m_PreviewColor.ForceUpdate();
		}
	}

	protected override void UpdatePreviewArea()
	{
		base.UpdatePreviewArea();
		m_ForbiddenAreaTips.SetActive(IsPreviewInValid);
	}
}
