using GameMessages;
using LightUI;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CommonPreviewBinder
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Text m_Desc;

	public UIStateItem m_Quality;

	public RawImage m_Preview;

	public UIGiftShowManager m_GiftScene;

	public UIStateItem m_ShowState;

	public GameObject m_Personality;

	protected int cameraFOV = 30;

	protected bool m_IsPreviewInScene;

	protected StoreUICameraView m_CameraView;

	public DropItem m_DropItem;

	private TweenPosition m_TweenPosition;

	public virtual void Bind(CommonDataCollection args)
	{
		if (args["dropItem"].val != null)
		{
			m_DropItem = (args["dropItem"].val as DropItem);
			m_IsPreviewInScene = args["IsPreviewInScene"];
			m_CameraView = (args["StoreUICameraView"].val as StoreUICameraView);
			if ((int)args["cameraFOV"] != 0 && (int)args["cameraFOV"] != 30)
			{
				cameraFOV = args["cameraFOV"];
			}
			else
			{
				cameraFOV = 30;
			}
			m_TweenPosition = m_Preview.GetComponent<TweenPosition>();
			SetName();
			SetQuality();
			SetDesc();
			SetPersonality();
			SetPreviewSize(m_DropItem.Type);
			PreviewItem();
		}
	}

	protected virtual void SetName()
	{
		if (m_Name != null)
		{
			m_Name.text = m_DropItem.Name.SimpleName();
		}
	}

	protected virtual void SetQuality()
	{
		if (m_Quality != null)
		{
			m_Quality.State = m_DropItem.Quality;
		}
	}

	protected virtual void SetPersonality()
	{
		if (m_Personality != null)
		{
			int itemsPersonality = DropItemUtility.GetItemsPersonality(m_DropItem);
			m_Personality.GetComponentInChildren<Text>().text = "+" + itemsPersonality.ToString();
			m_Personality.SetActive(itemsPersonality > 0);
		}
	}

	protected virtual void SetDesc()
	{
		if (m_Desc != null)
		{
			m_Desc.text = m_DropItem.NewBubbleTips;
		}
	}

	protected virtual void PreviewItem()
	{
		switch (m_DropItem.Type)
		{
		case DropItemType.Character:
			PreviewCharacter(m_DropItem.TypeParam);
			break;
		case DropItemType.SkinPart:
			PreviewSkinPart(m_DropItem.TypeParam);
			break;
		case DropItemType.SkinSuite:
			PreviewSuite(m_DropItem.TypeParam);
			break;
		case DropItemType.CardSkin:
			PreviewCardSkin(m_DropItem.TypeParam);
			break;
		case DropItemType.CardStyle:
			PreviewCardStyle(m_DropItem.TypeParam);
			break;
		case DropItemType.IngameEmotion:
			PreviewEmotion(m_DropItem.TypeParam);
			break;
		case DropItemType.Lightness:
			PreviewLightness(m_DropItem.TypeParam);
			break;
		case DropItemType.Gift:
			PreviewGift(m_DropItem.TypeParam);
			break;
		default:
			PreviewIcon(m_DropItem);
			break;
		}
		if (m_DropItem.Type == DropItemType.Gift)
		{
			if (m_ShowState != null)
			{
				m_ShowState.State = 1;
			}
		}
		else
		{
			if (m_ShowState != null)
			{
				m_ShowState.State = 0;
			}
			m_Preview.gameObject.SetActive(value: true);
		}
		m_Preview.gameObject.SetActive(value: true);
	}

	protected virtual void SetPreviewSize(DropItemType type)
	{
		switch (type)
		{
		case DropItemType.SkinPart:
		case DropItemType.Character:
		case DropItemType.CardLotteryTicket:
		case DropItemType.SkinSuite:
		case DropItemType.IngameEmotion:
		case DropItemType.Lightness:
		{
			Vector2 sizeDelta3 = new Vector2(900f, 787f);
			m_Preview.GetComponent<RectTransform>().sizeDelta = sizeDelta3;
			SetTweenPosition(enable: false);
			break;
		}
		case DropItemType.CardSkin:
		case DropItemType.CardStyle:
		{
			Vector2 sizeDelta2 = new Vector2(1236f, 1080f);
			m_Preview.GetComponent<RectTransform>().sizeDelta = sizeDelta2;
			SetTweenPosition(enable: false);
			break;
		}
		default:
		{
			Vector2 sizeDelta = new Vector2(512f, 512f);
			m_Preview.GetComponent<RectTransform>().sizeDelta = sizeDelta;
			SetTweenPosition(type != DropItemType.CardPiece);
			break;
		}
		}
	}

	protected void SetTweenPosition(bool enable)
	{
		if (m_TweenPosition != null)
		{
			m_TweenPosition.enabled = enable;
		}
	}

	protected void AdjustCampCamera(RoleType role, Vector3 pos)
	{
		if (role == RoleType.Police)
		{
			LobbyScene.Inst.m_CampPanel.PoliceCamera.transform.localPosition = pos;
		}
		else
		{
			LobbyScene.Inst.m_CampPanel.ThiefCamera.transform.localPosition = pos;
		}
	}

	protected void HideFakeShadow(GameObject go)
	{
		SpriteRenderer[] componentsInChildren = go.GetComponentsInChildren<SpriteRenderer>(includeInactive: true);
		if (componentsInChildren != null)
		{
			SpriteRenderer[] array = componentsInChildren;
			foreach (SpriteRenderer obj in array)
			{
				UnityEngine.Object.DestroyImmediate(obj.GetComponent<BlobShadow>());
				Color color = obj.color;
				color.a = 0f;
				obj.color = color;
			}
		}
	}

	protected virtual void PreviewCharacter(int charaterID)
	{
		PreviewSuite(charaterID);
	}

	protected virtual void PreviewSkinPart(int skinPartID)
	{
		SkinPartInfo skinPartInfo = LocalResources.SkinPartTable.Get(skinPartID);
		MatchPlayerData playerData = CharacterUtility.GetPlayerData(skinPartInfo.CharacterID);
		playerData.lightnessConfig = 0;
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(skinPartInfo.CharacterID);
		PlayerCharacterInfo characterDefaultInfo = CharacterUtility.GetCharacterDefaultInfo(skinPartInfo.CharacterID);
		characterDefaultInfo.currentSkinInfo.skinPartIDs[(int)skinPartInfo.PartType] = skinPartID;
		characterDefaultInfo.currentSkinInfo.skinPartColors[(int)skinPartInfo.PartType] = skinPartInfo.DefaultColorID;
		LobbyPlayerController lobbyPlayerController = LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, LocalPlayerDatabase.PlayerInfo.publicInfo.name, characterDefaultInfo, playerData, m_Preview, m_IsPreviewInScene, m_Preview.GetComponent<UIPointerBehaviour>(), closeOppositeRole: true, disableChangePartAnim: true, cameraFOV);
		if (m_CameraView != null)
		{
			m_CameraView.SetView();
		}
		HideFakeShadow(lobbyPlayerController.gameObject);
		m_Host.StartCoroutine(ShowAnimation(lobbyPlayerController, skinPartInfo.Animation));
		AdjustCampCamera(characterInfo.Role, new Vector3(0f, 0f, -3f));
	}

	protected virtual void PreviewSuite(int suiteID)
	{
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suiteID);
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(shopSuiteInfo.CharacterID);
		MatchPlayerData playerData = CharacterUtility.GetPlayerData(shopSuiteInfo.CharacterID);
		playerData.lightnessConfig = 0;
		PlayerCharacterInfo playerCharacterInfo = CharacterUtility.GetPlayerCharacterInfo(characterInfo, new int[0], suiteID);
		LobbyPlayerController lobbyPlayerController = LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, LocalPlayerDatabase.PlayerInfo.publicInfo.name, playerCharacterInfo, playerData, m_Preview, m_IsPreviewInScene, m_Preview.GetComponent<UIPointerBehaviour>(), closeOppositeRole: true, disableChangePartAnim: true, cameraFOV);
		if (m_CameraView != null)
		{
			m_CameraView.SetView();
		}
		AdjustCampCamera(characterInfo.Role, new Vector3(0f, 0f, -3f));
		m_Host.StartCoroutine(ShowAnimation(lobbyPlayerController, shopSuiteInfo.Animation));
		HideFakeShadow(lobbyPlayerController.gameObject);
	}

	protected IEnumerator ShowAnimation(LobbyPlayerController player, int animation)
	{
		yield return Yielders.EndOfFrame;
		if (player != null)
		{
			player.TryShowAnimation(animation);
		}
	}

	protected virtual void PreviewCardSkin(int cardSkinID)
	{
		string prefabs = LocalResources.CardSkinTable.Get(cardSkinID).Prefabs;
		string text = prefabs + "_Lobby";
		GameObject x = ResourceSource.Load(text);
		prefabs = text;
		if (x != null)
		{
			LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, prefabs, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>(), hideCharacterSceneRoot: true, 1f, -20f, cameraFOV);
			ClampCardSkinCameraAxis(50f, 0f, forbidAutoRotate: true);
			LobbyScene.Inst.m_CardSkinPanel.Camera.transform.localPosition = new Vector3(0f, 0.1f, -3f);
		}
	}

	protected virtual void PreviewCardStyle(int cardStyleID)
	{
		string prefabs = LocalResources.CardStyleTable.Get(cardStyleID).Prefabs;
		string text = prefabs + "_Lobby";
		GameObject x = ResourceSource.Load(text);
		prefabs = text;
		if (x != null)
		{
			LobbyScene.Inst.m_DecalPanel.Camera.targetTexture = null;
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, prefabs, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>(), hideCharacterSceneRoot: true, 1f, -20f, cameraFOV);
			ClampCardSkinCameraAxis(50f, 0f, forbidAutoRotate: true);
			LobbyScene.Inst.m_CardSkinPanel.Camera.transform.localPosition = new Vector3(0f, 0.1f, -3f);
		}
	}

	protected void ClampCardSkinCameraAxis(float x, float y, bool forbidAutoRotate)
	{
		CameraOrbit component = LobbyScene.Inst.m_CardSkinPanel.Camera.GetComponent<CameraOrbit>();
		component.OrbitClampX = x;
		component.OrbitClampY = y;
		component.GetComponent<CameraRotation>().enabled = !forbidAutoRotate;
	}

	protected virtual void PreviewEmotion(int emotionID)
	{
		IngameEmotionInfo ingameEmotionInfo = LocalResources.IngameEmotionInfo.Get(emotionID);
		LobbyScene.Inst.ClosePreviewPanels();
		LobbyScene.Inst.CloseCampPanels();
		UIPointerBehaviour component = m_Preview.GetComponent<UIPointerBehaviour>();
		if (ingameEmotionInfo.Type == 0)
		{
			GameObject gameObject = IngameEmotionUtility.PreviewDecal(ingameEmotionInfo.DecalPrefab, m_Preview, hideCharacterSceneRoot: true, component);
			if (gameObject != null)
			{
				Transform transform = gameObject.transform.parent.parent.Find("Shadow");
				if (transform != null)
				{
					transform.GetComponent<SpriteRenderer>().enabled = false;
				}
			}
			LobbyScene.Inst.m_DecalPanel.Camera.transform.localPosition = new Vector3(0f, 0f, -18f);
			SetTweenPosition(enable: true);
		}
		else
		{
			int chararcter = ingameEmotionInfo.Chararcter;
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(chararcter);
			PlayerCharacterInfo playerCharacterInfo = CharacterUtility.GetPlayerCharacterInfo(chararcter, LocalPlayerDatabase.PlayerInfo);
			MatchPlayerData playerData = CharacterUtility.GetPlayerData(chararcter);
			playerData.lightnessConfig = 0;
			string name = LocalPlayerDatabase.PlayerInfo.publicInfo.name;
			LobbyPlayerController lobbyPlayerController = LobbyScene.Inst.UpdateCampPanel(characterInfo.Role, name, playerCharacterInfo, playerData, m_Preview, m_IsPreviewInScene, component, closeOppositeRole: true, disableChangePartAnim: false, cameraFOV);
			AdjustCampCamera(characterInfo.Role, new Vector3(0f, 0f, -3f));
			lobbyPlayerController.GetComponent<IngameEmotionBaseController>().PlayAnimator(ingameEmotionInfo, loop: true);
			HideFakeShadow(lobbyPlayerController.gameObject);
		}
	}

	protected virtual void PreviewLightness(int lightnessID)
	{
		LobbyScene.Inst.ClosePreviewPanels();
		LobbyScene.Inst.CloseCampPanels();
		RoleType playingRole = GameRuntime.PlayingRole;
		int num = LocalPlayerDatabase.PlayerInfo.activeCharacterID[Mathf.Clamp((int)playingRole, 0, 1)];
		string name = LocalPlayerDatabase.PlayerInfo.publicInfo.name;
		PlayerCharacterInfo ownedCharacterInfo = CharacterUtility.GetOwnedCharacterInfo(num);
		LobbyPlayerController lobbyPlayerController = LobbyScene.Inst.UpdateCampPanel(playingRole, name, ownedCharacterInfo, CharacterUtility.GetPlayerData(num), m_Preview, m_IsPreviewInScene, m_Preview.GetComponent<UIPointerBehaviour>(), closeOppositeRole: true, disableChangePartAnim: false, cameraFOV);
		LightnessInfo lightnessInfo = LocalResources.LightnessInfo.Get(lightnessID);
		lobbyPlayerController.LightnessController.ShowLight(lightnessInfo.Prefab, lightnessInfo.Id);
		HideFakeShadow(lobbyPlayerController.gameObject);
		AdjustCampCamera(playingRole, new Vector3(0f, 0f, -3.5f));
	}

	protected virtual void PreviewGift(int giftID)
	{
		GiftInfo giftInfo = LocalResources.GiftInfo.Get(giftID);
		ShowGift(giftInfo);
	}

	private void ShowGift(GiftInfo giftInfo)
	{
		if (m_GiftScene != null)
		{
			m_GiftScene.ResetGiftShow();
			m_GiftScene.ShowGift(giftInfo, delegate
			{
				ShowGift(giftInfo);
			});
		}
	}

	protected virtual void PreviewIcon(DropItem dropItem)
	{
		if (dropItem.Type == DropItemType.CardLotteryTicket)
		{
			string prefabs = "CardLotteryItem_" + (CardLotteryType)dropItem.TypeParam + "_Lobby";
			LobbyScene.Inst.UpdatePreviewPanel(LobbyScene.PreviewType.CardSkin, prefabs, m_Preview, m_Preview.GetComponent<UIPointerBehaviour>(), hideCharacterSceneRoot: true, 1f, -20f, cameraFOV);
			ClampCardSkinCameraAxis(0f, 0f, forbidAutoRotate: true);
			LobbyScene.Inst.m_CardSkinPanel.Camera.transform.localPosition = new Vector3(0f, 0.1f, -3f);
			return;
		}
		Sprite sprite = SpriteSource.Inst.Find(dropItem.Icon + "_big");
		Sprite sprite2 = (sprite != null) ? sprite : SpriteSource.Inst.Find(dropItem.Icon);
		if (sprite2 != null)
		{
			m_Preview.texture = sprite2.texture;
		}
	}

	private void OnExitUI()
	{
		m_Preview.gameObject.SetActive(value: false);
	}
}
