using LightUI;

internal class CardLotteryOpenUI
{
	public UIDataBinder m_Host;

	public void Bind(CommonDataCollection args)
	{
		for (int i = 0; i < args.ArraySize; i++)
		{
			DataItem dataItem = args.Array[i];
		}
	}
}
