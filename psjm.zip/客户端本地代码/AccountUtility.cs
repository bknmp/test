using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine;

public class AccountUtility
{
	public static HttpResponseLogin LoginAccountInfo;

	public static bool IsSwitchAccount;

	public static HttpResponseMailCode MailCodeResponse;

	public static Delegates.VoidCallback OnChangeRedPoint;

	public static bool ShowAccountRedPoint
	{
		get
		{
			if (LoginAccountInfo != null)
			{
				if (LoginAccountInfo.isSetPwd)
				{
					return ShowMailRedPoint;
				}
				return true;
			}
			return false;
		}
	}

	public static bool ShowMailRedPoint
	{
		get
		{
			if (LocalPlayerDatabase.LoginInfo != null && string.IsNullOrEmpty(LocalPlayerDatabase.LoginInfo.mail))
			{
				return !LocalPlayerDatabase.GetPrefValue("AccountBindMailClick");
			}
			return false;
		}
		set
		{
			LocalPlayerDatabase.SetPrefValue("AccountBindMailClick", value);
		}
	}

	public static void LoginDefaultAccount(Delegates.VoidCallback onSuccess, Delegates.ObjectCallback<bool> onFailure)
	{
		LocalAccountInfo autoLoginInfo = GetAutoAccountInfo();
		if (autoLoginInfo == null)
		{
			LoginByOpenID(onSuccess, delegate(bool isNotSafe)
			{
				onFailure?.Invoke(!isNotSafe);
			});
		}
		else
		{
			LoginByDmmAccount(autoLoginInfo.roleId, "", autoLoginInfo.loginKey, onSuccess, delegate(bool isNotSafe)
			{
				if (!isNotSafe)
				{
					AccountLoginUI.ShowUI(onSuccess, autoLoginInfo.roleId);
				}
				onFailure?.Invoke(v: false);
			});
		}
	}

	public static void LoginByOpenID(Delegates.VoidCallback onSuccess, Delegates.ObjectCallback<bool> onFailure)
	{
		LoginAccount(LoginManager.SDKLoginType, delegate(HttpResponseLogin loginRes)
		{
			if (loginRes.accountSafe && loginRes.notSafe)
			{
				LoginVerify(loginRes, delegate
				{
					LoginByOpenID(onSuccess, onFailure);
				}, delegate
				{
					onFailure?.Invoke(v: true);
				});
			}
			else
			{
				OnLoginSuccess(LoginManager.SDKLoginType, loginRes, onSuccess);
			}
		}, delegate
		{
			onFailure?.Invoke(v: false);
		});
	}

	public static void LoginByDmmAccount(int roleId, string password, string loginKey, Delegates.VoidCallback onSuccess, Delegates.ObjectCallback<bool> onFailure)
	{
		if (string.IsNullOrEmpty(password) && string.IsNullOrEmpty(loginKey))
		{
			onFailure?.Invoke(v: false);
		}
		else
		{
			LoginAccount(5, delegate(HttpResponseLogin loginRes)
			{
				if (loginRes.accountSafe && loginRes.notSafe)
				{
					LoginVerify(loginRes, delegate
					{
						LoginByDmmAccount(roleId, password, loginKey, onSuccess, onFailure);
					}, delegate
					{
						onFailure?.Invoke(v: true);
					});
				}
				else
				{
					OnLoginSuccess(5, loginRes, onSuccess);
				}
			}, delegate
			{
				if (string.IsNullOrEmpty(password))
				{
					ClearLoginKey(roleId);
				}
				onFailure?.Invoke(v: false);
			}, roleId, password, loginKey);
		}
	}

	public static void DoSwitchAccount()
	{
		IsSwitchAccount = true;
		ResManager.LoadScene("Loading");
	}

	public static void FindDefaultAccount()
	{
		LoginUtility.LoginSDK(delegate(bool success)
		{
			if (success)
			{
				LoginAccount(LoginManager.SDKLoginType, delegate(HttpResponseLogin res)
				{
					if (LoginAccountInfo != null && res.roleID == LoginAccountInfo.roleID)
					{
						LoginAccountInfo = res;
						if (LocalPlayerDatabase.LoginInfo != null)
						{
							LocalPlayerDatabase.LoginInfo = res;
						}
						UILobby.Current.ShowTips(Localization.IsFindCurrentAccount);
					}
					else
					{
						AccountTipsUI.ShowUI((int)res.roleID, res.accountName, delegate
						{
							if (res.accountSafe && res.notSafe)
							{
								LoginVerify(res, delegate
								{
									LoginByOpenID(DoSwitchAccount, null);
								}, null);
							}
							else
							{
								OnLoginSuccess(LoginManager.SDKLoginType, res, DoSwitchAccount);
							}
						});
					}
				}, null);
			}
		}, (LoginType)LoginManager.SDKLoginType);
	}

	public static void ChangeAccountPwd(uint roleID, string newPwd, string mailCodeKey, string recoverCode, Delegates.VoidCallback onSuccess = null, Delegates.VoidCallback onFailure = null)
	{
		HttpRequestSetPwd httpRequestSetPwd = new HttpRequestSetPwd();
		httpRequestSetPwd.roleID = roleID;
		httpRequestSetPwd.newPwd = EncryptPwd(newPwd);
		httpRequestSetPwd.codeKey = mailCodeKey;
		httpRequestSetPwd.recoverCode = recoverCode;
		GameHttpManager.Inst.Send(httpRequestSetPwd, delegate(HttpResponseSetPwd res)
		{
			if (LoginAccountInfo != null && LoginAccountInfo.roleID == roleID && !string.IsNullOrEmpty(res.loginKey) && !string.IsNullOrEmpty(res.authKey))
			{
				LoginAccountInfo.isSetPwd = true;
				LoginAccountInfo.loginKey = res.loginKey;
				LoginAccountInfo.authKey = res.authKey;
				if (LocalPlayerDatabase.LoginInfo != null)
				{
					LocalPlayerDatabase.LoginInfo.isSetPwd = true;
					LocalPlayerDatabase.LoginInfo.loginKey = res.loginKey;
					LocalPlayerDatabase.LoginInfo.authKey = res.authKey;
				}
				OnLoginSuccess(5, LoginAccountInfo, null);
			}
		}, onSuccess, onFailure);
	}

	public static void SendMailCode(MailCodeType type, string mail, Delegates.VoidCallback onSuccess, int roleID = 0, string authKey = "")
	{
		HttpRequestSendMailCode httpRequestSendMailCode = new HttpRequestSendMailCode();
		httpRequestSendMailCode.type = (int)type;
		httpRequestSendMailCode.mail = mail;
		if (type == MailCodeType.LoginVerify)
		{
			httpRequestSendMailCode.roleID = (uint)roleID;
			httpRequestSendMailCode.authKey = authKey;
		}
		GameHttpManager.Inst.Send(httpRequestSendMailCode, null, delegate
		{
			UILobby.Current.ShowTips(Localization.TipsMailCodeSend);
			if (onSuccess != null)
			{
				onSuccess();
			}
		});
	}

	public static void CheckMailCode(MailCodeType type, string mail, int code, Delegates.VoidCallback onSuccess, int roleID = 0, string authKey = "")
	{
		HttpRequestCheckMailCode httpRequestCheckMailCode = new HttpRequestCheckMailCode();
		httpRequestCheckMailCode.type = (int)type;
		httpRequestCheckMailCode.mail = mail;
		httpRequestCheckMailCode.code = code;
		if (type == MailCodeType.LoginVerify)
		{
			httpRequestCheckMailCode.roleID = (uint)roleID;
			httpRequestCheckMailCode.authKey = authKey;
		}
		GameHttpManager.Inst.Send(httpRequestCheckMailCode, delegate(HttpResponseMailCode res)
		{
			MailCodeResponse = res;
			if (onSuccess != null)
			{
				onSuccess();
			}
		});
	}

	public static string PwdRemoveForbidWord(string CString)
	{
		for (int num = CString.Length - 1; num >= 0; num--)
		{
			int num2 = Convert.ToInt32(Convert.ToChar(CString.Substring(num, 1)));
			if (num2 >= Convert.ToInt32(Convert.ToChar(128)) || num2 == 32)
			{
				CString = CString.Remove(num, 1);
			}
		}
		return CString;
	}

	public static void ClearLoginKey(int roleID)
	{
		List<LocalAccountInfo> list = new List<LocalAccountInfo>();
		if (LoginManager.HistoryAccountList != null)
		{
			list.AddRange(LoginManager.HistoryAccountList);
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i].roleId == roleID)
			{
				list[i].loginKey = "";
				break;
			}
		}
		LoginManager.HistoryAccountList = list;
	}

	private static void LoginAccount(int loginType, Delegates.ObjectCallback<HttpResponseLogin> onResponse, Delegates.VoidCallback onFailure, int roleId = 0, string password = "", string loginKey = "")
	{
		HttpRequestLogin httpRequestLogin = new HttpRequestLogin();
		httpRequestLogin.roleID = roleId;
		httpRequestLogin.password = EncryptPwd(password);
		httpRequestLogin.openID = LoginManager.OpenID;
		httpRequestLogin.openKey = LoginManager.OpenKey;
		httpRequestLogin.pfID = LoginManager.pfID;
		httpRequestLogin.version = Application.version;
		httpRequestLogin.loginKey = LoginManager.SDKAutoLoginKey;
		httpRequestLogin.pfJson = LoginManager.PFJson;
		httpRequestLogin.fcm = LoginManager.FCM;
		httpRequestLogin.age = Mathf.Max(0, LoginManager.Age);
		httpRequestLogin.deviceInfo = VirtualUniqueDeviceID.DeviceInfo;
		httpRequestLogin.loginType = loginType;
		if (roleId > 0)
		{
			httpRequestLogin.loginKey = loginKey;
		}
		httpRequestLogin.deviceType = 1;
		GameHttpManager.Inst.Send(httpRequestLogin, onResponse, null, onFailure);
	}

	private static void LoginVerify(HttpResponseLogin loginRes, Delegates.VoidCallback onSuccess, Delegates.VoidCallback onFailue)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["roleId"] = (int)loginRes.roleID;
		commonDataCollection["authKey"] = loginRes.authKey;
		AccountMailVerifyUI.ShowUI(MailCodeType.LoginVerify, Localization.TipsLoginNotSafe, loginRes.mail, onSuccess, onFailue, commonDataCollection);
	}

	private static void OnLoginSuccess(int loginType, HttpResponseLogin res, Delegates.VoidCallback onSuccess)
	{
		LoginManager.LoginType = loginType;
		LoginAccountInfo = res;
		CacheLoginAccount(loginType);
		onSuccess?.Invoke();
	}

	private static void CacheLoginAccount(int loginType)
	{
		if (loginType == 5)
		{
			Dictionary<string, int> dictionary = new Dictionary<string, int>();
			if (LoginManager.LatestLoginDict != null)
			{
				dictionary = new Dictionary<string, int>(LoginManager.LatestLoginDict);
			}
			dictionary[LoginManager.OpenID] = (int)LoginAccountInfo.roleID;
			LoginManager.LatestLoginDict = dictionary;
			LocalAccountInfo localAccountInfo = new LocalAccountInfo
			{
				roleId = (int)LoginAccountInfo.roleID,
				name = LoginAccountInfo.accountName,
				loginKey = LoginAccountInfo.loginKey
			};
			List<LocalAccountInfo> list = new List<LocalAccountInfo>();
			if (LoginManager.HistoryAccountList != null)
			{
				list.AddRange(LoginManager.HistoryAccountList);
			}
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].roleId == localAccountInfo.roleId)
				{
					list.RemoveAt(i);
					break;
				}
			}
			list.Insert(0, localAccountInfo);
			LoginManager.HistoryAccountList = list;
			return;
		}
		LoginManager.SDKAutoLoginKey = LoginAccountInfo.loginKey;
		if (LoginManager.LatestLoginDict != null)
		{
			Dictionary<string, int> dictionary2 = new Dictionary<string, int>(LoginManager.LatestLoginDict);
			if (dictionary2.ContainsKey(LoginManager.OpenID))
			{
				dictionary2.Remove(LoginManager.OpenID);
				LoginManager.LatestLoginDict = dictionary2;
			}
		}
	}

	private static LocalAccountInfo GetAutoAccountInfo()
	{
		if (LoginManager.LatestLoginDict == null || LoginManager.LatestLoginDict.Count <= 0)
		{
			return null;
		}
		if (LoginManager.LatestLoginDict.ContainsKey(LoginManager.OpenID) && LoginManager.HistoryAccountList != null)
		{
			foreach (LocalAccountInfo historyAccount in LoginManager.HistoryAccountList)
			{
				if (historyAccount.roleId == LoginManager.LatestLoginDict[LoginManager.OpenID])
				{
					return historyAccount;
				}
			}
		}
		return null;
	}

	private static string EncryptPwd(string pwd)
	{
		if (string.IsNullOrEmpty(pwd))
		{
			return "";
		}
		return UniqueIdentifierTool.GetMd5Hash(pwd + "_DmmAccount");
	}
}
