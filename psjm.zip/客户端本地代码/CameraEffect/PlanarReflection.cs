using UnityEngine;

namespace CameraEffect
{
	public class PlanarReflection : MonoBehaviour
	{
		public Camera _activeCamera;

		public Vector4 _plane;

		private int _defaultSize = 512;

		[Range(0f, 4f)]
		public int _downSampler = 1;

		[SerializeField]
		private RenderTexture _reflectionRT;

		[SerializeField]
		private Camera _rtCamera;

		private GameObject _rtCameraGO;

		private Matrix4x4 reflectM;

		[SerializeField]
		private LayerMask _reflectionLayer;

		private void OnDisable()
		{
			_reflectionRT.Release();
			_reflectionRT = null;
			if ((bool)_rtCameraGO)
			{
				UnityEngine.Object.DestroyImmediate(_rtCameraGO);
			}
		}

		private void OnEnable()
		{
			if (!_reflectionRT)
			{
				_reflectionRT = new RenderTexture(_defaultSize >> _downSampler, _defaultSize >> _downSampler, 16, RenderTextureFormat.Default);
				_reflectionRT.name = "RefletionRT";
				Shader.SetGlobalTexture("_ReflectionRT", _reflectionRT);
			}
			_plane = new Vector4(base.transform.up.x, base.transform.up.y, base.transform.up.z, 0f - Vector3.Dot(base.transform.up, base.transform.position));
		}

		private void LateUpdate()
		{
			if (!(_activeCamera == null))
			{
				reflectM = CalculateReflectionMatrix(_plane);
				if (!_rtCameraGO)
				{
					_rtCameraGO = new GameObject("ReflectionCamera");
					_rtCameraGO.transform.position = reflectM * _activeCamera.transform.position;
					_rtCamera = _rtCameraGO.AddComponent<Camera>();
					_rtCamera.CopyFrom(_activeCamera);
					_rtCamera.useOcclusionCulling = true;
					_rtCamera.allowHDR = false;
					_rtCamera.allowMSAA = false;
				}
				else
				{
					_rtCamera.transform.position = reflectM * _activeCamera.transform.position;
				}
				if (!_reflectionRT)
				{
					_reflectionRT = new RenderTexture(_defaultSize >> _downSampler, _defaultSize >> _downSampler, 16, RenderTextureFormat.Default);
					_reflectionRT.name = "RefletionRT";
					Shader.SetGlobalTexture("_ReflectionRT", _reflectionRT);
				}
				_rtCamera.targetTexture = _reflectionRT;
				_rtCamera.worldToCameraMatrix = _activeCamera.worldToCameraMatrix * reflectM;
				_rtCamera.projectionMatrix = _activeCamera.CalculateObliqueMatrix(_rtCamera.worldToCameraMatrix.inverse.transpose * _plane);
				_rtCamera.cullingMask = _reflectionLayer;
				GL.invertCulling = true;
				_rtCamera.Render();
				GL.invertCulling = false;
			}
		}

		private static Matrix4x4 CalculateReflectionMatrix(Vector4 plane)
		{
			Matrix4x4 matrix4x = Matrix4x4.identity;
			matrix4x *= Matrix4x4.Scale(new Vector3(1f, -1f, 1f));
			matrix4x.m00 = 1f - 2f * plane[0] * plane[0];
			matrix4x.m01 = -2f * plane[0] * plane[1];
			matrix4x.m02 = -2f * plane[0] * plane[2];
			matrix4x.m03 = -2f * plane[3] * plane[0];
			matrix4x.m10 = -2f * plane[1] * plane[0];
			matrix4x.m11 = 1f - 2f * plane[1] * plane[1];
			matrix4x.m12 = -2f * plane[1] * plane[2];
			matrix4x.m13 = -2f * plane[3] * plane[1];
			matrix4x.m20 = -2f * plane[2] * plane[0];
			matrix4x.m21 = -2f * plane[2] * plane[1];
			matrix4x.m22 = 1f - 2f * plane[2] * plane[2];
			matrix4x.m23 = -2f * plane[3] * plane[2];
			matrix4x.m30 = 0f;
			matrix4x.m31 = 0f;
			matrix4x.m32 = 0f;
			matrix4x.m33 = 1f;
			return matrix4x;
		}
	}
}
