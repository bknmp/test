using LightUI;
using LightUtility;
using System;
using UnityEngine;

internal class AccountHistoryItem
{
	public UIDataBinder m_Host;

	public AccountInfoController m_AccountInfo;

	public MultiTargetGraphicButton m_Select;

	public MultiTargetGraphicButton m_Delete;

	private int m_Index;

	private Action<int> OnItemSelected;

	private Action<int, GameObject> OnItemDelete;

	public void Bind(CommonDataCollection args)
	{
		m_Index = args["index"];
		OnItemSelected = (args["onItemSelected"].val as Action<int>);
		OnItemDelete = (args["onItemDelete"].val as Action<int, GameObject>);
		m_AccountInfo.SetAccountInfo(AccountSwitchUI.AccountHistory[m_Index].roleId, AccountSwitchUI.AccountHistory[m_Index].name);
		m_Host.EventProxy(m_Select, "OnSelectClick");
		m_Host.EventProxy(m_Delete, "OnDeleteClick");
	}

	public void OnSelectClick()
	{
		if (OnItemSelected != null)
		{
			OnItemSelected(m_Index);
		}
	}

	public void OnDeleteClick()
	{
		if (OnItemDelete != null)
		{
			OnItemDelete(m_Index, m_Host.gameObject);
		}
	}
}
