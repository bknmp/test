public enum ChatChannel
{
	Public,
	Friend,
	Team
}
