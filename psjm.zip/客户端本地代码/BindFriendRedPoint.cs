using LightUI;
using UnityEngine;

public class BindFriendRedPoint : MonoBehaviour
{
	public GameObject m_InvitePageRedPoint;

	private void Start()
	{
		UIDataEvents.Inst.AddEventListener("OnBindFriendsRedPoint", this, SetRedPoint);
		SetRedPoint();
	}

	private void SetRedPoint()
	{
		m_InvitePageRedPoint.SetActive(BindFriendsUtility.HadRedpoint());
	}
}
