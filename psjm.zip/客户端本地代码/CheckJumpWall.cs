using BehaviorDesigner.Runtime.Tasks;
using LightUtility;
using UnityEngine;

[TaskName("检查是否要跳墙")]
[TaskCategory("考驾照功能/AI")]
public class CheckJumpWall : Conditional
{
	private float lastCheckTime;

	private PlayerController myself;

	public override void OnStart()
	{
		myself = GetComponent<PlayerController>();
	}

	public override TaskStatus OnUpdate()
	{
		if (CheckNearbyWall())
		{
			return TaskStatus.Success;
		}
		return TaskStatus.Failure;
	}

	private bool CheckNearbyWall()
	{
		if (Time.time - lastCheckTime < 0.5f || myself.m_MovementProperties.jumpVelocity < 0.001f || myself.IsDying)
		{
			return false;
		}
		int num = Physics.OverlapSphereNonAlloc(transform.localPosition + transform.forward * 0.5f, 0.2f, GameObjectUtility.CacheColliders);
		for (int i = 0; i < num; i++)
		{
			if (!string.IsNullOrEmpty(myself.AI.m_WallTag) && GameObjectUtility.CacheColliders[i].CompareTag(myself.AI.m_WallTag))
			{
				lastCheckTime = Time.time;
				return true;
			}
		}
		return false;
	}
}
