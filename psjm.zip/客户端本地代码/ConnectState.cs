using System;

[Serializable]
public struct ConnectState
{
	public PlayerController master;

	public PlayerController guest;

	public bool IsNull
	{
		get
		{
			if (!(master == null))
			{
				return guest == null;
			}
			return true;
		}
	}
}
