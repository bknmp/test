using System;

[AttributeUsage(AttributeTargets.Field)]
public class CheckField : Attribute
{
}
