using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class BubbleBoxPageItem_Binder
{
	public UIDataBinder m_Host;

	public Image m_BubbleBox;

	public Text m_GainTips;

	public GameObject m_Active;

	public GameObject m_RedPoint;

	public UIStateItem m_OwnState;

	public Button m_Button;

	public Text m_ChatText;

	public Text m_Remain;

	public Image m_Extra;

	public void Bind(CommonDataCollection args)
	{
		int bubbleBoxID = args["bubbleBoxID"];
		HeadBubbleBoxInfo headBubbleBoxInfo = LocalResources.HeadBubbleBoxInfos.Get(bubbleBoxID);
		m_GainTips.text = headBubbleBoxInfo.GainTips;
		m_Active.SetActive(bubbleBoxID == LocalPlayerDatabase.PlayerInfo.activeBubbleBoxID);
		m_BubbleBox.sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon);
		m_RedPoint.SetActive(HeadBubbleBoxUtility.IsNewHeadBubbleBox(bubbleBoxID) && HeadBubbleBoxUtility.CanUse(bubbleBoxID));
		m_ChatText.color = GameChatColors.HexToColor(headBubbleBoxInfo.TextColor);
		m_ChatText.text = headBubbleBoxInfo.Name;
		if (bubbleBoxID == LocalPlayerDatabase.PlayerInfo.activeBubbleBoxID)
		{
			m_Active.SetActive(value: true);
		}
		else
		{
			m_Active.SetActive(value: false);
		}
		m_Button.onClick.RemoveAllListeners();
		if (HeadBubbleBoxUtility.hasHeadOrBubble(bubbleBoxID))
		{
			if (bubbleBoxID != LocalPlayerDatabase.PlayerInfo.activeBubbleBoxID)
			{
				m_Button.onClick.AddListener(delegate
				{
					HeadBubbleBoxUtility.SetHeadOrBubbleBox(bubbleBoxID, delegate
					{
						UILobby.Current.ShowTips(Localization.ChangeBubbleBoxSuccess);
					}, delegate(string failureTips)
					{
						UILobby.Current.ShowTips(failureTips);
					});
				});
			}
			if (headBubbleBoxInfo.SpecialLimit == SpecialLimit.WEEKLY_MEMBERSHIP)
			{
				int num = MembershipUtility.m_DayRemaining[1];
				if (num > 0)
				{
					m_Remain.text = num.ToString() + Localization.Day;
					m_OwnState.State = 2;
				}
				else
				{
					m_OwnState.State = 3;
				}
			}
			else if (headBubbleBoxInfo.SpecialLimit == SpecialLimit.MONTHLY_MEMBERSHIP)
			{
				int num2 = MembershipUtility.m_DayRemaining[2];
				if (num2 > 0)
				{
					m_Remain.text = num2.ToString() + Localization.Day;
					m_OwnState.State = 2;
				}
				else
				{
					m_OwnState.State = 3;
				}
			}
			else
			{
				int num3 = HeadBubbleBoxUtility.DayRemaining(bubbleBoxID);
				if (num3 == 0)
				{
					m_OwnState.State = 1;
				}
				else
				{
					m_Remain.text = num3.ToString() + Localization.Day;
					m_OwnState.State = 2;
				}
			}
		}
		else
		{
			m_OwnState.State = 0;
		}
		if (m_Extra != null)
		{
			Sprite sprite = SpriteSource.Inst.Find(headBubbleBoxInfo.Icon + "_extra");
			if (sprite != null)
			{
				m_Extra.gameObject.SetActive(value: true);
				m_Extra.sprite = sprite;
				m_Extra.SetNativeSize();
			}
			else
			{
				m_Extra.gameObject.SetActive(value: false);
			}
		}
	}
}
