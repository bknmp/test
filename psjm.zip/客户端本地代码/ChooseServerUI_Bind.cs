using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

public class ChooseServerUI_Bind
{
	public UIDataBinder m_Host;

	public ToggleGroup m_ToggleGroup;

	public UIDataScrollView m_ServersGroup;

	public static int SelectServerIndex;

	public static ServerListInfo AllServerInfo;

	private Action OnChooseServer;

	private int m_ServersCount;

	public void Bind(CommonDataCollection args)
	{
		OnChooseServer = (args["onChooseServer"].val as Action);
		m_ServersCount = AllServerInfo.serverIds.Length;
		int num = SelectServerIndex / 10;
		SetTabButton();
		ToggleGroupUtility.SetValue(m_ToggleGroup, num);
		SetServers(num, scrollToSelect: true);
	}

	private void SetTabButton()
	{
		int num = m_ServersCount / 10 + 1;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < num; i++)
		{
			commonDataCollection[i]["tabIndex"] = i;
		}
		m_ToggleGroup.GetComponent<UIDataScrollView>().SetItems(commonDataCollection.Array);
		ToggleGroupUtility.SetListener(m_ToggleGroup, OnTabChange);
	}

	private void SetServers(int tabIndex, bool scrollToSelect = false)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = tabIndex * 10; i < Mathf.Min(tabIndex * 10 + 10, m_ServersCount); i++)
		{
			commonDataCollection[i - tabIndex * 10]["serverIndex"] = i;
			commonDataCollection[i - tabIndex * 10]["onChooseServer"].val = new Action(ChooseServer);
		}
		m_ServersGroup.SetItems(commonDataCollection.Array);
		if (scrollToSelect && tabIndex == SelectServerIndex / 10)
		{
			m_ServersGroup.ScrollToItem(SelectServerIndex - tabIndex * 10);
		}
	}

	private void OnTabChange(bool isOn)
	{
		if (isOn)
		{
			int toggleGroupValue = ToggleGroupUtility.GetToggleGroupValue(m_ToggleGroup);
			SetServers(toggleGroupValue);
		}
	}

	private void ChooseServer()
	{
		m_Host.GetComponent<UIPopup>().GoBack();
		if (OnChooseServer != null)
		{
			OnChooseServer();
		}
	}

	public static void GetServersInfo(Delegates.VoidCallback callback = null)
	{
		GameHttpManager.Inst.Send(new GetServersInfo(), delegate(ServerListInfo res)
		{
			AllServerInfo = res;
			SelectServerIndex = ((!res.isOldPlayer) ? LastFreeServer() : 0);
			if (callback != null)
			{
				callback();
			}
		});
	}

	public static void SelectServer(Delegates.VoidCallback onSuccess = null)
	{
		ChooseServer chooseServer = new ChooseServer();
		chooseServer.serverId = AllServerInfo.serverIds[SelectServerIndex];
		GameHttpManager.Inst.Send(chooseServer, null, onSuccess);
	}

	private static int LastFreeServer()
	{
		int num = AllServerInfo.serverIds.Length;
		for (int num2 = num - 1; num2 >= 0; num2--)
		{
			if (AllServerInfo.serverStates[num2] == 0)
			{
				return num2;
			}
		}
		return num - 1;
	}
}
