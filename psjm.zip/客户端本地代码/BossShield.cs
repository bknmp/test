using System.Collections.Generic;
using UnityEngine;

public class BossShield : MonoBehaviour
{
	public float m_RangeSqr;

	private static List<BossShield> AllBossShields = new List<BossShield>();

	private void Start()
	{
		AllBossShields.Add(this);
	}

	private void OnDestroy()
	{
		AllBossShields.Remove(this);
	}

	private bool InShield(Vector3 pos)
	{
		return (pos - base.transform.position).sqrMagnitude < m_RangeSqr;
	}

	public static bool IsInBossShield(Vector3 pos)
	{
		foreach (BossShield allBossShield in AllBossShields)
		{
			if (allBossShield.InShield(pos))
			{
				return true;
			}
		}
		return false;
	}
}
