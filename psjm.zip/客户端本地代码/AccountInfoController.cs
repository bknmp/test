using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class AccountInfoController : MonoBehaviour
{
	public Text m_AccountNum;

	public string m_NumFormat = "{0}";

	public Text m_AccountName;

	public string m_NameFormat = "{0}";

	public Button m_CopyAccount;

	public void SetAccountInfo(int accountNum, string accountName)
	{
		if (m_AccountNum != null)
		{
			m_AccountNum.text = string.Format(m_NumFormat, accountNum);
		}
		if (m_AccountName != null)
		{
			m_AccountName.text = string.Format(m_NameFormat, accountName);
		}
		if (m_CopyAccount != null)
		{
			m_CopyAccount.onClick.AddListener(CopyAccount);
		}
	}

	private void CopyAccount()
	{
		ClipboardTool.CopyToSystemClipboard(m_AccountNum.text);
		UILobby.Current.ShowTips(Localization.TipsCopyOK);
	}
}
