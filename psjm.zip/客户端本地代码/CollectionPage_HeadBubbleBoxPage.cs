using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine.UI;

public class CollectionPage_HeadBubbleBoxPage
{
	public UIDataBinder m_Host;

	public Text m_HeadBoxProgress;

	public Text m_HeadBoxPersonality;

	public Text m_BubbleBoxProgress;

	public UITemplateInitiator m_HeadBoxes;

	public UITemplateInitiator m_BubbleBoxes;

	public Text m_BubbleBoxPersonality;

	private uint m_PlayerID;

	private HttpResponsePlayerInfo m_PlayerInfo;

	public void Bind(CommonDataCollection args)
	{
		int now = UtcTimeStamp.Now;
		m_PlayerID = args["roleID"];
		m_PlayerInfo = (HttpResponsePlayerInfo)args["playerInfo"].val;
		List<int> list = Rank(HeadBubbleBoxUtility.GetHeadOrBubbleBoxIDs(HeadBubbleBox.HeadBox, open: true, m_PlayerInfo));
		List<int> list2 = Rank(HeadBubbleBoxUtility.GetHeadOrBubbleBoxIDs(HeadBubbleBox.BubbleBox, open: true, m_PlayerInfo));
		int count = list.Count;
		int count2 = list2.Count;
		int count3 = HeadBubbleBoxUtility.GetOwnedHeadOrBubbleBoxIDs(m_PlayerInfo, HeadBubbleBox.HeadBox, permanent: true).Count;
		int count4 = HeadBubbleBoxUtility.GetOwnedHeadOrBubbleBoxIDs(m_PlayerInfo, HeadBubbleBox.BubbleBox, permanent: true).Count;
		m_HeadBoxProgress.text = $"{Localization.HeadBox}: {count3.ToString()}/{count.ToString()}";
		m_BubbleBoxProgress.text = $"{Localization.BubbleBox}: {count4.ToString()}/{count2.ToString()}";
		m_HeadBoxPersonality.text = HeadBubbleBoxUtility.GetPersonality(m_PlayerInfo, HeadBubbleBox.HeadBox).ToString();
		m_BubbleBoxPersonality.text = HeadBubbleBoxUtility.GetPersonality(m_PlayerInfo, HeadBubbleBox.BubbleBox).ToString();
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < list.Count; i++)
		{
			if (HeadBubbleBoxUtility.hasHeadOrBubble(list[i], m_PlayerInfo, forever: true))
			{
				commonDataCollection[num]["id"] = list[i];
				commonDataCollection[num]["owned"] = true;
				num++;
			}
			else if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
			{
				commonDataCollection[count3 + num2]["id"] = list[i];
				commonDataCollection[count3 + num2]["owned"] = false;
				num2++;
			}
		}
		m_HeadBoxes.Args = commonDataCollection;
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		num = 0;
		num2 = 0;
		for (int j = 0; j < list2.Count; j++)
		{
			if (HeadBubbleBoxUtility.hasHeadOrBubble(list2[j], m_PlayerInfo, forever: true))
			{
				commonDataCollection2[num]["id"] = list2[j];
				commonDataCollection2[num]["owned"] = true;
				num++;
			}
			else if (m_PlayerID == LocalPlayerDatabase.LoginInfo.roleID)
			{
				commonDataCollection2[count4 + num2]["id"] = list2[j];
				commonDataCollection2[count4 + num2]["owned"] = false;
				num2++;
			}
		}
		m_BubbleBoxes.Args = commonDataCollection2;
	}

	public List<int> Rank(List<int> headOrBubbleBoxIDs)
	{
		headOrBubbleBoxIDs.Sort((int x, int y) => LocalResources.HeadBubbleBoxInfos.Get(x).Rank.CompareTo(LocalResources.HeadBubbleBoxInfos.Get(y).Rank));
		return headOrBubbleBoxIDs;
	}
}
