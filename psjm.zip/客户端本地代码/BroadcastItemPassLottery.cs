using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

public class BroadcastItemPassLottery : MonoBehaviour
{
	public UIDataBinder m_Host;

	public Text m_Player;

	public Image m_Icon;

	public Text m_Content;

	public PlayerSpaceButton m_SpaceButton;

	public UIStateRawImage m_Bg;

	public void Bind(CommonDataCollection args)
	{
		PassLotteryBroadcastInfo passLotteryBroadcastInfo = (PassLotteryBroadcastInfo)args["broadcast"].val;
		m_SpaceButton.SetPlayerID(passLotteryBroadcastInfo.roleID);
		m_Content.text = passLotteryBroadcastInfo.content;
		m_SpaceButton.SetDirty();
		m_SpaceButton.OnClickedSpace = delegate
		{
			if (UILobby.Current.CurrentPopup() != null)
			{
				UILobby.Current.CurrentPopup().GoBack();
			}
		};
	}
}
