using GameMessages;
using System.Collections.Generic;

public static class ChatUtility
{
	public static Dictionary<uint, bool> m_ChatBlacklistDict = new Dictionary<uint, bool>();

	public const int m_MaxChatCount = 1000;

	public static ChatChannelInfo GetChatChannelInfo(int channelID)
	{
		ChatChannelInfo[] infos = LocalPlayerDatabase.ChatChannelList.infos;
		foreach (ChatChannelInfo chatChannelInfo in infos)
		{
			if (chatChannelInfo.channelID == channelID)
			{
				return chatChannelInfo;
			}
		}
		return null;
	}

	public static void SetBlockPlayer(uint playerID, bool block)
	{
		m_ChatBlacklistDict[playerID] = block;
	}

	public static bool IsBlockPlayer(uint playerID)
	{
		m_ChatBlacklistDict.TryGetValue(playerID, out bool value);
		return value;
	}
}
