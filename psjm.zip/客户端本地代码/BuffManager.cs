using DG.Tweening;
using LightUI;
using LightUtility;
using SimpleJson;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(PhotonView))]
public class BuffManager : BatchUpdateBehaviour
{
	public enum BuffType
	{
		Default,
		AddMaxLife,
		ConnectRecover,
		Bubble,
		BubbleCaged,
		RedEnvelope,
		LifeShield
	}

	public enum EndType
	{
		Default,
		RPC
	}

	public class Buff
	{
		public int id;

		public float speedGain;

		public float jumpGain;

		public float cooldownGain;

		public float criticalGain;

		public bool skillDisabled;

		public bool invincible;

		public float bloodSucking;

		public bool loseControl;

		public float startTime;

		public float duration;

		public string userID;

		public bool debuff;

		public bool interrupt;

		public bool silence;

		public float damage;

		public float damageInterval;

		public float lastDamageTime;

		public string createUserID;

		public float shield;

		public EndType endType;

		public bool endingRpc;

		public BuffCorrelation correlation;

		public bool ignoreDebuff;

		public bool caged;

		public bool dyingUseable;

		public string icon;

		public bool avoidable;

		public bool deceleration;

		public DamageSourceType damageSourceType;

		public float remainedTime
		{
			get
			{
				if (!(duration > 0f))
				{
					return float.MaxValue;
				}
				return duration - (InGameScene.Inst.GameTime - startTime);
			}
		}

		public virtual bool BuffStart(BuffManager buffManager, PlayerController playerController)
		{
			return true;
		}

		public virtual void BuffUpdate()
		{
		}

		public virtual void BuffEnd(bool reconnect = false)
		{
		}
	}

	public PhotonView m_PhotonView;

	public UITemplateInitiator m_BuffDisplay;

	public UITemplateInitiator m_TopBuffDisplay;

	public GameObject m_InvincibleEffect;

	public GameObject[] m_SprintEffects;

	public Transform m_EffectRoot;

	public UnityAction OnSkillDisabledStart;

	public UnityAction OnSkillDisabledEnd;

	private PlayerController m_PlayerController;

	private DogObject m_DogController;

	private ProjectileLauncher m_Launcher;

	private CommonDataCollection m_BuffList = new CommonDataCollection();

	private CommonDataCollection m_BottomBuffList = new CommonDataCollection();

	private CommonDataCollection m_TopBuffList = new CommonDataCollection();

	private GameObject m_InvincibleEffectInst;

	private GameObject m_SprintEffectInst;

	private GameObject m_SprintEffect;

	private float m_SpeedGain;

	private float m_AddSpeed;

	private float m_CooldownGain = 1f;

	private float m_JumpGain;

	private float m_CriticalGain;

	private float m_BloodSucking;

	private bool m_IsSkillDisabled;

	private bool m_IsInvincible;

	private bool m_LastSkillDisabled;

	private bool m_IsLoseControl;

	private bool m_IsSprint;

	private bool m_IsDeBuff;

	private bool m_IsInterrupt;

	private bool m_IsSilence;

	private bool m_IsStoic;

	private bool m_IgnoreDebuff;

	private bool m_IsCaged;

	private bool m_IsAvoidable;

	private bool m_IsDeceleration;

	public static List<BuffManager> AllBuffManagers = new List<BuffManager>();

	public RoleType PlayingRole
	{
		get;
		set;
	}

	public float SpeedGain => m_SpeedGain;

	public float AddSpeedGain => m_AddSpeed;

	public float CooldownGain => m_CooldownGain;

	public float JumpGain => m_JumpGain;

	public float CriticalGain => m_CriticalGain;

	public float BloodSucking => m_BloodSucking;

	public bool IsSkillDisabled => m_IsSkillDisabled;

	public bool IsInvincible => m_IsInvincible;

	public bool IsAvoidable => m_IsAvoidable;

	public bool IsLoseControl => m_IsLoseControl;

	public bool IsDeBuff => m_IsDeBuff;

	public bool IsInterrupt => m_IsInterrupt;

	public bool IsDeceleration => m_IsDeceleration;

	public bool IsSprint => m_IsSprint;

	public bool IsSilence => m_IsSilence;

	public bool IsCaged => m_IsCaged;

	public bool IsStoic
	{
		get
		{
			if (!m_IsStoic && (!(m_Launcher != null) || !m_Launcher.IsSabering))
			{
				return m_PlayerController.Shifter.IsMissile;
			}
			return true;
		}
	}

	public event Delegates.ObjectCallback2<int, BuffCorrelation> OnBuffCreated;

	public event Delegates.IntCallback OnBuffRemoved;

	private void Awake()
	{
		m_PlayerController = GetComponent<PlayerController>();
		m_DogController = GetComponent<DogObject>();
		if (m_PlayerController != null)
		{
			m_Launcher = m_PlayerController.ProjectileLauncher;
		}
		AllBuffManagers.Add(this);
	}

	private void Start()
	{
		BatchUpdateManager.Inst.AddUpdate(this);
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		AllBuffManagers.Remove(this);
	}

	private void UpdateProperty()
	{
		m_SpeedGain = 0f;
		m_AddSpeed = 0f;
		m_CooldownGain = 1f;
		m_JumpGain = 0f;
		m_CriticalGain = 0f;
		m_BloodSucking = 0f;
		m_IsSkillDisabled = false;
		m_IsInvincible = false;
		m_IsLoseControl = false;
		m_IsSprint = false;
		m_IsDeBuff = false;
		m_IsInterrupt = false;
		m_IsSilence = false;
		m_IgnoreDebuff = false;
		m_IsCaged = false;
		m_IsAvoidable = false;
		m_IsDeceleration = false;
		int num = 0;
		while (num < m_BuffList.ArraySize)
		{
			Buff buff = m_BuffList[num]["buff"].val as Buff;
			if (buff.remainedTime <= 0f)
			{
				if (buff.endType == EndType.Default)
				{
					DoRemoveBuffByIndex(num);
				}
				else if (buff.endType == EndType.RPC)
				{
					if (!buff.endingRpc && m_PhotonView.isMine)
					{
						m_PhotonView.RPC("LocalMoveBuff", PhotonTargets.AllViaServer, buff.id);
						buff.endingRpc = true;
					}
					num++;
				}
				continue;
			}
			buff.BuffUpdate();
			m_SpeedGain += buff.speedGain;
			if (buff.speedGain > 0f)
			{
				m_AddSpeed += buff.speedGain;
			}
			m_JumpGain += buff.jumpGain;
			m_CriticalGain += buff.criticalGain;
			m_CooldownGain *= Mathf.Max(0f, 1f - buff.cooldownGain);
			m_BloodSucking = Mathf.Max(m_BloodSucking, buff.bloodSucking);
			m_IsSkillDisabled = (m_IsSkillDisabled || buff.skillDisabled || (m_PlayerController != null && m_PlayerController.OnHookJoint));
			m_IsInvincible = (m_IsInvincible || buff.invincible);
			m_IsLoseControl = (m_IsLoseControl || buff.loseControl);
			num++;
			if (buff.id == 103)
			{
				m_IsSprint = true;
			}
			if (buff.debuff)
			{
				m_IsDeBuff = true;
			}
			if (buff.interrupt)
			{
				m_IsInterrupt = true;
			}
			if (buff.silence)
			{
				m_IsSilence = true;
			}
			if (buff.ignoreDebuff)
			{
				m_IgnoreDebuff = true;
			}
			if (buff.caged)
			{
				m_IsCaged = true;
			}
			if (buff.avoidable)
			{
				m_IsAvoidable = true;
			}
			if (buff.deceleration)
			{
				m_IsDeceleration = true;
			}
			if (m_PhotonView.isMine && (double)Mathf.Abs(buff.damage) > 0.001 && InGameScene.Inst.GameTime - buff.lastDamageTime >= buff.damageInterval)
			{
				DamageSourceType damageSourceType = buff.damageSourceType;
				if (m_PlayerController != null && ((buff.damage < 0f && m_PlayerController.IsHurt) || buff.damage > 0f))
				{
					m_PlayerController.RpcApplyDamage(buff.damage, UserId2NumId.Get(buff.createUserID), damageSourceType);
				}
				if (m_DogController != null && ((buff.damage < 0f && m_DogController.IsHurt) || buff.damage > 0f))
				{
					m_DogController.RpcApplyDamage(buff.damage, UserId2NumId.Get(buff.createUserID), damageSourceType);
				}
				buff.lastDamageTime = InGameScene.Inst.GameTime;
			}
		}
	}

	public override void BatchUpdate()
	{
		UpdateProperty();
		bool flag = m_PlayerController == null || (m_PlayerController.IsVisible && !m_PlayerController.InStealth && m_PlayerController.CanShowBody);
		UpdateEffect(m_IsInvincible && flag, m_InvincibleEffect, ref m_InvincibleEffectInst);
		UpdateEffect(m_IsSprint && flag && m_PlayerController != null && m_PlayerController.SpeedForAnimator > 0.1f, m_SprintEffect, ref m_SprintEffectInst);
		UpdateEvents();
	}

	private void UpdateEffect(bool active, GameObject effect, ref GameObject inst)
	{
		if (!(effect == null))
		{
			if (active && inst == null)
			{
				Transform parent = (m_EffectRoot != null) ? m_EffectRoot : base.transform;
				inst = PoolSpawner.Spawn(effect, parent);
				inst.transform.localPosition = effect.transform.localPosition;
				inst.transform.localRotation = effect.transform.localRotation;
				inst.transform.localScale = Vector3.zero;
				inst.transform.DOScale(effect.transform.localScale, 0.4f).SetEase(Ease.OutBack);
			}
			else if (!active && inst != null)
			{
				GameObject tmp = inst;
				inst.transform.DOScale(0f, 0.4f).SetEase(Ease.InBack).OnComplete(delegate
				{
					PoolSpawner.DeSpawn(tmp);
				});
				inst = null;
			}
		}
	}

	private void UpdateEvents()
	{
		if (m_LastSkillDisabled == m_IsSkillDisabled)
		{
			return;
		}
		if (m_IsSkillDisabled)
		{
			if (OnSkillDisabledStart != null)
			{
				OnSkillDisabledStart();
			}
		}
		else if (OnSkillDisabledEnd != null)
		{
			OnSkillDisabledEnd();
		}
		m_LastSkillDisabled = m_IsSkillDisabled;
	}

	private void UpdateBuffDisplay()
	{
		if (GameRuntime.IsMapRedEnvelopeFight && m_TopBuffDisplay != null)
		{
			m_TopBuffList.Clear();
			m_BottomBuffList.Clear();
			for (int i = 0; i < m_BuffList.ArraySize; i++)
			{
				Buff buff = m_BuffList[i]["buff"].val as Buff;
				if (LocalResources.BuffTable.Get(buff.id).BuffType == BuffType.RedEnvelope)
				{
					m_TopBuffList[m_TopBuffList.ArraySize] = m_BuffList[i];
				}
				else
				{
					m_BottomBuffList[m_BottomBuffList.ArraySize] = m_BuffList[i];
				}
			}
			m_BuffDisplay.Args = m_BottomBuffList;
			m_TopBuffDisplay.Args = m_TopBuffList;
		}
		else
		{
			m_BuffDisplay.Args = m_BuffList;
		}
	}

	public void DoCreateBuff(int id, float duration, BuffCorrelation correlation, float startTime = 0f, bool triggerTalent = true, string createUserID = "", float shield = -1f)
	{
		float num = (InGameScene.Inst != null) ? InGameScene.Inst.GameTime : Time.realtimeSinceStartup;
		float lastDamageTime = num;
		BuffInfo buffInfo = LocalResources.BuffTable.Get(id);
		if (!buffInfo.Multiple)
		{
			for (int i = 0; i < m_BuffList.ArraySize; i++)
			{
				Buff buff = m_BuffList[i]["buff"].val as Buff;
				if (buff.id == id)
				{
					if (!buffInfo.Tilable)
					{
						return;
					}
					lastDamageTime = buff.lastDamageTime;
					m_BuffList.Array.Remove(i);
					buff.BuffEnd();
					break;
				}
			}
		}
		Buff buff2;
		switch (buffInfo.BuffType)
		{
		case BuffType.AddMaxLife:
			buff2 = new AddMaxLifeBuff();
			break;
		case BuffType.LifeShield:
			buff2 = new LifeShield(buffInfo.Shield);
			break;
		case BuffType.ConnectRecover:
			buff2 = new ConnectRecoverBuff();
			break;
		case BuffType.Bubble:
			buff2 = new BubbleBuff();
			break;
		case BuffType.BubbleCaged:
			buff2 = new BubbleCagedDebuff();
			break;
		case BuffType.RedEnvelope:
			buff2 = new RedEnvelopeBuff();
			break;
		default:
			buff2 = new Buff();
			break;
		}
		buff2.id = id;
		buff2.startTime = ((startTime < 1E-06f) ? num : startTime);
		buff2.duration = duration;
		buff2.speedGain = buffInfo.SpeedGain;
		buff2.jumpGain = buffInfo.JumpGain;
		buff2.cooldownGain = buffInfo.CooldownGain;
		buff2.criticalGain = buffInfo.CriticalGain;
		buff2.skillDisabled = buffInfo.SkillDisabled;
		buff2.invincible = buffInfo.Invincible;
		buff2.bloodSucking = buffInfo.BloodSucking;
		buff2.loseControl = buffInfo.LoseControl;
		buff2.debuff = buffInfo.DeBuff;
		buff2.interrupt = buffInfo.Interrupt;
		buff2.silence = buffInfo.Silence;
		buff2.damage = buffInfo.Damage;
		buff2.damageInterval = buffInfo.DamageInterval;
		buff2.lastDamageTime = lastDamageTime;
		buff2.createUserID = createUserID;
		buff2.shield = ((shield >= 0f) ? shield : buffInfo.Shield);
		buff2.endType = buffInfo.EndType;
		buff2.correlation = correlation;
		buff2.ignoreDebuff = buffInfo.IgnoreDebuff;
		buff2.caged = buffInfo.Caged;
		buff2.dyingUseable = buffInfo.DyingUseable;
		buff2.icon = buffInfo.Icon;
		buff2.avoidable = buffInfo.Avoidable;
		buff2.damageSourceType = DamageSourceType.Buff;
		buff2.deceleration = buffInfo.Deceleration;
		if (buff2.id == 201)
		{
			buff2.damageSourceType = DamageSourceType.Slime;
		}
		if (buff2.debuff && m_IgnoreDebuff)
		{
			return;
		}
		if (m_PlayerController != null)
		{
			buff2.userID = m_PlayerController.UserId;
			if (buffInfo.ShowEnemy)
			{
				m_PlayerController.ShowTime = num + duration;
			}
		}
		else if (m_DogController != null)
		{
			buff2.userID = m_DogController.UserId;
		}
		m_IsInvincible = buffInfo.Invincible;
		m_BloodSucking = buffInfo.BloodSucking;
		m_IsLoseControl = buffInfo.LoseControl;
		if (buffInfo.Id == 103)
		{
			m_IsSprint = true;
			if (m_SprintEffect == null)
			{
				int num2 = 100;
				BaseCardSkinInfo baseCardSkinInfo = m_PlayerController.Cards.Contains(num2) ? m_PlayerController.GetBaseCardSkinInfo(num2) : LocalResources.CardSkinTable.Get(LocalResources.InGameStoreTable.Get(num2).DefaultSkinID);
				string effectName = baseCardSkinInfo.Effect;
				if (!string.IsNullOrEmpty(effectName))
				{
					m_SprintEffect = m_SprintEffects.Find((GameObject t) => t.name.Equals(effectName));
				}
			}
		}
		if (buff2.BuffStart(this, m_PlayerController))
		{
			if (!string.IsNullOrEmpty(buffInfo.Icon))
			{
				CommonDataCollection commonDataCollection = new CommonDataCollection();
				commonDataCollection["buff"].val = buff2;
				m_BuffList.Array.Add(commonDataCollection);
				UpdateBuffDisplay();
			}
			if (triggerTalent && m_PlayerController != null && m_PlayerController.IsLocalPlayer && buffInfo.Correlation != BuffCorrelation.Talent && buffInfo.SpeedGain > 0f && buffInfo.Id != 506)
			{
				m_PlayerController.TalentManager.LocalCheckShiningRush();
			}
			if (buff2.shield > 0f)
			{
				m_PlayerController.UpdateBloodBar(tween: false);
			}
			if (this.OnBuffCreated != null)
			{
				this.OnBuffCreated(id, correlation);
			}
		}
	}

	[PunRPC]
	private void LocalMoveBuff(int id)
	{
		DoRemoveBuff(id);
	}

	private float TryOverrideTalentDuration(BuffInfo buff, BuffCorrelation correlation, int talentId, float duration, bool overrideDuration)
	{
		if (m_PlayerController == null)
		{
			return duration;
		}
		if (correlation == BuffCorrelation.Talent)
		{
			if (talentId != -1 && overrideDuration)
			{
				TalentInfo talentInfo = LocalResources.TalentTable.Get(talentId);
				int talentLevel = m_PlayerController.TalentManager.GetTalentLevel(talentId);
				if (talentLevel > 0 && talentInfo.Params[talentLevel - 1] > 0f)
				{
					duration = talentInfo.Params[talentLevel - 1];
				}
			}
		}
		else if (buff.DeBuff && buff.SpeedGain < 0f)
		{
			duration *= 1f - m_PlayerController.TalentManager.LocalCheckProtectByMagic();
		}
		return duration;
	}

	[PunRPC]
	private void LocalCreateBuff(int id, int carriedPropID)
	{
		if (id <= 0)
		{
			return;
		}
		PropInfo propInfo = LocalResources.PropTable.Find(carriedPropID);
		if (propInfo != null && carriedPropID > 0 && propInfo.InGameStoreItemID > 0)
		{
			AntiCheatingSystem.BehaviourCheck(RpcBehaviourType.UsePropcard, m_PlayerController, propInfo.InGameStoreItemID);
		}
		AntiCheatingSystem.BehaviourCheck(RpcBehaviourType.CreateBuff, m_PlayerController, id, BuffCorrelation.Buy, -1, m_PlayerController);
		BuffInfo buffInfo = LocalResources.BuffTable.Find(id);
		float duration = buffInfo.Duration;
		float shield = buffInfo.Shield;
		if (m_PlayerController != null)
		{
			m_PlayerController.LocalRemoveProp(carriedPropID);
			if (buffInfo.InGameStoreItemID != 0)
			{
				CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(buffInfo.InGameStoreItemID);
				if (cardGrowth.Type == CardGrowthType.Time)
				{
					duration = CardUtility.GetCardLevelGrowthResult(cardGrowth, m_PlayerController.GetCardLevel(buffInfo.InGameStoreItemID));
				}
				else if (cardGrowth.Type == CardGrowthType.Amount && buffInfo.Shield > 0f)
				{
					shield = CardUtility.GetCardLevelGrowthResult(cardGrowth, m_PlayerController.GetCardLevel(buffInfo.InGameStoreItemID));
				}
			}
		}
		DoCreateBuff(id, duration, BuffCorrelation.Buy, 0f, triggerTalent: true, "", shield);
	}

	public void RpcCreateBuff(int id, int carriedPropID)
	{
		m_PhotonView.RPC("LocalCreateBuff", PhotonTargets.AllViaServer, id, carriedPropID);
	}

	public void RpcCreateCorrelatedBuff(PlayerController user, int id, BuffCorrelation correlation, int talentId = -1, bool overrideDuration = false)
	{
		int num = UserId2NumId.Get(user.UserId);
		m_PhotonView.RPC("LocalCreateCorrelatedBuff", PhotonTargets.AllViaServer, num, id, correlation, talentId, overrideDuration);
	}

	[PunRPC]
	public void LocalCreateCorrelatedBuff(int numID, int id, BuffCorrelation correlation, int talentId = -1, bool overrideDuration = false)
	{
		string userID = NumId2UserId.Get(numID);
		CreateCorrelatedBuff(PlayerController.FindPlayer(userID), id, correlation, talentId, overrideDuration);
	}

	public void CreateCorrelatedBuff(PlayerController user, int id, BuffCorrelation correlation, int talentId = -1, bool overrideDuration = false)
	{
		BuffInfo buffInfo = LocalResources.BuffTable.Find(id);
		if (buffInfo == null || id <= 0 || (!buffInfo.DyingUseable && ((m_PlayerController != null && m_PlayerController.IsDying) || (m_DogController != null && m_DogController.IsDead))))
		{
			return;
		}
		AntiCheatingSystem.BehaviourCheck(RpcBehaviourType.CreateBuff, m_PlayerController, id, correlation, talentId, user);
		float duration = buffInfo.Duration;
		float shield = buffInfo.Shield;
		if (user != null && buffInfo.InGameStoreItemID != 0)
		{
			CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(buffInfo.InGameStoreItemID);
			if (cardGrowth.Type == CardGrowthType.Time)
			{
				duration = CardUtility.GetCardLevelGrowthResult(cardGrowth, user.GetCardLevel(buffInfo.InGameStoreItemID));
			}
			else if (cardGrowth.Type == CardGrowthType.Amount && buffInfo.Shield > 0f)
			{
				shield = CardUtility.GetCardLevelGrowthResult(cardGrowth, user.GetCardLevel(buffInfo.InGameStoreItemID));
			}
		}
		duration = TryOverrideTalentDuration(buffInfo, correlation, talentId, duration, overrideDuration);
		DoCreateBuff(id, duration, correlation, 0f, triggerTalent: true, (user != null) ? user.UserId : "", shield);
	}

	public void RemoveCorrelatedBuff(int id)
	{
		if (LocalResources.BuffTable.Find(id) != null)
		{
			DoRemoveBuff(id);
		}
	}

	public void LocalClearAllDeBuffs(bool force = false)
	{
		foreach (BuffInfo item in LocalResources.BuffTable)
		{
			if (item.DeBuff && (force || item.Clearable))
			{
				DoRemoveBuff(item.Id);
			}
		}
	}

	private void DoRemoveBuff(int id)
	{
		int num = 0;
		while (true)
		{
			if (num < m_BuffList.ArraySize)
			{
				if ((m_BuffList[num]["buff"].val as Buff).id == id)
				{
					break;
				}
				num++;
				continue;
			}
			return;
		}
		DoRemoveBuffByIndex(num);
	}

	private void DoRemoveBuffByIndex(int idx, bool reconnect = false)
	{
		Buff buff = m_BuffList[idx]["buff"].val as Buff;
		if (buff.shield > 0f)
		{
			m_PlayerController.UpdateBloodBar(tween: true);
		}
		m_BuffList.Array.Remove(idx);
		UpdateBuffDisplay();
		UpdateProperty();
		buff.BuffEnd(reconnect);
		if (this.OnBuffRemoved != null)
		{
			this.OnBuffRemoved(buff.id);
		}
	}

	public void LocalClearAllBuffs(bool force = true, bool reconnect = false)
	{
		int num = 0;
		while (num < m_BuffList.ArraySize)
		{
			Buff buff = m_BuffList[num]["buff"].val as Buff;
			if (!force && buff.debuff && buff.dyingUseable)
			{
				num++;
			}
			else
			{
				DoRemoveBuffByIndex(num, reconnect);
			}
		}
	}

	public void LocalClearBuffs(int excludeBuffId = -1)
	{
		int num = 0;
		while (num < m_BuffList.ArraySize)
		{
			Buff buff = m_BuffList[num]["buff"].val as Buff;
			if (buff.debuff || buff.id == excludeBuffId)
			{
				num++;
			}
			else
			{
				DoRemoveBuffByIndex(num);
			}
		}
	}

	public bool ContainsBuff(int id)
	{
		for (int i = 0; i < m_BuffList.ArraySize; i++)
		{
			Buff buff = m_BuffList[i]["buff"].val as Buff;
			if (buff != null && buff.id == id)
			{
				return true;
			}
		}
		return false;
	}

	public float GetSkillDisabledDuration(bool remained)
	{
		float num = 0f;
		for (int i = 0; i < m_BuffList.ArraySize; i++)
		{
			Buff buff = m_BuffList[i]["buff"].val as Buff;
			if (LocalResources.BuffTable.Get(buff.id).SkillDisabled)
			{
				num = (remained ? Mathf.Max(num, buff.remainedTime) : buff.duration);
			}
		}
		return num;
	}

	public Vector3 GetOverrideControllOffset(Vector3 dir)
	{
		if (m_Launcher == null)
		{
			m_Launcher = m_PlayerController.ProjectileLauncher;
		}
		if (IsLoseControl && (m_Launcher.CurrentWeapont == null || m_Launcher.CurrentWeapont.ProjectileType != ProjectileType.Placeable) && !m_PlayerController.Shifter.IsSkateBoard)
		{
			dir *= -1f;
		}
		return dir;
	}

	public float DamageShield(float damage)
	{
		if (damage <= 0f)
		{
			return damage;
		}
		for (int i = 0; i < m_BuffList.ArraySize; i++)
		{
			Buff buff = m_BuffList[i]["buff"].val as Buff;
			float num = Mathf.Min(damage, buff.shield);
			buff.shield -= num;
			damage -= num;
			if (damage <= 0f)
			{
				break;
			}
		}
		return damage;
	}

	public float GetShieldValue()
	{
		float num = 0f;
		for (int i = 0; i < m_BuffList.ArraySize; i++)
		{
			Buff buff = m_BuffList[i]["buff"].val as Buff;
			num += buff.shield;
		}
		return num;
	}

	private void OnReSyncWrite(object data)
	{
		if (m_BuffList.ArraySize > 0)
		{
			JsonObject jsonObject = data as JsonObject;
			JsonArray jsonArray = new JsonArray();
			for (int i = 0; i < m_BuffList.ArraySize; i++)
			{
				Buff buff = m_BuffList[i]["buff"].val as Buff;
				JsonObject jsonObject2 = new JsonObject();
				jsonObject2["id"] = buff.id;
				jsonObject2["duration"] = buff.duration;
				jsonObject2["startTime"] = buff.startTime;
				jsonObject2["shield"] = buff.shield;
				jsonObject2["createUserID"] = buff.createUserID;
				jsonObject2["correlation"] = (int)buff.correlation;
				jsonArray.Add(jsonObject2);
			}
			jsonObject["buffs"] = jsonArray;
		}
	}

	private void OnReSyncRead(object data)
	{
		JsonObject jsonObject = data as JsonObject;
		float shieldValue = GetShieldValue();
		LocalClearAllBuffs(force: true, reconnect: true);
		if (jsonObject.ContainsKey("buffs"))
		{
			foreach (object item in jsonObject["buffs"] as JsonArray)
			{
				JsonObject obj = item as JsonObject;
				int id = obj.AsInt("id");
				float duration = obj.AsFloat("duration");
				float startTime = obj.AsFloat("startTime");
				float shield = obj.AsFloat("shield");
				string createUserID = obj["createUserID"] as string;
				BuffCorrelation correlation = (BuffCorrelation)obj.AsInt("correlation");
				DoCreateBuff(id, duration, correlation, startTime, triggerTalent: false, createUserID, shield);
			}
		}
		if (GetShieldValue() != shieldValue)
		{
			m_PlayerController.UpdateBloodBar(tween: false);
		}
	}

	public static BuffManager FindBuffManager(int instanceID)
	{
		foreach (BuffManager allBuffManager in AllBuffManagers)
		{
			if (allBuffManager.GetInstanceID() == instanceID)
			{
				return allBuffManager;
			}
		}
		return null;
	}
}
