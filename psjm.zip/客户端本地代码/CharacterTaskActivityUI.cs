using GameMessages;
using LightUI;
using System;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterTaskActivityUI
{
	public UIDataBinder m_Host;

	public RectTransform m_TaskAnchor;

	public RectTransform m_ProcessAnchor;

	public UIDataBinder m_TaskActivityUI;

	public Text m_Time;

	public UIDataBinder m_CommonProgressActivity;

	public Text m_Desc;

	private string m_TimeFormat;

	private UIDataBinder m_TaskUIInst;

	private UIDataBinder m_ProcessUIInst;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		Activity activity = args["Activity"].val as Activity;
		m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(activity.startTime), UITimeText.GetDateTime(activity.endTime));
		m_Desc.text = LocalResources.ActivityLobbyInfos.Get(activity.activityId).Desc;
		if (m_TaskUIInst == null)
		{
			m_TaskUIInst = UnityEngine.Object.Instantiate(m_TaskActivityUI, m_TaskAnchor);
			args["TaskClaimAction"].val = new Action(DoTaskTaskClaim);
			args["RefreshActivityLobbyRedPoint"] = true;
			m_TaskUIInst.Args = args;
		}
		args["ProgressUpdateAction"].val = new Action(DoProgressUpdate);
		if (m_ProcessUIInst == null)
		{
			m_ProcessUIInst = UnityEngine.Object.Instantiate(m_CommonProgressActivity, m_ProcessAnchor);
		}
		m_ProcessUIInst.Args = args;
	}

	private void DoTaskTaskClaim()
	{
		m_ProcessUIInst.UpdateBinding();
	}

	private void DoProgressUpdate()
	{
		m_ProcessUIInst.UpdateBinding();
	}

	public static bool GetRedPoint()
	{
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.CHARACTER_TASK_ACTIVITY, ActivityCollectionType.CHARACTER_ACTIVITY);
		if (activityByActivityTypeAndCollectionType == null)
		{
			return false;
		}
		if (CommonProgressActivity.CommonProgressAllClaim(activityByActivityTypeAndCollectionType.activityId) == activityByActivityTypeAndCollectionType.startTime)
		{
			return false;
		}
		if (!CommonProgressActivity.GetRedPoint(activityByActivityTypeAndCollectionType.activityId))
		{
			return TaskUtility.CanReceiveTaskReward(activityByActivityTypeAndCollectionType.activityId);
		}
		return true;
	}
}
