using LightUtility;
using System;
using UnityEngine;

public class ConnectLine : MonoBehaviour
{
	public LineRenderer m_LineRenderer;

	public int m_SegmentNum = 50;

	public float m_WaveHeight = 0.2f;

	public float m_WaveSpeed = 1f;

	public float m_LineWidth = 0.5f;

	public AnimationCurve m_WaveHeightCurve;

	public Material m_Hidden;

	public Material m_Material;

	public Material m_MaterialMine;

	public GameObject m_OnLineFX;

	private Vector3[] m_Points;

	private Transform m_Source;

	private Transform m_Target;

	private float m_MaxLenght;

	private GameObject m_OnLineFXInst;

	private void Awake()
	{
		m_Points = ArrayUtility.Create<Vector3>(m_SegmentNum);
	}

	private void Update()
	{
		if (m_Source != null && m_Target != null)
		{
			UpdatePoints();
			UpdateLineWidth();
			UpdateLineFx();
		}
	}

	private void UpdatePoints()
	{
		Vector3 position = m_Source.position;
		Vector3 position2 = m_Target.position;
		float num = Vector3.Distance(position2, position);
		Vector3 normalized = (position2 - position).normalized;
		float num2 = num / (float)m_SegmentNum;
		float num3 = 0f;
		float num4 = 1f / (float)m_SegmentNum;
		float waveSpeed = m_WaveSpeed;
		if (m_LineRenderer.positionCount < m_Points.Length)
		{
			UnityEngine.Debug.LogError($"长度错误 {m_LineRenderer.positionCount} {m_Points.Length}");
			m_LineRenderer.positionCount = m_Points.Length;
		}
		for (int i = 0; i < m_Points.Length; i++)
		{
			m_Points[i] = position + (float)i * num2 * normalized;
			float num5 = Mathf.Sin((float)Math.PI * ((float)i * num2 + Time.time * waveSpeed)) * m_WaveHeight * m_WaveHeightCurve.Evaluate(num3);
			m_Points[i].x += num5;
			m_Points[i].z -= num5;
			m_LineRenderer.SetPosition(i, m_Points[i]);
			num3 += num4;
		}
	}

	private void UpdateLineWidth()
	{
		if (m_LineRenderer.positionCount > 2)
		{
			float b = Vector3.Distance(m_LineRenderer.GetPosition(0), m_LineRenderer.GetPosition(m_LineRenderer.positionCount - 1));
			b = Mathf.Max(3f, b);
			float b2 = m_LineWidth - b * (m_LineWidth / m_MaxLenght);
			b2 = Mathf.Max(0f, b2);
			m_LineRenderer.startWidth = b2;
			m_LineRenderer.endWidth = b2;
			if (m_OnLineFXInst != null)
			{
				m_OnLineFXInst.SetActive(b2 > 0f);
			}
		}
	}

	private void UpdateLineFx()
	{
		if (m_OnLineFXInst != null)
		{
			Vector3 position = m_Source.position;
			Vector3 position2 = m_Target.position;
			float num = Vector3.Distance(position2, position);
			Vector3 normalized = (position2 - position).normalized;
			m_OnLineFXInst.transform.position = position + num * 0.5f * normalized;
			m_OnLineFXInst.transform.localScale = new Vector3(Mathf.Max(0f, num - 2f), 1f, 1f);
			m_OnLineFXInst.transform.rotation = Quaternion.LookRotation(normalized) * Quaternion.Euler(new Vector3(0f, 90f, 0f));
		}
	}

	public void Init()
	{
		m_LineRenderer.positionCount = 0;
		m_Source = null;
		m_Target = null;
	}

	public void Connect(Transform from, Transform to, float maxLenght, bool isMine, bool connected)
	{
		m_Source = from;
		m_Target = to;
		m_MaxLenght = maxLenght;
		m_LineRenderer.positionCount = m_SegmentNum;
		m_LineRenderer.materials = new Material[2]
		{
			m_Hidden,
			isMine ? m_MaterialMine : m_Material
		};
		if (m_Points == null || m_Points.Length != m_SegmentNum)
		{
			m_Points = ArrayUtility.Create<Vector3>(m_SegmentNum);
		}
		if (connected && m_OnLineFX != null && m_OnLineFXInst == null)
		{
			m_OnLineFXInst = PoolSpawner.Spawn(m_OnLineFX, base.transform.parent);
		}
		Update();
	}

	public void HideOnLineFx()
	{
		if (m_OnLineFXInst != null)
		{
			PoolSpawner.DeSpawn(m_OnLineFXInst);
			m_OnLineFXInst = null;
		}
	}

	public void Disconnect()
	{
		Destroy();
	}

	private void Destroy()
	{
		m_Source = null;
		m_Target = null;
		m_LineRenderer.positionCount = 0;
		HideOnLineFx();
		PoolSpawner.DeSpawn(base.gameObject);
	}
}
