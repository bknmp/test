using LightUI;
using LightUtility;
using System.Collections.Generic;

internal class CardLotteryUI_PreviewTemplate
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Items;

	public UIStateItem m_NameState;

	public CardPreviewConfig m_Config;

	private List<int> m_CardIDs = new List<int>();

	private CommonDataCollection m_Args = new CommonDataCollection();

	public void Bind(CommonDataCollection args)
	{
		bool flag = args["unlocked"];
		bool flag2 = !(m_Config == null) && m_Config.m_ShowNewCard;
		m_CardIDs.Clear();
		InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			CardGrowthInfo cardGrowth = CardUtility.GetCardGrowth(inGameStoreInfo.Id);
			if (flag != CardUtility.CanDropCardPiece(inGameStoreInfo.Id) || cardGrowth == null)
			{
				continue;
			}
			if (!flag2)
			{
				if (cardGrowth.StartTime == 0 || cardGrowth.StartTime <= UtcTimeStamp.Now)
				{
					m_CardIDs.Add(inGameStoreInfo.Id);
				}
			}
			else
			{
				m_CardIDs.Add(inGameStoreInfo.Id);
			}
		}
		m_NameState.State = ((!flag) ? 1 : 0);
		m_Args.Clear();
		for (int j = 0; j < m_CardIDs.Count; j++)
		{
			m_Args[j]["cardID"] = m_CardIDs[j];
		}
		m_Items.Args = m_Args;
	}
}
