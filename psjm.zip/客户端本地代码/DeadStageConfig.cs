using System;

[Serializable]
public class DeadStageConfig
{
	public float startTime;

	public float endTime;

	public bool inheritTime;
}
