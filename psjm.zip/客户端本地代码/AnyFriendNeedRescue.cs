using BehaviorDesigner.Runtime.Tasks;

[TaskName("有我能救的人")]
[TaskCategory("躲猫猫AI/条件")]
public class AnyFriendNeedRescue : Conditional
{
	public SharedPlayerController rescueTarget;

	public SharedUsableObject usableObject;

	private PlayerController myself;

	private PlayerController nearestRescueTarget;

	public override void OnStart()
	{
		myself = GetComponent<PlayerController>();
	}

	public override TaskStatus OnUpdate()
	{
		UpdateRescueTarget();
		rescueTarget.Value = nearestRescueTarget;
		if (!(rescueTarget.Value != null))
		{
			return TaskStatus.Failure;
		}
		return TaskStatus.Success;
	}

	private void UpdateRescueTarget()
	{
		nearestRescueTarget = null;
		float num = float.MaxValue;
		foreach (PlayerController allPlayer in PlayerController.AllPlayers)
		{
			if (allPlayer.PlayingRole == myself.PlayingRole && allPlayer.IsDying && !allPlayer.FinalDeadOrEscaped && (allPlayer.OnVehichle == null || allPlayer.OnVehichle.viewID == myself.m_PhotonView.viewID))
			{
				float sqrMagnitude = (allPlayer.transform.localPosition - transform.localPosition).sqrMagnitude;
				if (SignRescueTarget.MeIsTheBestResucer(allPlayer, myself, sqrMagnitude) && sqrMagnitude < num)
				{
					nearestRescueTarget = allPlayer;
					num = sqrMagnitude;
				}
			}
		}
		if (usableObject != null && nearestRescueTarget != null)
		{
			usableObject.Value = nearestRescueTarget.GetComponent<UsableObject>();
		}
	}
}
