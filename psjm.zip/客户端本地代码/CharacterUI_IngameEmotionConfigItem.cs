using DG.Tweening;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_IngameEmotionConfigItem
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public UIStateItem m_State;

	public GameObject m_Highlight;

	public Button m_Button;

	public GameObject m_Root;

	public GameObject m_LoadEffect;

	public Image m_Frame;

	public Sprite m_DefaultFrame;

	public AudioItemData m_ReplacingSound;

	public UITabPage m_Tab;

	public Text m_PCKeyMap;

	private int m_id;

	private int m_index;

	private int m_lastCharacterId;

	private IngameEmotionConfigEdit m_configEdit;

	private string m_PCKeyMapFormat;

	public void Bind(CommonDataCollection args)
	{
		m_Host.EventProxy(m_Button, "OnClick");
		m_id = args["id"];
		m_index = args["index"];
		m_PCKeyMap.gameObject.SetActive(value: false);
		m_configEdit = (args["configEdit"].val as IngameEmotionConfigEdit);
		if (m_id == 0)
		{
			m_State.State = 0;
			m_Frame.sprite = m_DefaultFrame;
		}
		else
		{
			m_State.State = 1;
			IngameEmotionInfo ingameEmotionInfo = LocalResources.IngameEmotionInfo.Get(m_id);
			m_Icon.sprite = SpriteSource.Inst.Find(ingameEmotionInfo.Icon);
			m_Frame.sprite = SpriteSource.Inst.Find(ingameEmotionInfo.Frame);
		}
		if (CharacterUI_ActiveIngameEmotionConfigView.Replacing)
		{
			float num = 0.15f;
			float num2 = Random.Range(0f, num);
			m_Root.transform.localRotation = Quaternion.Euler(0f, 0f, -2f);
			m_Root.transform.localPosition = new Vector3(-2f, -2f, 0f);
			m_Root.transform.DOKill();
			m_Root.transform.DOLocalRotate(new Vector3(0f, 0f, 2f), num).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
				.SetDelay(num2);
			m_Root.transform.DOLocalMoveX(2f, num).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
				.SetDelay(num2);
			m_Root.transform.DOLocalMoveY(2f, num).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
				.SetDelay(num2 + 0.5f * num);
			m_Highlight.SetActive(value: true);
		}
		else
		{
			m_Root.transform.DOKill();
			m_Root.transform.localRotation = Quaternion.identity;
			m_Root.transform.localPosition = Vector3.zero;
			m_Highlight.SetActive(m_id == CharacterUI_IngameEmotionItemTemplate.Selected && CharacterUI_IngameEmotionItemTemplate.Selected != 0);
		}
		if (m_LoadEffect != null && m_lastCharacterId != CharacterUI_SelectCharacterItemTemplate.globalSelected)
		{
			m_LoadEffect.SetActive(value: false);
		}
		m_lastCharacterId = CharacterUI_SelectCharacterItemTemplate.globalSelected;
	}

	public void OnClick()
	{
		if (CharacterUI_ActiveIngameEmotionConfigView.Replacing)
		{
			CharacterUI_ActiveIngameEmotionConfigView.Replacing = false;
			m_configEdit.ChangeConfig(CharacterUI_IngameEmotionItemTemplate.Selected, m_index);
			m_LoadEffect.SetActive(value: true);
			m_configEdit.GetComponent<UIDataBinder>().UpdateBinding();
			UIDataEvents.Inst.InvokeEvent("OnIngameEmotionSelectedChange");
		}
		else if (m_id > 0)
		{
			CharacterUI_IngameEmotionItemTemplate.Selected = m_id;
			UIDataEvents.Inst.InvokeEvent("OnIngameEmotionSelectedChange");
			IngameEmotionInfo ingameEmotionInfo = LocalResources.IngameEmotionInfo.Get(m_id);
			int selectedTabIndex = m_Tab.GetSelectedTabIndex();
			if (selectedTabIndex != 2 && ingameEmotionInfo.Type != selectedTabIndex)
			{
				WardrobeUIRedPointJunction.IgnoreIngameEmotionChildTabChange = true;
				m_Tab.SetSelectedTabIndex(ingameEmotionInfo.Type);
			}
		}
	}
}
