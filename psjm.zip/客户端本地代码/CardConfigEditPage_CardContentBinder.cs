using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class CardConfigEditPage_CardContentBinder
{
	public UIDataBinder m_Host;

	public UIStateItem m_Role;

	public Text m_CharacterName;

	public Image m_Icon;

	public UITemplateInitiator m_OwnContent;

	public UITemplateInitiator m_NotOwnContent;

	public UIPage m_UniversalPieceExchangePage;

	public MultiTargetGraphicButton m_ExchangeBtn;

	public GameObject m_ExchangeTips;

	private CommonDataCollection m_OwnArgs = new CommonDataCollection();

	private CommonDataCollection m_NotOwnArgs = new CommonDataCollection();

	public static List<int> m_CardIdSortList = new List<int>();

	public void Bind(CommonDataCollection args)
	{
		List<InGameStoreInfo> list = new List<InGameStoreInfo>();
		List<InGameStoreInfo> list2 = new List<InGameStoreInfo>();
		List<InGameStoreInfo> list3 = new List<InGameStoreInfo>();
		List<InGameStoreInfo> list4 = new List<InGameStoreInfo>();
		List<InGameStoreInfo> list5 = new List<InGameStoreInfo>();
		InGameStoreInfo[] allCardInfos = CardUtility.GetAllCardInfos();
		foreach (InGameStoreInfo inGameStoreInfo in allCardInfos)
		{
			if (CardUtility.IsOwned(inGameStoreInfo.Id))
			{
				if (!CardUtility.IsCardRoleMatch(inGameStoreInfo))
				{
					list2.Add(inGameStoreInfo);
				}
				else
				{
					list.Add(inGameStoreInfo);
				}
			}
			else if (!CardUtility.CanDropCardPiece(inGameStoreInfo.Id))
			{
				list5.Add(inGameStoreInfo);
			}
			else if (!CardUtility.IsCardRoleMatch(inGameStoreInfo))
			{
				list4.Add(inGameStoreInfo);
			}
			else
			{
				list3.Add(inGameStoreInfo);
			}
		}
		m_OwnArgs.Clear();
		m_NotOwnArgs.Clear();
		m_CardIdSortList.Clear();
		ArgsWraper(ref m_OwnArgs, list);
		ArgsWraper(ref m_OwnArgs, list2);
		ArgsWraper(ref m_NotOwnArgs, list3);
		ArgsWraper(ref m_NotOwnArgs, list4);
		ArgsWraper(ref m_NotOwnArgs, list5);
		m_OwnContent.Args = m_OwnArgs;
		m_NotOwnContent.Args = m_NotOwnArgs;
		m_NotOwnContent.gameObject.SetActive(m_NotOwnArgs.ArraySize > 0);
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID);
		m_Role.State = (int)GameRuntime.PlayingRole;
		m_CharacterName.text = characterInfo.Name;
		m_Icon.sprite = SpriteSource.Inst.Find(characterInfo.ExpIcon);
		if (UniversalPieceCtrl.IsExchangeOpen() && !LocalPlayerDatabase.GetPrefValue("HadOpenUniversalPiecePage"))
		{
			m_ExchangeTips.gameObject.SetActive(value: true);
		}
		else
		{
			m_ExchangeTips.gameObject.SetActive(value: false);
		}
		m_Host.EventProxy(m_ExchangeBtn, "OnClickExchangeBtn");
	}

	private void ArgsWraper(ref CommonDataCollection args, List<InGameStoreInfo> infos)
	{
		foreach (InGameStoreInfo info in infos)
		{
			args[args.ArraySize]["id"] = info.Id;
			m_CardIdSortList.Add(info.Id);
		}
	}

	public void OnClickExchangeBtn()
	{
		UILobby.Current.GoToPage(m_UniversalPieceExchangePage);
		m_ExchangeTips.gameObject.SetActive(value: false);
		LocalPlayerDatabase.SetPrefValue("HadOpenUniversalPiecePage", value: true);
	}
}
