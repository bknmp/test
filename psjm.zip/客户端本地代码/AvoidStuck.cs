using BehaviorDesigner.Runtime.Tasks;
using LightUtility;
using UnityEngine;

public class AvoidStuck : Action
{
	public float avoidMoveDis = 1f;

	private AIController ai;

	private float totalTime;

	private float startTime;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
		startTime = Time.time;
		totalTime = Random.Range(ai.m_IdleTimeMin, ai.m_IdleTimeMax);
		ai.RecalculatePath(transform.localPosition + Random.insideUnitCircle.ExpandZ().SwapYZ() * avoidMoveDis);
	}

	public override TaskStatus OnUpdate()
	{
		if (ai.IsMoving)
		{
			ai.MoveToTarget();
			return TaskStatus.Running;
		}
		if (Time.time - startTime < totalTime)
		{
			return TaskStatus.Running;
		}
		return TaskStatus.Success;
	}
}
