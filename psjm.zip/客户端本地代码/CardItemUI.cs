using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CardItemUI : MonoBehaviour
{
	public Image m_Icon;

	public Image m_Frame;

	public Text m_Level;

	private string m_LevelFormat;

	private void Awake()
	{
		m_LevelFormat = m_Level.text;
	}

	public void SetInfo(int cardId, int skinOrStyleID, int level)
	{
		if (m_Frame != null)
		{
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardId);
			m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
		}
		if (m_Icon != null)
		{
			BaseCardSkinInfo baseCardSkinInfo = CardUtility.GetBaseCardSkinInfo(skinOrStyleID);
			m_Icon.sprite = SpriteSource.Inst.Find(baseCardSkinInfo.Icon);
		}
		if ((bool)m_Level)
		{
			m_Level.text = string.Format(m_LevelFormat, level);
		}
	}
}
