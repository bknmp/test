using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class BulletObject : MonoBehaviour
{
	public class GroupSharedHitData
	{
		public List<MonoBehaviour> damagableTarget = new List<MonoBehaviour>();

		public int link;
	}

	public float m_HitForce = 10f;

	public float m_ExposionRadius = 1f;

	protected int m_ID;

	protected Vector3 m_StartDir;

	protected Vector3 m_StartPos;

	protected float m_StartTime;

	protected Vector3 m_FarthestPos;

	protected ProjectileLauncher m_Launcher;

	protected PushCurve m_PlayerPushing;

	protected GroupSharedHitData m_GroupSharedHitData;

	public static Queue<GroupSharedHitData> GroupSharedHitDataCache = new Queue<GroupSharedHitData>();

	public int ID => m_ID;

	public ProjectileLauncher Launcher
	{
		get
		{
			return m_Launcher;
		}
		set
		{
			m_Launcher = value;
		}
	}

	public float Attack
	{
		get;
		set;
	}

	public int CardID
	{
		get;
		set;
	}

	public bool BrokenStealth
	{
		get;
		set;
	}

	public Vector3 FarthestPos => m_FarthestPos;

	public Vector3 StartDir => m_StartDir;

	public Vector3 StartPos => m_StartPos;

	public float StartTime => m_StartTime;

	protected void Awake()
	{
		m_PlayerPushing = GetComponent<PushCurve>();
	}

	public virtual void Finish(Vector3 pushDir, int[] targetPlayerIDs, int[] localNums, bool blocked)
	{
	}

	protected virtual void OnDeSpawn()
	{
		RemoveGroupSharedHitData();
	}

	public virtual bool CheckBulletThroughBarried(Vector3 playerPos)
	{
		if (IsBulletThroughBarrier(playerPos))
		{
			return true;
		}
		return false;
	}

	public virtual bool IsBulletThroughBarrier(Vector3 endPos)
	{
		Vector3 vector = base.transform.position - m_StartDir.normalized;
		vector.y += 0.1f;
		endPos.y = vector.y;
		return IsThroughBarrier(vector, endPos);
	}

	public static bool IsThroughBarrier(Vector3 startPos, Vector3 endPos)
	{
		Vector3 vector = endPos - startPos;
		Vector3 b = Vector3.Cross(Vector3.up, vector).normalized * 0.4f;
		Vector3 origin = startPos + b;
		Vector3 origin2 = startPos - b;
		float maxDistance = Vector3.Distance(startPos, endPos);
		int mask = LayerMask.GetMask("Default");
		int hitCount = Physics.RaycastNonAlloc(startPos, vector, GameObjectUtility.CacheRaycastHits, maxDistance, mask);
		if (IsHitOnlyWall(GameObjectUtility.CacheRaycastHits, hitCount))
		{
			return true;
		}
		if (IsHitExcludePlayer(GameObjectUtility.CacheRaycastHits, hitCount))
		{
			hitCount = Physics.RaycastNonAlloc(origin, vector, GameObjectUtility.CacheRaycastHits, maxDistance, mask);
			if (IsHitExcludePlayer(GameObjectUtility.CacheRaycastHits, hitCount))
			{
				hitCount = Physics.RaycastNonAlloc(origin2, vector, GameObjectUtility.CacheRaycastHits, maxDistance, mask);
				if (IsHitExcludePlayer(GameObjectUtility.CacheRaycastHits, hitCount))
				{
					return true;
				}
			}
		}
		return false;
	}

	public static bool IsHitOnlyWall(RaycastHit[] hits, int hitCount)
	{
		bool result = false;
		for (int i = 0; i < hitCount; i++)
		{
			RaycastHit raycastHit = hits[i];
			if (!(raycastHit.collider == null) && !GameUtility.IsPlayer(raycastHit.collider))
			{
				if (!raycastHit.collider.tag.Equals("InGame/Wall"))
				{
					return false;
				}
				result = true;
			}
		}
		return result;
	}

	public static bool IsHitExcludePlayer(RaycastHit[] hits, int hitCount)
	{
		for (int i = 0; i < hitCount; i++)
		{
			RaycastHit raycastHit = hits[i];
			if (!(raycastHit.collider == null) && !raycastHit.collider.isTrigger && !GameUtility.IsPlayer(raycastHit.collider))
			{
				return true;
			}
		}
		return false;
	}

	protected bool CanPushPlayerOnWall(PlayerController player, Vector3 playerPos)
	{
		bool flag = (!(m_Launcher.Controller is PlayerController)) ? (player.PlayingRole == m_Launcher.Controller.PlayingRole) : player.InSameTeam((PlayerController)m_Launcher.Controller);
		if (!flag && playerPos.y > 1f && !InGameScene.Inst.IsHighTile(playerPos))
		{
			return Vector3.Magnitude((base.transform.position - playerPos).FlattenY()) < (m_Launcher.IsSubMachineGun ? 1f : 2f);
		}
		return false;
	}

	protected Vector3 ReflectDirectionIfOnSceneEdge(Vector3 pos, Vector3 dir)
	{
		float num = 0.8f;
		int width = InGameScene.Inst.Map.Width;
		int height = InGameScene.Inst.Map.Height;
		Vector3 zero = Vector3.zero;
		if (pos.x < num)
		{
			zero.x = 1f;
		}
		else if (pos.z < num)
		{
			zero.z = 1f;
		}
		else if ((float)width - pos.x < num)
		{
			zero.x = -1f;
		}
		else if ((float)height - pos.z < num)
		{
			zero.z = -1f;
		}
		if (zero != Vector3.zero)
		{
			dir = dir.Reflection(zero);
		}
		return dir;
	}

	public void SetGroupSharedHitData(GroupSharedHitData groupSharedHitData)
	{
		m_GroupSharedHitData = groupSharedHitData;
		m_GroupSharedHitData.link++;
	}

	public void RemoveGroupSharedHitData()
	{
		if (m_GroupSharedHitData != null)
		{
			m_GroupSharedHitData.link--;
			if (m_GroupSharedHitData.link <= 0)
			{
				m_GroupSharedHitData.link = 0;
				ReleaseGroupSharedHitDataCache(m_GroupSharedHitData);
			}
			m_GroupSharedHitData = null;
		}
	}

	public static GroupSharedHitData GetCacheGroupSharedHitData()
	{
		if (GroupSharedHitDataCache.Count != 0)
		{
			return GroupSharedHitDataCache.Dequeue();
		}
		return new GroupSharedHitData();
	}

	public static void ReleaseGroupSharedHitDataCache(GroupSharedHitData groupSharedHitData)
	{
		groupSharedHitData.damagableTarget.Clear();
		groupSharedHitData.link = 0;
		GroupSharedHitDataCache.Enqueue(groupSharedHitData);
	}
}
