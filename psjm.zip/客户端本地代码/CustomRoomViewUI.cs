using CustomRoom;
using GameMessages;
using LightUI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CustomRoomViewUI : UIEventListener
{
	public UITabPage m_TabPages;

	public Dropdown m_MapDropdown;

	public InputField m_SearchInput;

	public UIShortcutSelectable m_SearchButton;

	public UILobbyElement m_CreateRoomUI;

	public UIPopup m_RecordsUI;

	public GameObject m_PerformanceTestBtn;

	public UIPopup m_CreatePerformanceTestUI;

	private float m_UpdateInterval = 1f;

	private bool m_Dirty;

	private bool IsAllMap => m_MapDropdown.value == 0;

	private MapType CurrentMapType
	{
		get
		{
			int value = m_MapDropdown.value;
			if (value > 0)
			{
				return (MapType)(value - 1);
			}
			return MapType.Type4v1;
		}
	}

	private RoomMode CurrentMode
	{
		get
		{
			if (m_TabPages.GetSelectedTabIndex() != 1)
			{
				return RoomMode.Custom;
			}
			return RoomMode.Classic;
		}
	}

	private void Start()
	{
		m_SearchButton.OnButtonDown = OnSearch;
	}

	private void OnEnable()
	{
		InvokeRepeating("MakeDirty", 1f, m_UpdateInterval);
	}

	private void OnDisable()
	{
		CancelInvoke();
	}

	private void Update()
	{
		if (m_Dirty)
		{
			m_Dirty = false;
			UpdateStatus();
		}
	}

	private void MakeDirty()
	{
		m_Dirty = true;
	}

	public override void OnEnterUI()
	{
		OnTabChanged();
		LobbyScene.Inst.ChatPanel.Hide(immediately: true);
	}

	public void OnTabChanged()
	{
		SetRoomViewArgs(CurrentMode, IsAllMap, CurrentMapType, forceUpdate: true);
		CustomRoomUtility.RefreshCustomRoomList(CurrentMode, isAllMap: true, CurrentMapType, OnRefreshCustomRoomListSuccess);
	}

	public void OnDropdownValueChanged()
	{
		SetRoomViewArgs(CurrentMode, IsAllMap, CurrentMapType, forceUpdate: true);
	}

	private void OnRefreshCustomRoomListSuccess()
	{
		SetUpdateInterval(CustomRoomUtility.UpdateInterval);
	}

	private void SetUpdateInterval(float interval)
	{
		if (interval != m_UpdateInterval)
		{
			m_UpdateInterval = interval;
			CancelInvoke();
			InvokeRepeating("MakeDirty", 0f, m_UpdateInterval);
		}
	}

	private void UpdateStatus()
	{
		if (UILobby.Current.CurrentPopup() != null)
		{
			return;
		}
		List<int> list = new List<int>();
		if (CustomRoomUtility.SearchedRoomInfo != null)
		{
			list.Add(CustomRoomUtility.SearchedRoomInfo.ID);
		}
		else
		{
			Dictionary<RoomMode, GameMessages.RoomInfo[]> rooms = CustomRoomUtility.Rooms;
			if (rooms.ContainsKey(CurrentMode))
			{
				GameMessages.RoomInfo[] array = rooms[CurrentMode];
				foreach (GameMessages.RoomInfo roomInfo in array)
				{
					if (roomInfo.status != RoomStatus.Destroyed && (IsAllMap || roomInfo.config.Map() == CurrentMapType))
					{
						list.Add(roomInfo.ID);
					}
				}
			}
		}
		CustomRoomUtility.RefreshCustomRoomStatusSlient(list.ToArray());
	}

	private void SetRoomViewArgs(RoomMode mode, bool allMap, MapType map, bool forceUpdate = false)
	{
		int selectedTabIndex = m_TabPages.GetSelectedTabIndex();
		if (selectedTabIndex != -1)
		{
			GameObject tabContent = m_TabPages.m_Buttons[selectedTabIndex].m_TabContent;
			if (tabContent != null && ((tabContent.transform.childCount == 0) | forceUpdate))
			{
				tabContent.GetComponent<TabPageAnchor>().Initialize(new CommonDataCollection
				{
					["mode"] = (int)mode,
					["allMap"] = allMap,
					["map"] = (int)map
				});
			}
		}
	}

	public void OnRefresh()
	{
		CustomRoomUtility.RefreshCustomRoomList(CurrentMode, isAllMap: true, CurrentMapType, OnRefreshCustomRoomListSuccess);
	}

	public void OnCreateRoom()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		RoomConfig cachedRoomConfig = CustomRoomUtility.CachedRoomConfig;
		cachedRoomConfig.mode = (int)CurrentMode;
		commonDataCollection["roomConfig"].val = cachedRoomConfig;
		UILobby.Current.ShowUI(m_CreateRoomUI, commonDataCollection);
	}

	public void OnSearch(UIShortcutSelectable.OperationType opType)
	{
		int result = 0;
		if (int.TryParse(m_SearchInput.text, out result))
		{
			CustomRoomUtility.SearchCustomRoom(result, delegate
			{
				SetRoomViewArgs(CurrentMode, IsAllMap, CurrentMapType, forceUpdate: true);
			});
		}
		else
		{
			UILobby.Current.ShowTips(Localization.TipsInvalidRoomID);
		}
	}

	public void OnRecord()
	{
		UILobby.Current.Popup(m_RecordsUI);
	}

	public void OnPerformanceTestClick()
	{
		UILobby.Current.Popup(m_CreatePerformanceTestUI);
	}
}
