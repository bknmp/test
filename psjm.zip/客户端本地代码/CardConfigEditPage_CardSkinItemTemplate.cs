using LightUI;

internal class CardConfigEditPage_CardSkinItemTemplate
{
	public UIDataBinder m_Host;

	public static int globalSelected = -1;

	private int m_skinId;

	private int m_cardId;

	private CardSkinInfo m_cardSkinInfo;

	private CardConfigEditPage_PageCardSkin m_skinPage;

	public void Bind(CommonDataCollection args)
	{
		m_skinId = args["cardSkinID"];
		m_cardId = args["cardID"];
		m_skinPage = (args["cardSkinPage"].val as CardConfigEditPage_PageCardSkin);
		m_cardSkinInfo = (args["cardSkinInfo"].val as CardSkinInfo);
		UpdateSelectedStatus();
	}

	private void UpdateSelectedStatus()
	{
		if (m_skinId == globalSelected)
		{
			m_skinPage.UpdateButton();
			m_skinPage.UpdateStates(m_cardId);
			m_skinPage.UpdateCardSkinData(m_cardSkinInfo);
		}
	}
}
