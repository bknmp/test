using LightUtility;

public class BaseAttacker : BatchUpdateBehaviour
{
	protected BasePlayerController m_PlayerController;

	public virtual float FireCooldownTimeRatio => 0f;

	protected void Awake()
	{
		m_PlayerController = GetComponent<BasePlayerController>();
	}

	public virtual bool StartFire()
	{
		return false;
	}

	public virtual void EndFire(bool tryCancel, bool combo = false)
	{
	}
}
