using LightUI;
using UnityEngine.UI;

internal class CharacterDetailUI_AttributeItem
{
	public UIDataBinder m_Host;

	public Text m_AttributeDesc;

	public Text m_AttributeValue;

	public void Bind(CommonDataCollection args)
	{
		string text = args["key"];
		string text2 = args["value"];
		m_AttributeDesc.text = text;
		m_AttributeValue.text = text2;
	}
}
