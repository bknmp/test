using LightUI;
using UnityEngine;

internal class ChatEntry_DataScrollView
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	public GameObject m_Empty;

	public void Bind(CommonDataCollection args)
	{
		m_DataScrollView.ClearItems();
		m_Empty.SetActive(value: true);
	}
}
