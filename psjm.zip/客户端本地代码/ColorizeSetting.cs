using UnityEngine;

[CreateAssetMenu(fileName = "ColorizeSetting", menuName = "部件染色配置", order = 1)]
public class ColorizeSetting : ScriptableObject
{
	public ObjectData[] colorDatas;

	public Material GetMatByRendererName(string name)
	{
		ObjectData[] array = colorDatas;
		foreach (ObjectData objectData in array)
		{
			if (objectData.partName.Equals(name))
			{
				return objectData.mat;
			}
		}
		return null;
	}
}
