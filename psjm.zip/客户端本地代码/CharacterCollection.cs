using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterCollection
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_Collection;

	public Text m_Title;

	public UICooldownBar m_CooldownText;

	public Button m_Mask;

	public Button m_BuyBtn;

	public Text m_DisCountDesc;

	public UIStateItem m_StateItem;

	public UIStateImage m_Good;

	public Text m_Current;

	public Text m_Original;

	private string m_DiscountString;

	private bool HasCollection;

	private int m_PriceID;

	private int m_PackageId;

	private int m_CollectionID;

	private int m_ActivityId;

	private bool useCollection;

	private CommonDataCollection m_args;

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		m_CollectionID = m_args["collectionID"];
		m_ActivityId = m_args["activityID"];
		m_args["useCollection"] = (m_BuyBtn != null);
		useCollection = (m_BuyBtn != null);
		SetInfo();
		OwnedTipHandle();
		m_Host.EventProxy(m_Mask, "OnMaskClick");
		if (CharacterDiscountUtility.CacheInfo.ContainsKey(m_ActivityId))
		{
			if (useCollection)
			{
				UseCollectionHandle();
			}
			else
			{
				m_Collection.Args = WrapData(CharacterDiscountUtility.GetCollection(m_ActivityId, m_CollectionID));
			}
		}
	}

	private void SetInfo()
	{
		if ((bool)m_Title)
		{
			m_Title.text = CharacterDiscountUtility.GetCollectionName(m_ActivityId, m_CollectionID);
		}
		if ((bool)m_CooldownText && CharacterDiscountUtility.CacheInfo.ContainsKey(m_ActivityId))
		{
			int num = (CharacterDiscountUtility.CacheInfo[m_ActivityId].endTime - UtcTimeStamp.Now > 0) ? (CharacterDiscountUtility.CacheInfo[m_ActivityId].endTime - UtcTimeStamp.Now) : 0;
			m_CooldownText.SetTime(num, Mathf.Max(1, num));
		}
	}

	private void OwnedTipHandle()
	{
		HasCollection = CharacterDiscountUtility.IsOwnCollection(m_ActivityId, m_CollectionID);
		m_Mask.gameObject.SetActive(HasCollection);
		if (m_BuyBtn != null)
		{
			m_BuyBtn.gameObject.SetActive(!HasCollection);
		}
	}

	private void UseCollectionHandle()
	{
		m_Collection.Args = WrapDataUseCollection(CharacterDiscountUtility.GetCollection(m_ActivityId, m_CollectionID));
		OwnedTipHandle();
		CurrencyHandle();
		m_Host.EventProxy(m_BuyBtn, "OnBuyBtnClick");
	}

	private void TextHandle(CharacterDiscountPackageInfo package)
	{
		m_Current.text = package.currentPrice.ToString();
		m_Original.text = package.orgPrice.ToString();
		m_PriceID = package.priceID;
		m_PackageId = package.packageID;
		if (string.IsNullOrEmpty(m_DiscountString))
		{
			m_DiscountString = m_DisCountDesc.text;
		}
		m_DisCountDesc.text = string.Format(m_DiscountString, package.discount, Localization.Discount);
	}

	private void CurrencyHandle()
	{
		m_StateItem.State = ((m_PriceID == 99) ? 1 : 0);
		switch (m_PriceID)
		{
		case 2:
			m_Good.State = 2;
			break;
		case 4:
			m_Good.State = 1;
			break;
		}
	}

	protected CommonDataCollection WrapData(List<CharacterDiscountPackageInfo> packageList)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		int collectionID = 1;
		if (packageList.Count > 1)
		{
			foreach (CharacterDiscountPackageInfo package in packageList)
			{
				if (package.characterID > 0 && package.suitItemID == 0)
				{
					SetArgs(commonDataCollection, package, 0);
					collectionID = package.collectionID;
				}
			}
			int collectionCharacterID = CharacterDiscountUtility.GetCollectionCharacterID(m_ActivityId, collectionID);
			if (collectionCharacterID > 0)
			{
				if (DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(collectionCharacterID)))
				{
					CharacterDiscountPackageInfo characterDiscountPackageInfo = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID == 0 && x.suitItemID > 0);
					SetArgs(commonDataCollection, characterDiscountPackageInfo, 1, characterDiscountPackageInfo.goodsID);
				}
				else
				{
					CharacterDiscountPackageInfo characterDiscountPackageInfo2 = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID > 0 && x.suitItemID > 0);
					SetArgs(commonDataCollection, characterDiscountPackageInfo2, 1, characterDiscountPackageInfo2.goodsID);
				}
			}
			else
			{
				CharacterDiscountPackageInfo characterDiscountPackageInfo3 = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID == 0 && x.suitItemID > 0);
				SetArgs(commonDataCollection, characterDiscountPackageInfo3, 1, characterDiscountPackageInfo3.goodsID);
			}
		}
		else
		{
			SetArgs(commonDataCollection, packageList[0], packageList[0].goodsID);
		}
		return commonDataCollection;
	}

	protected CommonDataCollection WrapDataUseCollection(List<CharacterDiscountPackageInfo> packageList)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (packageList.Count > 1)
		{
			CharacterDiscountPackageInfo characterDiscountPackageInfo = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID > 0 && x.suitItemID == 0);
			SetArgs(commonDataCollection, characterDiscountPackageInfo, 1, characterDiscountPackageInfo.goodsID);
			CharacterDiscountPackageInfo characterDiscountPackageInfo2 = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID == 0 && x.suitItemID > 0);
			CharacterDiscountPackageInfo characterDiscountPackageInfo3 = packageList.Find((CharacterDiscountPackageInfo x) => x.characterID > 0 && x.suitItemID > 0);
			SetArgs(commonDataCollection, characterDiscountPackageInfo2, 0, characterDiscountPackageInfo2.goodsID);
			if (CharacterDiscountUtility.IsOwnItem(characterDiscountPackageInfo3.characterID))
			{
				TextHandle(characterDiscountPackageInfo2);
			}
			else
			{
				TextHandle(characterDiscountPackageInfo3);
			}
		}
		else if (packageList.Count > 0)
		{
			SetArgs(commonDataCollection, packageList[0], packageList[0].goodsID);
			TextHandle(packageList[0]);
		}
		return commonDataCollection;
	}

	public void OnMaskClick()
	{
		UILobby.Current.ShowTips(Localization.OwnedItemHint);
	}

	public void OnBuyBtnClick()
	{
		CharacterDiscountUtility.TryBuy(m_ActivityId, m_PackageId, null);
	}

	private void SetArgs(CommonDataCollection goodsArg, CharacterDiscountPackageInfo package, int index, int goodID = 0)
	{
		goodsArg[index]["activityID"] = m_ActivityId;
		goodsArg[index]["goodsID"] = ((goodID != 0) ? goodID : 0);
		goodsArg[index]["packageID"] = package.packageID;
		goodsArg[index]["collectionID"] = package.collectionID;
		goodsArg[index]["characterID"] = package.characterID;
		goodsArg[index]["suitItemId"] = package.suitItemID;
		goodsArg[index]["orgPrice"] = package.orgPrice;
		goodsArg[index]["discountPrice"] = package.currentPrice;
		goodsArg[index]["priceID"] = package.priceID;
		goodsArg[index]["discount"] = package.discount;
		goodsArg[index]["buyCountLimit"] = package.buyCountLimit;
		goodsArg[index]["limitTimes"] = package.limitTimes;
		goodsArg[index]["mainName"] = package.mainName;
		goodsArg[index]["useCollection"] = useCollection;
		goodsArg[index]["itemId"] = package.itemID;
	}
}
