using GameMessages;
using LightUI;

internal class CollectionPage_SkinPartPanel
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_SkinParts;

	public UIDataBinder m_Part;

	public void Bind(CommonDataCollection args)
	{
		int[] array = (int[])args["itemIDs"].val;
		HttpResponsePlayerInfo val = (HttpResponsePlayerInfo)args["playerInfo"].val;
		if (m_Part != null)
		{
			CommonDataCollection commonDataCollection = new CommonDataCollection();
			commonDataCollection["itemID"] = array[0];
			commonDataCollection["playerInfo"].val = val;
			m_Part.Args = commonDataCollection;
			return;
		}
		for (int i = 0; i < array.Length; i++)
		{
			args[i]["itemID"] = array[i];
			args[i]["playerInfo"].val = val;
		}
		m_SkinParts.Args = args;
	}
}
