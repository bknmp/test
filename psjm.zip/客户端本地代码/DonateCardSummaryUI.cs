using LightUI;
using LightUtility;
using System.Linq;
using UnityEngine.UI;

internal class DonateCardSummaryUI
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public Image m_Frame;

	public Text m_ItemName;

	public Text m_Add;

	public CardPieceProcessBar m_CardProcessUI;

	public UITemplateInitiator m_Layout;

	public void Bind(CommonDataCollection args)
	{
		if (UnionUtility.Summary != null)
		{
			int cardID = UnionUtility.Summary.cardID;
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(cardID);
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID);
			m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
			m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
			m_ItemName.text = inGameStoreInfo.FullName;
			m_Add.text = $"+{UnionUtility.Summary.count.Sum()}";
			m_CardProcessUI.SetInfo(cardID);
			args.Clear();
			for (int i = 0; i < UnionUtility.Summary.player.Length; i++)
			{
				args[i]["name"] = UnionUtility.Summary.player[i];
				args[i]["count"] = UnionUtility.Summary.count[i];
			}
			m_Layout.Args = args;
		}
		else
		{
			GoBack();
		}
	}

	private void GoBack()
	{
		UnionUtility.Summary = null;
		m_Host.GetComponent<UIPopup>().GoBack();
	}
}
