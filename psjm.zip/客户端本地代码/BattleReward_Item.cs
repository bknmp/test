using LightUI;
using LightUtility;
using UnityEngine.UI;

public class BattleReward_Item
{
	public UIDataBinder m_Host;

	public UIStateItem m_Rank;

	public Image m_Icon;

	public Text m_Count;

	public Text m_Others;

	public Text m_End;

	private string m_OthersFormat;

	private string m_EndFormat;

	public void Bind(CommonDataCollection args)
	{
		SetRank(args["start"], args["end"]);
		int[] array = args["itemID"].val as int[];
		int[] array2 = args["count"].val as int[];
		SetItem(array[0], array2[0]);
	}

	private void SetRank(int start, int end)
	{
		if (start == end)
		{
			switch (start)
			{
			case 1:
				m_Rank.State = 0;
				break;
			case 2:
				m_Rank.State = 1;
				break;
			case 3:
				m_Rank.State = 2;
				break;
			}
		}
		else if (end != -1)
		{
			m_Rank.State = 3;
			if (m_OthersFormat == null)
			{
				m_OthersFormat = m_Others.text;
			}
			m_Others.text = string.Format(m_OthersFormat, start, end);
			m_Others.GetComponentsInChildren<Text>()[1].text = start + "~" + end;
		}
		else
		{
			m_Rank.State = 4;
			if (m_EndFormat == null)
			{
				m_EndFormat = m_End.text;
			}
			m_End.text = string.Format(m_EndFormat, start);
			m_End.GetComponentsInChildren<Text>()[1].text = start + "+";
		}
	}

	private void SetItem(int itemID, int count)
	{
		m_Icon.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(itemID).Icon);
		m_Count.text = "x" + count;
	}
}
