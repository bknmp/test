using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUI_IngameEmotionItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public Button m_SelectBtn;

	public GameObject m_Selected;

	public UIDataBinder m_Time;

	public Image m_Use;

	public Image m_Icon;

	public UIStateRawImage m_QualityBG;

	public UIStateItem m_Effect;

	public GameObject m_RedPoint;

	public UIScrollRect m_ScrollView;

	public UIStateItem m_LimitedEdition;

	public Button m_UseButton;

	public Button m_UnloadButton;

	public UIDataBinder m_ActiveIngameEmotionConfigView;

	public IngameEmotionConfigEdit m_ConfigEdit;

	public RawImage m_Preview;

	public Text m_PassSeasonText;

	public static int Selected;

	public static int LastPreviewId;

	private IngameEmotionInfo m_info;

	private bool m_lastSelected;

	public void Bind(CommonDataCollection args)
	{
		DataItem item = args["expiredTime"];
		m_info = (args["info"].val as IngameEmotionInfo);
		m_Name.text = m_info.Name;
		m_Icon.sprite = SpriteSource.Inst.Find(LocalResources.DropItemTable.Get(m_info.DropId).Icon);
		m_QualityBG.State = m_info.Quality;
		m_Effect.State = m_info.Quality;
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection[0]["time"] = (int)item;
		m_Time.Args = commonDataCollection;
		bool flag = CharacterUtility.IsOwnCharacter(CharacterUI_SelectCharacterItemTemplate.globalSelected);
		bool flag2 = m_ConfigEdit.IsUsing(m_info.Id);
		m_Use.gameObject.SetActive(flag2);
		m_UnloadButton.gameObject.SetActive(flag2 && flag);
		m_UseButton.gameObject.SetActive(!flag2 && flag);
		int limitedEdition = m_info.LimitedEdition;
		if (limitedEdition > 10000)
		{
			m_LimitedEdition.State = 3;
			m_PassSeasonText.text = "SS" + (limitedEdition - 10000).ToString();
		}
		else
		{
			m_LimitedEdition.State = limitedEdition;
		}
		m_Host.EventProxy(m_SelectBtn, "OnClickSelected");
		m_Host.EventProxy(m_UseButton, "Use");
		m_Host.EventProxy(m_UnloadButton, "Unload");
		m_RedPoint.gameObject.SetActive(NewIngameEmotionTips.Inst.IsNew(m_info.Id));
		UpdateSelectState();
	}

	private void UpdateSelectState()
	{
		bool flag = Selected == m_info.Id;
		if (!WardrobeUIRedPointJunction.IngameEmotionRedPointFlag && flag)
		{
			m_ScrollView.ScrollToItem(m_Host.gameObject.transform, tween: true);
		}
		if (flag != m_lastSelected)
		{
			m_lastSelected = flag;
			m_Selected.gameObject.SetActive(flag);
			if (flag)
			{
				Canvas canvas = m_Host.gameObject.AddComponent<Canvas>();
				canvas.overrideSorting = true;
				canvas.sortingOrder = -1;
				m_Host.gameObject.AddComponent<GraphicRaycaster>();
			}
			else
			{
				UnityEngine.Object.Destroy(m_Host.gameObject.GetComponent<GraphicRaycaster>());
				UnityEngine.Object.Destroy(m_Host.gameObject.GetComponent<Canvas>());
			}
		}
		if (flag && LastPreviewId != m_info.Id)
		{
			LastPreviewId = m_info.Id;
			Preview();
		}
	}

	private void Preview()
	{
		if (m_info.Type == 0)
		{
			m_Preview.gameObject.SetActive(value: true);
			IngameEmotionUtility.PreviewDecal(m_info.DecalPrefab, m_Preview, hideCharacterSceneRoot: false);
			return;
		}
		LobbyScene.Inst.ClosePreviewPanels();
		m_Preview.gameObject.SetActive(value: false);
		AutoHideLobbyCharacter.ReleaseHiding();
		LobbyScene.Inst.CurrentCharacter.GetComponent<IngameEmotionBaseController>().PlayAnimator(m_info);
	}

	public void OnClickSelected()
	{
		Selected = m_info.Id;
		NewIngameEmotionTips.Inst.TryToClear(m_info.Id);
		m_RedPoint.gameObject.SetActive(value: false);
		UIDataEvents.Inst.InvokeEvent("OnIngameEmotionSelectedChange");
	}

	public void Use()
	{
		CharacterUI_ActiveIngameEmotionConfigView.Replacing = true;
		m_ActiveIngameEmotionConfigView.UpdateBinding();
	}

	public void Unload()
	{
		m_ConfigEdit.Unload(m_info.Id);
		m_ActiveIngameEmotionConfigView.UpdateBinding();
		m_Host.UpdateBinding();
	}
}
