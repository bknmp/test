using DG.Tweening;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class ActiveCardConfigView_ItemTempalte
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public UIStateItem m_State;

	public GameObject m_Highlight;

	public Button m_Button;

	public GameObject m_Root;

	public UIPage m_CardConfigEditPage;

	public GameObject m_LoadEffect;

	public Image m_Frame;

	public Sprite m_DefaultFrame;

	public Text m_Level;

	public AudioItemData m_ReplacingSound;

	public Canvas m_Canvas;

	public Button m_LockButton;

	public UIStateImage m_LockState;

	public Button m_CardSlotLockButton;

	private int m_Index;

	private int m_ItemID;

	private int m_lastActiveConfig;

	private string m_levelFormat;

	private bool m_isLock;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_levelFormat) && m_Level != null)
		{
			m_levelFormat = m_Level.text;
		}
		m_Host.EventProxy(m_Button, "OnButtonClicked");
		m_Index = args["idx"];
		m_ItemID = args["id"];
		m_isLock = args["lock"];
		bool flag = args["lockEnable"];
		int num = args["lockNum"];
		if (LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade < LocalPlayerDatabase.Settings.UnlockCardSlotGrade[m_Index])
		{
			m_State.State = 2;
			if (m_DefaultFrame != null)
			{
				m_Frame.sprite = m_DefaultFrame;
			}
			if (m_Level != null)
			{
				m_Level.transform.parent.gameObject.SetActive(value: false);
			}
			m_Host.EventProxy(m_CardSlotLockButton, "OnClickCardSlotLockButton");
		}
		else if (m_ItemID <= 0)
		{
			m_State.State = 0;
			if (m_DefaultFrame != null)
			{
				m_Frame.sprite = m_DefaultFrame;
			}
			if (m_Level != null)
			{
				m_Level.transform.parent.gameObject.SetActive(value: false);
			}
		}
		else
		{
			m_State.State = 1;
			CardSkinInfo skinInfo = CardUtility.GetSkinInfo(m_ItemID);
			CardStyleInfo cardStyleInfo = LocalResources.CardStyleTable.Get(CardUtility.CurCardStyle(skinInfo.Id));
			string name = (cardStyleInfo == null || string.IsNullOrEmpty(cardStyleInfo.Icon)) ? skinInfo.Icon : cardStyleInfo.Icon;
			m_Icon.sprite = SpriteSource.Inst.Find(name);
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(m_ItemID);
			m_Frame.sprite = SpriteSource.Inst.Find(inGameStoreInfo.Frame);
			if (m_Level != null)
			{
				m_Level.transform.parent.gameObject.SetActive(value: true);
				m_Level.text = string.Format(m_levelFormat, CardUtility.GetCardLevel(m_ItemID));
			}
		}
		if (ActiveCardConfigView.Replacing && m_State.State != 2)
		{
			InGameStoreInfo inGameStoreInfo2 = LocalResources.InGameStoreTable.Get(CardConfigEditPage_ItemTemplate.SelectedID);
			if (GameSettings.Inst.NewIngameKeyMap && inGameStoreInfo2.Type == InGameStoreType.Weapon && m_Index != 5)
			{
				SetCanvasOrder(-3);
			}
			else
			{
				float num2 = 0.15f;
				float num3 = Random.Range(0f, num2);
				m_Root.transform.localRotation = Quaternion.Euler(0f, 0f, -2f);
				m_Root.transform.localPosition = new Vector3(-2f, -2f, 0f);
				m_Root.transform.DOKill();
				m_Root.transform.DOLocalRotate(new Vector3(0f, 0f, 2f), num2).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
					.SetDelay(num3);
				m_Root.transform.DOLocalMoveX(2f, num2).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
					.SetDelay(num3);
				m_Root.transform.DOLocalMoveY(2f, num2).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine)
					.SetDelay(num3 + 0.5f * num2);
				m_Highlight.SetActive(value: true);
				SetCanvasOrder(-1);
			}
		}
		else
		{
			bool flag2 = m_Host.GetComponentInParent<CardConfigEditPage>() != null;
			m_Root.transform.DOKill();
			m_Root.transform.localRotation = Quaternion.identity;
			m_Root.transform.localPosition = Vector3.zero;
			m_Highlight.SetActive(flag2 && m_ItemID == CardConfigEditPage_ItemTemplate.SelectedID);
			SetCanvasOrder(-2);
		}
		if (m_LockButton != null)
		{
			if (GameSettings.Inst.LockCardEnable)
			{
				m_LockButton.gameObject.SetActive(flag && !ActiveCardConfigView.Replacing && m_ItemID > 0 && ((num < 3 && !(m_Host.GetComponentInParent<CardConfigEditPage>() == null)) || m_isLock));
				m_LockState.gameObject.SetActive(value: true);
				m_LockState.State = (m_isLock ? 1 : 0);
				m_Host.EventProxy(m_LockButton, "ChangeLockState");
			}
			else
			{
				m_LockButton.gameObject.SetActive(value: false);
				m_LockState.gameObject.SetActive(value: false);
			}
		}
		if (m_LoadEffect != null && m_lastActiveConfig != CardUtility.CurrentCharacterCardConfigs.activeIndex)
		{
			m_LoadEffect.SetActive(value: false);
		}
		m_lastActiveConfig = CardUtility.CurrentCharacterCardConfigs.activeIndex;
	}

	public void OnButtonClicked()
	{
		if (!(m_Host.GetComponentInParent<CardConfigEditPage>() != null) && m_CardConfigEditPage != null)
		{
			UILobby.Current.GoToPage(m_CardConfigEditPage);
			LocalPlayerDatabase.SetPrefValue("HadShowTipsChangeCard", value: true);
			if (m_ItemID != 0)
			{
				CardConfigEditPage_ItemTemplate.SelectedID = m_ItemID;
			}
		}
		else if (ActiveCardConfigView.Replacing)
		{
			SoundManager.PlayOnce(m_ReplacingSound.Item);
			ActiveCardConfigView.Replacing = false;
			if (CardUtility.IsOwned(CardConfigEditPage_ItemTemplate.SelectedID) && CardUtility.IsCardRoleMatch(CardConfigEditPage_ItemTemplate.SelectedID))
			{
				CardUtility.LoadCard(CardConfigEditPage_ItemTemplate.SelectedID, m_Index);
				m_LoadEffect.SetActive(value: true);
			}
			else
			{
				UILobby.Current.ShowTips(Localization.IllegalOperation);
			}
			UIDataEvents.Inst.InvokeEvent("ActiveCardConfigReplacing");
		}
		else if (m_ItemID > 0)
		{
			CardConfigEditPage_ItemTemplate.SelectedID = m_ItemID;
			UIDataEvents.Inst.InvokeEvent("CardConfigEditPageSelectedChanged");
		}
	}

	public void ChangeLockState()
	{
		CardUtility.ChangeCardLockState(m_Index, !m_isLock);
		UIDataEvents.Inst.InvokeEvent("CardConfigChanged");
	}

	public void OnClickCardSlotLockButton()
	{
		UILobby.Current.ShowTips(string.Format(Localization.UnlockCardSlotTips, LocalResources.GetGradeName(LocalPlayerDatabase.Settings.UnlockCardSlotGrade[m_Index])));
	}

	private void SetCanvasOrder(int order)
	{
		if (m_Canvas != null)
		{
			m_Canvas.sortingOrder = order;
		}
	}
}
