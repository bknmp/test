using LightUtility;
using UnityEngine;

public class CardSkinPreviewEffectController : MonoBehaviour
{
	public GameObject m_Effect;

	public Transform m_EffectRoot;

	public Animation m_Anim;

	public float m_StopAnimTime;

	public AudioSource m_AS;

	public AudioClip m_Audio;

	private bool m_IsStop = true;

	public void Trigger()
	{
		m_IsStop = false;
		if (m_Effect != null && m_EffectRoot != null)
		{
			PoolSpawner.Spawn(m_Effect, m_EffectRoot);
		}
		if (m_Anim != null)
		{
			m_Anim.Play();
		}
		if (m_AS != null && m_Audio != null)
		{
			m_AS.PlayOneShot(m_Audio);
		}
	}

	public void Stop()
	{
		if (!m_IsStop)
		{
			if (m_Anim != null)
			{
				AnimationState animationState = m_Anim[m_Anim.clip.name];
				m_Anim.Play(m_Anim.clip.name);
				animationState.time = m_StopAnimTime;
				m_Anim.Sample();
				animationState.enabled = false;
				m_Anim.Stop();
			}
			if (m_AS != null && m_Audio != null)
			{
				m_AS.Stop();
			}
			m_IsStop = true;
		}
	}
}
