using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class CharacterPackageUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_DisCountDesc;

	public RawImage m_CharacterPreview;

	public Image m_CharacterIcon;

	public Image m_SuitIcon;

	public Text m_ItemName;

	public Text m_Limit;

	public UIStateItem m_StateItem;

	public UIStateImage m_Good;

	public Text m_Current;

	public Text m_Original;

	public Button m_BuyBtn;

	public GameObject m_OwnedCharacter;

	public GameObject m_OwnedSuit;

	public Button m_Mask;

	public Button m_CharacterIconBtn;

	public Button m_SuitIconBtn;

	public UIStateItem m_SuitState;

	public UIStateItem m_CharacterState;

	public Text m_CharacterText;

	public Text m_SuitText;

	private string m_DiscountString;

	private int m_CollectionId;

	private int m_PackageId;

	private int m_CharacterId;

	private int m_SuitItemId;

	private int m_PriceId;

	private int m_CurrentPrice;

	private int m_OriginalPrice;

	private bool HasCharacter;

	private bool HasSuit;

	private int m_ActivityId;

	private int m_ItemId;

	private CommonDataCollection m_args;

	public void Bind(CommonDataCollection args)
	{
		m_args = args;
		m_ActivityId = m_args["activityID"];
		m_CollectionId = m_args["collectionID"];
		m_PackageId = m_args["packageID"];
		m_CharacterId = m_args["characterID"];
		m_SuitItemId = m_args["suitItemId"];
		m_CurrentPrice = m_args["discountPrice"];
		m_OriginalPrice = m_args["orgPrice"];
		m_PriceId = m_args["priceID"];
		m_ItemId = m_args["itemId"];
		if ((bool)m_args["useCollection"])
		{
			TextHandle();
			InitIcon(useCollection: true);
			OwnedTipHandle();
			return;
		}
		if (string.IsNullOrEmpty(m_DiscountString))
		{
			m_DiscountString = m_DisCountDesc.text;
		}
		InitIcon();
		TextHandle();
		OwnedTipHandle();
		CurrencyHandle();
		m_Host.EventProxy(m_BuyBtn, "OnBuyBtnClick");
		m_Host.EventProxy(m_Mask, "OnMaskClick");
	}

	private void InitIcon(bool useCollection = false)
	{
		if (useCollection)
		{
			DropItem dropItem = LocalResources.DropItemTable.Get(m_ItemId);
			m_CharacterIcon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
			return;
		}
		m_SuitIcon.transform.parent.gameObject.SetActive(m_SuitItemId > 0);
		if (m_SuitItemId > 0)
		{
			if (m_SuitState != null && m_SuitState.State.Equals(1))
			{
				m_CharacterText.text = m_args["mainName"];
			}
			else
			{
				m_CharacterPreview.texture = ResManager.Load<Texture>($"CharacterPreview_{m_SuitItemId}");
			}
		}
		else if (m_CharacterState != null && m_CharacterState.State.Equals(1))
		{
			m_SuitText.text = m_args["mainName"];
		}
		else
		{
			m_CharacterPreview.texture = ResManager.Load<Texture>($"CharacterPreview_{m_CharacterId}");
		}
		if (m_SuitItemId > 0)
		{
			ShopInfo shopInfo = (m_CharacterId == 0) ? LocalResources.ShopTable.Get(CharacterDiscountUtility.GetCollectionCharacterID(m_ActivityId, m_CollectionId)) : LocalResources.ShopTable.Get(m_CharacterId);
			DropItem dropItem2 = LocalResources.DropItemTable.Get(shopInfo.Id);
			HasCharacter = DropItemUtility.IsOwnPermanent(dropItem2);
			m_CharacterIcon.sprite = SpriteSource.Inst.Find(dropItem2.Icon);
			ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(m_SuitItemId);
			DropItem dropItem3 = LocalResources.DropItemTable.Get(shopSuiteInfo.Id);
			m_SuitIcon.sprite = SpriteSource.Inst.Find(dropItem3.Icon);
			HasSuit = DropItemUtility.IsOwnPermanent(dropItem3);
		}
		else if (m_CharacterId > 0)
		{
			ShopInfo shopInfo2 = LocalResources.ShopTable.Get(m_CharacterId);
			DropItem dropItem4 = LocalResources.DropItemTable.Get(shopInfo2.Id);
			m_CharacterIcon.sprite = SpriteSource.Inst.Find(dropItem4.Icon);
			HasCharacter = DropItemUtility.IsOwnPermanent(dropItem4);
		}
	}

	private void TextHandle()
	{
		if ((bool)m_ItemName)
		{
			m_ItemName.text = m_args["mainName"];
		}
		if ((bool)m_Current)
		{
			m_Current.text = m_CurrentPrice.ToString();
		}
		if ((bool)m_Original)
		{
			m_Original.text = m_OriginalPrice.ToString();
		}
		m_PriceId = m_args["priceID"];
		if ((bool)m_DisCountDesc)
		{
			m_DisCountDesc.text = string.Format(m_DiscountString, m_args["discount"], Localization.Discount);
		}
	}

	private void OwnedTipHandle()
	{
		if ((bool)m_OwnedSuit)
		{
			m_OwnedSuit.SetActive(HasSuit);
		}
		if ((bool)m_OwnedCharacter)
		{
			m_OwnedCharacter.SetActive(HasCharacter);
		}
		if ((bool)m_Mask)
		{
			m_Mask.gameObject.SetActive(CharacterDiscountUtility.IsOwnPackage(m_ActivityId, m_CollectionId, m_PackageId));
			if (m_CharacterId > 0 && HasSuit)
			{
				m_Mask.gameObject.SetActive(value: true);
			}
		}
		if ((bool)m_DisCountDesc)
		{
			m_DisCountDesc.transform.parent.gameObject.SetActive(!m_Mask.gameObject.activeSelf);
		}
		if ((bool)m_Limit)
		{
			m_Limit.gameObject.SetActive(!m_Mask.gameObject.activeSelf);
		}
		if (m_Mask != null && m_Mask.gameObject.activeSelf && (bool)m_Limit)
		{
			m_Limit.text = Localization.OwnedGoods;
		}
		if ((bool)m_BuyBtn)
		{
			m_BuyBtn.gameObject.SetActive(!m_Mask.gameObject.activeSelf);
			if (m_BuyBtn.gameObject.activeSelf && m_SuitItemId > 0)
			{
				m_Host.EventProxy(m_SuitIconBtn, "OnSuitIconClick");
			}
		}
	}

	private void CurrencyHandle()
	{
		m_StateItem.State = ((m_PriceId == 99) ? 1 : 0);
		switch (m_PriceId)
		{
		case 2:
			m_Good.State = 2;
			break;
		case 4:
			m_Good.State = 1;
			break;
		}
	}

	public void OnBuyBtnClick()
	{
		CharacterDiscountUtility.TryBuy(m_ActivityId, m_args["packageID"], null);
	}

	public void OnCharacterIconClick()
	{
		if (IsActivityAvailable(m_ActivityId))
		{
			CommonDataCollection collectionArgByCollectionID = CharacterDiscountUtility.GetCollectionArgByCollectionID(m_ActivityId, m_CollectionId);
			collectionArgByCollectionID["index"] = 0;
			UIPage ui = PrefabSource.Inst.Load<UIPage>("CharacterGiftBagPreviewUI");
			UILobby.Current.ShowUI(ui, collectionArgByCollectionID);
		}
	}

	public void OnSuitIconClick()
	{
		if (IsActivityAvailable(m_ActivityId))
		{
			CommonDataCollection collectionArgByCollectionID = CharacterDiscountUtility.GetCollectionArgByCollectionID(m_ActivityId, m_CollectionId);
			collectionArgByCollectionID["index"] = 1;
			UIPage ui = PrefabSource.Inst.Load<UIPage>("CharacterGiftBagPreviewUI");
			UILobby.Current.ShowUI(ui, collectionArgByCollectionID);
		}
	}

	public void OnMaskClick()
	{
		UILobby.Current.ShowTips(Localization.OwnedItemHint);
	}

	private bool IsActivityAvailable(int activityID)
	{
		if (ActivityLobby.GetActivityById(activityID) == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return false;
		}
		return true;
	}
}
