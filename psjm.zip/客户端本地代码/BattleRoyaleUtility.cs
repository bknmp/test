using System.Collections.Generic;

public static class BattleRoyaleUtility
{
	public const int CardSlotNum = 4;

	public const int GroupEachNum = 2;

	public static int RemainedGroupCount
	{
		get
		{
			int num = 0;
			foreach (int uniqueGroupID in IngameGroupUtility.UniqueGroupIDs)
			{
				if (GetRemainedPlayerCount(uniqueGroupID) > 0)
				{
					num++;
				}
			}
			return num;
		}
	}

	public static int GroupCount => IngameGroupUtility.GroupCount;

	public static int MyGroupID => IngameGroupUtility.MyGroupID;

	public static int GetRemainedPlayerCount(int groupID)
	{
		int num = 0;
		foreach (KeyValuePair<string, int> groupID2 in IngameGroupUtility.GroupIDs)
		{
			if (groupID == groupID2.Value)
			{
				RuntimePlayerState runtimePlayerState = GameRuntime.PlayersState[groupID2.Key];
				if (!runtimePlayerState.IsFinalDead && !runtimePlayerState.IsDying)
				{
					num++;
				}
			}
		}
		return num;
	}
}
