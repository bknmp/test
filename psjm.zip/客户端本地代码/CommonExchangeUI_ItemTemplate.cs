using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CommonExchangeUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Button m_CantClaimBtn;

	public Button m_ClaimBtn;

	public UIStateItem m_Btns;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public UITemplateInitiator m_NeedContainer;

	public UITemplateInitiator m_RewardContainer;

	public GameObject m_RedPoint;

	public Text m_Limit;

	public Toggle m_UIToggle;

	public GameObject m_HadExchangeAll;

	public GameObject m_Arrow;

	public UIStateItem m_GetState;

	private string m_LimitFormat;

	private ExchangeActivityInfo m_exchangeInfo;

	private CommonExchangeUI m_CommonExchangeUI;

	private int m_activityId;

	private CommonDataCollection m_needItemArg = new CommonDataCollection();

	private CommonDataCollection m_rewardItemArg = new CommonDataCollection();

	private int m_exchangeTimes;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_LimitFormat))
		{
			m_LimitFormat = m_Limit.text;
		}
		m_exchangeInfo = (args["info"].val as ExchangeActivityInfo);
		m_exchangeTimes = args["exchangeTime"];
		m_CommonExchangeUI = (args["CommonExchangeUI"].val as CommonExchangeUI);
		m_activityId = args["activityId"];
		DataItem item = args["tipsOpen"];
		if (m_CommonExchangeUI.HaveLocalTipsOpenData(m_exchangeInfo.Id, out bool state))
		{
			item = state;
		}
		m_Limit.text = string.Format(m_LimitFormat, m_exchangeTimes, m_exchangeInfo.Limit);
		m_needItemArg.Clear();
		for (int i = 0; i < m_exchangeInfo.NeedIds.Length; i++)
		{
			m_needItemArg[i]["dropItemInfo"].val = new ItemInfo
			{
				itemID = m_exchangeInfo.NeedIds[i],
				itemCount = m_exchangeInfo.NeedCounts[i]
			};
		}
		m_NeedContainer.Args = m_needItemArg;
		m_NeedContainer.UpdateImmediately(withChildren: true);
		m_rewardItemArg.Clear();
		for (int j = 0; j < m_exchangeInfo.RewardIds.Length; j++)
		{
			m_rewardItemArg[j]["dropItemInfo"].val = new ItemInfo
			{
				itemID = m_exchangeInfo.RewardIds[j],
				itemCount = m_exchangeInfo.RewardCounts[j]
			};
		}
		m_RewardContainer.Args = m_rewardItemArg;
		m_RewardContainer.UpdateImmediately(withChildren: true);
		m_RedPoint.SetActive(CommonExchangeUI.CheckEnough(m_exchangeInfo) && (bool)item);
		m_Host.EventProxy(m_ClaimBtn, "OnClickClaim");
		m_Host.EventProxy(m_CantClaimBtn, "OnClickCantClaim");
		m_Btns.State = ((!CommonExchangeUI.CheckEnough(m_exchangeInfo)) ? 1 : 0);
		m_UIToggle.onValueChanged.RemoveAllListeners();
		m_UIToggle.isOn = item;
		m_UIToggle.onValueChanged.AddListener(OnTipsOpenToggleChange);
		if (m_exchangeTimes < m_exchangeInfo.Limit)
		{
			m_Btns.gameObject.SetActive(value: true);
			m_UIToggle.gameObject.SetActive(value: true);
			m_HadExchangeAll.gameObject.SetActive(value: false);
		}
		else
		{
			m_Btns.gameObject.SetActive(value: false);
			m_UIToggle.gameObject.SetActive(value: false);
			m_HadExchangeAll.gameObject.SetActive(value: true);
		}
		bool flag = m_exchangeTimes >= m_exchangeInfo.Limit;
		bool flag2 = NoNeed(m_exchangeInfo.NeedCounts);
		m_Limit.gameObject.SetActive(!flag2);
		m_NeedContainer.gameObject.SetActive(!flag2);
		m_Btns.gameObject.SetActive(!flag);
		m_UIToggle.gameObject.SetActive(!flag && !flag2);
		m_HadExchangeAll.gameObject.SetActive(flag);
		if (m_GetState != null)
		{
			m_GetState.State = (flag2 ? 1 : 0);
			UIStateItem component = m_ClaimBtn.GetComponent<UIStateItem>();
			if (component != null)
			{
				component.State = (flag2 ? 1 : 0);
			}
			if (m_Arrow != null)
			{
				m_Arrow.SetActive(!flag2);
			}
		}
	}

	private bool NoNeed(int[] needCount)
	{
		for (int i = 0; i < needCount.Length; i++)
		{
			if (needCount[i] > 0)
			{
				return false;
			}
		}
		return true;
	}

	public void OnClickClaim()
	{
		HttpRequestExchangeActivityClaim httpRequestExchangeActivityClaim = new HttpRequestExchangeActivityClaim();
		httpRequestExchangeActivityClaim.activityId = m_activityId;
		httpRequestExchangeActivityClaim.id = m_exchangeInfo.Id;
		GameHttpManager.Inst.Send(httpRequestExchangeActivityClaim, delegate(HttpResponseExchangeActivityClaim onResponse)
		{
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.AddItems(onResponse.rewards);
			commonRewardPopupUI.SetTitleAndTips("", "");
		});
	}

	public void OnClickCantClaim()
	{
		if (m_exchangeTimes >= m_exchangeInfo.Limit)
		{
			UILobby.Current.ShowTips(Localization.ExchangeWordTimesLimit);
		}
		else if (!CommonExchangeUI.CheckEnough(m_exchangeInfo))
		{
			UILobby.Current.ShowTips(Localization.CantClaim);
		}
	}

	private void OnTipsOpenToggleChange(bool value)
	{
		m_CommonExchangeUI.OnTipsOpenToggleChange(m_exchangeInfo.Id, value);
		m_RedPoint.SetActive(value && CommonExchangeUI.CheckEnough(m_exchangeInfo));
	}
}
