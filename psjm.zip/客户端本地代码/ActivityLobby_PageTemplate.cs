using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;

internal class ActivityLobby_PageTemplate
{
	public UIDataBinder m_Host;

	private int m_lastActivityId = -1;

	private GameObject m_inst;

	public void Bind(CommonDataCollection args)
	{
		Activity activity = args["Activity"].val as Activity;
		ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
		if (m_lastActivityId != activity.activityId)
		{
			if (m_inst != null)
			{
				UnityEngine.Object.Destroy(m_inst.gameObject);
			}
			m_inst = Object.Instantiate(PrefabSource.Inst.Find(activityLobbyInfo.Prefab), m_Host.transform);
			if ((bool)m_inst.GetComponent<UIDataBinder>())
			{
				m_inst.GetComponent<UIDataBinder>().Args = args;
				UpdateOnEnterUI();
			}
			m_inst.SetActive(value: true);
			m_lastActivityId = activity.activityId;
		}
		else if ((bool)m_inst.GetComponent<UIDataBinder>())
		{
			m_inst.GetComponent<UIDataBinder>().UpdateBinding();
		}
	}

	private void UpdateOnEnterUI()
	{
		UIEventListener[] componentsInChildren = m_Host.GetComponentsInChildren<UIEventListener>(includeInactive: true);
		foreach (UIEventListener uIEventListener in componentsInChildren)
		{
			if (uIEventListener != null)
			{
				uIEventListener.OnEnterUI();
			}
		}
	}
}
