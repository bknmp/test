using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddressList : MonoBehaviour
{
	public List<string> m_ProvinceInfo;

	public List<string> m_CityInfo;

	public List<string> m_ZoneInfo;

	public Dropdown[] m_AddressDropdown;

	public static AddressList Inst;

	public string CurrentProvince = "北京市";

	public string CurrentCity = "直辖区";

	public string CurrentZone = "东城区";

	public bool inited;

	private float[] m_TempScrollerValue = new float[3]
	{
		1f,
		1f,
		1f
	};

	private void Awake()
	{
		Inst = this;
		Inst.m_AddressDropdown[0].AddOptions(Inst.m_ProvinceInfo);
		SetCurrentProvince();
	}

	public void SetScrollerValue(int index)
	{
		if (m_AddressDropdown[index].transform.Find("Dropdown List") != null)
		{
			m_AddressDropdown[index].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>().value = m_TempScrollerValue[index];
		}
	}

	public void SetCurrentProvince()
	{
		if (m_AddressDropdown[0].transform.Find("Dropdown List") != null)
		{
			m_TempScrollerValue[0] = m_AddressDropdown[0].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>().value;
		}
		CurrentProvince = m_ProvinceInfo[m_AddressDropdown[0].value];
		List<ChinaCityTable> list = LocalResources.CityTable.FindAll((ChinaCityTable x) => x.Province == CurrentProvince);
		m_CityInfo.Clear();
		foreach (ChinaCityTable item in list)
		{
			if (!m_CityInfo.Contains(item.City))
			{
				m_CityInfo.Add(item.City);
			}
		}
		m_AddressDropdown[1].options.Clear();
		m_AddressDropdown[1].AddOptions(m_CityInfo);
		m_AddressDropdown[1].value = 0;
		CurrentCity = m_CityInfo[0];
		List<ChinaCityTable> list2 = LocalResources.CityTable.FindAll((ChinaCityTable y) => y.Province == CurrentProvince && y.City == CurrentCity);
		m_ZoneInfo.Clear();
		foreach (ChinaCityTable item2 in list2)
		{
			if (!m_ZoneInfo.Contains(item2.District))
			{
				m_ZoneInfo.Add(item2.District);
			}
		}
		m_AddressDropdown[2].options.Clear();
		m_AddressDropdown[2].AddOptions(m_ZoneInfo);
		m_AddressDropdown[2].value = 0;
		CurrentZone = m_ZoneInfo[0];
	}

	public void SetCurrentCity()
	{
		if (m_AddressDropdown[1].transform.Find("Dropdown List") != null && (bool)m_AddressDropdown[1].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>())
		{
			m_TempScrollerValue[1] = m_AddressDropdown[1].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>().value;
		}
		CurrentCity = m_CityInfo[m_AddressDropdown[1].value];
		List<ChinaCityTable> list = LocalResources.CityTable.FindAll((ChinaCityTable x) => x.Province == CurrentProvince && x.City == CurrentCity);
		m_ZoneInfo.Clear();
		foreach (ChinaCityTable item in list)
		{
			if (!m_ZoneInfo.Contains(item.District))
			{
				m_ZoneInfo.Add(item.District);
			}
		}
		m_AddressDropdown[2].options.Clear();
		m_AddressDropdown[2].AddOptions(m_ZoneInfo);
		m_AddressDropdown[2].value = 0;
		CurrentZone = m_ZoneInfo[0];
	}

	public void SetCurrentZone()
	{
		if (m_AddressDropdown[2].transform.Find("Dropdown List") != null && m_AddressDropdown[2].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>() != null)
		{
			m_TempScrollerValue[2] = m_AddressDropdown[2].transform.Find("Dropdown List").GetComponentInChildren<Scrollbar>().value;
		}
		CurrentZone = m_ZoneInfo[m_AddressDropdown[2].value];
	}

	public void InitProvinceIndex(string m_Name)
	{
		m_AddressDropdown[0].value = m_ProvinceInfo.FindIndex((string x) => x.Equals(m_Name));
		SetCurrentProvince();
	}

	public void InitCityIndex(string m_Name)
	{
		m_AddressDropdown[1].value = m_CityInfo.FindIndex((string x) => x.Equals(m_Name));
		SetCurrentCity();
	}

	public void InitZoneIndex(string m_Name)
	{
		m_AddressDropdown[2].value = m_ZoneInfo.FindIndex((string x) => x.Equals(m_Name));
		SetCurrentZone();
	}
}
