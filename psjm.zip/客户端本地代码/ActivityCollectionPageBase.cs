using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActivityCollectionPageBase : UIEventListener
{
	public ActivityCollectionType m_CollectionType;

	public Text m_TitleText;

	public UIDataTabPage m_DataTabPage;

	protected List<Activity> m_ActivityList = new List<Activity>();

	protected int m_JumpIndex = -1;

	public int GoBackIndex
	{
		get;
		set;
	}

	private new void Awake()
	{
		base.Awake();
		m_DataTabPage.OnButtonItemChanged.AddListener(TryJump);
	}

	private void Start()
	{
		m_DataTabPage.TabPage.OnTabChanged.AddListener(OnTabChanged);
	}

	public override void OnEnterUI()
	{
		m_ActivityList.Clear();
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
			if (m_CollectionType == activityLobbyInfo.CollectionType && LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade >= activity.gradeLimit && (UtcTimeStamp.Now >= activity.startTime || UtcTimeStamp.Now >= activity.exchangeStartTime) && (UtcTimeStamp.Now <= activity.endTime || UtcTimeStamp.Now <= activity.exchangeEndTime))
			{
				m_ActivityList.Add(activity);
			}
		}
		if (m_ActivityList.Count <= 0)
		{
			UILobby.Current.ShowMessageBoxOK(Localization.ActivityOver, Localization.MsgBoxKnow, Localization.MsgBoxTitle, delegate
			{
				GetComponent<UIPage>().GoBack();
			}, showCloseButton: false);
			return;
		}
		m_ActivityList.Sort((Activity a, Activity b) => LocalResources.ActivityLobbyInfos.Get(a.activityId).Rank.CompareTo(LocalResources.ActivityLobbyInfos.Get(b.activityId).Rank));
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		CommonDataCollection commonDataCollection2 = new CommonDataCollection();
		for (int j = 0; j < m_ActivityList.Count; j++)
		{
			commonDataCollection[j]["Activity"].val = m_ActivityList[j];
			commonDataCollection2[j]["Activity"].val = m_ActivityList[j];
			commonDataCollection2[j]["dataTabPage"].val = m_DataTabPage;
			if (j == m_ActivityList.Count - 1)
			{
				commonDataCollection[j]["IsLast"] = true;
				commonDataCollection2[j]["IsLast"] = true;
			}
		}
		m_DataTabPage.SetItems(commonDataCollection.Array, commonDataCollection2.Array);
		OnTabChanged();
	}

	protected virtual void OnTabChanged()
	{
		UpdateTitleName();
		GoBackIndex = -1;
	}

	private void UpdateTitleName()
	{
		if (m_ActivityList.Count > 0)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(m_ActivityList[Mathf.Clamp(m_DataTabPage.TabPage.GetSelectedTabIndex(), 0, m_ActivityList.Count - 1)].activityId);
			m_TitleText.text = activityLobbyInfo.TitleName;
		}
	}

	public virtual void SetEnterTabPage()
	{
	}

	private void TryJump()
	{
		if (m_JumpIndex >= 0)
		{
			m_DataTabPage.TabPage.SetSelectedTabIndex(m_JumpIndex);
			m_JumpIndex = -1;
		}
	}

	public void GoBack()
	{
		if (GoBackIndex >= 0)
		{
			m_DataTabPage.TabPage.SetSelectedTabIndex(GoBackIndex);
			GoBackIndex = -1;
		}
		else
		{
			GetComponent<UIPage>().GoBack();
		}
	}

	public ActivityLobbyInfo GetActivityInfoByType(ActivityType type)
	{
		foreach (Activity activity in m_ActivityList)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activity.activityId);
			if (activityLobbyInfo.Type == type)
			{
				return activityLobbyInfo;
			}
		}
		return null;
	}

	public Activity GetActivityByID(int activityID, bool includeNotOpen = false)
	{
		Activity[] activitys = LocalPlayerDatabase.Settings.activitys;
		foreach (Activity activity in activitys)
		{
			if (activity.activityId == activityID)
			{
				return activity;
			}
		}
		if (includeNotOpen)
		{
			ActivityLobbyInfo activityLobbyInfo = LocalResources.ActivityLobbyInfos.Get(activityID);
			if (activityLobbyInfo != null)
			{
				return new Activity
				{
					activityId = activityID,
					endTime = activityLobbyInfo.EndTime,
					exchangeEndTime = activityLobbyInfo.exchangeEndTime,
					exchangeStartTime = activityLobbyInfo.startTime,
					gradeLimit = activityLobbyInfo.gradeLimit,
					startTime = activityLobbyInfo.startTime
				};
			}
		}
		return null;
	}
}
