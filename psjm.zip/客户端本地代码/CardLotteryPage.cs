using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class CardLotteryPage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_TemplateInitiator;

	public UITemplateInitiator m_TemplateInitiatorForRainbowCardLottery;

	public Button m_GoRainbowLotteryButton;

	public Button m_GoNormalLotteriesButton;

	public Button m_MoreInfoButtn;

	public UIPage m_NewCardAcitivity;

	public GameObject m_NormalLotteryTicket;

	public GameObject m_AdvanceLotteryTicket;

	public GameObject m_SuperLotteryTicket;

	public GameObject m_RainbowLotteryTicket;

	public GameObject m_RedPoint;

	public Button m_AdButton;

	public UIPage m_BoxOpenUI;

	public Text m_NewCardActivityTips;

	public Text m_NewCardActivityTips2;

	private CommonDataCollection m_ItemArgs = new CommonDataCollection();

	private CommonDataCollection m_ItemArgsForRainbowCardLottery = new CommonDataCollection();

	private AdScene m_AdScene = AdScene.CARD_DRAW;

	private string m_NewCardActivityTipsFormat;

	public void Bind(CommonDataCollection args)
	{
		if (LocalPlayerDatabase.CardLotteryInfo == null)
		{
			LocalPlayerDatabase.RefreshCardLotteryInfo(silent: false, LoadCardLotteryUI);
		}
		else
		{
			LoadCardLotteryUI();
		}
		TryShowAd();
		m_Host.EventProxy(m_GoNormalLotteriesButton, "OnGoNormalLotteries");
		m_Host.EventProxy(m_GoRainbowLotteryButton, "OnGoRainbowLottery");
		m_Host.EventProxy(m_MoreInfoButtn, "OnMoreInfo");
		m_Host.EventProxy(m_AdButton, "OnWatchAd");
	}

	public void OnMoreInfo()
	{
		if (m_NewCardAcitivity != null)
		{
			UILobby.Current.ShowUI(m_NewCardAcitivity, null);
		}
	}

	public void OnGoRainbowLottery()
	{
		_OnGoRainbowLottery();
	}

	public void _OnGoRainbowLottery(bool withNormalBackground = false)
	{
		CardLotteryUI.OpenRainbowLotteryScene(withNormalBackground);
	}

	private void TryShowAd()
	{
		m_AdButton.gameObject.SetActive(value: false);
		if (AdUtility.IsAdEnable(AdScene.CARD_DRAW))
		{
			m_AdButton.gameObject.SetActive(value: true);
			AdSDKManager.TryReportEvent(AdScene.CARD_DRAW, AdStatistics.Show);
		}
	}

	public void OnWatchAd()
	{
		BoxInfo boxInfo = CardLotteryUtility.GetLotteryBox(CardLotteryType.Normal, LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade);
		AdSDKManager.Inst.ShowAd(m_AdScene, delegate
		{
			AdUtility.RequestRewards(m_AdScene, 0, delegate
			{
				BoxUtility.RequestOpenBoxByID(boxInfo.Id, delegate(ItemInfo[] items)
				{
					CardLotteryItem cardLotteryItem = LobbyScene.Inst.GetCardLotteryItem((CardLotteryType)boxInfo.Type);
					CardLotteryUI.Inst.OnOpenBox(boxInfo.Id, m_BoxOpenUI, cardLotteryItem, items);
					LocalPlayerDatabase.RefreshCardLotteryInfo();
				}, null, 1);
			});
		});
	}

	public void OnGoNormalLotteries()
	{
		CardLotteryUI.OpenNormalLotteryScene();
	}

	private void LoadCardLotteryUI()
	{
		m_ItemArgs.Clear();
		m_ItemArgsForRainbowCardLottery.Clear();
		CardLotteryInfo[] infos = LocalPlayerDatabase.CardLotteryInfo.infos;
		int num = 19;
		bool flag = false;
		bool flag2 = false;
		int num2 = 0;
		CardLotteryInfo[] array = infos;
		foreach (CardLotteryInfo cardLotteryInfo in array)
		{
			BoxInfo lotteryBox = CardLotteryUtility.GetLotteryBox(cardLotteryInfo.type, LocalPlayerDatabase.PlayerInfo.publicInfo.higherGrade);
			if (cardLotteryInfo.type == (CardLotteryType)num && !flag)
			{
				if (lotteryBox != null)
				{
					flag = true;
					m_ItemArgsForRainbowCardLottery[0]["boxID"] = lotteryBox.Id;
				}
				continue;
			}
			bool flag3 = cardLotteryInfo.IsFree();
			int prefValueInt = LocalPlayerDatabase.GetPrefValueInt(GetNewbieFlag(cardLotteryInfo));
			flag2 = (flag2 || (flag3 && prefValueInt != 2));
			if (lotteryBox != null)
			{
				m_ItemArgs[num2]["boxID"] = lotteryBox.Id;
				num2++;
			}
		}
		int activityId = 0;
		flag = (flag && ActivityLobby.IsActicityAvailable(ActivityType.BUY_NEW_CARD_DIRECT, ActivityCollectionType.NEW_CARD_ACTIVITY, out activityId));
		m_NewCardActivityTips.gameObject.SetActive(flag);
		m_NewCardActivityTips2.gameObject.SetActive(flag);
		m_TemplateInitiator.Args = m_ItemArgs;
		if (flag)
		{
			m_TemplateInitiatorForRainbowCardLottery.Args = m_ItemArgsForRainbowCardLottery;
			if (string.IsNullOrEmpty(m_NewCardActivityTipsFormat))
			{
				m_NewCardActivityTipsFormat = m_NewCardActivityTips.text;
			}
			string text3 = m_NewCardActivityTips.text = (m_NewCardActivityTips2.text = string.Format(m_NewCardActivityTipsFormat, LocalResources.InGameStoreTable.Get(LocalResources.ActivityLobbyInfos.Get(activityId).Index).FullName));
		}
		m_GoRainbowLotteryButton.gameObject.SetActive(flag);
		CardLotteryUI.ClearLastOpenLotteryFlag();
		CardLotteryInfo lotteryInfo = CardLotteryUtility.GetLotteryInfo(7);
		CardLotteryInfo lotteryInfo2 = CardLotteryUtility.GetLotteryInfo(8);
		if (m_RedPoint != null)
		{
			m_RedPoint.SetActive(lotteryInfo2.IsFree() || lotteryInfo.IsFree());
		}
	}

	private string GetNewbieFlag(CardLotteryInfo info)
	{
		if (info.type != CardLotteryType.Normal)
		{
			return "CardLotteryFirstFree_Purple";
		}
		return "CardLotteryFirstFree_Blue";
	}
}
