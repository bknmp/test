using GameMessages;
using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

public class AccountTipsUI : MonoBehaviour
{
	public AccountInfoController m_AccountController;

	public Text m_TouristText;

	public Text m_SDKText;

	public Button m_Yes;

	public Button m_No;

	public Button m_Close;

	private string m_SDKFormat;

	private Delegates.VoidCallback m_Callback;

	private void Awake()
	{
		m_Yes.onClick.AddListener(OnYesClick);
		m_No.onClick.AddListener(CloseUI);
		m_Close.onClick.AddListener(CloseUI);
		m_SDKFormat = m_SDKText.text;
	}

	private void Init(int roleID, string accountName, Delegates.VoidCallback callback)
	{
		m_AccountController.SetAccountInfo(roleID, accountName);
		m_Callback = callback;
		if (LoginManager.SDKLoginType == 1)
		{
			m_TouristText.gameObject.SetActive(value: true);
			m_SDKText.gameObject.SetActive(value: false);
		}
		else
		{
			m_SDKText.gameObject.SetActive(value: true);
			m_TouristText.gameObject.SetActive(value: false);
			m_SDKText.text = string.Format(m_SDKFormat, LoginUtility.SDKAccountName((LoginType)LoginManager.SDKLoginType));
		}
	}

	private void OnYesClick()
	{
		CloseUI();
		m_Callback?.Invoke();
	}

	private void CloseUI()
	{
		GetComponent<UIPopup>().GoBack();
	}

	public static void ShowUI(int roleID, string accountName, Delegates.VoidCallback callback)
	{
		UIPopup ui = ResManager.Load<UIPopup>("AccountTipsUI");
		UILobby.Current.ShowUI(ui, null).GetComponent<AccountTipsUI>().Init(roleID, accountName, callback);
	}
}
