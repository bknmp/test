using LightUI;

public class CardDetailUI : UIEventListener
{
	public override void OnExitUI()
	{
		CardConfigEditPage_PageCardSkin.HadSetCardSkinDefaultSelect = false;
	}
}
