using System.Collections.Generic;
using UnityEngine;

public class AttackArea_Parabola : AttackArea
{
	public LineRenderer m_Line;

	public GameObject m_WillHitEffect;

	private ThrownObject m_ThrownObject;

	private Vector3 m_StartPos;

	private bool m_StartMove;

	public override void Bind(ProjectileLauncher launcher, GameObject prefab)
	{
		m_ThrownObject = prefab.GetComponent<ThrownObject>();
		base.Bind(launcher, prefab);
	}

	protected override void UpdatePosition()
	{
		if (base.IsShow && base.gameObject.activeSelf && m_ThrownObject != null)
		{
			m_StartPos = m_Launcher.transform.position + (m_Launcher.m_LaunchHeightScale * m_Launcher.CurrentWeapont.LaunchHeightMin + ((m_Launcher.Controller.OnVehichle != null) ? (-0.5f) : 0f)) * Vector3.up;
			m_MaxDistance = m_ThrownObject.GetMaxDistance(0f - m_StartPos.y);
			m_Range.transform.localScale = Vector3.one * m_MaxDistance;
			DrawParabola();
		}
	}

	private void DrawParabola()
	{
		m_Postion = m_ThrownObject.GetRealTargetPos(m_StartPos, m_Postion, m_MaxDistance);
		Vector3 velocity = m_ThrownObject.GetVelocity(m_StartPos, m_Postion);
		List<Vector3> wholeHitPos;
		List<Vector3> wholeHitNormal;
		List<Vector3> wholeHitVelocity;
		List<float> wholeHitTime;
		List<Vector3> wholeTrack = m_ThrownObject.GetWholeTrack(m_StartPos, velocity, out wholeHitPos, out wholeHitNormal, out wholeHitVelocity, out wholeHitTime);
		m_Line.positionCount = wholeTrack.Count;
		m_WillHitEffect.SetActive(value: true);
		m_WillHitEffect.transform.position = wholeHitPos[0] + 0.02f * wholeHitNormal[0];
		m_WillHitEffect.transform.LookAt(m_WillHitEffect.transform.position + wholeHitNormal[0]);
		int num = wholeTrack.IndexOf(wholeHitPos[0]);
		for (int i = 0; i < wholeTrack.Count; i++)
		{
			Vector3 vector = wholeTrack[i];
			if (i < num)
			{
				float d = Mathf.Min(0.3f * (vector - wholeHitPos[0]).magnitude / (m_StartPos - wholeHitPos[0]).magnitude, 0.2f * vector.y);
				vector -= d * Vector3.up;
			}
			m_Line.SetPosition(i, vector);
		}
	}

	public override void Show()
	{
		m_StartMove = false;
		base.Show();
	}

	public override void SetPositionOffset(Vector2 deltaRatio)
	{
		Vector2 vector = deltaRatio;
		if (!m_StartMove)
		{
			if ((double)Mathf.Abs(vector.x) < 0.01 && (double)Mathf.Abs(vector.y) < 0.01)
			{
				vector = new Vector2(m_Launcher.transform.forward.x, m_Launcher.transform.forward.z);
			}
			else
			{
				m_StartMove = true;
			}
		}
		base.SetPositionOffset(vector);
	}
}
