public enum AuthModeOption
{
	Auth,
	AuthOnce,
	AuthOnceWss
}
