using BehaviorDesigner.Runtime;
using BehaviorDesigner.Runtime.Tasks;
using UnityEngine;

[TaskName("处理遇敌情况")]
[TaskCategory("躲猫猫AI/条件")]
public class DealWithNearbyEnemy : Conditional
{
	public SharedPlayerController nearbyEnemy;

	public SharedPlayerController rescueTarget;

	public SharedUsableObject usingTarget;

	public SharedGameObject warningMsg;

	private AIController ai;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
	}

	public override TaskStatus OnUpdate()
	{
		if ((ai.IsFocus() && (rescueTarget.Value != null || usingTarget.Value != null)) || (warningMsg.Value != null && (bool)warningMsg.Value.GetComponent<JailDoor>() && !ai.IsIgnoreWarning()) || ai.PerformanceMode)
		{
			return TaskStatus.Failure;
		}
		if (nearbyEnemy.Value != null && ai.CanPursuitEnemy(nearbyEnemy.Value))
		{
			if (ai.InMode(AIMode.Navigate))
			{
				UnityEngine.Debug.Log("导航模式被打断，切换回预警模式");
				ai.SetWander();
				ai.NotifyNavigationIfNeed(complete: false);
			}
			return TaskStatus.Success;
		}
		return TaskStatus.Failure;
	}
}
