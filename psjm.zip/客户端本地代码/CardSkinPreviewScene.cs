using DG.Tweening;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class CardSkinPreviewScene : MonoBehaviour
{
	public Camera m_Camera;

	public Transform m_PefabRoot;

	public float m_Param = 1f;

	public float m_OffsetZ = 1.2f;

	public float m_Duration = 0.5f;

	public UITemplateInitiator m_TemplateInitiator;

	private List<GameObject> m_item = new List<GameObject>();

	private int m_index;

	private void Awake()
	{
		m_TemplateInitiator.OnItemsChanged.AddListener(delegate
		{
			UpdateItemPositon(0f);
		});
	}

	public void Scroll(int index, bool tween, Delegates.VoidCallback OnComplete)
	{
		m_index = index;
		float endValue = (float)index * m_Param;
		float duration = tween ? m_Duration : 0.01f;
		m_PefabRoot.transform.DOLocalMoveX(endValue, duration).OnComplete(OnComplete.Invoke);
		UpdateItemPositon(duration);
	}

	private void UpdateItemPositon(float duration)
	{
		UpdateItem();
		for (int i = 0; i < m_item.Count; i++)
		{
			if (i != m_index)
			{
				m_item[i].transform.DOLocalMoveZ(m_OffsetZ, duration);
			}
			else
			{
				m_item[i].transform.DOLocalMoveZ(0f, duration);
			}
		}
	}

	private void UpdateItem()
	{
		m_item.Clear();
		for (int i = 0; i < m_PefabRoot.transform.childCount; i++)
		{
			GameObject gameObject = m_PefabRoot.transform.GetChild(i).gameObject;
			if (gameObject.activeSelf)
			{
				m_item.Add(gameObject);
			}
		}
	}
}
