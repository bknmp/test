using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine.UI;

internal class CardLotteryConfirmPage
{
	public UIDataBinder m_Host;

	public Button m_ButtonBuy;

	public UIStateRawImage m_Quality;

	public Image m_Icon;

	public Text m_ItemName;

	public Text m_SaleText;

	public UIPage m_CardLotteryOpenUI;

	public UITemplateInitiator m_DiamondTemplateInitiator;

	public Text m_SelectedNum;

	public Image m_PriceTypeImg;

	public Text m_PriceTypeText;

	public bool m_IsMoneyEnough;

	public int m_ChoosedUnit;

	private List<int> m_BatchSelectUnitList = new List<int>
	{
		1,
		5,
		10
	};

	private BoxInfo m_BoxInfo;

	private float m_Discount;

	private DropItem m_SelectedItemInfo;

	private int m_GoodsID;

	public void Bind(CommonDataCollection args)
	{
		m_BoxInfo = (args["boxInfo"].val as BoxInfo);
		m_GoodsID = args["goodsID"];
		m_Discount = args["discount"];
		m_SaleText.transform.parent.gameObject.SetActive(m_Discount < 1f);
		m_SaleText.text = (int)(m_Discount * 10f) + Localization.Discount;
		SetOutsideInfo(m_GoodsID);
		CommonDataCollection diamondArgs = new CommonDataCollection();
		for (int i = 0; i < m_BatchSelectUnitList.Count; i++)
		{
			BindSelectedTemplates(m_BatchSelectUnitList[i], diamondArgs);
		}
		m_Host.EventProxy(m_ButtonBuy, "OnYes");
		if (m_ChoosedUnit == 0)
		{
			m_ChoosedUnit = m_BatchSelectUnitList[0];
		}
		m_IsMoneyEnough = ((!((float)ShopUtility.GetCurrencyAmount(m_BoxInfo.LotteryMoneyType) < (float)(m_BoxInfo.LotteryMoneyCost * m_ChoosedUnit) * m_Discount)) ? true : false);
		m_SelectedNum.text = "x" + m_ChoosedUnit.ToString();
	}

	private void SetOutsideInfo(int goodID)
	{
		DropItem dropItem = LocalResources.DropItemTable.Get(goodID);
		m_Quality.State = dropItem.Quality;
		m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		m_ItemName.text = dropItem.Name;
		DropItem dropItem2 = LocalResources.DropItemTable.Get(m_BoxInfo.LotteryMoneyType);
		m_PriceTypeImg.sprite = SpriteSource.Inst.Find(dropItem2.Icon.Replace("_drop", ""));
		m_PriceTypeText.text = dropItem2.Name;
	}

	private void BindSelectedTemplates(int unit, CommonDataCollection diamondArgs)
	{
		int arraySize = diamondArgs.ArraySize;
		diamondArgs[arraySize]["boxInfo"].val = m_BoxInfo;
		diamondArgs[arraySize]["unit"] = unit;
		diamondArgs[arraySize]["discount"] = m_Discount;
		diamondArgs[arraySize]["m_ParentUI"].val = this;
		m_DiamondTemplateInitiator.Args = diamondArgs;
	}

	public void OnYes()
	{
		if (!m_IsMoneyEnough)
		{
			if (m_BoxInfo.LotteryMoneyType == 2)
			{
				UILobby.Current.ShowMessageBoxYesNo(Localization.NotEnoughDiamonds, Localization.Yes, Localization.NextTime, "", LobbyScene_Money.Recharge, null);
				return;
			}
			string msg = string.Format(Localization.NotEnoughAndBuy, Localization.Ticket);
			UILobby.Current.ShowMessageBoxYesNo(msg, Localization.Yes, Localization.NextTime, "", LobbyScene_Money.BuyTicket, null);
		}
		else
		{
			BoxUtility.RequestOpenBoxByID(m_BoxInfo.Id, delegate(ItemInfo[] items)
			{
				GoBack();
				CardLotteryItem cardLotteryItem = LobbyScene.Inst.GetCardLotteryItem((CardLotteryType)m_BoxInfo.Type);
				CardLotteryUI.Inst.OnOpenBox(m_BoxInfo.Id, m_CardLotteryOpenUI, cardLotteryItem, items);
				LocalPlayerDatabase.RefreshCardLotteryInfo();
			}, null, 0, m_ChoosedUnit);
		}
	}

	private void GoBack()
	{
		m_Host.GetComponent<UILobbyElement>().GoBack();
	}
}
