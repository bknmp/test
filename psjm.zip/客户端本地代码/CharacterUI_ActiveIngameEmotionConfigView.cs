using LightUI;
using UnityEngine.UI;

internal class CharacterUI_ActiveIngameEmotionConfigView
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_ActiveIngameEmotionConfigView;

	public Button m_ReplacingDimmer;

	public IngameEmotionConfigEdit m_ConfigEdit;

	private CommonDataCollection m_activeConfigArgs = new CommonDataCollection();

	public static bool Replacing;

	public void Bind(CommonDataCollection args)
	{
		m_activeConfigArgs.Clear();
		for (int i = 0; i < m_ConfigEdit.m_config.config.Length; i++)
		{
			m_activeConfigArgs[i]["id"] = m_ConfigEdit.m_config.config[i];
			m_activeConfigArgs[i]["configEdit"].val = m_ConfigEdit;
			m_activeConfigArgs[i]["index"] = i;
		}
		m_ActiveIngameEmotionConfigView.Args = m_activeConfigArgs;
		m_ReplacingDimmer.gameObject.SetActive(Replacing);
		m_Host.EventProxy(m_ReplacingDimmer, "OnCancelReplace");
	}

	public void OnCancelReplace()
	{
		Replacing = false;
		m_Host.UpdateBinding();
	}
}
