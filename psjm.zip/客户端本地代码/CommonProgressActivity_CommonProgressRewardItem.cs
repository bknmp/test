using GameMessages;
using LightUI;
using LightUtility;
using System;
using UnityEngine;
using UnityEngine.UI;

internal class CommonProgressActivity_CommonProgressRewardItem
{
	public UIDataBinder m_Host;

	public Text m_Target;

	public MultiTargetGraphicButton m_ClaimBtn;

	public GameObject m_HadClaim;

	public UIStateImage m_State;

	public CommonRewardPopupUI m_CommonRewardPopupUI;

	public UITemplateInitiator m_TemplateInitiatorHorizontal;

	public MultiTargetGraphicButton m_CantClaimBtn;

	public Slider m_ProgressBar;

	public CommonProgressActivityItemConfig m_Config;

	protected CommonProgressActivityInfo m_info;

	private CommonDataCollection m_rewardArg = new CommonDataCollection();

	protected int m_index;

	protected int m_type;

	protected CommonProgressActivity m_CommonProgressActivity;

	protected string m_targetFormat;

	protected int m_Point;

	private Action<int> m_OnClaim;

	public void Bind(CommonDataCollection args)
	{
		m_index = args["index"];
		m_type = args["type"];
		m_Point = (int)args["point"].val;
		m_info = (args["info"].val as CommonProgressActivityInfo);
		m_CommonProgressActivity = (args["CommonProgressActivity"].val as CommonProgressActivity);
		m_OnClaim = (args["OnClaimCallBack"].val as Action<int>);
		bool flag = args["isLast"];
		m_TemplateInitiatorHorizontal.GetComponent<RectTransform>().localScale = ((!flag) ? new Vector3(1f, 1f, 1f) : ((m_Config != null) ? m_Config.m_ListItemSize : new Vector3(1.2f, 1.2f, 1.2f)));
		if (m_Target != null)
		{
			if (string.IsNullOrEmpty(m_targetFormat))
			{
				m_targetFormat = m_Target.text;
			}
			m_Target.text = string.Format(m_targetFormat, m_info.target);
		}
		if (m_State != null)
		{
			m_State.State = ((m_Point >= m_info.target) ? (m_info.received ? 1 : 2) : 0);
		}
		m_HadClaim.gameObject.SetActive(m_info.received);
		m_ClaimBtn.gameObject.SetActive(m_Point >= m_info.target && !m_info.received);
		if (m_CantClaimBtn != null)
		{
			m_CantClaimBtn.gameObject.SetActive(!m_HadClaim.gameObject.activeSelf && !m_ClaimBtn.gameObject.activeSelf);
			m_Host.EventProxy(m_CantClaimBtn, "OnClickCantClaim");
		}
		m_rewardArg.Clear();
		for (int i = 0; i < m_info.rewards.Length; i++)
		{
			m_rewardArg[i]["dropItemInfo"].val = m_info.rewards[i];
			m_rewardArg[i]["SetClaimBtn"] = m_ClaimBtn.isActiveAndEnabled;
			m_rewardArg[i]["OnClickClaim"].val = new Action(OnClickClaim);
		}
		m_TemplateInitiatorHorizontal.Args = m_rewardArg;
		m_Host.EventProxy(m_ClaimBtn, "OnClickClaim");
		if (m_ProgressBar != null)
		{
			int num = (int)args["lastTarget"].val;
			m_ProgressBar.value = Mathf.Clamp01(((float)m_Point - (float)num) / ((float)m_info.target - (float)num));
			if (m_index == 0 && m_Config != null && !m_Config.m_ShowFirstProgress)
			{
				m_ProgressBar.gameObject.SetActive(value: false);
			}
		}
	}

	public void OnClickClaim()
	{
		if (m_Point < m_info.target)
		{
			UILobby.Current.ShowTips(Localization.CantClaim);
			return;
		}
		if (m_info.received)
		{
			UILobby.Current.ShowTips(Localization.hadClaim);
			return;
		}
		HttpRequestCommonProgressActivityReceive httpRequestCommonProgressActivityReceive = new HttpRequestCommonProgressActivityReceive();
		httpRequestCommonProgressActivityReceive.index = m_index;
		httpRequestCommonProgressActivityReceive.type = m_type;
		GameHttpManager.Inst.Send(httpRequestCommonProgressActivityReceive, delegate(HttpResponseCommonProgressActivityReceive onResponse)
		{
			CommonRewardPopupUI commonRewardPopupUI = CommonRewardPopupUI.Show(m_CommonRewardPopupUI);
			commonRewardPopupUI.SetTitleAndTips("", "");
			commonRewardPopupUI.AddItems(onResponse.reward);
			if (m_CommonProgressActivity != null)
			{
				m_CommonProgressActivity.DoUpdate();
			}
			else
			{
				m_info.received = true;
				CommonDataCollection args = new CommonDataCollection
				{
					["index"] = m_index,
					["type"] = m_type,
					["point"] = m_Point,
					["info"] = 
					{
						val = m_info
					}
				};
				m_Host.Args = args;
			}
			if (m_OnClaim != null)
			{
				m_OnClaim(m_index);
			}
			LocalPlayerDatabase.ReportClickEvent(ClickEventParam.ACTIVITY_SCORETASK_CLAIM_CLICK, m_type.ToString(), m_index.ToString());
		});
	}

	public void OnClickCantClaim()
	{
		UILobby.Current.ShowTips(Localization.CantClaim);
	}
}
