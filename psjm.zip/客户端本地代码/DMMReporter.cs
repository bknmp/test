using LightUtility;
using PerformanceSDK;
using PerformanceSDK.Core;
using System.Collections.Generic;
using UnityEngine;

public class DMMReporter : MonoBehaviour, IDataReporter
{
	private static DMMReporter instance;

	private HttpRequestPerformanceReport reportRequest;

	[DataReporterCreatorAttrubute("DefaultReporter")]
	public static IDataReporter Create()
	{
		if (instance == null)
		{
			GameObject gameObject = new GameObject("PerformSDK.DefaultReporter");
			instance = gameObject.AddComponent<DMMReporter>();
			ResManager.DontDestroyOnLoad(gameObject);
		}
		return instance;
	}

	public void Report(object data, object extraUserData = null)
	{
		if (data != null)
		{
			HttpRequestPerformanceReport httpRequestPerformanceReport = Utility.Dict2ObjectConvert<HttpRequestPerformanceReport>(data as Dictionary<string, object>);
			httpRequestPerformanceReport.timeStamp = UtcTimeStamp.Now;
			HttpRequestPerformanceReport.InGameInfo inGameInfo = extraUserData as HttpRequestPerformanceReport.InGameInfo;
			if (inGameInfo != null)
			{
				httpRequestPerformanceReport.gameInfo = inGameInfo;
			}
			reportRequest = httpRequestPerformanceReport;
			reportRequest.userInfo.roleType = (int)GameRuntime.PlayingRole;
			CancelInvoke();
			Invoke("_Report", 1f);
		}
	}

	private void _Report()
	{
		if (reportRequest != null)
		{
			if (reportRequest.deviceruntimeInfoSampleSampleData != null)
			{
				reportRequest.deviceruntimeInfoSampleSampleData.endGameTemperature = PerformanceInfoUtils.GetTemperature();
			}
			GameHttpManager.Inst.SendNoWait(reportRequest);
			reportRequest = null;
		}
	}
}
