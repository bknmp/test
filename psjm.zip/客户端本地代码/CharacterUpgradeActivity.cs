using GameMessages;
using LightUI;
using System;
using UnityEngine;
using UnityEngine.UI;

internal class CharacterUpgradeActivity
{
	public UIDataBinder m_Host;

	public UIDataScrollView m_DataScrollView;

	public Button m_GetCharacter;

	public Text m_Time;

	public Button m_UpgradeCharacter;

	public UIPopup m_CharacterUpgradeTipsUI;

	private string m_TimeFormat;

	private CommonDataCollection m_rewardArgs = new CommonDataCollection();

	private Activity m_Activity;

	private static string CharacterUpgradeClaimed = "CharacterUpgradeClaimed";

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_TimeFormat))
		{
			m_TimeFormat = m_Time.text;
		}
		m_Host.EventProxy(m_GetCharacter, "OnClickGetCharacter");
		m_Host.EventProxy(m_UpgradeCharacter, "OnClickUpgradeCharacter");
		m_Activity = (args["Activity"].val as Activity);
		if (m_Activity != null)
		{
			m_Time.text = string.Format(m_TimeFormat, UITimeText.GetDateTime(m_Activity.startTime), UITimeText.GetDateTime(m_Activity.endTime));
		}
		RefreshInfo();
	}

	private void RefreshInfo()
	{
		CharacterUpgradeRewardInfo info = new CharacterUpgradeRewardInfo();
		HttpRequestCharacterUpgradeActivity requset = new HttpRequestCharacterUpgradeActivity();
		GameHttpManager.Inst.Send(requset, delegate(HttpResponseCharacterUpgradeActivity OnHttpResponse)
		{
			info = OnHttpResponse.infos[0];
			if (info != null)
			{
				SetInfo(info);
			}
		}, null, null, LocalPlayerDatabase.DummyWait);
	}

	private void SetInfo(CharacterUpgradeRewardInfo info)
	{
		m_rewardArgs.Clear();
		for (int i = 0; i < LocalResources.CharacterUpgradeTable.Count; i++)
		{
			m_rewardArgs[i]["Id"] = LocalResources.CharacterUpgradeTable[i].Id;
			m_rewardArgs[i]["CharacterID"] = LocalResources.CharacterUpgradeTable[i].CharacterID;
			m_rewardArgs[i]["Desc"] = LocalResources.CharacterUpgradeTable[i].Desc;
			m_rewardArgs[i]["itemIds"].val = LocalResources.CharacterUpgradeTable[i].ItemID;
			m_rewardArgs[i]["itemCounts"].val = LocalResources.CharacterUpgradeTable[i].ItemCount;
			m_rewardArgs[i]["claimed"] = info.claimed[LocalResources.CharacterUpgradeTable[i].Id - 1];
			m_rewardArgs[i]["CharacterUpgradeActivity"].val = this;
		}
		m_DataScrollView.m_TemplateInitiator.Args = m_rewardArgs;
		bool flag = CharacterUtility.IsOwnForeverCharacter(info.characterId);
		m_GetCharacter.gameObject.SetActive(!flag);
		m_UpgradeCharacter.gameObject.SetActive(flag);
		SetLocalClaimInfo(info);
	}

	public void OnClickGetCharacter()
	{
		if (ActivityLobby.IsActicityAvailable(ActivityType.CHARACTER_PREVIEW, ActivityCollectionType.CHARACTER_ACTIVITY))
		{
			m_Host.GetComponentInParent<CharacterActivityUI>().JumpTabByActivityType(ActivityType.CHARACTER_PREVIEW);
		}
	}

	public void OnClickUpgradeCharacter()
	{
		UILobby.Current.Popup(m_CharacterUpgradeTipsUI);
	}

	private void SetLocalClaimInfo(CharacterUpgradeRewardInfo info)
	{
		string value = JsonUtility.ToJson(info);
		LocalPlayerDatabase.SetPrefValue(CharacterUpgradeClaimed + m_Activity.startTime, value);
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	public static bool GetRedPointState(int activityId)
	{
		Activity activityById = ActivityLobby.GetActivityById(activityId);
		if (activityById == null)
		{
			return false;
		}
		string prefValueString = LocalPlayerDatabase.GetPrefValueString(CharacterUpgradeClaimed + activityById.startTime);
		if (string.IsNullOrEmpty(prefValueString))
		{
			return true;
		}
		try
		{
			CharacterUpgradeRewardInfo characterUpgradeRewardInfo = JsonUtility.FromJson<CharacterUpgradeRewardInfo>(prefValueString);
			int num = CharacterUtility.IsOwnForeverCharacter(characterUpgradeRewardInfo.characterId) ? CharacterUtility.GetOwnedCharacterInfo(characterUpgradeRewardInfo.characterId).ExpLevel : 0;
			for (int i = 0; i < num; i++)
			{
				for (int j = 0; j < LocalResources.CharacterUpgradeTable.Count; j++)
				{
					int num2 = LocalResources.CharacterUpgradeTable[j].Id - 1;
					if (i < num2)
					{
						break;
					}
					if (i == num2 && !characterUpgradeRewardInfo.claimed[i] && num >= i + 1)
					{
						return true;
					}
				}
			}
		}
		catch (Exception value)
		{
			Console.WriteLine(value);
		}
		return false;
	}
}
