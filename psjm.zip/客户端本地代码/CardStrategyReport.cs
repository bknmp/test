using GameMessages;
using UnityEngine;

public class CardStrategyReport : MonoBehaviour
{
	private float m_EnterTime;

	private void OnEnable()
	{
		m_EnterTime = Time.time;
	}

	private void OnDisable()
	{
		if (m_EnterTime > 0f)
		{
			int num = Mathf.Max(0, (int)(Time.time - m_EnterTime));
			if (num > 0)
			{
				LocalPlayerDatabase.ReportClickEvent(ClickEventParam.CARDACTIVITY_STAY_STRATEGY_PAGE, num.ToString());
			}
			m_EnterTime = 0f;
		}
	}
}
