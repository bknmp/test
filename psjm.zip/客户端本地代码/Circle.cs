using System;
using UnityEngine;
using UnityEngine.UI;

public class Circle : Image
{
	[Tooltip("圆形或扇形填充比例")]
	[Range(0f, 1f)]
	public float fillPercent = 1f;

	[Tooltip("是否填充圆形")]
	public bool fill = true;

	[Tooltip("圆环宽度")]
	public float thickness = 5f;

	[Tooltip("圆形")]
	[Range(3f, 100f)]
	public int segements = 20;

	protected override void OnPopulateMesh(VertexHelper vh)
	{
		vh.Clear();
		float num = (float)Math.PI * 2f / (float)segements;
		int num2 = (int)((float)segements * fillPercent);
		float width = base.rectTransform.rect.width;
		float height = base.rectTransform.rect.height;
		float num3 = base.rectTransform.pivot.x * width;
		float num4 = base.rectTransform.pivot.x * width - thickness;
		float num5 = 0f;
		UIVertex v;
		int num6;
		int num9;
		if (fill)
		{
			Vector2 zero = Vector2.zero;
			num6 = num2 + 1;
			v = default(UIVertex);
			v.color = color;
			v.position = zero;
			vh.AddVert(v);
			for (int i = 1; i < num6; i++)
			{
				float num7 = Mathf.Cos(num5);
				float num8 = Mathf.Sin(num5);
				zero = new Vector2(num7 * num3, num8 * num3);
				num5 += num;
				v = default(UIVertex);
				v.color = color;
				v.position = zero;
				vh.AddVert(v);
			}
			num9 = num2 * 3;
			int num10 = 0;
			int num11 = 1;
			while (num10 < num9 - 3)
			{
				vh.AddTriangle(num11, 0, num11 + 1);
				num10 += 3;
				num11++;
			}
			if (fillPercent == 1f)
			{
				vh.AddTriangle(num6 - 1, 0, 1);
			}
			return;
		}
		num6 = num2 * 2;
		for (int j = 0; j < num6; j += 2)
		{
			float num12 = Mathf.Cos(num5);
			float num13 = Mathf.Sin(num5);
			num5 += num;
			Vector2 zero = new Vector3(num12 * num4, num13 * num4);
			v = default(UIVertex);
			v.color = color;
			v.position = zero;
			vh.AddVert(v);
			zero = new Vector3(num12 * num3, num13 * num3);
			v = default(UIVertex);
			v.color = color;
			v.position = zero;
			vh.AddVert(v);
		}
		num9 = num2 * 3 * 2;
		int num14 = 0;
		int num15 = 0;
		while (num14 < num9 - 6)
		{
			vh.AddTriangle(num15 + 1, num15, num15 + 3);
			vh.AddTriangle(num15, num15 + 2, num15 + 3);
			num14 += 6;
			num15 += 2;
		}
		if (fillPercent == 1f)
		{
			vh.AddTriangle(num6 - 1, num6 - 2, 1);
			vh.AddTriangle(num6 - 2, 0, 1);
		}
	}
}
