using DG.Tweening;
using LightUtility;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class CollectCoinEffect : MonoBehaviour
{
	public Material m_CoinMaterial;

	public float m_CoinSize = 1f;

	public float m_StartInterval = 0.2f;

	public float m_Phase1Scale = 1.2f;

	public float m_Phase1OffsetMin = 1f;

	public float m_Phase1OffsetMax = 2f;

	public float m_Phase1Angle = 60f;

	public float m_Phase1Duration = 0.5f;

	public float m_Phase2Duration = 0.5f;

	public float m_Phase2Curveness = 1f;

	public float m_Phase2MaxSpeed = 15f;

	private UnityAction m_OnComplete;

	private void OnDisable()
	{
		InvokeOnComplete();
	}

	private void InvokeOnComplete()
	{
		if (m_OnComplete != null)
		{
			m_OnComplete();
			m_OnComplete = null;
		}
	}

	public void Show(int count, Vector3 start, Vector3 end, UnityAction onComplete)
	{
		m_OnComplete = onComplete;
		base.transform.position = start;
		StartCoroutine(SpawnCoins(count, start, end));
	}

	private IEnumerator SpawnCoins(int count, Vector3 start, Vector3 end)
	{
		int num;
		for (int i = 0; i < count; i = num)
		{
			CoinDrawingManager.CoinInst inst = CoinDrawingManager.Inst.AcquireCoinInst(m_CoinMaterial);
			inst.position = start;
			inst.size = m_CoinSize;
			Vector3 a = Quaternion.AngleAxis(UnityEngine.Random.Range(-0.5f * m_Phase1Angle, 0.5f * m_Phase1Angle), Vector3.forward) * Vector3.up;
			bool isLast = i == count - 1;
			Vector3 phase1Pos = start + a * UnityEngine.Random.Range(m_Phase1OffsetMin, m_Phase1OffsetMax);
			inst.DOScale(m_Phase1Scale, m_Phase1Duration);
			inst.DOMove(phase1Pos, m_Phase1Duration).OnComplete(delegate
			{
				Vector3 v = end - phase1Pos;
				Vector2 v2 = MathUtility.Right(v).normalized * UnityEngine.Random.Range(0f - m_Phase2Curveness, m_Phase2Curveness);
				float num2 = Mathf.Max(m_Phase2Duration, v.magnitude / m_Phase2MaxSpeed);
				inst.DOScale(1f, num2);
				inst.DOBlendableMoveBy(v2, num2 * 0.5f).SetLoops(2, LoopType.Yoyo);
				inst.DOBlendableMoveBy(end - phase1Pos, num2).SetEase(Ease.InSine).OnComplete(delegate
				{
					if (this != null)
					{
						CoinDrawingManager.Inst.ReleaseCoinInst(inst);
						if (isLast)
						{
							InvokeOnComplete();
							PoolSpawner.DeSpawn(base.gameObject);
						}
					}
				});
			});
			yield return Yielders.GetWaitForSeconds(m_StartInterval);
			num = i + 1;
		}
	}
}
