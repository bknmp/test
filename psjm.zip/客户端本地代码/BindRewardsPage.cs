using LightUI;

internal class BindRewardsPage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_RewardsInitiator;

	public void Bind(CommonDataCollection args)
	{
		CommonDataCollection wrapBindRewardArgs = AntiAddictionUtility.WrapBindRewardArgs;
		m_RewardsInitiator.gameObject.SetActive(wrapBindRewardArgs.ArraySize > 0);
		m_RewardsInitiator.Args = wrapBindRewardArgs;
	}
}
