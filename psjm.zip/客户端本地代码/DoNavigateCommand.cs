using BehaviorDesigner.Runtime.Tasks;

public class DoNavigateCommand : Action
{
	private AIController ai;

	public override void OnStart()
	{
		ai = GetComponent<AIController>();
		if (!ReachNavigatePosition())
		{
			ai.RecalculatePath(ai.m_NavigationPosition);
		}
	}

	public override TaskStatus OnUpdate()
	{
		if (!ai.InMode(AIMode.Navigate))
		{
			return TaskStatus.Failure;
		}
		if (!ai.IsMoving)
		{
			if (!ReachNavigatePosition())
			{
				ai.RecalculatePath(ai.m_NavigationPosition);
			}
			else
			{
				ai.NotifyNavigationIfNeed(complete: true);
			}
		}
		ai.MoveToTarget();
		return TaskStatus.Running;
	}

	private bool ReachNavigatePosition()
	{
		return (transform.localPosition - ai.m_NavigationPosition).sqrMagnitude <= ai.m_NavigateNearReach;
	}
}
