using DG.Tweening;
using LightUI;
using System.Collections.Generic;
using UnityEngine;

public class CicleLevelBar : MonoBehaviour
{
	public UIStateImage m_ItemTemplate;

	public Transform m_Container;

	private List<UIStateImage> m_Items = new List<UIStateImage>();

	private void Awake()
	{
		m_ItemTemplate.gameObject.SetActive(value: false);
	}

	public void SetLevel(int level, int maxLevel, bool highLightNextLevel = true)
	{
		while (m_Items.Count > maxLevel)
		{
			UnityEngine.Object.Destroy(m_Items[0].gameObject);
			m_Items.RemoveAt(0);
		}
		while (m_Items.Count < maxLevel)
		{
			m_Items.Add(UnityEngine.Object.Instantiate(m_ItemTemplate, m_Container));
		}
		float num = -360f / (float)maxLevel;
		for (int i = 0; i < maxLevel; i++)
		{
			CanvasGroup component = m_Items[i].GetComponent<CanvasGroup>();
			component.DOKill();
			component.alpha = 1f;
			if (i < level)
			{
				m_Items[i].State = 1;
			}
			else if (i == level && highLightNextLevel)
			{
				m_Items[i].State = 2;
				component.alpha = 0.5f;
				component.DOFade(1f, 0.5f).SetLoops(-1, LoopType.Yoyo);
			}
			else
			{
				m_Items[i].State = 0;
			}
			m_Items[i].gameObject.SetActive(value: true);
			m_Items[i].transform.localRotation = Quaternion.Euler(0f, 0f, (float)i * num);
		}
	}
}
