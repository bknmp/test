using GameMessages;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class CharacterPreLoader : MonoBehaviour, IPunPrefabPool
{
	private Dictionary<string, GameObject> m_CharacterInst = new Dictionary<string, GameObject>();

	private Dictionary<Animator, Transform> m_PrewarmInst = new Dictionary<Animator, Transform>();

	public static CharacterPreLoader Inst;

	private void Awake()
	{
		Inst = this;
		PhotonNetwork.PrefabPool = this;
		foreach (KeyValuePair<string, RuntimePlayerInfo> roomPlayer in GameRuntime.RoomPlayers)
		{
			PreLoadNewCharacter(roomPlayer.Key);
		}
	}

	private void OnDestroy()
	{
		if (Inst == this)
		{
			Inst = null;
		}
		foreach (KeyValuePair<string, GameObject> item in m_CharacterInst)
		{
			if (item.Value != null)
			{
				Destroy(item.Value);
			}
		}
		m_CharacterInst.Clear();
		if ((Object)PhotonNetwork.PrefabPool == this)
		{
			PhotonNetwork.PrefabPool = null;
		}
		TextureColorationCache.Clear();
	}

	public void FinishPreLoad()
	{
		foreach (KeyValuePair<Animator, Transform> item in m_PrewarmInst)
		{
			item.Key.transform.SetParent(item.Value, worldPositionStays: false);
		}
		m_PrewarmInst.Clear();
	}

	public GameObject Instantiate(string prefabId, Vector3 position, Quaternion rotation)
	{
		if (m_CharacterInst.ContainsKey(prefabId))
		{
			GameObject gameObject = m_CharacterInst[prefabId];
			gameObject.transform.position = position;
			gameObject.transform.rotation = rotation;
			return gameObject;
		}
		GameObject gameObject2 = PrefabSource.Inst.Load(prefabId);
		gameObject2.SetActive(value: false);
		GameObject result = UnityEngine.Object.Instantiate(gameObject2, position, rotation, base.transform);
		gameObject2.SetActive(value: true);
		return result;
	}

	public GameObject Load(string prefabId)
	{
		if (m_CharacterInst.ContainsKey(prefabId))
		{
			return m_CharacterInst[prefabId];
		}
		return PrefabSource.Inst.Load(prefabId);
	}

	public void Destroy(GameObject gameObject)
	{
		if (gameObject != null)
		{
			PlayerController component = gameObject.GetComponent<PlayerController>();
			if (component == null || component.IsPuppet)
			{
				UnityEngine.Object.Destroy(gameObject);
			}
		}
	}

	private GameObject InstantiateCharacter(string userID)
	{
		PlayerCharacterInfo characterInfo = GameRuntime.RoomPlayers[userID].CharacterInfo;
		string inGamePrefab = LocalResources.CharacterTable.Get(characterInfo.characterID).InGamePrefab;
		GameObject gameObject = InstantiatePrefab(userID, inGamePrefab);
		SkinPartController componentInChildren = gameObject.GetComponentInChildren<SkinPartController>(includeInactive: true);
		if (componentInChildren != null)
		{
			componentInChildren.UpdateParts(characterInfo.currentSkinInfo, isInGame: true);
		}
		BasePlayerController component = gameObject.GetComponent<BasePlayerController>();
		if (component != null)
		{
			component.CharacterID = characterInfo.characterID;
		}
		LightnessController component2 = gameObject.GetComponent<LightnessController>();
		if (component2 != null)
		{
			component2.ShowLight(GameRuntime.RoomPlayers[userID].MatchData.lightnessConfig, 0.05f);
		}
		return gameObject;
	}

	private GameObject InstantiatePrefab(string playerName, string prefabName)
	{
		GameObject gameObject = PrefabSource.Inst.Load(prefabName);
		if (gameObject != null)
		{
			gameObject.SetActive(value: false);
			GameObject gameObject2 = UnityEngine.Object.Instantiate(gameObject, base.transform);
			gameObject2.AddComponent<LiteComponentOwner>();
			gameObject.SetActive(value: true);
			gameObject2.name = playerName;
			return gameObject2;
		}
		return null;
	}

	public void PreLoadNewCharacter(string userId)
	{
		if (!GameRuntime.RoomPlayers[userId].IsJudge)
		{
			GameObject gameObject = InstantiateCharacter(userId);
			Animator animator = gameObject.GetComponent<PlayerController>().m_Animator;
			m_PrewarmInst[animator] = animator.transform.parent;
			animator.transform.SetParent(base.transform, worldPositionStays: false);
			m_CharacterInst[userId] = gameObject;
		}
	}
}
