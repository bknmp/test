using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class ChangeCharacterUI_ItemTemplate
{
	public UIDataBinder m_Host;

	public Text m_Name;

	public MultiTargetGraphicButton m_SetActiveBtn;

	public UIPopup m_ChangeCharacterUI;

	public GameObject m_NotOwn;

	public GameObject m_CurSelected;

	public Image m_Icon;

	public GameObject m_SetActiveEffect;

	public Text m_Level;

	public UIStateItem m_State;

	public UIStateRawImage m_BG;

	public GameObject m_IsFree;

	private int m_Id;

	private bool m_IsActive;

	private bool m_Own;

	private CharacterInfo m_CharacterInfo;

	private string m_LevelFormat;

	public void Bind(CommonDataCollection args)
	{
		if (string.IsNullOrEmpty(m_LevelFormat))
		{
			m_LevelFormat = m_Level.text;
		}
		m_Id = args["Id"];
		if (m_Id == 0)
		{
			m_State.State = 1;
			if (m_BG != null)
			{
				m_BG.State = 0;
			}
		}
		else
		{
			m_State.State = 0;
			m_Name.text = args["Name"];
			m_Icon.sprite = SpriteSource.Inst.Find(args["Icon"]);
			m_Own = args["Own"];
			m_CharacterInfo = LocalResources.CharacterTable.Get(m_Id);
			int num = CharacterUtility.GetActiveCharacter(GameRuntime.PlayingRole).characterID;
			CharacterInfo characterInfo = LocalResources.CharacterTable.Get(num);
			if (m_CharacterInfo.Role == RoleType.Boss && characterInfo.Role == RoleType.Police)
			{
				num = m_Id;
			}
			if (m_CharacterInfo.Role == RoleType.Boss)
			{
				m_Level.gameObject.SetActive(value: false);
				if (m_BG != null)
				{
					m_BG.State = 1;
				}
			}
			else
			{
				if (m_BG != null)
				{
					m_BG.State = 0;
				}
				m_Level.gameObject.SetActive(value: true);
				m_Level.text = string.Format(m_LevelFormat, CharacterUtility.GetOwnedCharacterInfo(m_Id).ExpLevel);
				m_IsFree.SetActive(CharacterFreeUtility.IsCharacterFree && !m_Own && m_CharacterInfo.Role != RoleType.Boss);
			}
			m_IsActive = (m_Id == num);
			m_CurSelected.SetActive(m_IsActive);
			m_NotOwn.gameObject.SetActive(!m_Own && !CharacterFreeUtility.IsCharacterFree);
		}
		m_Host.EventProxy(m_SetActiveBtn, "SetActive");
	}

	public void SetActive()
	{
		if (m_Id == 0)
		{
			UILobby.Current.ShowTips(Localization.CharacterComingSoon);
			return;
		}
		if (m_IsActive && !GameRuntime.IsJudge)
		{
			m_ChangeCharacterUI.GoBack();
		}
		if (!m_Own && !CharacterFreeUtility.IsCharacterFree)
		{
			m_ChangeCharacterUI.GoBack();
			CharacterUI_SelectCharacterItemTemplate.globalSelected = m_Id;
			PreviewUtility.PreviewCharacter(m_Id, force: true);
			UIDataEvents.Inst.InvokeEvent("OnCharacterSelectedChange");
			JumpModuleManager.Inst.DoJump(JumpModule.CharacterDetailUI);
			return;
		}
		int id = (m_CharacterInfo.Role == RoleType.Boss) ? 100 : m_Id;
		CharacterInfo characterInfo = LocalResources.CharacterTable.Get(id);
		RoleType roleType = (GameRuntime.PlayingRole == RoleType.Thief) ? RoleType.Thief : RoleType.Police;
		if (TeamRoomUI.IsShowing && (GameRuntime.IsCustomRoom || GameRuntime.IsUnionBattle) && (characterInfo.Role != roleType || GameRuntime.IsJudge))
		{
			if (TeamRoomManager.Inst.IsRoleTypeFull(characterInfo.Role))
			{
				UILobby.Current.ShowTips(Localization.TipsCampFull);
			}
			else
			{
				TeamRoomManager.Inst.SendChangeCharacter((int)characterInfo.Role, changeRole: true, id, delegate(int status)
				{
					if (status == 0)
					{
						GameRuntime.IsJudge = false;
						TeamRoomUI.DisableSendChangeCharacter = true;
						DoChangeCharacter(id);
						UIDataEvents.Inst.InvokeEvent("OnPlayerRoleChanged");
					}
					else
					{
						UILobby.Current.ShowTips(Localization.TipsCampFull);
					}
				});
			}
		}
		else
		{
			DoChangeCharacter(id);
		}
	}

	private void DoChangeCharacter(int id)
	{
		bool flag = !CharacterUtility.IsActiveCharacter(id);
		CharacterUtility.SetActiveCharacter(id);
		PreviewUtility.RevertAllPreview();
		if (flag && UILobby.Current.CurrentPage() == null)
		{
			LobbyScene.Inst.CurrentCharacter.StartLobbyEntrance();
		}
		else if (!TeamRoomUI.IsShowing)
		{
			if (LobbyScene.Inst.CurrentPreviewCampRoot.gameObject.activeInHierarchy)
			{
				PoolSpawner.Spawn(m_SetActiveEffect, LobbyScene.Inst.CurrentPreviewCampRoot);
			}
			else
			{
				PoolSpawner.Spawn(m_SetActiveEffect, LobbyScene.Inst.CurrentCharacter.transform);
			}
		}
		else
		{
			LobbyScene.Inst.m_TeamPanel.Root.SetActive(value: true);
			if (flag)
			{
				AdUtility.ClearTryCharacter();
			}
		}
		m_ChangeCharacterUI.GoBack();
	}
}
