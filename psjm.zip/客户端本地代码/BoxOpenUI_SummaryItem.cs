using LightUI;
using LightUtility;
using UnityEngine;
using UnityEngine.UI;

internal class BoxOpenUI_SummaryItem
{
	public UIDataBinder m_Host;

	public Image m_Icon;

	public UIStateImage m_Frame;

	public Text m_Num;

	public CardPieceProcessBar m_CardProcessUI;

	public GameObject m_NewCard;

	public void Bind(CommonDataCollection args)
	{
		int num = args["itemID"];
		int num2 = args["itemCount"];
		m_Frame.State = LocalResources.DropItemTable.Find(num).Quality;
		m_Num.text = num2.FormatPureAmountX();
		m_Num.gameObject.SetActive(num2 > 1);
		m_CardProcessUI.DropCardPiece(num, num2, tween: false);
		m_NewCard.SetActive(value: false);
		DropItem dropItem = LocalResources.DropItemTable.Find(num);
		if (dropItem.Type == DropItemType.CardPiece)
		{
			int typeParam = dropItem.TypeParam;
			InGameStoreInfo inGameStoreInfo = LocalResources.InGameStoreTable.Get(typeParam);
			CardSkinInfo cardSkinInfo = LocalResources.CardSkinTable.Get(inGameStoreInfo.DefaultSkinID);
			m_Icon.sprite = SpriteSource.Inst.Find(cardSkinInfo.Icon);
			m_NewCard.SetActive(!CardUtility.IsOwned(typeParam));
		}
		else
		{
			m_Icon.sprite = SpriteSource.Inst.Find(dropItem.Icon);
		}
		switch (dropItem.Type)
		{
		case DropItemType.SkinPart:
			NewSkinPartTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.CardSkin:
		case DropItemType.CardStyle:
			NewCardSkinTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		case DropItemType.HeadBox:
		case DropItemType.BubbleBox:
			HeadBubbleBoxUtility.TryToSetNewHeadBubbleBoxData(dropItem.TypeParam);
			break;
		case DropItemType.IngameEmotion:
			NewIngameEmotionTips.Inst.TryToSetNew(dropItem.TypeParam);
			break;
		}
	}
}
