using GameMessages;
using LightUI;
using LightUtility;
using System.Collections.Generic;
using UnityEngine;

public class CharacterDiscountUtility
{
	public static Dictionary<int, HttpResponseCharacterDiscountPackageInfo> CacheInfo = new Dictionary<int, HttpResponseCharacterDiscountPackageInfo>();

	public static Dictionary<int, List<CharacterDiscountPackageInfo>> packageInfo = new Dictionary<int, List<CharacterDiscountPackageInfo>>();

	private static int lastRefreshTime;

	private static string Claimed = "CharacterDiscountPackageClaimed";

	private static string TimeOutClaimed = "TimeOutClaimed";

	public static List<int> DiscountActivitys()
	{
		List<Activity> activitysByType = ActivityLobby.GetActivitysByType(ActivityType.CHARACTER_DISCOUNT_PACKAGE);
		List<int> list = new List<int>();
		foreach (Activity item in activitysByType)
		{
			list.Add(item.activityId);
		}
		return list;
	}

	public static void TryRefreshActivityInfo(int activityID, Delegates.VoidCallback OnSuccess, Delegates.VoidCallback OnFail)
	{
		if (ActivityLobby.GetActivityById(activityID) != null)
		{
			if (UtcTimeStamp.IsOverDay(lastRefreshTime, UtcTimeStamp.Now))
			{
				CacheInfo.Clear();
				packageInfo.Clear();
			}
			lastRefreshTime = UtcTimeStamp.Now;
			if (!CacheInfo.ContainsKey(activityID))
			{
				HttpRequestCharacterDiscountPackageActivity httpRequestCharacterDiscountPackageActivity = new HttpRequestCharacterDiscountPackageActivity();
				httpRequestCharacterDiscountPackageActivity.activityId = activityID;
				GameHttpManager.Inst.Send(httpRequestCharacterDiscountPackageActivity, delegate(HttpResponseCharacterDiscountPackageInfo onResponse)
				{
					if (!CacheInfo.ContainsKey(activityID))
					{
						CacheInfo.Add(activityID, onResponse);
						if (!packageInfo.ContainsKey(activityID))
						{
							List<CharacterDiscountPackageInfo> list = new List<CharacterDiscountPackageInfo>();
							CharacterDiscountPackageInfo[] array = CacheInfo[activityID].packageInfo;
							foreach (CharacterDiscountPackageInfo characterDiscountPackageInfo in array)
							{
								ItemInfo[] items = characterDiscountPackageInfo.items;
								foreach (ItemInfo itemInfo in items)
								{
									if (characterDiscountPackageInfo.characterID == 0 && !string.IsNullOrEmpty(LocalResources.CharacterTable.Get(itemInfo.itemID).Name))
									{
										characterDiscountPackageInfo.characterID = itemInfo.itemID;
									}
									if (characterDiscountPackageInfo.suitItemID == 0 && LocalResources.DropItemTable.Get(itemInfo.itemID).Type == DropItemType.SkinSuite)
									{
										characterDiscountPackageInfo.suitItemID = itemInfo.itemID;
									}
									DropItemType type = LocalResources.DropItemTable.Get(itemInfo.itemID).Type;
									if (characterDiscountPackageInfo.itemID == 0)
									{
										characterDiscountPackageInfo.itemID = itemInfo.itemID;
										switch (type)
										{
										case DropItemType.Lightness:
											characterDiscountPackageInfo.type = 3;
											break;
										case DropItemType.CardSkin:
											characterDiscountPackageInfo.type = 4;
											break;
										}
									}
								}
								if (characterDiscountPackageInfo.characterID > 0 && characterDiscountPackageInfo.suitItemID > 0)
								{
									characterDiscountPackageInfo.type = 0;
								}
								else if (characterDiscountPackageInfo.characterID == 0 && characterDiscountPackageInfo.suitItemID > 0)
								{
									characterDiscountPackageInfo.type = 1;
								}
								else if (characterDiscountPackageInfo.characterID > 0 && characterDiscountPackageInfo.suitItemID == 0)
								{
									characterDiscountPackageInfo.type = 2;
								}
								list.Add(characterDiscountPackageInfo);
							}
							packageInfo.Add(activityID, list);
							if (OnSuccess != null)
							{
								OnSuccess();
							}
						}
					}
				}, null, delegate
				{
					if (OnFail != null)
					{
						OnFail();
					}
				});
			}
			else if (OnSuccess != null)
			{
				OnSuccess();
			}
		}
	}

	public static void TryRefreshAllActivityInfo(ActivityType type, Delegates.VoidCallback OnSuccess)
	{
		List<Activity> activitysByType = ActivityLobby.GetActivitysByType(type);
		int[] activityIDs = new int[activitysByType.Count];
		int count = 0;
		if (activityIDs.Length != 0)
		{
			TryRefreshActivityInfo(activityIDs[count], delegate
			{
				count++;
				if (count < activityIDs.Length)
				{
					TryRefreshActivityInfo(activityIDs[count], delegate
					{
						if (OnSuccess != null)
						{
							OnSuccess();
						}
					}, null);
				}
				else if (OnSuccess != null)
				{
					OnSuccess();
				}
			}, null);
		}
		else if (OnSuccess != null)
		{
			OnSuccess();
		}
	}

	public static List<CharacterDiscountPackageInfo> GetCollection(int activityID, int collectionID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			return packageInfo[activityID].FindAll((CharacterDiscountPackageInfo x) => x.activityID.Equals(activityID) && x.collectionID.Equals(collectionID));
		}
		UnityEngine.Debug.LogError("No PackageInfo,activityID: " + activityID);
		return null;
	}

	public static int GetAllCollectionCount(int activityID)
	{
		List<CharacterDiscountPackageInfo> list = packageInfo[activityID].FindAll((CharacterDiscountPackageInfo x) => x.activityID.Equals(activityID));
		int num = 1;
		foreach (CharacterDiscountPackageInfo item in list)
		{
			if (item.collectionID > num)
			{
				num = item.collectionID;
			}
		}
		return num;
	}

	public static string GetCharactDiscount(int activityID, int characterID)
	{
		CharacterDiscountPackageInfo characterDiscountPackageInfo = CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID == 0);
		if (characterDiscountPackageInfo != null)
		{
			return characterDiscountPackageInfo.discount.ToString();
		}
		return "";
	}

	public static string GetNextPackageCharacterName(int activityID, int collectionID)
	{
		if (CacheInfo[activityID].nextCharacterId.Length == 0)
		{
			return "";
		}
		if (collectionID.Equals(1))
		{
			ShopInfo shopInfo = LocalResources.ShopTable.Get(CacheInfo[activityID].nextCharacterId[0]);
			return LocalResources.DropItemTable.Get(shopInfo.Id).Name;
		}
		if (collectionID.Equals(2))
		{
			ShopInfo shopInfo2 = LocalResources.ShopTable.Get(CacheInfo[activityID].nextCharacterId[1]);
			return LocalResources.DropItemTable.Get(shopInfo2.Id).Name;
		}
		return "";
	}

	public static string GetCharacterOnlyPackageName(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.suitItemID == 0).mainName;
	}

	public static string GetCharacterAndSuitPackageName(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0).mainName;
	}

	public static int GetCharacterOnlyPackageOriginalPrice(int activityID, int characterID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID == 0).orgPrice;
	}

	public static int GetCharacterOnlyPackageCurrentPrice(int activityID, int characterID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID == 0).currentPrice;
	}

	public static int GetCharacterAndSuitOriginalPrice(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0).orgPrice;
	}

	public static int GetCharacterAndSuitCurrentPrice(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0).currentPrice;
	}

	public static int GetSuitOnlyPackageOriginalPrice(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.suitItemID > 0 && x.characterID == 0).orgPrice;
	}

	public static int GetSuitOnlyPackageCurrentPrice(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.suitItemID > 0 && x.characterID == 0).currentPrice;
	}

	public static int GetSuitOnlyPackageID(int activityID, int collectionID)
	{
		return CacheInfo[activityID].packageInfo.Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.suitItemID > 0 && x.characterID == 0).packageID;
	}

	public static int GetCollectionCharacterID(int activityID, int collectionID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			CharacterDiscountPackageInfo characterDiscountPackageInfo = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0);
			if (characterDiscountPackageInfo != null)
			{
				return characterDiscountPackageInfo.characterID;
			}
		}
		return 0;
	}

	public static string GetCollectionName(int activityID, int collectionID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			CharacterDiscountPackageInfo characterDiscountPackageInfo = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID));
			if (characterDiscountPackageInfo != null)
			{
				return characterDiscountPackageInfo.collectionName;
			}
		}
		return "";
	}

	public static bool IsCollectionCharacter(int activityID, int characterID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			return packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID.Equals(0) && x.discount != "0") != null;
		}
		return false;
	}

	public static bool IsCharacterOnly(int activityID, int packageID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			CharacterDiscountPackageInfo characterDiscountPackageInfo = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.packageID.Equals(packageID));
			if (characterDiscountPackageInfo.characterID > 0)
			{
				return characterDiscountPackageInfo.suitItemID == 0;
			}
			return false;
		}
		return false;
	}

	public static CommonDataCollection GetCollectionArgByCollectionID(int activityID, int collectionID)
	{
		CharacterDiscountPackageInfo characterDiscountPackageInfo = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0);
		return GetCollectionArgByCharacterID(activityID, characterDiscountPackageInfo.characterID);
	}

	public static void TryBuy(int activityID, int packageID, Delegates.VoidCallback UIGoback)
	{
		if (ActivityLobby.GetActivityById(activityID) == null)
		{
			UILobby.Current.ShowTips(Localization.ActivityUnabled);
			return;
		}
		CharacterDiscountPackageInfo package = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.packageID.Equals(packageID));
		if (package.priceID.Equals(99))
		{
			ItemInfo[] itemInfos;
			if (package.characterID > 0 && package.suitItemID > 0)
			{
				itemInfos = new ItemInfo[2]
				{
					new ItemInfo
					{
						itemID = package.characterID,
						itemCount = 1
					},
					new ItemInfo
					{
						itemID = package.suitItemID,
						itemCount = 1
					}
				};
			}
			else
			{
				itemInfos = new ItemInfo[1]
				{
					new ItemInfo
					{
						itemID = package.suitItemID,
						itemCount = 1
					}
				};
			}
			EnsureBuyPopUp.EnsureBuyItems(itemInfos, package.priceID, package.orgPrice, package.currentPrice, delegate
			{
				GoodsInfo goodsInfo = LocalResources.GoodsTable.Find(package.goodsID);
				PaymentUtility.DoPay(goodsInfo.Id, goodsInfo.ItemDesc, null, delegate(int res)
				{
					if (res > 0)
					{
						if (package.characterID > 0)
						{
							if (UIGoback != null)
							{
								UIGoback();
							}
							if (!IsOwnItem(package.characterID))
							{
								CharacterFeatureUI.Inst.TryShowNewCharacter(package.characterID);
							}
						}
						CommonRewardPopupUI.Show(PrefabSource.Inst.Load<CommonRewardPopupUI>("CommonRewardPopupUI")).AddItems(itemInfos);
					}
				}, SocialModuleType.RechargeGift, "", package.packageID);
			});
		}
		else if (package.characterID > 0 && package.suitItemID == 0)
		{
			TryBuyCharacter(activityID, package.characterID, UIGoback);
		}
		else
		{
			TryBuyItemCollection(activityID, package.collectionID, UIGoback);
		}
	}

	public static void TryBuyCharacter(int activityID, int characterID, Delegates.VoidCallback UIGoback)
	{
		CharacterDiscountPackageInfo package = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID == 0);
		EnsureBuyPopUp.EnsureBuyItems(new ItemInfo[1]
		{
			new ItemInfo
			{
				itemID = package.characterID,
				itemCount = 1
			}
		}, package.priceID, package.orgPrice, package.currentPrice, delegate
		{
			ShopUtility.CheckMoneyEnough((CurrencyType)package.priceID, package.currentPrice, delegate
			{
				HttpRequestBuyCharacterPackage requset = new HttpRequestBuyCharacterPackage
				{
					packageID = package.packageID
				};
				GameHttpManager.Inst.Send(requset, delegate
				{
					if (UIGoback != null)
					{
						UIGoback();
					}
					DropItem dropItem = LocalResources.DropItemTable.Get(package.characterID);
					CharacterFeatureUI.Inst.TryShowNewCharacter(dropItem.TypeParam);
				});
			}, package.characterID, currentUIGoBack: false);
		});
	}

	public static void TryBuyItemCollection(int activityID, int collectionID, Delegates.VoidCallback UIGoback)
	{
		CollectionOwnStateHandle(activityID, collectionID);
		List<CharacterDiscountPackageInfo> list = packageInfo[activityID].FindAll((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && !x.isOwn);
		if (list.Count == 0)
		{
			if (UIGoback != null)
			{
				UIGoback();
			}
		}
		else
		{
			CharacterDiscountPackageInfo package = null;
			SetItemInfo(list, ref package, out ItemInfo[] itemInfos);
			EnsureBuyPopUp.EnsureBuyItems(itemInfos, package.priceID, package.orgPrice, package.currentPrice, delegate
			{
				ShopUtility.CheckMoneyEnough((CurrencyType)package.priceID, package.currentPrice, delegate
				{
					HttpRequestBuyCharacterPackage requset = new HttpRequestBuyCharacterPackage
					{
						packageID = package.packageID
					};
					GameHttpManager.Inst.Send(requset, delegate
					{
						if (UIGoback != null)
						{
							UIGoback();
						}
						if (package.type.Equals(0))
						{
							DropItem dropItem = LocalResources.DropItemTable.Get(package.characterID);
							CharacterFeatureUI.Inst.TryShowNewCharacter(dropItem.TypeParam);
						}
						CommonRewardPopupUI.Show(PrefabSource.Inst.Load<CommonRewardPopupUI>("CommonRewardPopupUI")).AddItems(itemInfos);
					});
				});
			});
		}
	}

	private static void SetItemInfo(List<CharacterDiscountPackageInfo> packages, ref CharacterDiscountPackageInfo package, out ItemInfo[] itemInfos)
	{
		if (packages.Find((CharacterDiscountPackageInfo x) => x.type == 0) != null || packages.Find((CharacterDiscountPackageInfo x) => x.type == 1) != null || packages.Find((CharacterDiscountPackageInfo x) => x.type == 2) != null)
		{
			if (packages.Count > 1)
			{
				package = packages.Find((CharacterDiscountPackageInfo x) => x.type == 0);
				if (package != null && !IsOwnItem(package.characterID))
				{
					itemInfos = new ItemInfo[2]
					{
						new ItemInfo
						{
							itemID = package.characterID,
							itemCount = 1
						},
						new ItemInfo
						{
							itemID = package.suitItemID,
							itemCount = 1
						}
					};
					return;
				}
				package = packages.Find((CharacterDiscountPackageInfo x) => x.type == 1);
				itemInfos = new ItemInfo[1]
				{
					new ItemInfo
					{
						itemID = package.suitItemID,
						itemCount = 1
					}
				};
			}
			else
			{
				package = packages.Find((CharacterDiscountPackageInfo x) => x.type == 1);
				itemInfos = new ItemInfo[1]
				{
					new ItemInfo
					{
						itemID = package.suitItemID,
						itemCount = 1
					}
				};
			}
		}
		else
		{
			package = packages.Find((CharacterDiscountPackageInfo x) => (x.type != 3) ? (x.type == 4) : true);
			itemInfos = new ItemInfo[1]
			{
				new ItemInfo
				{
					itemID = package.itemID,
					itemCount = 1
				}
			};
		}
	}

	public static void CollectionOwnStateHandle(int activityID, int collectionID)
	{
		foreach (CharacterDiscountPackageInfo item in packageInfo[activityID])
		{
			if (item.collectionID == collectionID)
			{
				switch (item.type)
				{
				case 0:
					item.isOwn = (IsOwnItem(item.characterID) && IsOwnSuit(item.suitItemID));
					break;
				case 1:
					item.isOwn = IsOwnSuit(item.suitItemID);
					break;
				case 2:
					item.isOwn = IsOwnItem(item.characterID);
					break;
				case 3:
				case 4:
					item.isOwn = IsOwnItem(item.itemID);
					break;
				}
			}
		}
	}

	private static bool IsOwnSuit(int suitId)
	{
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(suitId);
		return DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(shopSuiteInfo.Id));
	}

	public static bool IsOwnItem(int itemId)
	{
		return DropItemUtility.IsOwnPermanent(LocalResources.DropItemTable.Get(itemId));
	}

	public static bool IsOwnCollection(int activityID, int collectionID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			CollectionOwnStateHandle(activityID, collectionID);
			return packageInfo[activityID].FindAll((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && !x.isOwn).Count == 0;
		}
		return false;
	}

	public static bool IsOwnPackage(int activityID, int collectionID, int packageID)
	{
		if (packageInfo.ContainsKey(activityID))
		{
			CollectionOwnStateHandle(activityID, collectionID);
			return packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.packageID.Equals(packageID)).isOwn;
		}
		return false;
	}

	public static float ReturnTicketHandle(int itemID)
	{
		DropItem dropItem = LocalResources.DropItemTable.Get(itemID);
		ShopSuiteInfo shopSuiteInfo = LocalResources.ShopSuiteTable.Get(dropItem.TypeParam);
		float num = 0f;
		int[] shopItemIDs = shopSuiteInfo.ShopItemIDs;
		foreach (int id in shopItemIDs)
		{
			DropItem dropItem2 = LocalResources.DropItemTable.Get(id);
			if (DropItemUtility.IsOwnPermanent(dropItem2))
			{
				num += dropItem2.Price * 10f;
			}
		}
		return num;
	}

	public static CommonDataCollection GetCollectionArgByCharacterID(int activityID, int characterID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		CharacterDiscountPackageInfo package = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.characterID.Equals(characterID) && x.suitItemID > 0);
		if (!IsOwnItem(characterID))
		{
			SetArgs(commonDataCollection, activityID, package);
		}
		else
		{
			CharacterDiscountPackageInfo package2 = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(package.collectionID) && x.characterID == 0 && x.suitItemID > 0);
			SetArgs(commonDataCollection, activityID, package2);
		}
		return commonDataCollection;
	}

	public static CommonDataCollection GetLoverPreviewArgs(int activityID, int collectionID)
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		if (collectionID == 1)
		{
			CharacterDiscountPackageInfo package = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID));
			SetArgs(commonDataCollection, activityID, package);
			commonDataCollection["characterID"] = 200;
		}
		else
		{
			CharacterDiscountPackageInfo characterDiscountPackageInfo = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID > 0 && x.suitItemID > 0);
			if (IsOwnItem(characterDiscountPackageInfo.characterID))
			{
				CharacterDiscountPackageInfo package2 = packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.characterID == 0 && x.suitItemID > 0);
				SetArgs(commonDataCollection, activityID, package2);
			}
			else
			{
				SetArgs(commonDataCollection, activityID, characterDiscountPackageInfo);
			}
		}
		return commonDataCollection;
	}

	public static int GetCharacterPriceID(int activityID, int collectionID)
	{
		CollectionOwnStateHandle(activityID, collectionID);
		return packageInfo[activityID].Find((CharacterDiscountPackageInfo x) => x.collectionID.Equals(collectionID) && x.type == 2).priceID;
	}

	private static void SetArgs(CommonDataCollection goodsArg, int activityID, CharacterDiscountPackageInfo package)
	{
		goodsArg["activityID"] = activityID;
		goodsArg["packageID"] = package.packageID;
		goodsArg["goodsID"] = package.goodsID;
		goodsArg["collectionID"] = package.collectionID;
		goodsArg["characterID"] = package.characterID;
		goodsArg["suitItemId"] = package.suitItemID;
		goodsArg["orgPrice"] = package.orgPrice;
		goodsArg["discountPrice"] = package.currentPrice;
		goodsArg["priceID"] = package.priceID;
		goodsArg["discount"] = package.discount;
		goodsArg["buyCountLimit"] = package.buyCountLimit;
		goodsArg["limitTimes"] = package.limitTimes;
		goodsArg["mainName"] = package.mainName;
	}

	public static void SetLocalClaimInfo(int activityID)
	{
		LocalPlayerDatabase.SetPrefValue(Claimed + activityID, CacheInfo[activityID].endTime);
		LocalPlayerDatabase.SetPrefValue(TimeOutClaimed + activityID, 1);
		UIDataEvents.Inst.InvokeEvent("OnActivityLobbyRedPointChange");
	}

	public static bool GetRedPointState(int activityID)
	{
		int prefValueInt = LocalPlayerDatabase.GetPrefValueInt(Claimed + activityID);
		if (prefValueInt.Equals(0))
		{
			return true;
		}
		if (UtcTimeStamp.Now > prefValueInt)
		{
			LocalPlayerDatabase.SetPrefValue(TimeOutClaimed + activityID, 0);
			return true;
		}
		if (LocalPlayerDatabase.GetPrefValueInt(Claimed + activityID) - UtcTimeStamp.Now > 172800 && LocalPlayerDatabase.GetPrefValue(TimeOutClaimed + activityID).Equals(0))
		{
			LocalPlayerDatabase.SetPrefValue(Claimed + activityID, CacheInfo[activityID].endTime);
			return true;
		}
		return false;
	}
}
