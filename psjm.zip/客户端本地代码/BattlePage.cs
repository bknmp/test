using GameMessages;
using LightUI;
using LightUtility;
using System;
using System.Collections.Generic;
using UnityEngine.UI;

public class BattlePage
{
	public UIDataBinder m_Host;

	public Button m_ChallengeButton;

	public UIStateItem m_Top;

	public Text m_NoBattle;

	public Text m_Time;

	public Text m_Grade;

	public Text m_Map;

	public Text m_Rules;

	public Text m_Count;

	public UIDataBinder m_UnionBattleRecords;

	public UITemplateInitiator m_RewardsContent;

	public static int CanBattleTime;

	public static int CanBattleGrade;

	private int m_HasBattleCount;

	private bool m_DuringBattle;

	private RoomConfig m_RoomConfig;

	private UnionBattleInfo m_BattleInfo;

	private ActivityConditionWithDayTime m_BattleTime;

	public void Bind(CommonDataCollection args)
	{
		SetBattleInfo();
		SetButtonState();
		SetRecords();
		SetRewards();
	}

	private void SetBattleInfo()
	{
		m_BattleTime = LocalPlayerDatabase.Settings.unionBattleMode;
		CanBattleGrade = LocalResources.GradeMappingTable.Find((GradeMappingInfo x) => x.GradeId == m_BattleTime.gradeLimit).Id;
		m_DuringBattle = (UtcTimeStamp.Now >= m_BattleTime.startTime && UtcTimeStamp.Now <= m_BattleTime.endTime);
		if (!m_DuringBattle)
		{
			m_Top.State = 1;
			m_NoBattle.text = Localization.NoUnionBattle;
			m_BattleInfo = null;
			m_Time.text = Localization.ComingSoon;
		}
		else
		{
			m_Top.State = 0;
			m_BattleInfo = LocalResources.UnionBattleTable.Get(1);
			CanBattleTime = m_BattleInfo.LimitDays;
			m_HasBattleCount = UnionUtility.MyUnionInfo.battleCount;
			m_Grade.text = LocalResources.GradeTable.Get(m_BattleTime.gradeLimit).Name;
			m_Rules.text = m_BattleInfo.Rule;
			m_Map.text = m_BattleInfo.MapDesc;
			m_Count.text = $"<color=#ffaa24FF>{m_HasBattleCount}</color>/{m_BattleInfo.BattleCount}";
			DateTime date = UtcTimeStamp.GetDate(m_BattleTime.startTime);
			DateTime date2 = UtcTimeStamp.GetDate(m_BattleTime.endTime);
			m_Time.text = date.ToString("MM/dd") + "-" + date2.ToString("MM/dd") + " " + m_BattleInfo.WeekDesc + " " + m_BattleTime.startHours[0] + ":00-" + m_BattleTime.endHours[0] + ":00";
		}
		m_Count.transform.parent.gameObject.SetActive(m_BattleInfo != null);
	}

	private void SetButtonState()
	{
		UIStateRawImage component = m_ChallengeButton.GetComponent<UIStateRawImage>();
		UIStateItem component2 = m_ChallengeButton.GetComponent<UIStateItem>();
		if (m_BattleInfo == null)
		{
			component.State = 1;
			component2.State = 3;
		}
		else if (UnionUtility.MyUnionInfo.curUnionJob != UnionJob.Leader && UnionUtility.MyUnionInfo.curUnionJob != UnionJob.Admin)
		{
			component.State = 1;
			component2.State = 0;
		}
		else if (m_HasBattleCount >= m_BattleInfo.BattleCount)
		{
			component.State = 1;
			component2.State = 1;
		}
		else
		{
			component.State = 0;
			component2.State = 2;
			m_Host.EventProxy(m_ChallengeButton, "OnChallengeButtonClick");
		}
		m_ChallengeButton.interactable = (component.State == 0);
	}

	private void SetRecords()
	{
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		commonDataCollection["unionID"] = UnionUtility.UnionID;
		commonDataCollection["unionName"] = UnionUtility.MyUnionInfo.unionPublicinfo.name;
		commonDataCollection["isPopUp"] = false;
		m_UnionBattleRecords.Args = commonDataCollection;
	}

	private void SetRewards()
	{
		List<CommonRankReward> list = LocalResources.CommonRankRewardInfo.FindAll((CommonRankReward x) => x.Type == 5);
		CommonDataCollection commonDataCollection = new CommonDataCollection();
		for (int i = 0; i < list.Count; i++)
		{
			commonDataCollection[i]["start"] = list[i].ConditionMin;
			commonDataCollection[i]["end"] = list[i].ConditionMax;
			commonDataCollection[i]["itemID"].val = list[i].ItemIdList;
			commonDataCollection[i]["count"].val = list[i].ItemCountList;
		}
		m_RewardsContent.Args = commonDataCollection;
	}

	private bool JudgeBattleTime()
	{
		if (m_BattleInfo == null && m_BattleTime == null)
		{
			return false;
		}
		if (m_BattleTime.weekTime.Contains((int)UtcTimeStamp.NowDateTime.DayOfWeek) && m_BattleTime.InTime())
		{
			return true;
		}
		return false;
	}

	public void OnChallengeButtonClick()
	{
		if (!JudgeBattleTime())
		{
			UILobby.Current.ShowTips(Localization.NotUnionBattleTime);
			return;
		}
		if (UtcTimeStamp.Now - UnionUtility.MyUnionInfo.joinTimeStamp < UtcTimeStamp.DAYSECOND * CanBattleTime)
		{
			UILobby.Current.ShowTips(string.Format(Localization.TipsJoinUnionLate, CanBattleTime));
			return;
		}
		HttpRequestTeamRoomServer httpRequestTeamRoomServer = new HttpRequestTeamRoomServer();
		httpRequestTeamRoomServer.mapType = (int)m_BattleInfo.Map;
		httpRequestTeamRoomServer.teamID = 0;
		GameHttpManager.Inst.Send(httpRequestTeamRoomServer, delegate(HttpResponseTeamRoomServer response)
		{
			GameRuntime.SetRoomMapAndConfig(m_BattleInfo.Map);
			EnterRoom(response);
		});
	}

	private void EnterRoom(HttpResponseTeamRoomServer createRoom)
	{
		TeamRoomManager.Inst.CustomConnectToTeamServer(createRoom, delegate
		{
			TeamRoomManager.Inst.ActiveOpenRoomUI();
		});
	}
}
