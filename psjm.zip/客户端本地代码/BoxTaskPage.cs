using GameMessages;
using LightUI;
using UnityEngine;
using UnityEngine.UI;

internal class BoxTaskPage
{
	public UIDataBinder m_Host;

	public UITemplateInitiator m_BoxSlotInitiator;

	public GameObject m_Tips;

	public GameObject m_WeekendDoubleTips;

	public Text m_WeekendDoubleText;

	private string m_WeekendDoubleTextFormat;

	public void Bind(CommonDataCollection args)
	{
		if (LocalPlayerDatabase.BoxListInfo == null)
		{
			BoxUtility.RefreshBoxList();
			return;
		}
		args.Clear();
		bool x = AdUtility.IsAdEnable(AdScene.FREE_BOX) && BoxUtility.CurrentBoxSlotCount() <= 1;
		for (int i = 0; i < 4; i++)
		{
			BoxItemInfo boxInfoByPosition = BoxUtility.GetBoxInfoByPosition(i);
			if (boxInfoByPosition != null)
			{
				args[i]["boxPos"] = boxInfoByPosition.boxPosition;
				args[i]["ad"] = false;
			}
			else
			{
				args[i]["boxPos"] = -1;
				args[i]["ad"] = x;
				x = false;
			}
		}
		m_BoxSlotInitiator.Args = args;
		m_Tips.SetActive(BoxUtility.IsAllBoxSlotEmpty());
		if (!(m_WeekendDoubleTips != null))
		{
			return;
		}
		ActivityLobbyInfo activityInfo = new ActivityLobbyInfo();
		Activity activityByActivityTypeAndCollectionType = ActivityLobby.GetActivityByActivityTypeAndCollectionType(ActivityType.WEEKEND_DOUBLE, ActivityCollectionType.ANNIVERSART_ACTIVITY, out activityInfo);
		m_WeekendDoubleTips.SetActive(activityByActivityTypeAndCollectionType != null);
		if (activityByActivityTypeAndCollectionType != null)
		{
			m_Host.EventProxy(m_WeekendDoubleTips.GetComponentInChildren<Button>(includeInactive: true), "OnGotoActivityPage");
			if (string.IsNullOrEmpty(m_WeekendDoubleTextFormat))
			{
				m_WeekendDoubleTextFormat = m_WeekendDoubleText.text;
			}
			m_WeekendDoubleText.text = string.Format(m_WeekendDoubleTextFormat, activityInfo.TabName);
		}
	}

	public void OnGotoActivityPage()
	{
		JumpModuleManager.Inst.DoJump(JumpModule.AnniversaryActivity).GetComponent<AnniversaryActivityUI>().JumpTabByActivityType(ActivityType.WEEKEND_DOUBLE);
	}
}
